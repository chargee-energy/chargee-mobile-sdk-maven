package energy.chargee.sdk

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the iOS [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production].
 *
 * SKIE default-argument interop is enabled so Swift callers can omit [environment] — from Swift,
 * pass `ChargeeEnvironment.development` or `.production` to select one explicitly.
 */
@DefaultArgumentInterop.Enabled
fun createChargeeSdk(environment: Environment = Environment.production, tokenProvider: TokenProvider): ChargeeSdk =
    ChargeeSdkIos(environment, tokenProvider)
