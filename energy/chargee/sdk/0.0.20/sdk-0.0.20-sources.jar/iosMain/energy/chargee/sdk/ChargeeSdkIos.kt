package energy.chargee.sdk

import energy.chargee.core.di.module
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider
import energy.chargee.discovery.mdns.mdnsDiscoveryModuleIos
import energy.chargee.onboarding.chargeedevice.chargeeDeviceOnboardingModuleIos
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.LocalAddressProviderIos
import energy.chargee.utils.wifi.WifiConnection
import energy.chargee.utils.wifi.WifiConnectionIos

/**
 * The iOS [ChargeeSdk], adding the Darwin implementations of Wi-Fi access, local address lookup,
 * mDNS discovery, and ESP provisioning on top of the shared modules. Created via [createChargeeSdk].
 */
internal class ChargeeSdkIos(environment: Environment, tokenProvider: TokenProvider) : ChargeeSdk(environment, tokenProvider) {
    init {
        dependencyRegistry.registerModule(
            module {
                factory<WifiConnection> { WifiConnectionIos() }
                lazySingleton<LocalAddressProvider> { LocalAddressProviderIos() }
            },
        )
        dependencyRegistry.registerModule(mdnsDiscoveryModuleIos)
        dependencyRegistry.registerModule(chargeeDeviceOnboardingModuleIos)
    }
}
