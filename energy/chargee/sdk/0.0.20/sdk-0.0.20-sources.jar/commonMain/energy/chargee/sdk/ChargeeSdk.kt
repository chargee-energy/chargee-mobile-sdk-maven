package energy.chargee.sdk

import energy.chargee.core.di.DependencyNotFoundException
import energy.chargee.core.di.DependencyRegistry
import energy.chargee.core.di.Parameters
import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.core.network.Environment
import energy.chargee.core.network.networkModule
import energy.chargee.core.network.providers.TokenProvider
import energy.chargee.data.chargeedevice.chargeeDeviceDataModule
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.correctionfactor.correctionFactorDataModule
import energy.chargee.data.correctionfactor.repositories.CorrectionFactorRepository
import energy.chargee.data.device.deviceDataModule
import energy.chargee.data.device.repositories.DeviceRepository
import energy.chargee.data.electricity.live.liveElectricityDataModule
import energy.chargee.data.electricity.live.repositories.LiveElectricityRepository
import energy.chargee.data.energy.energyDataModule
import energy.chargee.data.energy.repositories.EnergyRepository
import energy.chargee.data.featureflags.featureFlagsDataModule
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository
import energy.chargee.data.flint.flintDataModule
import energy.chargee.data.flint.repositories.FlintRepository
import energy.chargee.data.localdevice.localDeviceDataModule
import energy.chargee.data.price.priceDataModule
import energy.chargee.data.price.repositories.PriceRepository
import energy.chargee.data.smartmeter.repositories.SmartMeterRepository
import energy.chargee.data.smartmeter.smartMeterDataModule
import energy.chargee.data.sparky.repositories.SparkyRepository
import energy.chargee.data.sparky.sparkyDataModule
import energy.chargee.discovery.portscan.portScanDiscoveryModule
import energy.chargee.discovery.udpbroadcast.udpBroadcastDiscoveryModule
import energy.chargee.onboarding.alfen.AlfenOnboardingSession
import energy.chargee.onboarding.alfen.alfenOnboardingModule
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingSession
import energy.chargee.onboarding.chargeedevice.chargeeDeviceErrorCodeSerializersModule
import energy.chargee.onboarding.chargeedevice.chargeeDeviceOnboardingModule
import energy.chargee.onboarding.core.engineErrorCodeSerializersModule
import energy.chargee.onboarding.goodwe.GoodweOnboardingSession
import energy.chargee.onboarding.goodwe.goodweErrorCodeSerializersModule
import energy.chargee.onboarding.goodwe.goodweOnboardingModule
import energy.chargee.onboarding.huawei.HuaweiOnboardingSession
import energy.chargee.onboarding.huawei.huaweiOnboardingModule
import energy.chargee.onboarding.localdevice.localDeviceErrorCodeSerializersModule
import energy.chargee.onboarding.peblar.PeblarOnboardingSession
import energy.chargee.onboarding.peblar.peblarOnboardingModule
import energy.chargee.onboarding.solaredge.SolarEdgeOnboardingSession
import energy.chargee.onboarding.solaredge.solarEdgeOnboardingModule
import io.ktor.client.HttpClient
import io.ktor.client.plugins.auth.clearAuthTokens
import kotlinx.serialization.json.Json
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.plus
import kotlin.native.HiddenFromObjC
import kotlin.native.ObjCName

/**
 * Entry point to the Chargee SDK, exposing the remote [data] repositories and the [onboarding]
 * sessions on top of a dependency graph it owns.
 *
 * A single instance holds all SDK state — the HTTP client with its cached Bearer token, the
 * registered modules, and the repositories resolved from them — so create one per application and
 * keep it alive for as long as the SDK is used. Instances are not created through this constructor
 * but through the platform factory: `ChargeeSdk(context, tokenProvider, environment)` on Android and
 * `createChargeeSdk(environment:tokenProvider:)` on iOS, each of which adds the platform-specific
 * Wi-Fi, discovery, and provisioning implementations on top of the shared modules registered here.
 *
 * [environment] selects the backend every request targets and [tokenProvider] supplies the Bearer
 * token they are authenticated with; both are registered as singletons and resolved by the modules
 * that need them.
 */
abstract class ChargeeSdk protected constructor(environment: Environment, tokenProvider: TokenProvider) {
    /**
     * The registry backing every dependency the SDK resolves.
     *
     * Platform subclasses register their own modules into it during construction. It is internal
     * rather than public so the registry itself never becomes part of the SDK's surface: consumers
     * replace registrations through [overrideDependencies] and read them back through
     * [getDependency].
     */
    @PublishedApi
    internal val dependencyRegistry = DependencyRegistry()

    init {
        dependencyRegistry.registerModule(
            module {
                singleton(environment)
                singleton(tokenProvider)
            },
        )
        dependencyRegistry.registerModule(networkModule)
        dependencyRegistry.registerModule(chargeeDeviceDataModule)
        dependencyRegistry.registerModule(localDeviceDataModule)
        dependencyRegistry.registerModule(correctionFactorDataModule)
        dependencyRegistry.registerModule(energyDataModule)
        dependencyRegistry.registerModule(featureFlagsDataModule)
        dependencyRegistry.registerModule(flintDataModule)
        dependencyRegistry.registerModule(liveElectricityDataModule)
        dependencyRegistry.registerModule(priceDataModule)
        dependencyRegistry.registerModule(smartMeterDataModule)
        dependencyRegistry.registerModule(sparkyDataModule)
        dependencyRegistry.registerModule(deviceDataModule)
        dependencyRegistry.registerModule(portScanDiscoveryModule)
        dependencyRegistry.registerModule(udpBroadcastDiscoveryModule)
        dependencyRegistry.registerModule(chargeeDeviceOnboardingModule)
        dependencyRegistry.registerModule(solarEdgeOnboardingModule)
        dependencyRegistry.registerModule(goodweOnboardingModule)
        dependencyRegistry.registerModule(huaweiOnboardingModule)
        dependencyRegistry.registerModule(peblarOnboardingModule)
        dependencyRegistry.registerModule(alfenOnboardingModule)
    }

    /**
     * The remote data repositories, created on first access.
     */
    val data by lazy { Data() }

    /**
     * The onboarding session factories, one per supported brand, created on first access.
     */
    val onboarding by lazy { Onboarding() }

    /**
     * Clears the Bearer token cached by the HTTP client, so the next authenticated request asks
     * [TokenProvider.getToken] for a token again.
     *
     * The [TokenProvider] itself stays registered — call this when a user signs out, so no request
     * made afterwards reuses the token of the previous session.
     */
    fun logout() {
        dependencyRegistry.get<HttpClient>().clearAuthTokens()
    }

    /**
     * The remote data repositories, each resolved from the registry on access.
     */
    inner class Data internal constructor() {
        // These raw Kotlin repositories are exposed under `_`-prefixed names so the clean Swift names
        // are free for the generated Swift facades: an `extension ChargeeSdk.Data` (bundled in the
        // iOS framework) surfaces `energy`, `featureFlags`, … as their facade types, built from these.

        /**
         * The [CorrectionFactorRepository] with the correction factors of an address.
         */
        @ObjCName("_correctionFactor")
        val correctionFactor get() = dependencyRegistry.get<CorrectionFactorRepository>()

        /**
         * The [EnergyRepository] with aggregated energy data.
         */
        @ObjCName("_energy")
        val energy get() = dependencyRegistry.get<EnergyRepository>()

        /**
         * The [FeatureFlagsRepository] with the remotely configured feature flags.
         */
        @ObjCName("_featureFlags")
        val featureFlags get() = dependencyRegistry.get<FeatureFlagsRepository>()

        /**
         * The [FlintRepository] with the Flint device registrations of an address.
         */
        @ObjCName("_flint")
        val flint get() = dependencyRegistry.get<FlintRepository>()

        /**
         * The [LiveElectricityRepository] with the live electricity readings of an address.
         */
        @ObjCName("_liveElectricity")
        val liveElectricity get() = dependencyRegistry.get<LiveElectricityRepository>()

        /**
         * The [PriceRepository] with dynamic electricity and gas prices.
         */
        @ObjCName("_price")
        val price get() = dependencyRegistry.get<PriceRepository>()

        /**
         * The [SmartMeterRepository] with the smart meters registered to an address.
         */
        @ObjCName("_smartMeter")
        val smartMeter get() = dependencyRegistry.get<SmartMeterRepository>()

        /**
         * The [SparkyRepository] with the Sparky device registrations of an address.
         */
        @ObjCName("_sparky")
        val sparky get() = dependencyRegistry.get<SparkyRepository>()

        /**
         * The [DeviceRepository] with the devices registered to an address.
         */
        @ObjCName("_device")
        val device get() = dependencyRegistry.get<DeviceRepository>()
    }

    /**
     * The onboarding entry points: one nested factory per brand, each creating a fresh session for
     * a single onboarding attempt, plus the [json] the resulting state is serialized with.
     */
    inner class Onboarding internal constructor() {
        /**
         * The combined [SerializersModule] covering every [OnboardingErrorCode] subtype across the engine
         * and the brand onboarding modules.
         *
         * [OnboardingErrorCode] is an open (non-`sealed`) interface, so each module registers its own
         * subtypes for polymorphic serialization; this sums those contributions into the single module the
         * SDK serializes onboarding state with. A new brand module's error codes become serializable by
         * adding its `SerializersModule` to this sum.
         */
        private val serializersModule: SerializersModule by lazy {
            engineErrorCodeSerializersModule +
                chargeeDeviceErrorCodeSerializersModule +
                localDeviceErrorCodeSerializersModule +
                goodweErrorCodeSerializersModule
        }

        /**
         * The [Json] configured with [serializersModule], for serializing onboarding state whose
         * error codes are the open [OnboardingErrorCode] type. Unknown keys are ignored so that state
         * persisted by a newer SDK still decodes on an older one.
         */
        val json: Json by lazy {
            Json {
                serializersModule = this@Onboarding.serializersModule
                ignoreUnknownKeys = true
                encodeDefaults = true
            }
        }

        /**
         * Onboarding for Chargee devices (Sparky and Flint).
         */
        val chargeeDevice by lazy { ChargeeDevice() }

        /**
         * Onboarding for SolarEdge inverters.
         */
        val solarEdge by lazy { SolarEdge() }

        /**
         * Onboarding for Goodwe inverters.
         */
        val goodwe by lazy { Goodwe() }

        /**
         * Onboarding for Huawei inverters.
         */
        val huawei by lazy { Huawei() }

        /**
         * Onboarding for Peblar chargers.
         */
        val peblar by lazy { Peblar() }

        /**
         * Onboarding for Alfen chargers.
         */
        val alfen by lazy { Alfen() }

        /**
         * Creates [ChargeeDeviceOnboardingSession]s.
         */
        inner class ChargeeDevice internal constructor() {
            /**
             * Creates a session that onboards a Chargee device of [deviceType] onto the address
             * identified by [addressUuid], provisioning it over Bluetooth and Wi-Fi.
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, deviceType: ChargeeDeviceType) =
                dependencyRegistry.get<ChargeeDeviceOnboardingSession>(
                    parameters = parametersOf(addressUuid, deviceType),
                )
        }

        /**
         * Creates [SolarEdgeOnboardingSession]s.
         */
        inner class SolarEdge internal constructor() {
            /**
             * Creates a session that onboards a SolarEdge inverter onto the address identified by
             * [addressUuid], behind the already-onboarded Chargee device [chargeeDeviceUuid] of
             * [chargeeDeviceType].
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, chargeeDeviceUuid: String, chargeeDeviceType: ChargeeDeviceType) =
                dependencyRegistry.get<SolarEdgeOnboardingSession>(
                    parameters = parametersOf(addressUuid, chargeeDeviceUuid, chargeeDeviceType),
                )
        }

        /**
         * Creates [GoodweOnboardingSession]s.
         */
        inner class Goodwe internal constructor() {
            /**
             * Creates a session that onboards a Goodwe inverter onto the address identified by
             * [addressUuid], behind the already-onboarded Chargee device [chargeeDeviceUuid] of
             * [chargeeDeviceType].
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, chargeeDeviceUuid: String, chargeeDeviceType: ChargeeDeviceType) =
                dependencyRegistry.get<GoodweOnboardingSession>(
                    parameters = parametersOf(addressUuid, chargeeDeviceUuid, chargeeDeviceType),
                )
        }

        /**
         * Creates [HuaweiOnboardingSession]s.
         */
        inner class Huawei internal constructor() {
            /**
             * Creates a session that onboards a Huawei inverter onto the address identified by
             * [addressUuid], behind the already-onboarded Chargee device [chargeeDeviceUuid] of
             * [chargeeDeviceType].
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, chargeeDeviceUuid: String, chargeeDeviceType: ChargeeDeviceType) =
                dependencyRegistry.get<HuaweiOnboardingSession>(
                    parameters = parametersOf(addressUuid, chargeeDeviceUuid, chargeeDeviceType),
                )
        }

        /**
         * Creates [PeblarOnboardingSession]s.
         */
        inner class Peblar internal constructor() {
            /**
             * Creates a session that onboards a Peblar charger onto the address identified by
             * [addressUuid], behind the already-onboarded Chargee device [chargeeDeviceUuid] of
             * [chargeeDeviceType].
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, chargeeDeviceUuid: String, chargeeDeviceType: ChargeeDeviceType) =
                dependencyRegistry.get<PeblarOnboardingSession>(
                    parameters = parametersOf(addressUuid, chargeeDeviceUuid, chargeeDeviceType),
                )
        }

        /**
         * Creates [AlfenOnboardingSession]s.
         */
        inner class Alfen internal constructor() {
            /**
             * Creates a session that onboards an Alfen charger onto the address identified by
             * [addressUuid], behind the already-onboarded Chargee device [chargeeDeviceUuid] of
             * [chargeeDeviceType].
             *
             * A session covers a single onboarding attempt: create a new one for every attempt.
             */
            fun createSession(addressUuid: String, chargeeDeviceUuid: String, chargeeDeviceType: ChargeeDeviceType) =
                dependencyRegistry.get<AlfenOnboardingSession>(
                    parameters = parametersOf(addressUuid, chargeeDeviceUuid, chargeeDeviceType),
                )
        }
    }

    /**
     * Runs [dependencies] against the SDK's [DependencyRegistry] and returns it, so registrations
     * made by the SDK can be replaced with test doubles or custom implementations.
     *
     * Registering a dependency under a type and name that is already taken replaces it, but only
     * for resolutions that happen afterwards: cached instances — the singletons, plus any session
     * or repository already built from them — keep the dependency they were created with. Apply
     * overrides right after creating the SDK.
     */
    fun overrideDependencies(dependencies: DependencyRegistry.() -> Unit) = dependencyRegistry.dependencies()

    /**
     * Resolves the dependency of type [T] registered under [name] from the SDK's registry, so a
     * registration that has no dedicated accessor on [data] or [onboarding] can still be reached
     * without the registry being exposed.
     *
     * Lookup semantics are those of [DependencyRegistry.get]: whether a fresh instance is created
     * or a cached one returned follows how the dependency was declared, [name] disambiguates
     * between multiple providers of the same type, and [parameters] are forwarded to parameterized
     * factories and ignored by the rest. The SDK's own registrations are an implementation detail
     * and may change between releases.
     *
     * [T] is reified, so this is a Kotlin-only entry point and is hidden from the Objective-C
     * framework: the bridge would erase [T] to `Any` and every call from Swift would fail to
     * resolve. Swift consumers reach the SDK's dependencies through [data] and [onboarding].
     *
     * @throws DependencyNotFoundException if no provider is registered for [T] under [name].
     */
    @HiddenFromObjC
    @Throws(DependencyNotFoundException::class)
    inline fun <reified T : Any> getDependency(name: String? = null, parameters: Parameters = Parameters.EMPTY): T =
        dependencyRegistry.get<T>(name, parameters)
}
