package energy.chargee.onboarding.core.state

/**
 * How the [OnboardingStep] an [OnboardingState] currently holds is progressing or paused.
 */
enum class OnboardingStepStatus {
    /**
     * The step is executing — including while the engine cycles through its retry policy, so the
     * same step may be observed [Running] several times across retry attempts.
     */
    Running,

    /**
     * The step has paused awaiting user input; it resumes once that input is submitted.
     */
    WaitingForInput,

    /**
     * The step failed with the engine's automatic retries exhausted; it can be retried manually or
     * reverted to a previous step.
     */
    Failure,
}
