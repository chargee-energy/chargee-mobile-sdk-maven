package energy.chargee.onboarding.core.state

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * A presentation-friendly snapshot of an onboarding flow's progress, folded from the engine's
 * event stream by [OnboardingSessionBase][energy.chargee.onboarding.core.session.OnboardingSessionBase].
 *
 * [currentStep] is the brand [OnboardingStep] the flow is presently on — running, waiting for
 * input, or failed — or `null` between steps and once the flow has [finished]. [completedSteps]
 * lists the ids of the steps completed so far, in completion order.
 */
@ObjCName("_OnboardingState")
@Serializable
data class OnboardingState<Id : Any, Step : OnboardingStep<Id>>(
    val currentStep: Step? = null,
    val completedSteps: List<Id> = emptyList(),
    val finished: Boolean = false,
)
