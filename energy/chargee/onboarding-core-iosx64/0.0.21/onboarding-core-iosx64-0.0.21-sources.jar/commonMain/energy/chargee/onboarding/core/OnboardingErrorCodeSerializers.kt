package energy.chargee.onboarding.core

import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * The [SerializersModule] registering the engine's own [OnboardingErrorCode] subtypes for
 * polymorphic serialization.
 *
 * [OnboardingErrorCode] is intentionally not `sealed` — feature modules implement it across
 * module and package boundaries — so kotlinx.serialization cannot derive a serializer for the
 * whole hierarchy on its own. Every module that declares error codes contributes its subtypes
 * through a module like this one, and the aggregating SDK sums them into the
 * [kotlinx.serialization.json.Json] it serializes onboarding state with.
 */
val engineErrorCodeSerializersModule: SerializersModule =
    SerializersModule {
        polymorphic(OnboardingErrorCode::class) {
            subclass(OnboardingErrorCode.Timeout::class)
            subclass(OnboardingErrorCode.Cancelled::class)
            subclass(OnboardingErrorCode.Unhandled::class)
        }
    }
