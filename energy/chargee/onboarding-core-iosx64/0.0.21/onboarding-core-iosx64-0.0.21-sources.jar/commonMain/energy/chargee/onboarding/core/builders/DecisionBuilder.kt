package energy.chargee.onboarding.core.builders

import energy.chargee.onboarding.core.OnboardingFlow

/**
 * Builder for configuring the branches of a decision node in an [OnboardingFlow].
 *
 * Use [whenTrue] and [whenFalse] to define which steps execute depending on [condition].
 */
@OnboardingFlowTagMarker
class DecisionBuilder<Id, Context> internal constructor(private val condition: suspend (Context) -> Boolean) {
    private val ifTrue = mutableListOf<OnboardingFlow.Node<Id, Context>>()
    private val ifFalse = mutableListOf<OnboardingFlow.Node<Id, Context>>()

    /**
     * Configures the branch to execute when [condition] evaluates to `true`.
     */
    fun whenTrue(block: OnboardingFlowBuilder<Id, Context>.() -> Unit) {
        val builder = OnboardingFlowBuilder<Id, Context>("trueBranch")
        builder.block()
        ifTrue += builder.build().nodes
    }

    /**
     * Configures the branch to execute when [condition] evaluates to `false`.
     */
    fun whenFalse(block: OnboardingFlowBuilder<Id, Context>.() -> Unit) {
        val builder = OnboardingFlowBuilder<Id, Context>("falseBranch")
        builder.block()
        ifFalse += builder.build().nodes
    }

    internal fun build() = OnboardingFlow.Node.Decision(condition, ifTrue, ifFalse)
}
