package energy.chargee.onboarding.core.session

import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.native.ObjCName

/**
 * Base for the per-brand onboarding sessions — a thin, UI-facing wrapper around an
 * [OnboardingEngine] that owns the flow's observable [state] and accepts user input.
 *
 * The engine itself only emits events; [runFlow] drives it and folds its event stream into [state]
 * through [reduce]. [state] holds the brand's [OnboardingState] — its [currentStep] is a [Step],
 * the sealed presentation step each subclass builds in [reduce] from the raw events, carrying only
 * the data and callbacks its UI needs rather than the flow's internal [Context]. [submit] validates
 * an [Input] against the current step and translates it into an engine signal, returning
 * [SubmitResult.Accepted] or [SubmitResult.Rejected].
 *
 * Each subclass fixes the four type parameters to its own flow — the step [Id] type, the flow
 * [Context], its brand [Step], and its brand [Input] — then overrides [reduce] to map events onto
 * its steps and [submit] to route its inputs, reusing the shared `require*` guards to gate each
 * input on the current step.
 */
abstract class OnboardingSessionBase<Id : Any, Context : Any, Step : OnboardingStep<Id>, Input>(
    protected val engine: OnboardingEngine<Id, Context>,
) {
    private val _state = MutableStateFlow(OnboardingState<Id, Step>())

    /**
     * The current [OnboardingState][energy.chargee.onboarding.core.state.OnboardingState], folded
     * from the engine's event stream by [runFlow], for observing flow progress.
     */
    @ObjCName("_state")
    val state: StateFlow<OnboardingState<Id, Step>> = _state.asStateFlow()

    /**
     * Drives the underlying engine to completion while folding its event stream into [state].
     *
     * Launches a collector that reduces every [OnboardingFlow.Event] the engine emits into [state]
     * via [reduce], then calls [OnboardingEngine.start] (seeding the context with [initialContext]).
     * Suspends until the flow finishes — the engine closes its event channel on completion, which
     * ends the collector, or on cancellation, which tears both down together. Concrete sessions
     * expose a public `start` that calls this; see [OnboardingEngine.start] for the single-use
     * contract.
     *
     * @throws IllegalStateException if the engine has already been started.
     */
    protected suspend fun runFlow(initialContext: (Context) -> Context = { it }): Unit =
        coroutineScope {
            launch {
                for (event in engine.events) {
                    _state.value = reduce(_state.value, event)
                }
            }
            engine.start(initialContext)
        }

    /**
     * Folds a single engine [event] into the next [OnboardingState], called by [runFlow] for every
     * event the engine emits.
     *
     * The base implementation handles the flow-level transitions common to every session:
     * [FlowStarted][OnboardingFlow.Event.FlowStarted] clears [OnboardingState.finished],
     * [FlowFinished][OnboardingFlow.Event.FlowFinished] sets it, and
     * [StepCompleted][OnboardingFlow.Event.StepCompleted] clears [OnboardingState.currentStep] and
     * appends the completed step id; every other event leaves the state untouched. Subclasses
     * override this to map the step-level events —
     * [StepStarted][OnboardingFlow.Event.StepStarted],
     * [StepInputRequired][OnboardingFlow.Event.StepInputRequired], and
     * [StepFailure][OnboardingFlow.Event.StepFailure] — onto their brand [Step]s, delegating the
     * events they don't handle back here via `super.reduce`.
     */
    protected open fun reduce(current: OnboardingState<Id, Step>, event: OnboardingFlow.Event<Id, Context>): OnboardingState<Id, Step> =
        when (event) {
            is OnboardingFlow.Event.FlowStarted -> {
                current.copy(finished = false)
            }

            is OnboardingFlow.Event.FlowFinished -> {
                current.copy(finished = true)
            }

            is OnboardingFlow.Event.StepCompleted -> {
                current.copy(currentStep = null, completedSteps = current.completedSteps + event.stepId)
            }

            else -> {
                current
            }
        }

    /**
     * Validates [input] against the current step and applies it to the engine, returning
     * [SubmitResult.Accepted] when the input is valid for the current state or
     * [SubmitResult.Rejected] with a reason otherwise.
     *
     * Each subclass implements this over its own sealed [Input] type, gating every case on the
     * current step with the shared [requireWaitingForInput], [requireFailure], and [requirePaused]
     * guards before translating it into an [OnboardingEngine] signal.
     */
    @ObjCName("_submit")
    abstract fun submit(input: Input): SubmitResult

    /**
     * Runs [block] and returns [SubmitResult.Accepted] when the current step is [id] and waiting
     * for input; otherwise returns [SubmitResult.Rejected] without running it.
     */
    protected fun requireWaitingForInput(id: Id, block: () -> Unit): SubmitResult =
        requireStep(id, listOf(OnboardingStepStatus.WaitingForInput)) {
            block()
            SubmitResult.Accepted
        }

    /**
     * Runs [block] and returns [SubmitResult.Accepted] when the current step (optionally required
     * to be [id]) is in a failure state; otherwise returns [SubmitResult.Rejected].
     */
    protected fun requireFailure(id: Id? = null, block: () -> Unit): SubmitResult =
        requireStep(id, listOf(OnboardingStepStatus.Failure)) {
            block()
            SubmitResult.Accepted
        }

    /**
     * Runs [onWaitingForInput] or [onFailure] depending on how the current step (optionally required
     * to be [id]) is paused, returning [SubmitResult.Accepted]; [SubmitResult.Rejected] if the step
     * is not paused.
     */
    protected fun requirePaused(id: Id? = null, onWaitingForInput: () -> Unit, onFailure: () -> Unit): SubmitResult =
        requirePaused(id) { step ->
            when (step.status) {
                OnboardingStepStatus.WaitingForInput -> onWaitingForInput()
                OnboardingStepStatus.Failure -> onFailure()
                else -> error("Unexpected step status: ${step.status}")
            }
        }

    /**
     * Runs [block] with the current paused step — waiting-for-input or failure, optionally required
     * to be [id] — and returns [SubmitResult.Accepted]; [SubmitResult.Rejected] if it is not paused.
     */
    protected fun requirePaused(id: Id? = null, block: (step: OnboardingStep<Id>) -> Unit): SubmitResult =
        requireStep(id, listOf(OnboardingStepStatus.WaitingForInput, OnboardingStepStatus.Failure)) { step ->
            block(step)
            SubmitResult.Accepted
        }

    private fun requireStep(
        id: Id?,
        allowedStatuses: List<OnboardingStepStatus>,
        block: (step: OnboardingStep<Id>) -> SubmitResult,
    ): SubmitResult =
        state.value.currentStep?.let { step ->
            when {
                id != null && step.id != id -> SubmitResult.Rejected("Wrong step id: ${step.id}, expected: $id")
                step.status !in allowedStatuses -> SubmitResult.Rejected("Wrong step status: ${step.status}, expected: $allowedStatuses")
                else -> block(step)
            }
        } ?: SubmitResult.Rejected("Not currently running any step, expected: $id")
}
