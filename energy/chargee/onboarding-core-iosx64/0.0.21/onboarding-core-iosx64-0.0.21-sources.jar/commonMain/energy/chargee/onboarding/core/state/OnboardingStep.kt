package energy.chargee.onboarding.core.state

/**
 * The presentation-facing view of the step an onboarding flow currently holds in focus.
 *
 * Each onboarding module defines its own sealed [OnboardingStep] implementation with one variant
 * per distinct thing its UI must render — running, awaiting a particular input, failed — so a
 * session's [OnboardingState] surfaces exactly the steps that flow can reach, each carrying the
 * data and callbacks that step needs and nothing of the flow's internal context. [id] identifies
 * the step within the flow and [status] classifies how it is progressing or paused.
 */
interface OnboardingStep<Id : Any> {
    /**
     * Identifies which step of the flow this state refers to.
     */
    val id: Id

    /**
     * Whether the step is running, waiting for input, or stuck on a failure.
     */
    val status: OnboardingStepStatus
}
