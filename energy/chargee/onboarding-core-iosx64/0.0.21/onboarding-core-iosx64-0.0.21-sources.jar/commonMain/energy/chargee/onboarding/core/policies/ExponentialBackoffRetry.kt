package energy.chargee.onboarding.core.policies

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlin.math.pow
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * A [RetryPolicy] that implements exponential backoff.
 *
 * The delay for each attempt is `initialDelay * (factor ^ attempt)`, capped at [maxDelay].
 * Retries stop after [maxAttempts] attempts.
 *
 * @throws IllegalArgumentException if [maxAttempts] is negative, [initialDelay] is negative,
 *   [maxDelay] is less than [initialDelay], or [factor] is less than `1.0`.
 */
class ExponentialBackoffRetry(
    private val maxAttempts: Int,
    private val initialDelay: Duration = 1.seconds,
    private val maxDelay: Duration = 30.seconds,
    private val factor: Double = 2.0,
    private val condition: (errorCode: OnboardingErrorCode) -> Boolean = { true },
) : RetryPolicy {
    init {
        require(maxAttempts >= 0) { "maxAttempts must be non-negative, was $maxAttempts" }
        require(initialDelay >= Duration.ZERO) { "initialDelay must be non-negative, was $initialDelay" }
        require(maxDelay >= initialDelay) { "maxDelay ($maxDelay) must be at least initialDelay ($initialDelay)" }
        require(factor >= 1.0) { "factor must be at least 1.0, was $factor" }
    }

    override fun nextDelay(attempt: Int): Duration? {
        if (attempt >= maxAttempts) return null
        val delay = initialDelay * factor.pow(attempt)
        return delay.coerceAtMost(maxDelay)
    }

    override fun shouldRetry(errorCode: OnboardingErrorCode) = condition(errorCode)
}
