package energy.chargee.onboarding.core.policies

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlin.time.Duration

/**
 * Defines a policy for determining retry delays.
 *
 * Implementations specify how long to wait before the next attempt based on the current
 * attempt number. Return `null` from [nextDelay] to signal that no further retries should occur.
 *
 * @see ExponentialBackoffRetry
 */
interface RetryPolicy {
    /**
     * Returns the delay before the next retry, or `null` if no more retries should be made.
     *
     * [attempt] is 0-based: 0 for the first retry, 1 for the second, and so on.
     */
    fun nextDelay(attempt: Int): Duration?

    /**
     * Returns `true` if a step failure with [errorCode] should be retried, or `false` to skip
     * the retry loop and propagate the failure immediately.
     */
    fun shouldRetry(errorCode: OnboardingErrorCode): Boolean
}
