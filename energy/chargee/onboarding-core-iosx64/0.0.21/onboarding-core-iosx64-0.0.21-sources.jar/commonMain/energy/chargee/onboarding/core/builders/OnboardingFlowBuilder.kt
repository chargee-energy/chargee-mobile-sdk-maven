package energy.chargee.onboarding.core.builders

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.policies.RetryPolicy
import kotlin.time.Duration

/**
 * Builder for constructing an [OnboardingFlow] using a DSL.
 *
 * Use [step], [decision], and [extend] to add nodes, then obtain the finished flow via
 * [createOnboardingFlow][energy.chargee.onboarding.core.createOnboardingFlow].
 */
@OnboardingFlowTagMarker
class OnboardingFlowBuilder<Id, Context> internal constructor(private val name: String) {
    private val nodes = mutableListOf<OnboardingFlow.Node<Id, Context>>()

    /**
     * Adds [step] to the flow with an optional [retryPolicy] and [timeout].
     */
    fun step(step: OnboardingFlow.Step<Id, Context>, retryPolicy: RetryPolicy? = null, timeout: Duration? = null) {
        nodes += OnboardingFlow.Node.Step(step, retryPolicy, timeout)
    }

    /**
     * Adds a decision node that evaluates [condition] and branches using a [DecisionBuilder] block.
     */
    fun decision(condition: suspend (Context) -> Boolean, block: DecisionBuilder<Id, Context>.() -> Unit) {
        val builder = DecisionBuilder<Id, Context>(condition)
        builder.block()
        nodes += builder.build()
    }

    /**
     * Adds a decision node that runs the nodes declared in [block] only when [condition] evaluates
     * to `true`, falling through to the rest of the flow otherwise.
     *
     * This is shorthand for a [decision] with only a [whenTrue][DecisionBuilder.whenTrue] branch.
     */
    fun whenTrue(condition: suspend (Context) -> Boolean, block: OnboardingFlowBuilder<Id, Context>.() -> Unit) {
        decision(condition) {
            whenTrue {
                block()
            }
        }
    }

    /**
     * Adds a decision node that runs the nodes declared in [block] only when [condition] evaluates
     * to `false`, falling through to the rest of the flow otherwise.
     *
     * This is shorthand for a [decision] with only a [whenFalse][DecisionBuilder.whenFalse] branch.
     */
    fun whenFalse(condition: suspend (Context) -> Boolean, block: OnboardingFlowBuilder<Id, Context>.() -> Unit) {
        decision(condition) {
            whenFalse {
                block()
            }
        }
    }

    /**
     * Appends all nodes from [flow] to this flow.
     */
    fun extend(flow: OnboardingFlow<Id, Context>) {
        nodes += flow.nodes
    }

    internal fun build() = OnboardingFlow(name, nodes)
}
