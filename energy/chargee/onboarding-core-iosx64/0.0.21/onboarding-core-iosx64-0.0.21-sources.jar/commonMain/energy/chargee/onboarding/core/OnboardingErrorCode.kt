package energy.chargee.onboarding.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The shape of every error code emitted on [OnboardingFlow.Event.StepFailure] and
 * [OnboardingFlow.Step.Result.Failure].
 *
 * Feature modules implement this interface to declare their own codes; the engine
 * itself emits [Timeout], [Cancelled], and [Unhandled]. The interface is intentionally
 * not `sealed` because Kotlin restricts sealed-type subclasses to the same Kotlin
 * compilation module and package — a constraint feature modules need to escape.
 */
@ObjCName("_OnboardingErrorCode")
interface OnboardingErrorCode {
    /**
     * Emitted by [OnboardingEngine] when a step exceeds its configured `timeout`.
     */
    @Serializable
    data object Timeout : OnboardingErrorCode

    /**
     * Emitted by [OnboardingEngine] when the surrounding coroutine is cancelled.
     */
    @Serializable
    data object Cancelled : OnboardingErrorCode

    /**
     * Emitted by [OnboardingEngine] when a step throws an exception instead of
     * returning [OnboardingFlow.Step.Result.Failure].
     *
     * Steps should return a [Failure][OnboardingFlow.Step.Result.Failure] for expected
     * error conditions — see [OnboardingFlow.Step.execute]. This code exists to keep
     * the engine's invariants intact when a step misbehaves; the original exception is
     * preserved on [OnboardingFlow.Event.StepFailure.throwable].
     *
     * Holds the original exception as [cause].
     */
    @Serializable
    data class Unhandled(
        @Transient val cause: Throwable? = null,
        val originalException: String? = cause?.message,
        val originalStackTrace: String? = cause?.stackTraceToString(),
    ) : OnboardingErrorCode
}
