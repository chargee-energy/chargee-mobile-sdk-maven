package energy.chargee.onboarding.core

import energy.chargee.onboarding.core.builders.OnboardingFlowBuilder

/**
 * Creates an [OnboardingFlow] named [name] using an [OnboardingFlowBuilder] DSL [block].
 */
fun <Id, Context> createOnboardingFlow(name: String, block: OnboardingFlowBuilder<Id, Context>.() -> Unit): OnboardingFlow<Id, Context> {
    val builder = OnboardingFlowBuilder<Id, Context>(name)
    builder.block()
    return builder.build()
}
