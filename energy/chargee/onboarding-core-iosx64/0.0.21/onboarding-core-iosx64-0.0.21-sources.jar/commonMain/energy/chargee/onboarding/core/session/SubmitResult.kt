package energy.chargee.onboarding.core.session

import kotlinx.serialization.Serializable

@Serializable
sealed interface SubmitResult {
    @Serializable
    data object Accepted : SubmitResult

    @Serializable
    data class Rejected(val reason: String) : SubmitResult
}
