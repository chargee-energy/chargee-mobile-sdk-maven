package energy.chargee.onboarding.core.session

/**
 * Marks an [OnboardingSessionBase] subclass as an onboarding session whose types should be exposed
 * to consuming platforms through generated, native bindings.
 *
 * The annotation is a platform-agnostic marker: it only identifies the session. Its `Id`, `Step`,
 * and `Input` types are read from the [OnboardingSessionBase] supertype's type arguments, so they
 * never need restating here. Today the bundled `swift-facade` KSP processor uses it to generate,
 * per session, a Swift `enum` over the flat, sealed input hierarchy (one case per direct subtype)
 * with a `submit(input:)` extension, a matching `enum` over the step hierarchy, and a
 * `state` / `currentState` bridge for the session's state flow. The same marker is intended to drive
 * other consumer bindings too — for example Flutter or React Native bridge generation.
 *
 * ```
 * @OnboardingSession
 * class ChargeeDeviceOnboardingSession(...) :
 *     OnboardingSessionBase<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext, ChargeeDeviceStep, ChargeeDeviceInput>(...)
 * ```
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.BINARY)
annotation class OnboardingSession
