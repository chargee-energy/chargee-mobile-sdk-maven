package energy.chargee.onboarding.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/**
 * Executes an [OnboardingFlow] with a given [initialContext], managing step execution, retries,
 * timeouts, and event emission.
 *
 * An engine is driven by a single call to [start], which suspends until the flow finishes or the
 * calling coroutine is cancelled. While the engine is running, callers can nudge it via
 * [resume], [advance], and [revert] — these are non-suspending signal functions that can be
 * invoked from any thread.
 *
 * Automatic retries follow each step's
 * [RetryPolicy][energy.chargee.onboarding.core.policies.RetryPolicy], and the context is updated
 * by each step's result as it propagates through the flow.
 *
 * An engine is single-use: once [start] returns (normal completion) or throws (cancellation),
 * it cannot be restarted. Construct a new [OnboardingEngine] to run the flow again — multiple
 * engines can run concurrently against the same [OnboardingFlow] without interfering.
 */
class OnboardingEngine<Id : Any, Context : Any>(private val flow: OnboardingFlow<Id, Context>, initialContext: Context) {
    private sealed interface Phase {
        /** Constructed; [start] has not been called yet. */
        data object Idle : Phase

        /** Currently executing nodes. */
        data object Running : Phase

        /** Paused mid-flow; can be resumed, advanced, or reverted. */
        sealed interface Paused : Phase {
            /**
             * A step returned [OnboardingFlow.Step.Result.InputRequired] with
             * [advanceAfterInput][OnboardingFlow.Step.Result.InputRequired.advanceAfterInput] `= true`;
             * index already advanced past the paused step.
             */
            data object AfterInputAdvanced : Paused

            /**
             * A step returned [OnboardingFlow.Step.Result.InputRequired] with
             * [advanceAfterInput][OnboardingFlow.Step.Result.InputRequired.advanceAfterInput] `= false`;
             * index left on the paused step so it re-executes on resume.
             */
            data object AfterInputRerun : Paused

            /** A step returned [OnboardingFlow.Step.Result.Failure] with no remaining retries; index unchanged. */
            data object AfterFailure : Paused
        }

        /** Flow ran to completion. Terminal. */
        data object Finished : Phase

        /** Flow was cancelled or its coroutine errored out. Terminal. */
        data object Terminated : Phase
    }

    private sealed interface Command<Context> {
        val updateContext: (Context) -> Context

        data class Resume<Context>(override val updateContext: (Context) -> Context) : Command<Context>

        data class Advance<Context>(override val updateContext: (Context) -> Context) : Command<Context>

        data class Revert<Context>(override val updateContext: (Context) -> Context) : Command<Context>
    }

    private sealed interface StepExecutionResult {
        data object Success : StepExecutionResult

        data class InputRequired(val advanceAfterInput: Boolean) : StepExecutionResult

        data object Failure : StepExecutionResult
    }

    private class NodeStackEntry<Id, Context>(val nodes: List<OnboardingFlow.Node<Id, Context>>, var currentIndex: Int)

    private val stack: ArrayDeque<NodeStackEntry<Id, Context>> = ArrayDeque(listOf(NodeStackEntry(flow.nodes, 0)))
    private var phase: Phase = Phase.Idle
    private var currentContext: Context = initialContext
    private var pauseGate: CompletableDeferred<Command<Context>>? = null

    private val _events = Channel<OnboardingFlow.Event<Id, Context>>(Channel.UNLIMITED)

    /**
     * [ReceiveChannel] of [OnboardingFlow.Event] emitted during execution, in the exact order they
     * occur.
     *
     * Backed by an unbounded [Channel], so it has a single consumer and every event is buffered
     * until received — including those emitted before the consumer starts collecting, so the
     * opening [OnboardingFlow.Event.FlowStarted] is never missed regardless of subscription
     * timing. The channel is closed once [start] returns (normal completion) or throws
     * (cancellation or error), which ends any `for (event in events)` loop draining it. The engine
     * derives no state of its own — a consumer (typically an
     * [OnboardingSessionBase][energy.chargee.onboarding.core.session.OnboardingSessionBase]) folds
     * these events into whatever state its presentation layer needs.
     */
    val events: ReceiveChannel<OnboardingFlow.Event<Id, Context>> = _events

    /**
     * Drives this engine to completion. Suspends until the flow finishes normally, throws if
     * the flow is cancelled or an internal error occurs.
     *
     * [initialContext] transforms the context this engine was constructed with just before
     * the first [OnboardingFlow.Event.FlowStarted] is emitted, giving callers a last chance to
     * seed data that isn't available at construction time (deep-link parameters, freshly
     * fetched configuration, etc.). The default leaves the context unchanged.
     *
     * On cancellation of the calling coroutine, the currently active step's
     * [onCancelled][OnboardingFlow.Step.onCancelled] and [onFinished][OnboardingFlow.Step.onFinished]
     * hooks fire under [NonCancellable] before the [CancellationException] is rethrown —
     * regardless of whether cancellation happens while a step is executing or while the engine
     * is paused waiting for a signal.
     *
     * An engine is single-use: calling [start] a second time throws [IllegalStateException].
     *
     * @throws IllegalStateException if the engine has already been started.
     */
    @Throws(IllegalStateException::class)
    suspend fun start(initialContext: (Context) -> Context = { it }) {
        check(phase is Phase.Idle) {
            "Cannot start an Engine in phase $phase. Create a new engine to run the flow again."
        }

        phase = Phase.Running
        currentContext = initialContext(currentContext)
        emit(OnboardingFlow.Event.FlowStarted(currentContext))

        try {
            loop()
            phase = Phase.Finished
            emit(OnboardingFlow.Event.FlowFinished(currentContext))
        } catch (e: CancellationException) {
            // Cancellation during a step's execute() was already handled by executeStep
            // (StepFailure emitted + onCancelled/onFinished fired). Cancellation while suspended
            // at the pause gate lands here with no prior handling; fire the cancelled lifecycle
            // for the paused step under NonCancellable so subscribers observe the terminal event.
            val pausedPhase = phase as? Phase.Paused
            if (pausedPhase != null) {
                withContext(NonCancellable) {
                    pausedStepAt(pausedPhase)?.step?.fireCancelled(currentContext)
                }
            }
            phase = Phase.Terminated
            throw e
        } catch (t: Throwable) {
            phase = Phase.Terminated
            throw t
        } finally {
            // Close after the terminal event has been emitted so consumers drain the full stream,
            // then see the channel close and end their receive loop.
            _events.close()
        }
    }

    /**
     * Resumes execution from the paused state, optionally transforming the current context via
     * [updateContext].
     *
     * Behaviour depends on why the engine paused:
     * - After [OnboardingFlow.Step.Result.InputRequired] with `advanceAfterInput = true` the
     *   paused step is treated as complete and execution continues at the next node.
     * - After [OnboardingFlow.Step.Result.InputRequired] with `advanceAfterInput = false` the
     *   paused step re-executes with the updated context.
     * - After a step failed with no remaining retries, the failed step re-executes.
     *
     * Non-suspending signal — returns immediately after handing the command to the driving
     * coroutine, which is then free to make progress.
     *
     * @throws IllegalStateException if the engine is not currently paused.
     */
    fun resume(updateContext: (Context) -> Context = { it }) {
        signal(Command.Resume(updateContext))
    }

    /**
     * Skips the paused step and continues execution at the next node.
     *
     * Regardless of why the engine paused, the paused step is treated as complete: its
     * [onCompleted][OnboardingFlow.Step.onCompleted] and [onFinished][OnboardingFlow.Step.onFinished]
     * hooks fire, a [OnboardingFlow.Event.StepCompleted] is emitted for it, the cursor is
     * advanced past it, and execution continues. Use this to skip past an
     * input step whose input the caller has decided is unnecessary, or to acknowledge and move
     * past an unrecoverable failure. [updateContext] receives the current context and returns
     * the context to use going forward; the default leaves it unchanged.
     *
     * Non-suspending signal — returns immediately after handing the command to the driving
     * coroutine.
     *
     * @throws IllegalStateException if the engine is not currently paused.
     */
    fun advance(updateContext: (Context) -> Context = { it }) {
        signal(Command.Advance(updateContext))
    }

    /**
     * Reverts to a prior step and resumes execution, optionally transforming the current
     * context via [updateContext].
     *
     * When paused after [OnboardingFlow.Step.Result.InputRequired] with `advanceAfterInput = true`,
     * revert re-runs the step that requested input, letting its logic execute again — this may
     * yield a different result given an updated context. When paused after a failure or after
     * `InputRequired(advanceAfterInput = false)`, the paused step will already re-execute on
     * resume, so revert steps back to the step *before* it so that step can run again first.
     *
     * Walks backwards through the node stack, popping any decision-pushed sub-flow frames as
     * needed. If no prior step exists, execution restarts from the beginning of the flow.
     * [updateContext] receives the current context and returns the context to use when
     * re-executing; the default leaves it unchanged.
     *
     * Non-suspending signal — returns immediately after handing the command to the driving
     * coroutine.
     *
     * @throws IllegalStateException if the engine is not currently paused.
     */
    fun revert(updateContext: (Context) -> Context = { it }) {
        signal(Command.Revert(updateContext))
    }

    private fun signal(command: Command<Context>) {
        val gate = pauseGate
        check(phase is Phase.Paused && gate != null) {
            "Cannot signal an Engine in phase $phase. This action requires a paused engine."
        }
        gate.complete(command)
    }

    /**
     * Runs the driving loop: execute nodes until pause or finish, then (if paused) await a
     * signal via the pause gate, apply it, and resume execution.
     */
    private suspend fun loop() {
        while (true) {
            execute()
            val pausedPhase = phase as? Phase.Paused ?: return

            val gate = CompletableDeferred<Command<Context>>().also { pauseGate = it }
            emit(OnboardingFlow.Event.FlowPaused(currentContext))
            val command =
                try {
                    gate.await()
                } finally {
                    pauseGate = null
                }

            // Transition to Running *before* applying the command, so that cancellation
            // interrupting applyCommand doesn't cause the outer catch in [start] to fire
            // onComplete a second time for the same paused step.
            phase = Phase.Running
            applyCommand(pausedPhase, command)
            emit(OnboardingFlow.Event.FlowResumed(currentContext))
        }
    }

    private suspend fun applyCommand(pausedPhase: Phase.Paused, command: Command<Context>) {
        currentContext = command.updateContext(currentContext)

        when (command) {
            is Command.Resume<Context> -> {
                if (pausedPhase == Phase.Paused.AfterInputAdvanced) {
                    // InputRequired(advanceAfterInput = true) advanced currentIndex past the
                    // paused step without emitting a completion event; finalize it now so
                    // `state.completedSteps` includes it and `state.currentStep` clears from
                    // WaitingForInput.
                    val paused = pausedStepAt(pausedPhase) ?: return
                    paused.step.fireCompleted(currentContext)
                    emit(OnboardingFlow.Event.StepCompleted(paused.step.id, currentContext))
                }
            }

            is Command.Advance<Context> -> {
                val paused = pausedStepAt(pausedPhase) ?: return
                paused.step.fireCompleted(currentContext)
                emit(OnboardingFlow.Event.StepCompleted(paused.step.id, currentContext))
                if (pausedPhase != Phase.Paused.AfterInputAdvanced) {
                    stack.last().currentIndex++
                }
            }

            is Command.Revert<Context> -> {
                // AfterInputAdvanced advanced currentIndex past the paused step, so
                // currentIndex - 1 is that step — the step to re-run. AfterInputRerun and
                // AfterFailure left currentIndex on the paused step, so currentIndex - 1 is
                // the step before it. In all cases, searching backwards from currentIndex - 1
                // lands on the correct step.
                while (stack.isNotEmpty()) {
                    val current = stack.last()
                    val stepIndex =
                        (current.currentIndex - 1 downTo 0)
                            .firstOrNull { current.nodes[it] is OnboardingFlow.Node.Step<Id, Context> }
                    if (stepIndex != null) {
                        current.currentIndex = stepIndex
                        break
                    }
                    stack.removeLast()
                }

                if (stack.isEmpty()) {
                    stack.addLast(NodeStackEntry(flow.nodes, 0))
                }
            }
        }
    }

    /**
     * Returns the step the engine paused on for [pausedPhase], or `null` if the stack is empty
     * or the resolved index is out of range.
     */
    private fun pausedStepAt(pausedPhase: Phase.Paused): OnboardingFlow.Node.Step<Id, Context>? {
        val current = stack.lastOrNull() ?: return null
        val index =
            when (pausedPhase) {
                Phase.Paused.AfterInputAdvanced -> current.currentIndex - 1
                Phase.Paused.AfterInputRerun, Phase.Paused.AfterFailure -> current.currentIndex
            }
        if (index !in current.nodes.indices) return null

        @Suppress("UNCHECKED_CAST")
        return current.nodes[index] as? OnboardingFlow.Node.Step<Id, Context>
    }

    private suspend fun execute() {
        while (stack.isNotEmpty()) {
            val current = stack.last()

            if (current.currentIndex >= current.nodes.size) {
                stack.removeLast()
                continue
            }

            when (val node = current.nodes[current.currentIndex]) {
                is OnboardingFlow.Node.Step -> {
                    when (val result = executeStep(node)) {
                        StepExecutionResult.Success -> {
                            current.currentIndex++
                        }

                        is StepExecutionResult.InputRequired -> {
                            if (result.advanceAfterInput) {
                                current.currentIndex++
                                phase = Phase.Paused.AfterInputAdvanced
                            } else {
                                phase = Phase.Paused.AfterInputRerun
                            }
                            return
                        }

                        StepExecutionResult.Failure -> {
                            phase = Phase.Paused.AfterFailure
                            return
                        }
                    }
                }

                is OnboardingFlow.Node.Decision -> {
                    val branch = if (node.condition(currentContext)) node.ifTrue else node.ifFalse
                    stack.addLast(NodeStackEntry(branch, 0))
                    current.currentIndex++
                }
            }
        }
    }

    private suspend fun executeStep(node: OnboardingFlow.Node.Step<Id, Context>): StepExecutionResult {
        var attempt = 0

        while (true) {
            currentCoroutineContext().ensureActive()
            emit(OnboardingFlow.Event.StepStarted(node.step.id, currentContext, attempt))

            try {
                val result =
                    if (node.timeout != null) {
                        withTimeout(node.timeout) { node.step.execute(currentContext) }
                    } else {
                        node.step.execute(currentContext)
                    }

                currentContext = result.context

                when (result) {
                    is OnboardingFlow.Step.Result.Success -> {
                        node.step.fireCompleted(currentContext)
                        emit(OnboardingFlow.Event.StepCompleted(node.step.id, currentContext))
                        return StepExecutionResult.Success
                    }

                    is OnboardingFlow.Step.Result.InputRequired -> {
                        emit(OnboardingFlow.Event.StepInputRequired(node.step.id, currentContext))
                        return StepExecutionResult.InputRequired(result.advanceAfterInput)
                    }

                    is OnboardingFlow.Step.Result.Failure -> {
                        if (maybeRetry(node, attempt, result.errorCode, result.throwable)) {
                            attempt++
                        } else {
                            return StepExecutionResult.Failure
                        }
                    }
                }
            } catch (e: TimeoutCancellationException) {
                // TimeoutCancellationException is a subtype of CancellationException, so this
                // catch must come first — otherwise timeouts would be misclassified as user
                // cancellations.
                if (maybeRetry(node, attempt, OnboardingErrorCode.Timeout, e)) {
                    attempt++
                } else {
                    return StepExecutionResult.Failure
                }
            } catch (e: CancellationException) {
                // Emit the terminal StepFailure and fire the cancelled lifecycle under
                // NonCancellable so subscribers observe them even though the surrounding
                // coroutine is being torn down.
                withContext(NonCancellable) {
                    emit(
                        OnboardingFlow.Event.StepFailure(
                            node.step.id,
                            currentContext,
                            OnboardingErrorCode.Cancelled,
                            e,
                        ),
                    )
                    node.step.fireCancelled(currentContext)
                }
                throw e
            } catch (t: Throwable) {
                // Step threw instead of returning Result.Failure. Documented as misuse on
                // Step.execute, but recover gracefully so the engine's invariants stay intact.
                if (maybeRetry(node, attempt, OnboardingErrorCode.Unhandled(t), t)) {
                    attempt++
                } else {
                    return StepExecutionResult.Failure
                }
            }
        }
    }

    private suspend fun maybeRetry(
        node: OnboardingFlow.Node.Step<Id, Context>,
        attempt: Int,
        errorCode: OnboardingErrorCode,
        throwable: Throwable?,
    ): Boolean {
        val delayDuration = node.retryPolicy?.nextDelay(attempt)

        if (node.retryPolicy?.shouldRetry(errorCode) == false || delayDuration == null) {
            emit(OnboardingFlow.Event.StepFailure(node.step.id, currentContext, errorCode, throwable))
            return false
        }

        emit(OnboardingFlow.Event.StepFailure(node.step.id, currentContext, errorCode, throwable, willRetry = true))
        delay(delayDuration)
        return true
    }

    /**
     * Publishes [event] to [events]. Sends never suspend or drop — the backing [Channel] is
     * unbounded — so ordering is preserved and no event is lost even if the consumer has not yet
     * started receiving.
     */
    private suspend fun emit(event: OnboardingFlow.Event<Id, Context>) {
        _events.send(event)
    }

    private suspend fun OnboardingFlow.Step<Id, Context>.fireCompleted(context: Context) {
        onCompleted(context)
        onFinished(context)
    }

    private suspend fun OnboardingFlow.Step<Id, Context>.fireCancelled(context: Context) {
        onCancelled(context)
        onFinished(context)
    }
}
