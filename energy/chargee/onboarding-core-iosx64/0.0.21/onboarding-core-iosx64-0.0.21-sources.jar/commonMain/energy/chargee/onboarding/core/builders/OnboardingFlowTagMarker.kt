package energy.chargee.onboarding.core.builders

/**
 * DSL marker annotation for onboarding flow builders.
 *
 * This annotation prevents mixing DSL contexts in onboarding flow builders,
 * ensuring type-safe DSL usage.
 */
@DslMarker
@Target(AnnotationTarget.CLASS)
internal annotation class OnboardingFlowTagMarker
