package energy.chargee.onboarding.core

import energy.chargee.onboarding.core.policies.RetryPolicy
import kotlin.time.Duration

/**
 * Represents an onboarding flow that can be executed with a given [Context].
 *
 * An onboarding flow consists of a sequence of nodes that define the steps and decisions
 * to be performed during the onboarding process. The flow is executed by [OnboardingEngine],
 * which manages step execution, context propagation, pausing/resuming, and event emission.
 *
 * The context flows through each step: the initial context is provided to the first step,
 * and each subsequent step receives the context from the previous step's result.
 */
class OnboardingFlow<Id, Context> internal constructor(val name: String, internal val nodes: List<Node<Id, Context>>) {
    init {
        val duplicates = mutableSetOf<Id>()

        // Returns the union of ids that may have run by the time `nodes` finishes — i.e. across
        // every possible decision-branch combination. Decision branches each see the same prefix
        // (`idsBefore`) but contribute their own ids to the union flowing into the suffix.
        fun visit(nodes: List<Node<Id, Context>>, idsBefore: Set<Id>): Set<Id> {
            var ids = idsBefore
            for (node in nodes) {
                when (node) {
                    is Node.Step -> {
                        if (node.step.id in ids) duplicates += node.step.id
                        ids = ids + node.step.id
                    }

                    is Node.Decision -> {
                        val trueIds = visit(node.ifTrue, ids)
                        val falseIds = visit(node.ifFalse, ids)
                        ids = trueIds + falseIds
                    }
                }
            }
            return ids
        }
        visit(nodes, emptySet())
        require(duplicates.isEmpty()) {
            "OnboardingFlow '$name' has duplicate step ids on at least one execution path: ${duplicates.joinToString()}"
        }
    }

    /**
     * Represents a node in the onboarding flow, which can be either a step or a decision.
     */
    internal sealed interface Node<Id, Context> {
        /**
         * A node that wraps a [step] with an optional [retryPolicy] and [timeout].
         *
         * When [retryPolicy] is `null` no retries are attempted. When [timeout] is `null`
         * no timeout is applied.
         */
        data class Step<Id, Context>(
            val step: OnboardingFlow.Step<Id, Context>,
            val retryPolicy: RetryPolicy? = null,
            val timeout: Duration? = null,
        ) : Node<Id, Context>

        /**
         * A node that evaluates [condition] and branches into [ifTrue] or [ifFalse].
         */
        data class Decision<Id, Context>(
            val condition: suspend (Context) -> Boolean,
            val ifTrue: List<Node<Id, Context>>,
            val ifFalse: List<Node<Id, Context>>,
        ) : Node<Id, Context>
    }

    /**
     * Represents a step in the onboarding flow that can be executed.
     */
    abstract class Step<Id, Context> {
        /**
         * The id of the step.
         */
        abstract val id: Id

        /**
         * Executes the step with the given [context] and returns a [Result].
         *
         * The context carried in the returned result is passed to the next step.
         *
         * Steps should not throw. Return [Result.Failure] for expected error conditions
         * (network errors, validation failures, etc.) so the engine can route them through
         * the configured retry policy and emit a [StepFailure][OnboardingFlow.Event.StepFailure]
         * event with the right [OnboardingErrorCode]. If a step does throw, the engine catches
         * the exception and treats it as a failure with [OnboardingErrorCode.Unhandled], but
         * this is a fallback for misbehaving steps and should not be relied on. Cancellation
         * exceptions are propagated as usual.
         */
        abstract suspend fun execute(context: Context): Result<Context>

        /**
         * Lifecycle hook invoked when the step successfully completes its role in the engine
         * — either it returned [Result.Success] from [execute], the caller
         * [advanced][OnboardingEngine.advance] past it while paused, or the caller
         * [resumed][OnboardingEngine.resume] after it returned
         * [Result.InputRequired] with `advanceAfterInput = true`.
         *
         * Called before the [OnboardingFlow.Event.StepCompleted] event is emitted, and always
         * followed by [onFinished] with the same [context]. Use this hook for cleanup that only
         * runs on the happy path (e.g. persisting captured input).
         *
         * The default implementation does nothing. Overrides should not throw; exceptions
         * propagate out of the driving coroutine and terminate the engine.
         */
        open suspend fun onCompleted(context: Context) {}

        /**
         * Lifecycle hook invoked when the step's role in the engine ends via cancellation of
         * the engine's driving coroutine — either while [execute] was running, or while the
         * engine was paused with this step as the active paused step.
         *
         * Invoked under [NonCancellable][kotlinx.coroutines.NonCancellable] so it can safely
         * suspend even though the surrounding coroutine is cancelling, and always followed by
         * [onFinished] with the same [context]. Use this hook for cleanup that only runs when
         * the step didn't get to finish (e.g. surfacing an abort event to the UI).
         *
         * The default implementation does nothing. Overrides should not throw; exceptions
         * propagate out of the driving coroutine and terminate the engine.
         */
        open suspend fun onCancelled(context: Context) {}

        /**
         * Lifecycle hook invoked when this step's active role in the engine ends for any
         * reason, giving the step a chance to release any resources it acquired during
         * [execute] (open sockets, ongoing scans, background listeners, etc.).
         *
         * Fired exactly once per activation of the step, always after either [onCompleted] or
         * [onCancelled] fires. Concretely, [onFinished] runs when:
         * - The step's [execute] returned [Result.Success].
         * - The caller invoked [OnboardingEngine.advance] while this step was the paused step.
         * - The caller invoked [OnboardingEngine.resume] after the step returned
         *   [Result.InputRequired] with `advanceAfterInput = true`.
         * - The engine's driving coroutine was cancelled while [execute] was running or while
         *   paused with this step as the active paused step — in which case [onFinished] is
         *   invoked under [NonCancellable][kotlinx.coroutines.NonCancellable].
         *
         * `onFinished` is **not** invoked when the flow simply pauses ([Result.InputRequired] /
         * [Result.Failure]) but has not yet been cancelled or skipped past, because the step
         * may still resume. It is also not invoked when the caller
         * [reverts][OnboardingEngine.revert] to or past this step, because the step is
         * expected to run again.
         *
         * The default implementation does nothing. Overrides should not throw; exceptions
         * propagate out of the driving coroutine and terminate the engine.
         */
        open suspend fun onFinished(context: Context) {}

        /**
         * The result of a step execution.
         *
         * All result types include the [context] to be used for subsequent steps. Steps can
         * modify and return an updated context that flows through the rest of the flow.
         */
        sealed interface Result<Context> {
            /**
             * The context to be passed to the next step or used for resuming.
             */
            val context: Context

            /**
             * Indicates that the step completed successfully.
             *
             * Execution continues to the next step with the returned [context].
             */
            data class Success<Context>(override val context: Context) : Result<Context>

            /**
             * Indicates that user input is required to proceed.
             *
             * The flow pauses and can be resumed by calling [OnboardingEngine.resume] with an
             * updated context containing the user input. [advanceAfterInput] controls what happens
             * on resume:
             * - `true` (default): the step is considered done — execution continues at the next
             *   node. Use this when the step's job is to prompt for input and the follow-up work
             *   lives in a later step (e.g. a plain "wait for user selection" node).
             * - `false`: the step re-executes with the updated context. Use this when the step
             *   returned early because a required field was missing and it needs to do real work
             *   once the field is supplied.
             */
            data class InputRequired<Context>(override val context: Context, val advanceAfterInput: Boolean = true) :
                Result<Context>

            /**
             * Indicates that the step failed with the given [errorCode] and optional [throwable].
             *
             * The flow pauses and can be retried by calling [OnboardingEngine.resume].
             */
            data class Failure<Context>(
                override val context: Context,
                val errorCode: OnboardingErrorCode,
                val throwable: Throwable? = null,
            ) : Result<Context>
        }
    }

    /**
     * An event emitted by [OnboardingEngine] during flow execution.
     *
     * Collect these from [OnboardingEngine.events] to observe flow and step lifecycle.
     * All event types carry the current [context] at the time of emission.
     */
    sealed interface Event<Id, Context> {
        /**
         * The context at the time this event was emitted.
         */
        val context: Context

        /**
         * Emitted with the initial [context] when the flow starts execution.
         */
        data class FlowStarted<Id, Context>(override val context: Context) : Event<Id, Context>

        /**
         * Emitted when the flow pauses, either because a step requires input or failed after exhausting retries.
         */
        data class FlowPaused<Id, Context>(override val context: Context) : Event<Id, Context>

        /**
         * Emitted when the flow resumes from a paused state.
         */
        data class FlowResumed<Id, Context>(override val context: Context) : Event<Id, Context>

        /**
         * Emitted with the final [context] when the flow finishes successfully.
         */
        data class FlowFinished<Id, Context>(override val context: Context) : Event<Id, Context>

        /**
         * Emitted when step [stepId] starts execution.
         *
         * [attempt] is 0-based: 0 for the first attempt, 1 for the first retry, and so on.
         */
        data class StepStarted<Id, Context>(val stepId: Id, override val context: Context, val attempt: Int) :
            Event<Id, Context>

        /**
         * Emitted when step [stepId] completes successfully.
         */
        data class StepCompleted<Id, Context>(val stepId: Id, override val context: Context) : Event<Id, Context>

        /**
         * Emitted when step [stepId] requires user input.
         *
         * The flow pauses until [OnboardingEngine.resume] is called with the user-provided input.
         */
        data class StepInputRequired<Id, Context>(val stepId: Id, override val context: Context) : Event<Id, Context>

        /**
         * Emitted when step [stepId] fails with [errorCode] and an optional [throwable].
         *
         * When [willRetry] is `true` the step will be retried automatically according to its retry
         * policy. Otherwise the flow pauses and can be manually retried via [OnboardingEngine.resume].
         */
        data class StepFailure<Id, Context>(
            val stepId: Id,
            override val context: Context,
            val errorCode: OnboardingErrorCode,
            val throwable: Throwable? = null,
            val willRetry: Boolean = false,
        ) : Event<Id, Context>
    }
}
