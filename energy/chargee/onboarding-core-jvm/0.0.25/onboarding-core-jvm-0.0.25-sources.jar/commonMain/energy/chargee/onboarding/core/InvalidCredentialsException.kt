package energy.chargee.onboarding.core

/**
 * A device rejected the credentials it was given — a charger's installer password, an inverter's
 * service login.
 *
 * Clients raise it instead of handing back the status code that carried it, so a step can tell
 * the one failure the user can do something about from every other way a request can fail, without
 * knowing anything about HTTP. The step turns it into
 * its brand's `DeviceConfigurationFailure` with `invalidCredentials = true` and asks for the
 * password again.
 *
 * It is the one failure that is deliberately *not* passed on as the cause of that result: a
 * mistyped password is the flow working, not a defect, and a monitoring logger reads an attached
 * throwable as something to raise. See the Logging section of the README.
 */
class InvalidCredentialsException(message: String) : RuntimeException(message)
