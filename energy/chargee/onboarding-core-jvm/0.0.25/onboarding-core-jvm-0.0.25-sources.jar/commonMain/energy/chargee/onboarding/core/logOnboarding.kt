package energy.chargee.onboarding.core

import energy.chargee.core.logging.ChargeeLog
import energy.chargee.core.logging.LogLevel

/**
 * The tag every onboarding line carries, so a consumer's logger can isolate onboarding from
 * everything else it is given.
 *
 * One tag for all brands rather than one per brand: a flow is identified by the name it was built
 * with, which prefixes every line, so a single tag still reads as one narrative per run.
 */
const val ONBOARDING_LOG_TAG = "ChargeeOnboarding"

/**
 * Writes one line about an onboarding flow, at [level] under [ONBOARDING_LOG_TAG], with
 * [throwable] when the line reports a failure that carried one.
 *
 * [OnboardingEngine] narrates the whole step lifecycle through this already — a step starting,
 * retrying, completing, asking for input, or failing — so a step only calls it for something that
 * lifecycle does not say: a branch it took internally, a count it settled on. [message] is built
 * only when the consumer installed a logger.
 *
 * Never put the flow context in a line. It carries Wi-Fi passwords, installer credentials, and
 * device serial numbers, and where these lines end up is the host app's decision.
 */
fun logOnboarding(level: LogLevel = LogLevel.Debug, throwable: Throwable? = null, message: () -> String) {
    ChargeeLog.log(level, ONBOARDING_LOG_TAG, throwable, message)
}

/**
 * This error code as one short line.
 *
 * [OnboardingErrorCode.Unhandled] holds the whole stack trace in its `toString`, which is not a log
 * line; the exception itself goes to the logger as the `throwable` instead, so naming it is enough.
 * Every other code is a small data class or object whose `toString` already reads well.
 */
internal fun OnboardingErrorCode.describe(): String =
    when (this) {
        is OnboardingErrorCode.Unhandled -> "Unhandled(${originalException ?: cause?.let { it::class.simpleName } ?: "no message"})"
        else -> toString()
    }
