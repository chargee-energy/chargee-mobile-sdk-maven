package energy.chargee.onboarding.core

/**
 * A device refused to be configured, in a way that produced no exception of its own: it answered
 * the request and then reported a state the flow cannot continue from — Modbus still disabled
 * after the write that enables it, registers that hold no address, a login the API declined
 * without failing.
 *
 * It exists because a monitoring logger needs something with a type and a stack trace to raise,
 * and these failures arrive as a `false` or a `null`. A step attaches one to
 * [OnboardingFlow.Step.Result.Failure] exactly where it would attach a real cause, so a device that misbehaves is reported the same
 * way as one that threw.
 *
 * It is for defects only. A failure the flow is designed to produce — a wrong password, a device
 * that is not there — carries no throwable at all, so the two stay distinguishable to whoever is
 * watching; see the Logging section of the README.
 */
class DeviceConfigurationException(message: String, override val cause: Throwable? = null) : RuntimeException(message, cause)
