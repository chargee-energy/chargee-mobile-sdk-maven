package energy.chargee.data.localdevice.repositories

import energy.chargee.core.network.enums.SortOrder
import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.localdevice.clients.InverterApiClient
import energy.chargee.data.localdevice.converters.asLocalDeviceReading
import energy.chargee.data.localdevice.dtos.LocalDeviceReadingDto
import energy.chargee.data.localdevice.models.LocalDeviceReading
import energy.chargee.utils.result.Result
import kotlin.time.Instant

internal class InverterApiRepository(private val inverterApiClient: InverterApiClient) : InverterRepository {
    override suspend fun getInverterReadings(
        addressUuid: String,
        inverterUuid: String,
        fromDate: Instant?,
        toDate: Instant?,
        limit: Int,
        sortOrder: SortOrder,
    ): Result<List<LocalDeviceReading>, ApiError> =
        runApi {
            inverterApiClient
                .getInverterReadings(
                    addressUuid,
                    inverterUuid,
                    fromDate?.toString(),
                    toDate?.toString(),
                    limit,
                    when (sortOrder) {
                        SortOrder.Ascending -> "ASC"
                        SortOrder.Descending -> "DESC"
                    },
                ).results
                .map(LocalDeviceReadingDto::asLocalDeviceReading)
        }
}
