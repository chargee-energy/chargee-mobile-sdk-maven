package energy.chargee.data.localdevice.models

/**
 * A single key/value entry in a local device configuration.
 *
 * [name] is the field key. [value] is the field value and must be one of [String], [Boolean],
 * or a numeric type ([Long] or [Double]); other types are rejected during serialization.
 */
data class LocalDeviceConfigField(val name: String, val value: Any)
