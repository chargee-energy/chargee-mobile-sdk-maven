package energy.chargee.data.localdevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class CreateLocalDeviceDto(
    val type: String,
    val connectionType: String,
    val deviceType: String,
    val brand: String,
    val model: String? = null,
    val config: List<LocalDeviceConfigFieldDto>,
)
