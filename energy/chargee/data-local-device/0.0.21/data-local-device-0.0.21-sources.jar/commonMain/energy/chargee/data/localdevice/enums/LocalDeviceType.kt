package energy.chargee.data.localdevice.enums

/**
 * The type of local device connected through a Chargee device.
 */
enum class LocalDeviceType {
    /**
     * A solar inverter.
     */
    Inverter,

    /**
     * An EV charger.
     */
    Charger,
}
