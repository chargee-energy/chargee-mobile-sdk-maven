package energy.chargee.data.localdevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class LocalDeviceDto(
    val uuid: String,
    val brand: String,
    val type: String,
    val connectionType: String,
    val config: List<LocalDeviceConfigFieldDto>,
)
