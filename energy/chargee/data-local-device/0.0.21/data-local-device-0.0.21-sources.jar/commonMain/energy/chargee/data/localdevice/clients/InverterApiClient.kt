package energy.chargee.data.localdevice.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.localdevice.dtos.LocalDeviceReadingDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter

internal class InverterApiClient(val httpClient: HttpClient) {
    suspend fun getInverterReadings(
        addressUuid: String,
        inverterUuid: String,
        fromDate: String?,
        toDate: String?,
        limit: Int,
        sortOrder: String,
    ): PaginatedResponseDto<PaginatedMetaDto, LocalDeviceReadingDto> =
        httpClient
            .get("/v5/addresses/$addressUuid/solar_inverters/$inverterUuid/energy/production") {
                fromDate?.let { parameter("fromDate", it) }
                toDate?.let { parameter("toDate", it) }
                parameter("limit", limit)
                parameter("sortBy", sortOrder)
            }.body()
}
