package energy.chargee.data.localdevice.converters

import energy.chargee.data.localdevice.dtos.CreateLocalDeviceDto
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField

internal fun LocalDeviceConfig.asCreateLocalDeviceDto() =
    CreateLocalDeviceDto(
        when (type) {
            LocalDeviceType.Inverter -> "inverter"
            LocalDeviceType.Charger -> "charger"
        },
        connectionType,
        deviceType,
        brand,
        model,
        config.map(LocalDeviceConfigField::asDto),
    )
