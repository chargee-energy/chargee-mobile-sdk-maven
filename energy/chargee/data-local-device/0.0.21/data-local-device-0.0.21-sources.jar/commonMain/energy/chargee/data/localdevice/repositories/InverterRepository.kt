package energy.chargee.data.localdevice.repositories

import energy.chargee.core.network.enums.SortOrder
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.localdevice.models.LocalDeviceReading
import energy.chargee.utils.result.Result
import kotlin.time.Instant

/**
 * Provides access to production readings from solar inverters registered to an address.
 */
interface InverterRepository {
    /**
     * Fetches production readings from the inverter identified by [inverterUuid] under
     * [addressUuid].
     *
     * When [fromDate] or [toDate] are `null` the backend applies its own default range.
     * [limit] caps the number of readings returned (default 1000). [sortOrder] determines
     * whether readings are ordered oldest-first ([SortOrder.Ascending]) or newest-first
     * ([SortOrder.Descending]).
     */
    suspend fun getInverterReadings(
        addressUuid: String,
        inverterUuid: String,
        fromDate: Instant? = null,
        toDate: Instant? = null,
        limit: Int = 1000,
        sortOrder: SortOrder = SortOrder.Ascending,
    ): Result<List<LocalDeviceReading>, ApiError>
}
