package energy.chargee.data.localdevice.converters

import energy.chargee.data.localdevice.dtos.LocalDeviceConfigFieldDto
import energy.chargee.data.localdevice.dtos.LocalDeviceDto
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDevice

internal fun LocalDeviceDto.asLocalDevice() =
    LocalDevice(
        uuid,
        brand,
        when (type) {
            "inverter" -> LocalDeviceType.Inverter
            "charger" -> LocalDeviceType.Charger
            else -> null
        },
        connectionType,
        config.map(LocalDeviceConfigFieldDto::asLocalDeviceConfigField),
    )
