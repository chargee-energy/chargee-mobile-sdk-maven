package energy.chargee.data.localdevice.clients

import energy.chargee.data.localdevice.dtos.CreateLocalDeviceDto
import energy.chargee.data.localdevice.dtos.LocalDeviceDto
import energy.chargee.data.localdevice.dtos.UpdateLocalDeviceDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.post
import io.ktor.client.request.put
import io.ktor.client.request.setBody

internal class LocalDeviceApiClient(private val httpClient: HttpClient) {
    suspend fun createLocalDevice(
        addressUuid: String,
        chargeeDeviceType: String,
        chargeeDeviceUuid: String,
        config: CreateLocalDeviceDto,
    ): LocalDeviceDto =
        httpClient
            .post("/v5/addresses/$addressUuid/$chargeeDeviceType/$chargeeDeviceUuid/devices") { setBody(config) }
            .body()

    suspend fun updateLocalDevice(
        addressUuid: String,
        chargeeDeviceType: String,
        chargeeDeviceUuid: String,
        deviceUuid: String,
        config: UpdateLocalDeviceDto,
    ): LocalDeviceDto =
        httpClient
            .put("/v5/addresses/$addressUuid/$chargeeDeviceType/$chargeeDeviceUuid/devices/$deviceUuid") {
                setBody(config)
            }.body()
}
