package energy.chargee.data.localdevice.models

import kotlin.time.Instant

/**
 * A single power reading emitted by a local device.
 *
 * [time] is the moment the reading was taken. [power] is the reported power value in watts.
 */
data class LocalDeviceReading(val time: Instant, val power: Int)
