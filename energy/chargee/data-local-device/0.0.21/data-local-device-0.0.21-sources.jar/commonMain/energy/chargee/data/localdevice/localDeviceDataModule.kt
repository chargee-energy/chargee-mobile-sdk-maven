package energy.chargee.data.localdevice

import energy.chargee.core.di.module
import energy.chargee.data.localdevice.clients.ChargerApiClient
import energy.chargee.data.localdevice.clients.InverterApiClient
import energy.chargee.data.localdevice.clients.LocalDeviceApiClient
import energy.chargee.data.localdevice.repositories.ChargerApiRepository
import energy.chargee.data.localdevice.repositories.ChargerRepository
import energy.chargee.data.localdevice.repositories.InverterApiRepository
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceApiRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository

val localDeviceDataModule =
    module {
        factory { LocalDeviceApiClient(get()) }
        factory { InverterApiClient(get()) }
        factory { ChargerApiClient(get()) }
        factory<LocalDeviceRepository> { LocalDeviceApiRepository(get()) }
        factory<InverterRepository> { InverterApiRepository(get()) }
        factory<ChargerRepository> { ChargerApiRepository(get()) }
    }
