package energy.chargee.data.localdevice.converters

import energy.chargee.data.localdevice.dtos.LocalDeviceConfigFieldDto
import energy.chargee.data.localdevice.dtos.UpdateLocalDeviceDto
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.double
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.long
import kotlinx.serialization.json.longOrNull

internal fun LocalDeviceConfigFieldDto.asLocalDeviceConfigField() =
    LocalDeviceConfigField(
        name,
        when {
            value.isString -> value.content
            value.booleanOrNull != null -> value.boolean
            value.longOrNull != null -> value.long
            value.doubleOrNull != null -> value.double
            else -> error("Unsupported JSON primitive: $value")
        },
    )

internal fun LocalDeviceConfigField.asDto() =
    LocalDeviceConfigFieldDto(
        name,
        when (value) {
            is String -> JsonPrimitive(value)
            is Number -> JsonPrimitive(value)
            is Boolean -> JsonPrimitive(value)
            else -> error("Unsupported value type: ${value::class}")
        },
    )

internal fun List<LocalDeviceConfigField>.asUpdateLocalDeviceDto() = UpdateLocalDeviceDto(map(LocalDeviceConfigField::asDto))
