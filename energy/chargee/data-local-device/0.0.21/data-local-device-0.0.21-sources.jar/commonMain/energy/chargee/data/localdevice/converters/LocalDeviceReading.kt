package energy.chargee.data.localdevice.converters

import energy.chargee.data.localdevice.dtos.LocalDeviceReadingDto
import energy.chargee.data.localdevice.models.LocalDeviceReading
import kotlin.time.Instant

internal fun LocalDeviceReadingDto.asLocalDeviceReading() = LocalDeviceReading(Instant.parse(time), power)
