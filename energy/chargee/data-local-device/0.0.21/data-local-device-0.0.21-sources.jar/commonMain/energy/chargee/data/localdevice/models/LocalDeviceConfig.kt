package energy.chargee.data.localdevice.models

import energy.chargee.data.localdevice.enums.LocalDeviceType

/**
 * The configuration used to register a local device behind a Chargee device.
 *
 * [type] is the category of local device being registered, [brand] the manufacturer,
 * [deviceType] the backend-recognized product family, and [model] the specific hardware
 * revision, or `null` when the model cannot be determined. [connectionType] identifies the
 * protocol used to reach the device (for example a Modbus transport). [config] holds the
 * protocol-specific settings — typically host, port, and any device-specific parameters.
 */
data class LocalDeviceConfig(
    val type: LocalDeviceType,
    val connectionType: String,
    val deviceType: String,
    val brand: String,
    val model: String? = null,
    val config: List<LocalDeviceConfigField>,
)
