package energy.chargee.data.localdevice.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.localdevice.clients.LocalDeviceApiClient
import energy.chargee.data.localdevice.converters.asCreateLocalDeviceDto
import energy.chargee.data.localdevice.converters.asLocalDevice
import energy.chargee.data.localdevice.converters.asUpdateLocalDeviceDto
import energy.chargee.data.localdevice.models.LocalDevice
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.utils.result.Result

internal class LocalDeviceApiRepository(private val localDeviceApiClient: LocalDeviceApiClient) : LocalDeviceRepository {
    override suspend fun createLocalDevice(
        addressUuid: String,
        chargeeDeviceType: ChargeeDeviceType,
        chargeeDeviceUuid: String,
        config: LocalDeviceConfig,
    ): Result<LocalDevice, ApiError> =
        runApi {
            localDeviceApiClient
                .createLocalDevice(
                    addressUuid,
                    getChargeeDeviceTypeString(chargeeDeviceType),
                    chargeeDeviceUuid,
                    config.asCreateLocalDeviceDto(),
                ).asLocalDevice()
        }

    override suspend fun updateLocalDevice(
        addressUuid: String,
        chargeeDeviceType: ChargeeDeviceType,
        chargeeDeviceUuid: String,
        deviceUuid: String,
        config: List<LocalDeviceConfigField>,
    ): Result<LocalDevice, ApiError> =
        runApi {
            localDeviceApiClient
                .updateLocalDevice(
                    addressUuid,
                    getChargeeDeviceTypeString(chargeeDeviceType),
                    chargeeDeviceUuid,
                    deviceUuid,
                    config.asUpdateLocalDeviceDto(),
                ).asLocalDevice()
        }

    private fun getChargeeDeviceTypeString(deviceType: ChargeeDeviceType) =
        when (deviceType) {
            ChargeeDeviceType.Sparky -> "sparkies"
            ChargeeDeviceType.Flint -> "flints"
        }
}
