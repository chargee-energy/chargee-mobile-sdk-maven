package energy.chargee.data.localdevice.models

import energy.chargee.data.localdevice.enums.LocalDeviceType

/**
 * A local device registered behind a Chargee device.
 *
 * [uuid] is the unique identifier assigned by the backend. [brand] and [type] describe the
 * manufacturer and category of the local device; [type] is `null` when the backend reports a
 * value the client does not recognize. [connectionType] identifies the protocol used to reach
 * the device (for example a Modbus transport). [config] holds the protocol-specific settings
 * that were used when registering the device.
 */
data class LocalDevice(
    val uuid: String,
    val brand: String,
    val type: LocalDeviceType? = null,
    val connectionType: String,
    val config: List<LocalDeviceConfigField>,
)
