package energy.chargee.data.localdevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class LocalDeviceReadingDto(val time: String, val power: Int)
