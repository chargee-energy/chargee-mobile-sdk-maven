package energy.chargee.data.localdevice.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.localdevice.models.LocalDevice
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.utils.result.Result

/**
 * Provides access to local devices connected behind a Chargee device.
 */
interface LocalDeviceRepository {
    /**
     * Registers a new local device with [config] behind the Chargee device identified by
     * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
     */
    suspend fun createLocalDevice(
        addressUuid: String,
        chargeeDeviceType: ChargeeDeviceType,
        chargeeDeviceUuid: String,
        config: LocalDeviceConfig,
    ): Result<LocalDevice, ApiError>

    /**
     * Updates the local device identified by [deviceUuid] behind the Chargee device identified by
     * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid], sending [config] as its
     * configuration fields. Only those fields are part of the request — the device's type, brand
     * and model stay as they were at registration.
     */
    suspend fun updateLocalDevice(
        addressUuid: String,
        chargeeDeviceType: ChargeeDeviceType,
        chargeeDeviceUuid: String,
        deviceUuid: String,
        config: List<LocalDeviceConfigField>,
    ): Result<LocalDevice, ApiError>
}
