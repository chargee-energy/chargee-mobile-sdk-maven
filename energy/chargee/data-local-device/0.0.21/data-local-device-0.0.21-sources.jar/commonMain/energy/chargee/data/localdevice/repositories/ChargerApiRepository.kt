package energy.chargee.data.localdevice.repositories

import energy.chargee.core.network.enums.SortOrder
import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.localdevice.clients.ChargerApiClient
import energy.chargee.data.localdevice.converters.asLocalDeviceReading
import energy.chargee.data.localdevice.dtos.LocalDeviceReadingDto
import energy.chargee.data.localdevice.models.LocalDeviceReading
import energy.chargee.utils.result.Result
import kotlin.time.Instant

internal class ChargerApiRepository(private val chargerApiClient: ChargerApiClient) : ChargerRepository {
    override suspend fun getChargerReadings(
        addressUuid: String,
        chargerUuid: String,
        fromDate: Instant?,
        toDate: Instant?,
        limit: Int,
        sortOrder: SortOrder,
    ): Result<List<LocalDeviceReading>, ApiError> =
        runApi {
            chargerApiClient
                .getChargerReadings(
                    addressUuid,
                    chargerUuid,
                    fromDate?.toString(),
                    toDate?.toString(),
                    limit,
                    when (sortOrder) {
                        SortOrder.Ascending -> "ASC"
                        SortOrder.Descending -> "DESC"
                    },
                ).results
                .map(LocalDeviceReadingDto::asLocalDeviceReading)
        }
}
