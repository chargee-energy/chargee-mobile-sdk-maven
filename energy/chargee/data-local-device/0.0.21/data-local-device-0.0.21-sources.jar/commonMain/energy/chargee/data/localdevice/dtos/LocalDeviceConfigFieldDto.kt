package energy.chargee.data.localdevice.dtos

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive

@Serializable
internal data class LocalDeviceConfigFieldDto(val name: String, val value: JsonPrimitive)
