package energy.chargee.data.localdevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class UpdateLocalDeviceDto(val config: List<LocalDeviceConfigFieldDto>)
