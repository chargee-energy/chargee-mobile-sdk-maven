package energy.chargee.data.flint.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.utils.result.Result

internal class FlintApiRepository(private val chargeeDeviceRepository: ChargeeDeviceRepository) : FlintRepository {
    override suspend fun getFlints(addressUuid: String): Result<List<ChargeeDevice>, ApiError> =
        chargeeDeviceRepository.getChargeeDevices(addressUuid, ChargeeDeviceType.Flint)

    override suspend fun createFlint(addressUuid: String, serialNumber: String): Result<ChargeeDevice, ApiError> =
        chargeeDeviceRepository.createChargeeDevice(addressUuid, ChargeeDeviceType.Flint, serialNumber)

    override suspend fun getFlint(addressUuid: String, flintUuid: String): Result<ChargeeDevice, ApiError> =
        chargeeDeviceRepository.getChargeeDevice(addressUuid, ChargeeDeviceType.Flint, flintUuid)

    override suspend fun deleteFlint(addressUuid: String, flintUuid: String): Result<Unit, ApiError> =
        chargeeDeviceRepository.deleteChargeeDevice(addressUuid, ChargeeDeviceType.Flint, flintUuid)
}
