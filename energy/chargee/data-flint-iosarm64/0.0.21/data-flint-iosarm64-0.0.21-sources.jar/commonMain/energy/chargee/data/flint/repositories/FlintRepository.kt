package energy.chargee.data.flint.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to Flint device registration for an address.
 */
@Repository
@ObjCName("_FlintRepository")
interface FlintRepository {
    /**
     * Fetches all Flints for [addressUuid].
     */
    suspend fun getFlints(addressUuid: String): Result<List<ChargeeDevice>, ApiError>

    /**
     * Registers a new Flint device with [serialNumber] to the address identified by [addressUuid].
     */
    suspend fun createFlint(addressUuid: String, serialNumber: String): Result<ChargeeDevice, ApiError>

    /**
     * Fetches the Flint identified by [flintUuid] for [addressUuid].
     */
    suspend fun getFlint(addressUuid: String, flintUuid: String): Result<ChargeeDevice, ApiError>

    /**
     * Deletes the Flint identified by [flintUuid] for [addressUuid].
     */
    suspend fun deleteFlint(addressUuid: String, flintUuid: String): Result<Unit, ApiError>
}
