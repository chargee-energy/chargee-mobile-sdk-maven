package energy.chargee.data.flint

import energy.chargee.core.di.module
import energy.chargee.data.flint.repositories.FlintApiRepository
import energy.chargee.data.flint.repositories.FlintRepository

val flintDataModule =
    module {
        factory<FlintRepository> { FlintApiRepository(get()) }
    }
