package energy.chargee.onboarding.solaredge.clients

import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * How long a single probe is given to reach the inverter. Short because the inverter is one hop
 * away over its own access point, and because a candidate that is not there is paid for once per
 * address.
 */
private val PROBE_TIMEOUT: Duration = 3.seconds

/**
 * Reports whether anything answers HTTP at [host], which is how the flow confirms the phone really
 * did end up on the inverter's access point before it moves on.
 *
 * The join itself cannot be trusted to answer that. On iOS `NEHotspotConfigurationManager` reports
 * a rejected passphrase to the user rather than to the app, and on Android a network that was
 * joined can be torn down again before the configuration calls run. Either way the flow carries on
 * to the configuration step and fails there, where "nothing answered" reads to the user as a
 * problem with the inverter rather than with the Wi-Fi password they just typed.
 *
 * Deliberately stops at the response: the status is not inspected and no body is read, because
 * which paths an inverter serves varies with firmware, and a probe that reported a joined network
 * as unreachable would strand the flow on a step the user cannot get past. Anything that completes
 * an HTTP exchange at this address is close enough to a device to hand over to the configuration
 * step, which reports what it finds there.
 */
internal suspend fun probeSolarEdgeInverter(host: String): Boolean {
    val httpClient =
        HttpClient {
            install(HttpTimeout) {
                requestTimeoutMillis = PROBE_TIMEOUT.inWholeMilliseconds
                connectTimeoutMillis = PROBE_TIMEOUT.inWholeMilliseconds
                socketTimeoutMillis = PROBE_TIMEOUT.inWholeMilliseconds
            }
        }

    return try {
        httpClient.get("http://$host/web/v1/communication")
        true
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: Exception) {
        // A connect timeout, a refused connection, or an address with no route to it — nothing
        // that answers for an inverter is here.
        false
    } finally {
        httpClient.close()
    }
}
