package energy.chargee.onboarding.solaredge.clients

import energy.chargee.core.logging.LogLevel
import energy.chargee.onboarding.core.logOnboarding
import energy.chargee.onboarding.solaredge.SolarEdgeConfig
import energy.chargee.onboarding.solaredge.models.ModbusTcpConfig
import energy.chargee.onboarding.solaredge.wire.types.Bool
import energy.chargee.onboarding.solaredge.wire.types.Uint32
import energy.chargee.onboarding.solaredge.wire.web_communication.Communication
import energy.chargee.utils.wifi.WifiConfiguration
import energy.chargee.utils.wifi.WifiConnection
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsBytes
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.coroutines.delay
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.seconds

internal class SolarEdgeLocalApiClient(
    private val wifiConnection: WifiConnection,
    private val fallbackHosts: List<String> = listOf(SolarEdgeConfig.LOCAL_CONFIG_HOST),
    private val probeAt: suspend (String) -> Boolean = ::probeSolarEdgeInverter,
) : SolarEdgeClient {
    /**
     * The address the inverter answered on, resolved by [connect] while it verifies the access
     * point and reused by the configuration calls for the rest of the session. Cleared by
     * [disconnect], which ends the session it was valid for.
     */
    private var resolvedHost: String? = null

    /**
     * Where the configuration calls go. [connect] resolves this before the flow reaches them and
     * the configuration step's retries reuse what it found, so the fallback stands in only for a
     * caller that skipped [connect] altogether.
     */
    private val host: String get() = resolvedHost ?: SolarEdgeConfig.LOCAL_CONFIG_HOST

    private val httpClient: HttpClient by lazy {
        HttpClient {
            // As on the Peblar and Alfen clients: a non-2xx from the inverter throws rather than
            // being handed back as a status for the caller to interpret, so the configuration
            // step reports the failure with the response that caused it.
            expectSuccess = true
            defaultRequest {
                contentType(ContentType("application", "x-protobuf"))
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 15_000
            }
        }
    }

    /**
     * Joins the inverter's access point and then confirms the inverter is actually reachable on
     * it, keeping the address that answered for the configuration calls to reuse.
     *
     * The association alone does not settle it — see [probeSolarEdgeInverter] for what it leaves
     * open on each platform. Reaching the inverter here keeps the failure on the step that can ask
     * for the Wi-Fi password again, instead of handing a phone that is on no useful network to the
     * configuration step, which can only report that the inverter never answered.
     */
    override suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean {
        // The inverter needs some time to initialize the connection after flipping the switch
        delay(ACTIVATION_DELAY)

        if (!wifiConnection.connect(wifiConfiguration, saveNetwork = true)) return false

        // Give the device some time to properly initialize the connection
        delay(INITIALIZATION_DELAY)

        resolvedHost = candidateHosts().firstOrNull { probeAt(it) }
        if (resolvedHost != null) return true

        // Leave nothing installed for this SSID: on iOS a leftover configuration makes the retry
        // that carries the corrected passphrase report `alreadyAssociated` against the stale one,
        // and the new passphrase is never applied.
        disconnect()
        return false
    }

    override suspend fun disconnect() {
        resolvedHost = null

        val disconnected = wifiConnection.disconnect()
        if (disconnected) {
            // Give the device some time to reset the connection
            delay(TEARDOWN_DELAY)
        }
    }

    // `expectSuccess` turns anything but a 2xx into an exception, which is the whole of the
    // check: there is nothing to report back that the absence of a throw does not already say.
    override suspend fun enableModbusTcp(port: Int) {
        httpClient.post("http://$host/web/v1/communication/modbus_tcp") {
            setBody(
                Communication
                    .ModbusTcpPort(
                        enabled = Bool(true),
                        port = Uint32(port),
                    ).encode(),
            )
        }
    }

    override suspend fun getModbusTcpConfig(): ModbusTcpConfig =
        try {
            val communication =
                Communication.ADAPTER.decode(
                    httpClient
                        .get("http://$host/web/v1/communication")
                        .bodyAsBytes(),
                )

            ModbusTcpConfig(
                enabled = communication.modbus_tcp_port?.enabled?.value_ ?: false,
                port = communication.modbus_tcp_port?.port?.value_,
            )
        } catch (cancellation: CancellationException) {
            // `runCatching`, which this replaced, caught this too and reported an abandoned
            // onboarding as an inverter with Modbus switched off.
            throw cancellation
        } catch (exception: Exception) {
            // The one failure this client swallows, and on purpose: the step falls back to
            // enabling the default port and usually succeeds. Say which of the two happened,
            // because the fallback is indistinguishable from an inverter that reported Modbus
            // off — but leave the throwable off the line, since a read the next request recovers
            // from is not a defect and attaching it would raise an issue for a flow that worked.
            logOnboarding(LogLevel.Warning) {
                "solaredge: could not read the Modbus TCP config, assuming it is off " +
                    "(${exception::class.simpleName}: ${exception.message})"
            }
            ModbusTcpConfig(enabled = false)
        }

    /**
     * The gateway of the joined network first, then [fallbackHosts]. Deduplicated, so a gateway
     * that matches a known address does not get probed twice.
     */
    private suspend fun candidateHosts(): List<String> =
        buildList {
            wifiConnection.getGatewayAddress()?.let(::add)
            addAll(fallbackHosts)
        }.distinct()

    private companion object {
        /** How long the inverter is given to bring its access point up after the switch is flipped. */
        val ACTIVATION_DELAY = 5.seconds

        /** How long the inverter is given to bring its web server up after the phone joins. */
        val INITIALIZATION_DELAY = 15.seconds

        /** How long to wait for the access point to tear down before the next attempt joins it. */
        val TEARDOWN_DELAY = 5.seconds
    }
}
