package energy.chargee.onboarding.solaredge

/**
 * SolarEdge-specific constants shared across the flow, module, and clients.
 */
object SolarEdgeConfig {
    /** Brand identifier used as the SolarEdge onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "solaredge"

    /**
     * Fallback Modbus TCP port used when the device does not report a port in its
     * communication config. SolarEdge devices expose Modbus TCP on 1502 by default.
     */
    const val DEFAULT_PORT = 1502

    /**
     * mDNS service type SolarEdge inverters advertise once Modbus TCP is enabled on them. Only
     * half of the SolarEdge strategy: the DI module pairs it with a port scan on the resolved
     * Modbus port (see [DEFAULT_PORT]) in a
     * [energy.chargee.discovery.core.CompositeDeviceDiscovery], because inverters that have Modbus
     * enabled but do not answer mDNS are reachable only by scanning.
     */
    const val SERVICE_TYPE = "_solaredge-modbus._tcp"
}
