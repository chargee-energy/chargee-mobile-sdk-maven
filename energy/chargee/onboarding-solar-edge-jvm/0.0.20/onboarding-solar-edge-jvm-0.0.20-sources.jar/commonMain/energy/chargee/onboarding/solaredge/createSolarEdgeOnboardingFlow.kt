package energy.chargee.onboarding.solaredge

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyInverterStep
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.BRAND
import energy.chargee.onboarding.solaredge.clients.SolarEdgeClient
import energy.chargee.onboarding.solaredge.steps.ConfigureDeviceStep
import energy.chargee.onboarding.solaredge.steps.ConnectLocalWifiStep

/**
 * Builds the onboarding flow for a SolarEdge inverter behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Prompt the user for SolarEdge Wi-Fi credentials, then join the inverter's local AP via
 *    [solarEdgeClient].
 * 3. Enable Modbus TCP on the inverter (skipped when no Wi-Fi configuration was captured).
 * 4. Scan the inverter's network for the Modbus endpoint using [solarEdgeDiscoveryFactory],
 *    which is invoked with the resolved Modbus TCP port.
 * 5. Register the discovered inverter through [localDeviceRepository].
 * 6. Poll [inverterRepository] until the Chargee device reports readings from the inverter,
 *    confirming end-to-end connectivity.
 *
 * When the context is seeded with a `deviceUuid` the flow resets that already-registered inverter
 * instead: steps 2 and 3 are skipped — the inverter is assumed to be configured already — and
 * step 5 updates the stored configuration with the rediscovered values rather than creating a
 * second registration.
 */
internal fun createSolarEdgeOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    solarEdgeDiscoveryFactory: (port: Int) -> DeviceDiscovery,
    solarEdgeClient: SolarEdgeClient,
    localDeviceRepository: LocalDeviceRepository,
    inverterRepository: InverterRepository,
) = createOnboardingFlow<LocalDeviceStepId, SolarEdgeOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    whenTrue(condition = { it.deviceUuid == null }) {
        step(ConnectLocalWifiStep(solarEdgeClient))
        whenTrue(condition = { it.wifiConfiguration != null }) {
            step(
                ConfigureDeviceStep(solarEdgeClient),
                retryPolicy =
                    ExponentialBackoffRetry(
                        maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                        condition = { (it as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials != true },
                    ),
            )
        }
    }
    discoverDeviceStep { solarEdgeDiscoveryFactory(it.port) }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = { context, fields ->
            LocalDeviceConfig(
                type = LocalDeviceType.Inverter,
                connectionType = "solaredge_tcp",
                deviceType = BRAND,
                brand = BRAND,
                model = context.model,
                config =
                fields,
            )
        },
        createConfigFields = { context ->
            val selectedDevice =
                requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }
            listOf(
                LocalDeviceConfigField("modbus_type", "tcp"),
                LocalDeviceConfigField("address", 1),
                LocalDeviceConfigField("ip", selectedDevice.ipAddress),
                LocalDeviceConfigField("port", selectedDevice.port ?: context.port),
                LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
            )
        },
    )
    verifyInverterStep(addressUuid, inverterRepository)
}
