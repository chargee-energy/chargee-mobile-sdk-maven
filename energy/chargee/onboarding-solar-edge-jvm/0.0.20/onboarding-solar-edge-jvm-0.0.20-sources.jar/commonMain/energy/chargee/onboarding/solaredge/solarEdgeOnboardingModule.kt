package energy.chargee.onboarding.solaredge

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.CompositeDeviceDiscovery
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.BRAND
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.SERVICE_TYPE
import energy.chargee.onboarding.solaredge.clients.SolarEdgeClient
import energy.chargee.onboarding.solaredge.clients.SolarEdgeLocalApiClient

val solarEdgeOnboardingModule =
    module {
        factory<SolarEdgeClient> { SolarEdgeLocalApiClient(get()) }
        factoryWithParameters<DeviceDiscovery>(name = BRAND) { parameters ->
            CompositeDeviceDiscovery(
                get<DeviceDiscovery>(
                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                    parameters = parametersOf(SERVICE_TYPE),
                ),
                get<DeviceDiscovery>(
                    name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE,
                    parameters = parameters,
                ),
            )
        }
        factoryWithParameters { parameters ->
            SolarEdgeOnboardingSession(
                OnboardingEngine(
                    initialContext = SolarEdgeOnboardingContext(),
                    flow =
                        createSolarEdgeOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            solarEdgeDiscoveryFactory = { port ->
                                get<DeviceDiscovery>(
                                    name = BRAND,
                                    parameters = parametersOf(port),
                                )
                            },
                            solarEdgeClient = get(),
                            localDeviceRepository = get(),
                            inverterRepository = get(),
                        ),
                ),
            )
        }
    }
