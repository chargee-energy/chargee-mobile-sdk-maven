package energy.chargee.onboarding.solaredge.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.DEFAULT_PORT
import energy.chargee.onboarding.solaredge.SolarEdgeOnboardingContext
import energy.chargee.onboarding.solaredge.clients.SolarEdgeClient

internal class ConfigureDeviceStep(private val client: SolarEdgeClient) :
    OnboardingFlow.Step<LocalDeviceStepId, SolarEdgeOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: SolarEdgeOnboardingContext): Result<SolarEdgeOnboardingContext> {
        val config = client.getModbusTcpConfig()
        val port = config.port ?: DEFAULT_PORT

        if (config.enabled) {
            // Modbus TCP is already enabled, no need to enable it again.
            return Result.Success(context.copy(port = port))
        }

        if (client.enableModbusTcp(port)) {
            return Result.Success(context.copy(port = port))
        }

        return Result.Failure(
            context.copy(port = port),
            LocalDeviceErrorCode.DeviceConfigurationFailure(),
        )
    }

    override suspend fun onFinished(context: SolarEdgeOnboardingContext) {
        client.disconnect()
    }
}
