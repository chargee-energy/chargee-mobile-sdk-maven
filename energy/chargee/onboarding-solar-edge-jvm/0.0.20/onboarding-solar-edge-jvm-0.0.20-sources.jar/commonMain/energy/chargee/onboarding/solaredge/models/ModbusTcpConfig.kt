package energy.chargee.onboarding.solaredge.models

data class ModbusTcpConfig(val enabled: Boolean, val port: Int? = null)
