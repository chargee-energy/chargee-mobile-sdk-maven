package energy.chargee.onboarding.solaredge.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.solaredge.SolarEdgeOnboardingContext
import energy.chargee.onboarding.solaredge.clients.SolarEdgeClient

internal class ConnectLocalWifiStep(private val client: SolarEdgeClient) :
    OnboardingFlow.Step<LocalDeviceStepId, SolarEdgeOnboardingContext>() {
    override val id = LocalDeviceStepId.ConnectLocalWifi

    override suspend fun execute(context: SolarEdgeOnboardingContext): Result<SolarEdgeOnboardingContext> {
        val wifiConfiguration =
            context.wifiConfiguration ?: return Result.InputRequired(
                context,
                advanceAfterInput = false,
            )

        return if (client.connect(wifiConfiguration)) {
            Result.Success(context)
        } else {
            Result.Failure(context, LocalDeviceErrorCode.WifiConnectionFailure)
        }
    }

    override suspend fun onCancelled(context: SolarEdgeOnboardingContext) {
        client.disconnect()
    }
}
