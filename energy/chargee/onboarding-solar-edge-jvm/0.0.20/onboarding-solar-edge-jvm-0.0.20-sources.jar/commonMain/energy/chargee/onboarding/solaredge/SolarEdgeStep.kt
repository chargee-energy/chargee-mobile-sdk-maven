package energy.chargee.onboarding.solaredge

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [SolarEdgeOnboardingSession] surfaces through its typed state,
 * each carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_SolarEdgeStep")
@Serializable
sealed interface SolarEdgeStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        SolarEdgeStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : SolarEdgeStep

    /**
     * The flow is waiting for the user to set up the inverter's Wi-Fi. Call [setWifi] with the
     * chosen network — optionally narrowing to a specific inverter model — or [skipWifi] to continue
     * over the local connection.
     */
    @Serializable
    data class AwaitingWifi(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConnectLocalWifi,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        @Transient val setWifi: (wifi: WifiConfiguration, model: String?) -> Unit = { _, _ -> },
        @Transient val skipWifi: () -> Unit = {},
    ) : SolarEdgeStep

    /**
     * The flow is waiting for the user to pick which device to onboard from [possibleDevices]. Call
     * [setDevice] with the chosen device.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : SolarEdgeStep
}
