package energy.chargee.onboarding.solaredge

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the SolarEdge inverter onboarding flow. A flat, sealed hierarchy whose cases the
 * [SolarEdgeOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_SolarEdgeInput")
@Serializable
sealed interface SolarEdgeInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : SolarEdgeInput

    /**
     * Skips connecting the inverter to Wi-Fi and continues over the local connection. Accepted
     * while the flow is waiting for Wi-Fi setup.
     */
    @Serializable
    data object SkipWifiSetup : SolarEdgeInput

    /**
     * Connects the inverter to the [wifi] network, optionally narrowing to a specific inverter
     * [model]. Accepted while the flow is waiting for Wi-Fi setup.
     */
    @Serializable
    data class SetWifi(val wifi: WifiConfiguration, val model: String? = null) : SolarEdgeInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : SolarEdgeInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : SolarEdgeInput
}
