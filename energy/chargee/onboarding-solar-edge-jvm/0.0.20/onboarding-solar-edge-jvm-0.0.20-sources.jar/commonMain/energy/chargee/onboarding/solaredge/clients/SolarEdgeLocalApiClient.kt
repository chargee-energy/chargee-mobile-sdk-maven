package energy.chargee.onboarding.solaredge.clients

import energy.chargee.onboarding.solaredge.models.ModbusTcpConfig
import energy.chargee.onboarding.solaredge.wire.types.Bool
import energy.chargee.onboarding.solaredge.wire.types.Uint32
import energy.chargee.onboarding.solaredge.wire.web_communication.Communication
import energy.chargee.utils.wifi.WifiConfiguration
import energy.chargee.utils.wifi.WifiConnection
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsBytes
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.seconds

internal class SolarEdgeLocalApiClient(private val wifiConnection: WifiConnection) : SolarEdgeClient {
    private val httpClient: HttpClient by lazy {
        HttpClient {
            defaultRequest {
                url("http://172.16.0.1")
                contentType(ContentType("application", "x-protobuf"))
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 15_000
            }
        }
    }

    override suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean {
        // The inverter needs some time to initialize the connection after flipping the switch
        delay(5.seconds)

        val connected = wifiConnection.connect(wifiConfiguration, saveNetwork = true)
        if (connected) {
            // Give the device some time to properly initialize the connection
            delay(15.seconds)
            return true
        }

        return false
    }

    override suspend fun disconnect() {
        val disconnected = wifiConnection.disconnect()
        if (disconnected) {
            // Give the device some time to reset the connection
            delay(5.seconds)
        }
    }

    override suspend fun enableModbusTcp(port: Int): Boolean {
        val response =
            httpClient.post("/web/v1/communication/modbus_tcp") {
                setBody(
                    Communication
                        .ModbusTcpPort(
                            enabled = Bool(true),
                            port = Uint32(port),
                        ).encode(),
                )
            }

        return response.status == HttpStatusCode.OK
    }

    override suspend fun getModbusTcpConfig(): ModbusTcpConfig =
        runCatching {
            Communication.ADAPTER.decode(
                httpClient
                    .get("/web/v1/communication")
                    .bodyAsBytes(),
            )
        }.fold(
            onSuccess = {
                ModbusTcpConfig(
                    enabled = it.modbus_tcp_port?.enabled?.value_ ?: false,
                    port = it.modbus_tcp_port?.port?.value_,
                )
            },
            onFailure = { ModbusTcpConfig(enabled = false) },
        )
}
