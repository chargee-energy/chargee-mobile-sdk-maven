package energy.chargee.onboarding.solaredge

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.DEFAULT_PORT
import energy.chargee.utils.wifi.WifiConfiguration

/**
 * The mutable context that flows through the SolarEdge onboarding steps.
 *
 * Extends [LocalDeviceOnboardingContext] with SolarEdge-specific fields. [wifiConfiguration]
 * holds the credentials for the SolarEdge local access point and is required by
 * [energy.chargee.onboarding.solaredge.steps.ConnectLocalWifiStep] — the step pauses for user
 * input until it is set. [port] is the Modbus TCP port the inverter listens on; it defaults
 * to [SolarEdgeConfig.DEFAULT_PORT] and is overwritten by
 * [energy.chargee.onboarding.solaredge.steps.ConfigureDeviceStep] once the device's actual
 * port is known.
 */
data class SolarEdgeOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    val port: Int = DEFAULT_PORT,
    val wifiConfiguration: WifiConfiguration? = null,
) : LocalDeviceOnboardingContext<SolarEdgeOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
