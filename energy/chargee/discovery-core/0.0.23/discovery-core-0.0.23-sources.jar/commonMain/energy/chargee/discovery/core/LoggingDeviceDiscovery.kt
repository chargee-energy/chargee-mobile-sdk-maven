package energy.chargee.discovery.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.time.TimeSource

/**
 * A [DeviceDiscovery] that logs what [discovery] does under the name [name], and otherwise changes
 * nothing about it.
 *
 * Discovery is the part of onboarding that is hardest to reason about after the fact: several
 * strategies run, most of them find nothing most of the time, and which one produced a given device
 * decides what the rest of the flow does with it. One line per device, bracketed by the strategy
 * that found it, is enough to answer that from a log someone sends you.
 *
 * Apply it with [logged] rather than constructing it directly.
 */
internal class LoggingDeviceDiscovery(private val name: String, private val discovery: DeviceDiscovery) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            val started = TimeSource.Monotonic.markNow()
            var found = 0
            discoveryLog.d { "$name: started" }

            try {
                discovery.discover().collect { device ->
                    found++
                    discoveryLog.d { "$name: found ${device.describe()}" }
                    emit(device)
                }
                discoveryLog.d { "$name: finished with $found after ${started.elapsedNow()}" }
            } catch (throwable: Throwable) {
                // Including cancellation, which is the ordinary way a discovery ends when something
                // downstream has seen enough - worth telling apart from a strategy that completed.
                discoveryLog.d { "$name: stopped after ${started.elapsedNow()} with $found (${throwable::class.simpleName})" }
                throw throwable
            }
        }
}

/**
 * This discovery, logging what it does under [name].
 *
 * Name it after the strategy rather than the caller — `"mdns"`, `"port-scan"`, `"sma"` — since the
 * point is to tell apart the several strategies one flow runs.
 */
fun DeviceDiscovery.logged(name: String): DeviceDiscovery = LoggingDeviceDiscovery(name, this)
