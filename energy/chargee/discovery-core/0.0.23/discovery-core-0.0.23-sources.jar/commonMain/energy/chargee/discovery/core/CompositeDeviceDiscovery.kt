package energy.chargee.discovery.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.coroutines.cancellation.CancellationException

/**
 * A [DeviceDiscovery] that tries [discoveries] in order and yields the results of the first
 * strategy that finds anything.
 *
 * Each strategy is collected in turn and its devices are emitted as they arrive. Once a strategy
 * finishes, discovery stops there if that strategy produced at least one device; a strategy that
 * completes without emitting counts as a miss and the next one is tried. When every strategy comes
 * up empty — or when there are no [discoveries] at all — the composite completes empty too.
 *
 * Use this to express a preference order between transports, for example an mDNS lookup first and
 * a port scan only as a fallback for devices that don't announce themselves. Every collection
 * restarts the sequence from the first strategy, so the composite honours the
 * collect-again-for-a-fresh-run contract of [DeviceDiscovery] as long as its [discoveries] do.
 */
class CompositeDeviceDiscovery(private vararg val discoveries: DeviceDiscovery) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            for ((index, discovery) in discoveries.withIndex()) {
                val position = "strategy ${index + 1} of ${discoveries.size}"
                var emitted = false

                try {
                    discovery.discover().collect {
                        emitted = true
                        emit(it)
                    }
                } catch (cancellation: CancellationException) {
                    throw cancellation
                } catch (throwable: Throwable) {
                    // A strategy that cannot run is a strategy that found nothing, and the next one
                    // still gets its turn. Letting the failure out would defeat the whole point of
                    // ordering strategies by preference: on iOS the OS refuses a multicast send
                    // outright when the app holds no multicast entitlement, and that refusal would
                    // otherwise end discovery instead of falling through to the scan behind it.
                    discoveryLog.d { "composite: $position failed (${throwable.message ?: throwable::class.simpleName})" }
                    if (emitted) return@flow
                    continue
                }

                if (emitted) {
                    discoveryLog.d { "composite: $position found devices" }
                    return@flow
                }
                discoveryLog.d { "composite: $position found nothing" }
            }
        }
}
