package energy.chargee.discovery.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.mapNotNull

/**
 * A [DeviceDiscovery] that runs every device [discovery] finds past [verifier] and emits only
 * those it confirms.
 *
 * Use it to narrow a transport that casts too wide a net — a port scan in particular, where every
 * host on the subnet with that port open looks the same until something speaks the device's
 * protocol to it. The verifier may also enrich a device it keeps; see [DeviceVerifier].
 *
 * Verification happens inline as devices arrive, so candidates are checked one at a time and in
 * the order the underlying discovery reports them. That keeps the scan from opening a connection
 * to every host at once, at the cost of adding each probe to the total discovery time.
 */
class VerifyingDeviceDiscovery(private val discovery: DeviceDiscovery, private val verifier: DeviceVerifier) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        discovery
            .discover()
            .mapNotNull { candidate ->
                verifier.verify(candidate).also { verified ->
                    // A scan that turns up twelve hosts and keeps one looks identical in a log to a
                    // scan that turned up one, unless the rejections are said out loud.
                    discoveryLog.d {
                        if (verified == null) {
                            "verifier: rejected ${candidate.describe()}"
                        } else {
                            "verifier: confirmed ${verified.describe()}"
                        }
                    }
                }
            }
}
