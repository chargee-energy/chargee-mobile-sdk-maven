package energy.chargee.discovery.core

import co.touchlab.kermit.Logger

/**
 * The log every discovery writes to, tagged so it can be isolated from everything else the host app
 * emits — `adb logcat -s ChargeeDiscovery` on Android, a subsystem filter in Console on iOS,
 * stdout on the JVM.
 *
 * Everything here is logged at debug level, which a release build's log view conventionally hides.
 * A consumer that wants it gone entirely can raise the bound with
 * `Logger.setMinSeverity(Severity.Warn)`.
 *
 * Device addresses and ports are logged; nothing a device reports about itself is. A serial number
 * is a hardware identifier, and the system log is readable by more than the app that wrote it.
 */
internal val discoveryLog = Logger.withTag("ChargeeDiscovery")

/**
 * Writes one line to the discovery log, for the discovery modules that live outside this one.
 *
 * A function rather than the [Logger] itself, so that the logging library stays an implementation
 * detail of this module instead of appearing in the published API of every module that logs.
 */
fun logDiscovery(message: () -> String) {
    discoveryLog.d { message() }
}

/** This device as `10.33.2.53:502`, or just the address when the strategy reported no port. */
fun DiscoveredDevice.describe(): String = port?.let { "$ipAddress:$it" } ?: ipAddress
