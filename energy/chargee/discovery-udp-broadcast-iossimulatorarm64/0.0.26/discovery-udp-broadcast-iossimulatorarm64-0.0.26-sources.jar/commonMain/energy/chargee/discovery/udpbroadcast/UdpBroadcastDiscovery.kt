package energy.chargee.discovery.udpbroadcast

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.discovery.core.logDiscovery
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.broadcastAddress
import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.Datagram
import io.ktor.network.sockets.InetSocketAddress
import io.ktor.network.sockets.aSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.io.Buffer
import kotlinx.io.readByteArray
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * Sends [message] to [port] and reports the devices that answer.
 *
 * By default the datagram goes to the subnet-directed broadcast address of the network the phone
 * is on. Pass a [targetAddress] to send somewhere specific instead — a multicast group, say, for a
 * vendor whose discovery is defined on one.
 */
internal class UdpBroadcastDiscovery(
    private val localAddressProvider: LocalAddressProvider,
    private val port: Int,
    private val message: ByteArray,
    private val timeout: Duration,
    private val responseParser: UdpDatagramParser,
    private val targetAddress: String? = null,
) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        channelFlow {
            val localAddress = localAddressProvider.getLocalAddress() ?: return@channelFlow
            val destination = targetAddress ?: localAddress.broadcastAddress()

            val selector = SelectorManager(Dispatchers.IO)
            val socket =
                aSocket(selector).udp().bind(
                    // The wildcard for a broadcast, which is what has always been used and what
                    // still receives a datagram addressed to the subnet broadcast address.
                    //
                    // For an explicit target it is the phone's own address instead. A multicast
                    // group has no route of its own, so the outgoing interface is chosen from the
                    // socket's local address, and binding it makes that choice explicit rather than
                    // leaving it to whatever the routing table happens to hold. A wildcard-bound
                    // socket does reach the group on a machine with an ordinary default route - we
                    // measured that - but SMA discovery has been seen to fail with "No route to
                    // host" on macOS, and a phone with a VPN or more than one interface up is
                    // exactly the case where the default route is not the one we want.
                    localAddress = if (targetAddress == null) null else InetSocketAddress(localAddress.address, 0),
                ) {
                    broadcast = true
                }

            val target = InetSocketAddress(destination, port)

            // Repeated rather than sent once. Neither a broadcast nor a multicast datagram is
            // acknowledged or retransmitted by the link layer, both go out at a low basic rate, and
            // access points commonly rate-limit them or hold them back for a sleeping client, so
            // losing a single datagram is ordinary. Nothing is in flight to wait for once that
            // happens, which is why a longer window does not help and repeating does.
            val broadcaster =
                launch {
                    try {
                        while (true) {
                            socket.send(Datagram(Buffer().apply { write(message) }, target))
                            delay(REBROADCAST_INTERVAL)
                        }
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (throwable: Throwable) {
                        // The OS can refuse the send outright rather than merely dropping it: iOS
                        // does exactly that for a multicast group when the app holds no multicast
                        // entitlement. That is this strategy finding nothing, not an error for the
                        // caller to handle, and [DeviceDiscovery] requires it be reported as such —
                        // so the sender stops and the window closes on its own, with any replies
                        // already in flight still collected.
                        logDiscovery { "udp: cannot send to $destination:$port (${throwable.message ?: throwable::class.simpleName})" }
                    }
                }

            try {
                // A device answering more than one of those broadcasts is still the same device,
                // and emitting it twice would read downstream as two candidates.
                val seenAddresses = mutableSetOf<String>()

                withTimeoutOrNull(timeout) {
                    while (true) {
                        val response = socket.receive()
                        val sourceAddress = (response.address as? InetSocketAddress)?.numericAddress() ?: continue
                        val payload = response.packet.readByteArray()

                        if (seenAddresses.add(sourceAddress)) {
                            responseParser.parse(payload, sourceAddress)?.let { send(it) }
                        }
                    }
                }
            } finally {
                // Before the socket it sends on is closed, and on every path out — an infinite
                // sender left running would hold the flow open.
                broadcaster.cancel()
                socket.close()
                selector.close()
            }
        }.flowOn(Dispatchers.IO)
}

/**
 * How often the broadcast is repeated while the discovery window is open. Ten chances inside a
 * ten-second window rather than one.
 */
private val REBROADCAST_INTERVAL = 1.seconds

/**
 * This address written as a numeric literal, or `null` when it cannot be read as one.
 *
 * Deliberately not [InetSocketAddress.hostname], which gives whatever name the platform has for the
 * peer — on a network with reverse DNS or an mDNS responder that is a host name, not an address. A
 * discovered address is stored as a device's `ip` and dialled directly by the gateway, which has no
 * resolver of its own, so it has to be the literal address.
 */
private fun InetSocketAddress.numericAddress(): String? = resolveAddress()?.toNumericAddress()

/** These raw address bytes as an IPv4 dotted quad or an uncompressed IPv6 literal. */
internal fun ByteArray.toNumericAddress(): String? =
    when (size) {
        IPV4_BYTES -> joinToString(".") { (it.toInt() and 0xFF).toString() }
        IPV6_BYTES -> toIpv6Literal()
        else -> null
    }

private fun ByteArray.toIpv6Literal() =
    (indices step 2).joinToString(":") { index ->
        (((this[index].toInt() and 0xFF) shl 8) or (this[index + 1].toInt() and 0xFF)).toString(16)
    }

private const val IPV4_BYTES = 4
private const val IPV6_BYTES = 16
