package energy.chargee.discovery.udpbroadcast

import energy.chargee.discovery.core.DiscoveredDevice

/**
 * Turns one datagram answered by a device into a [DiscoveredDevice], reading it as raw bytes.
 *
 * This is the parser the discovery actually drives. Implement it for a device whose reply is
 * binary — a magic number, packed fields, anything that would not survive being decoded as text.
 * For a device that answers in text, implement [UdpBroadcastResponseParser] instead, which bridges
 * to this one.
 *
 * [sourceAddress] is the IP the datagram came from; prefer it over any address the device reports
 * about itself, since not every reply carries one. Returning `null` ignores the datagram, which is
 * how a parser filters out replies from devices it does not recognise.
 */
fun interface UdpDatagramParser {
    fun parse(payload: ByteArray, sourceAddress: String): DiscoveredDevice?
}
