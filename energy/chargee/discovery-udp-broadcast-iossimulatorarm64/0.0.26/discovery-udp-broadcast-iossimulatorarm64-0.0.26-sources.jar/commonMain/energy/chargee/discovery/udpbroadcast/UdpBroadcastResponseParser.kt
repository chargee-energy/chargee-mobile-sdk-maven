package energy.chargee.discovery.udpbroadcast

import energy.chargee.discovery.core.DiscoveredDevice

/**
 * Turns one datagram answered by a device into a [DiscoveredDevice], reading it as text.
 *
 * The transport is generic but the reply format never is, so callers that know their device's
 * reply grammar pass a parser alongside the payload to send. [payload] is the datagram decoded as
 * text and [sourceAddress] is the IP the datagram actually came from — prefer it over any address
 * the device reports about itself, since not every reply carries one.
 *
 * Returning `null` ignores the datagram, which is how a parser filters out replies from devices it
 * does not recognise.
 *
 * A reply that is not text — a binary protocol with a magic number or packed fields — would not
 * survive the decode, so those implement [UdpDatagramParser] directly instead.
 */
fun interface UdpBroadcastResponseParser : UdpDatagramParser {
    fun parse(payload: String, sourceAddress: String): DiscoveredDevice?

    /**
     * Decodes the datagram as text and hands it to [parse]. Bytes that are not valid UTF-8 become
     * replacement characters rather than failing, which is why this bridge is only for devices
     * already known to answer in text.
     */
    override fun parse(payload: ByteArray, sourceAddress: String): DiscoveredDevice? = parse(payload.decodeToString(), sourceAddress)
}

/**
 * The parser used when a caller supplies none: reports the device at the address its datagram came
 * from and reads nothing out of the payload.
 *
 * Answering at all is the only thing a reply means without knowing the device's reply grammar, so
 * a caller that wants anything more out of the payload passes its own parser.
 */
internal object DefaultUdpBroadcastResponseParser : UdpBroadcastResponseParser {
    override fun parse(payload: String, sourceAddress: String) = DiscoveredDevice(ipAddress = sourceAddress)
}
