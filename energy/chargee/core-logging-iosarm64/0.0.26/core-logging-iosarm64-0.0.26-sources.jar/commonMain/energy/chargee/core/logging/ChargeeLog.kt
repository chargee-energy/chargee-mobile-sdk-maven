package energy.chargee.core.logging

import kotlin.concurrent.Volatile

/**
 * The sink every line the SDK logs passes through, and the one place that knows whether there is a
 * [ChargeeLogger] to pass it to.
 *
 * It is a process-wide singleton rather than something resolved from the dependency registry,
 * because the places that log are not all built by the registry: the discovery combinators are
 * plain classes and extension functions that brand modules compose by hand, and threading a logger
 * through each of them would put it in the public signature of every one. The SDK installs the
 * logger its factory was given, so a consumer never calls [setLogger] directly unless they want to
 * change it mid-run. Only one logger is installed at a time: creating a second `ChargeeSdk`
 * replaces the first one's logger, which is one more reason to keep a single SDK instance.
 *
 * Every entry point takes the message as a lambda. With no logger installed the lambda is never
 * called, so building the string — and the formatting and allocation behind it — costs nothing in
 * an app that logs nothing.
 */
object ChargeeLog {
    @Volatile
    private var logger: ChargeeLogger? = null

    /**
     * Installs [logger] as the destination for everything the SDK logs from here on, or stops the
     * SDK logging altogether when it is `null`.
     *
     * Called by the SDK with the logger passed to its factory. Lines already written are not
     * replayed to a logger installed afterwards.
     */
    fun setLogger(logger: ChargeeLogger?) {
        this.logger = logger
    }

    /**
     * Writes [message] at [level] under [tag], with [throwable] when the line reports a failure
     * that carried one.
     *
     * [message] is evaluated only when a logger is installed.
     */
    fun log(level: LogLevel, tag: String, throwable: Throwable? = null, message: () -> String) {
        val logger = logger ?: return
        logger.log(level, tag, message(), throwable)
    }

    /**
     * Writes [message] at [LogLevel.Debug] under [tag]. See [log].
     */
    fun debug(tag: String, throwable: Throwable? = null, message: () -> String) = log(LogLevel.Debug, tag, throwable, message)

    /**
     * Writes [message] at [LogLevel.Info] under [tag]. See [log].
     */
    fun info(tag: String, throwable: Throwable? = null, message: () -> String) = log(LogLevel.Info, tag, throwable, message)

    /**
     * Writes [message] at [LogLevel.Warning] under [tag]. See [log].
     */
    fun warning(tag: String, throwable: Throwable? = null, message: () -> String) = log(LogLevel.Warning, tag, throwable, message)

    /**
     * Writes [message] at [LogLevel.Error] under [tag]. See [log].
     */
    fun error(tag: String, throwable: Throwable? = null, message: () -> String) = log(LogLevel.Error, tag, throwable, message)
}
