package energy.chargee.core.logging

/**
 * The severity of a line the SDK logs, for a [ChargeeLogger] to map onto whatever levels the host
 * app's own logging has.
 *
 * The SDK logs almost everything at [Debug]: it narrates what it is doing so a flow can be
 * reconstructed afterwards, not because each line needs attention. Treat the higher levels as the
 * exception rather than the norm.
 */
enum class LogLevel {
    /** Detail that only matters while diagnosing a flow — where nearly everything the SDK logs lands. */
    Debug,

    /** A milestone worth noting in an otherwise ordinary run. */
    Info,

    /** Something unexpected that the SDK recovered from and carried on past. */
    Warning,

    /** A failure the SDK could not recover from. */
    Error,
}
