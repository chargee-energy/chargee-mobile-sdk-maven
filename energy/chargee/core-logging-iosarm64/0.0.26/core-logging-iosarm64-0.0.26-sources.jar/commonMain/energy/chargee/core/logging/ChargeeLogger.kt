package energy.chargee.core.logging

/**
 * Receives the lines the SDK logs, so that where they end up is the host app's decision rather than
 * the SDK's.
 *
 * Implemented by the SDK consumer and handed to the platform factory — `ChargeeSdk(context,
 * tokenProvider, environment, logger)` on Android, `createChargeeSdk(environment:tokenProvider:logger:)`
 * on iOS. It is optional: with no logger the SDK logs nothing, and does not even build the message
 * strings.
 *
 * An implementation is called from whichever coroutine produced the line, which is not the main
 * thread and may be several threads at once, so it has to tolerate concurrent calls. It should also
 * return quickly — the call is made inline, in the middle of discovery or onboarding.
 *
 * ```kotlin
 * val sdk = ChargeeSdk(context, tokenProvider) { level, tag, message, throwable ->
 *     Log.println(level.toAndroidPriority(), tag, message + (throwable?.let { "\n$it" } ?: ""))
 * }
 * ```
 *
 * Nothing the SDK logs identifies a device or a person: addresses and ports appear, serial numbers
 * and credentials do not. An implementation that forwards lines off the device inherits that
 * guarantee and should not widen it.
 */
fun interface ChargeeLogger {
    /**
     * Writes one [message] at [level], attributed to the SDK subsystem named by [tag] — `"ChargeeDiscovery"`
     * for device discovery, for instance — with [throwable] set when the line reports a failure
     * that carried one.
     */
    fun log(level: LogLevel, tag: String, message: String, throwable: Throwable?)
}
