package energy.chargee.discovery.portscan

import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.aSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration

/**
 * Answers whether a TCP port on a host accepts a connection.
 *
 * The one piece of real I/O the discovery strategies in this module do, behind a function so the
 * scanning logic around it — which hosts are tried, how many at once — can be exercised without
 * a network.
 */
internal fun interface PortProbe {
    suspend fun isOpen(ipAddress: String, port: Int): Boolean
}

/**
 * The [PortProbe] that opens a real socket, giving up on a host that has not accepted within
 * [connectionTimeout].
 *
 * The timeout is the only thing bounding a sweep: an address with nothing at it never refuses the
 * connection, it just stays silent, so every dead address in the range costs the full
 * [connectionTimeout]. That is why [PortScanDiscovery] probes several at a time.
 */
internal class SocketPortProbe(private val connectionTimeout: Duration) : PortProbe {
    override suspend fun isOpen(ipAddress: String, port: Int): Boolean =
        withContext(Dispatchers.IO) {
            val selector = SelectorManager(Dispatchers.IO)
            try {
                withTimeoutOrNull(connectionTimeout) {
                    runCatching {
                        aSocket(selector).tcp().connect(ipAddress, port).close()
                    }.isSuccess
                } ?: false
            } finally {
                selector.close()
            }
        }
}
