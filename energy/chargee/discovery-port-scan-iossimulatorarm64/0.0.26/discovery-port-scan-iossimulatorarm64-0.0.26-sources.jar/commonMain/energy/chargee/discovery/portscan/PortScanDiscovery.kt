package energy.chargee.discovery.portscan

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.hostAddresses
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore

/**
 * How many hosts are probed at the same time.
 *
 * A sweep is dominated by addresses with nothing at them, which can only fail by timing out, so a
 * sequential scan costs the connection timeout times the size of the subnet — on a /24 that is
 * 254 timeouts end to end, which forces the timeout down to a value too tight for slower devices
 * to answer within. Probing in parallel decouples the two: the timeout can be generous enough for
 * the hardware while the sweep still finishes in seconds.
 *
 * The number is a compromise. Each probe holds a socket and its own selector for as long as it
 * runs, every unresolved address costs an ARP broadcast that some access points rate-limit, and a
 * phone's Wi-Fi link is also the thing being measured — too many at once distorts the very
 * timings the connection timeout is judging.
 */
private const val MAX_CONCURRENT_PROBES = 32

internal class PortScanDiscovery(
    private val localAddressProvider: LocalAddressProvider,
    private val port: Int,
    private val probe: PortProbe,
    private val maxConcurrentProbes: Int = MAX_CONCURRENT_PROBES,
) : DeviceDiscovery {
    /**
     * Sweeps the local subnet, emitting each host that accepts a connection on [port] as it is
     * found.
     *
     * Devices arrive in the order they answer rather than in address order, since the hosts are
     * probed concurrently. The flow still completes only once every address has been tried.
     *
     * The permit is taken before the probe is launched rather than inside it, so the number of
     * live coroutines is bounded by [maxConcurrentProbes] too, not just the number of open
     * sockets. Launching one per address up front would be fine for the /24 this normally runs
     * on and ruinous on the wider prefixes a guest or corporate network hands out — a /16 is
     * 65,534 addresses.
     */
    override fun discover(): Flow<DiscoveredDevice> =
        channelFlow {
            val local = localAddressProvider.getLocalAddress() ?: return@channelFlow
            val permits = Semaphore(maxConcurrentProbes)

            for (ipAddress in local.hostAddresses()) {
                permits.acquire()
                launch {
                    try {
                        if (probe.isOpen(ipAddress, port)) {
                            send(DiscoveredDevice(ipAddress, port))
                        }
                    } finally {
                        permits.release()
                    }
                }
            }
        }
}
