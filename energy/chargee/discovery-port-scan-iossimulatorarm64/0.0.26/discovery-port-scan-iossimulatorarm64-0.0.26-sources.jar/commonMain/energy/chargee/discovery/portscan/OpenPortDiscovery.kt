package energy.chargee.discovery.portscan

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Probes one known host across [possiblePorts], in order.
 *
 * Deliberately sequential, unlike [PortScanDiscovery]: this walks a handful of candidate ports on
 * a single device rather than a whole subnet, so there is nothing to gain from overlapping them
 * and the order the device's ports are reported in stays predictable.
 */
internal class OpenPortDiscovery(private val ipAddress: String, private val possiblePorts: List<Int>, private val probe: PortProbe) :
    DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            for (port in possiblePorts) {
                if (probe.isOpen(ipAddress, port)) {
                    emit(DiscoveredDevice(ipAddress, port))
                }
            }
        }
}
