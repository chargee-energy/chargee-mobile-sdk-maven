package energy.chargee.discovery.portscan

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

/**
 * How long a host is given to accept a connection when the caller names no timeout of its own.
 *
 * Deliberately generous. The value used to be 100 ms, which was chosen when a sweep was
 * sequential and every extra millisecond cost 254 of them; a Growatt inverter was then measured
 * answering at around 120 ms, so that default was quietly rejecting hardware that was merely
 * slow. Now that [PortScanDiscovery] probes concurrently the timeout no longer sets the length of
 * the sweep, only how long one unresponsive address is waited on, so the margin is close to free
 * and a device that answers late is the failure worth avoiding.
 */
private val DEFAULT_CONNECTION_TIMEOUT: Duration = 500.milliseconds

val portScanDiscoveryModule =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE) { parameters ->
            PortScanDiscovery(
                localAddressProvider = get(),
                port = parameters.get(0),
                probe = SocketPortProbe(parameters.getOrNull(1) ?: DEFAULT_CONNECTION_TIMEOUT),
            )
        }
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.OPEN_PORT_DISCOVERY_TYPE) { parameters ->
            OpenPortDiscovery(
                ipAddress = parameters.get(0),
                possiblePorts = parameters.get(1),
                probe = SocketPortProbe(parameters.getOrNull(2) ?: DEFAULT_CONNECTION_TIMEOUT),
            )
        }
    }
