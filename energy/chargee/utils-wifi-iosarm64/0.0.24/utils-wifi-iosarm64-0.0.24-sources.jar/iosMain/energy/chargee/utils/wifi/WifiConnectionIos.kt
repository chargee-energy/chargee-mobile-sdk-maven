package energy.chargee.utils.wifi

import energy.chargee.utils.concurrency.ResumeOnce
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import platform.Foundation.NSError
import platform.NetworkExtension.NEHotspotConfiguration
import platform.NetworkExtension.NEHotspotConfigurationErrorAlreadyAssociated
import platform.NetworkExtension.NEHotspotConfigurationManager
import platform.NetworkExtension.NEHotspotNetwork
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * How long to wait for `applyConfiguration` to report back. Generous because the system may put a
 * "Join Wi-Fi Network?" prompt in front of the user first, and the callback only fires once they
 * have answered it.
 */
private val APPLY_TIMEOUT: Duration = 60.seconds

/** How long to wait for `fetchCurrent`, which is expected to answer immediately. */
private val SSID_TIMEOUT: Duration = 5.seconds

/**
 * The Darwin [WifiConnection], joining networks through `NEHotspotConfigurationManager` and
 * deriving the gateway from the address [localAddressProvider] reports on the joined network.
 *
 * **[connect] reports an installed configuration, not a joined network**, and Darwin offers no
 * signal that tells the two apart — see there. Callers that need to know whether the device really
 * is on the access point verify it by reaching the device across it.
 *
 * Every call into `NetworkExtension` here is bounded. The framework delivers its results through
 * completion handlers that are not guaranteed to fire — a handler that never arrives would
 * otherwise suspend the caller indefinitely, with no event and no way out.
 */
class WifiConnectionIos(private val localAddressProvider: LocalAddressProvider) : WifiConnection {
    /** Creates an instance backed by [LocalAddressProviderIos]. */
    constructor() : this(LocalAddressProviderIos())

    /**
     * The SSID this instance has a configuration installed for, so [disconnect] removes the
     * network this instance joined rather than whichever one the device happens to be on. The two
     * are not the same once the system has moved on, and removing a configuration for a network
     * we never applied is at best a no-op.
     */
    private var appliedSsid: String? = null

    /**
     * Installs a configuration for [configuration] and reports whether the system accepted it.
     *
     * **A `true` from here is not a join.** `applyConfiguration` only reports errors raised by the
     * Network Extension framework itself; whatever the Wi-Fi subsystem underneath it rejects — a
     * wrong passphrase, an access point out of range — is shown to the user as a system alert
     * while the completion handler still reports success. Nothing on this platform closes that
     * gap. [getSsid] answers for the network the app holds a configuration for and goes on naming
     * it after an association that never happened. The interface address cannot stand in for it
     * either: an access point on the same subnet as the network the device came from can hand out
     * the address it already had, and `192.168.0.x` and `192.168.1.x` are common enough on both
     * sides of that comparison to make it a coin flip rather than a check. A caller that needs the
     * answer gets it by reaching the device over the network it asked for.
     *
     * An apply that fails — or never answers — takes the configuration back out again, because it
     * is installed whether or not the association follows and a leftover entry makes the next
     * attempt, the one carrying a corrected passphrase, report `alreadyAssociated` against the
     * stale one and never apply the new passphrase. For the same reason a caller that establishes
     * the join did not happen must call [disconnect] itself.
     */
    override suspend fun connect(configuration: WifiConfiguration, saveNetwork: Boolean): Boolean {
        val hotspotConfiguration =
            if (configuration.password != null) {
                NEHotspotConfiguration(
                    sSID = configuration.ssid,
                    passphrase = configuration.password,
                    isWEP = configuration.auth == WifiAuth.Wep,
                )
            } else {
                NEHotspotConfiguration(sSID = configuration.ssid)
            }.apply { joinOnce = !saveNetwork }

        // Claim the SSID before the outcome is known: an apply that timed out says nothing either
        // way, and the configuration it installed still has to be removable. Removing a
        // configuration this app never installed is a no-op.
        appliedSsid = configuration.ssid
        if (applyConfiguration(hotspotConfiguration)) return true

        disconnect()
        return false
    }

    override suspend fun disconnect(): Boolean {
        val ssid = appliedSsid ?: return false

        NEHotspotConfigurationManager.sharedManager.removeConfigurationForSSID(ssid)
        appliedSsid = null
        return true
    }

    /**
     * The SSID `NEHotspotNetwork.fetchCurrent` reports, or `null` when it answers with nothing or
     * does not answer at all.
     *
     * Treat the result as the network this app configured rather than the one the device is on:
     * the two diverge after a join that failed, and [connect] documents what that rules out.
     */
    override suspend fun getSsid(): String? =
        withTimeoutOrNull(SSID_TIMEOUT) {
            suspendCancellableCoroutine { continuation ->
                val gate = ResumeOnce(continuation)
                NEHotspotNetwork.fetchCurrentWithCompletionHandler { gate.resumeOnce(it?.SSID) }
            }
        }

    /**
     * Returns the first host address of the subnet the joined network placed this device on,
     * which is where consumer access points — including the inverter and charger APs this SDK
     * onboards — put their own interface.
     *
     * Darwin exposes no supported API for the gateway of a specific interface. Reading the
     * routing table would not answer this question either: the access points joined during
     * onboarding carry no internet, so the system default route stays on another transport and
     * would yield that transport's gateway. Deriving from the address the access point itself
     * assigned cannot name a host off that subnet, at the cost of assuming the access point
     * takes the first address on it.
     */
    override suspend fun getGatewayAddress(): String? = localAddressProvider.getLocalAddress()?.hostAddresses()?.firstOrNull()

    /**
     * Installs [configuration], returning `true` once it is in place and `false` if the system
     * refused it or never answered.
     *
     * `alreadyAssociated` counts as installed: it reports a configuration for this SSID that is
     * already present, which includes one this instance left behind on an earlier failed attempt.
     * Like every other answer this call can give, it says nothing about whether the device is on
     * that network.
     */
    private suspend fun applyConfiguration(configuration: NEHotspotConfiguration): Boolean =
        withTimeoutOrNull(APPLY_TIMEOUT) {
            suspendCancellableCoroutine { continuation ->
                val gate = ResumeOnce(continuation)
                NEHotspotConfigurationManager.sharedManager.applyConfiguration(configuration) { error ->
                    gate.resumeOnce(error !is NSError || error.code == NEHotspotConfigurationErrorAlreadyAssociated)
                }
            }
        } ?: false
}
