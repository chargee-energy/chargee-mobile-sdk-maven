package energy.chargee.utils.bluetooth

import com.juul.kable.ServicesDiscoveredPeripheral

internal actual suspend fun ServicesDiscoveredPeripheral.negotiateMtu() {
    // A peripheral that refuses to negotiate is not a connection failure: the link still works at
    // the default MTU, and the short writes that fit it still go through.
    runCatching { requestMtu(PREFERRED_MTU) }
}
