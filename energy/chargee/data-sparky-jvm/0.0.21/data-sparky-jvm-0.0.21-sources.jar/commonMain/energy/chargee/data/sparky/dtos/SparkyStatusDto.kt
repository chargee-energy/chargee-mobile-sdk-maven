package energy.chargee.data.sparky.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class SparkyStatusDto(
    val latestMessage: String? = null,
    val ip: String? = null,
    val rssi: String? = null,
    val meterNumberElec: String? = null,
    val meterNumberGas: String? = null,
    val hardwareVersion: String? = null,
    val firmwareVersion: String? = null,
    val p1Version: String? = null,
)
