package energy.chargee.data.sparky.converters

import energy.chargee.data.sparky.dtos.SparkyStatusDto
import energy.chargee.data.sparky.models.SparkyStatus
import kotlin.time.Instant

internal fun SparkyStatusDto.asSparkyStatus() =
    SparkyStatus(
        latestMessage?.let(Instant::parse),
        ip,
        rssi?.toIntOrNull(),
        meterNumberElec,
        meterNumberGas,
        hardwareVersion,
        firmwareVersion,
        p1Version,
    )
