package energy.chargee.data.sparky

import energy.chargee.core.di.module
import energy.chargee.data.sparky.clients.SparkyApiClient
import energy.chargee.data.sparky.repositories.SparkyApiRepository
import energy.chargee.data.sparky.repositories.SparkyRepository

val sparkyDataModule =
    module {
        factory { SparkyApiClient(get()) }
        factory<SparkyRepository> { SparkyApiRepository(get(), get()) }
    }
