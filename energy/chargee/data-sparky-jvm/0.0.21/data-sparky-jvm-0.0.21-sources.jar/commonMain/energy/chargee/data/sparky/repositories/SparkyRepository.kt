package energy.chargee.data.sparky.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.data.sparky.models.SparkyStatus
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to Sparky device registration for an address.
 */
@Repository
@ObjCName("_SparkyRepository")
interface SparkyRepository {
    /**
     * Fetches all Sparkies for [addressUuid].
     */
    suspend fun getSparkies(addressUuid: String): Result<List<ChargeeDevice>, ApiError>

    /**
     * Registers a new Sparky device with [serialNumber] to the address identified by [addressUuid].
     */
    suspend fun createSparky(addressUuid: String, serialNumber: String): Result<ChargeeDevice, ApiError>

    /**
     * Fetches the Sparky identified by [sparkyUuid] for [addressUuid].
     */
    suspend fun getSparky(addressUuid: String, sparkyUuid: String): Result<ChargeeDevice, ApiError>

    /**
     * Deletes the Sparky identified by [sparkyUuid] for [addressUuid].
     */
    suspend fun deleteSparky(addressUuid: String, sparkyUuid: String): Result<Unit, ApiError>

    /**
     * Fetches the current [SparkyStatus] for the device identified by [sparkyUuid] at the address
     * identified by [addressUuid].
     */
    suspend fun getSparkyStatus(addressUuid: String, sparkyUuid: String): Result<SparkyStatus, ApiError>
}
