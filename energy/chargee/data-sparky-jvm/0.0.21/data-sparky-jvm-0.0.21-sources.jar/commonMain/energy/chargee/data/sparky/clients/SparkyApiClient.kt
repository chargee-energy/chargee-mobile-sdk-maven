package energy.chargee.data.sparky.clients

import energy.chargee.data.sparky.dtos.SparkyStatusDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

internal class SparkyApiClient(val httpClient: HttpClient) {
    suspend fun getSparkyStatus(addressUuid: String, sparkyUuid: String): SparkyStatusDto =
        httpClient.get("/v5/addresses/$addressUuid/sparkies/$sparkyUuid/status").body()
}
