package energy.chargee.data.sparky.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * Status snapshot of a Sparky device. All fields are nullable — a `null` value means the device
 * has not yet reported that value.
 *
 * [latestMessage] is the UTC timestamp of the most recent message; [ip] is the device's local
 * IPv4 address; [rssi] is the Wi-Fi signal strength in dBm at the time of the last message.
 *
 * [meterNumberElectricity] and [meterNumberGas] are the meter numbers reported by the connected
 * electricity and gas meters. [hardwareVersion] and [firmwareVersion] identify the revisions of
 * the Sparky dongle itself, while [p1Version] is the DSMR P1 version reported by the smart meter
 * it is plugged into.
 */
@Serializable
@ObjCName("_SparkyStatus")
data class SparkyStatus(
    val latestMessage: Instant? = null,
    val ip: String? = null,
    val rssi: Int? = null,
    val meterNumberElectricity: String? = null,
    val meterNumberGas: String? = null,
    val hardwareVersion: String? = null,
    val firmwareVersion: String? = null,
    val p1Version: String? = null,
)
