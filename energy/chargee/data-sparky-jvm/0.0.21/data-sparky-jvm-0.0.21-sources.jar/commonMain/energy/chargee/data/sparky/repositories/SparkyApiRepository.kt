package energy.chargee.data.sparky.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.sparky.clients.SparkyApiClient
import energy.chargee.data.sparky.converters.asSparkyStatus
import energy.chargee.data.sparky.models.SparkyStatus
import energy.chargee.utils.result.Result

internal class SparkyApiRepository(
    private val sparkyApiClient: SparkyApiClient,
    private val chargeeDeviceRepository: ChargeeDeviceRepository,
) : SparkyRepository {
    override suspend fun getSparkies(addressUuid: String): Result<List<ChargeeDevice>, ApiError> =
        chargeeDeviceRepository.getChargeeDevices(addressUuid, ChargeeDeviceType.Sparky)

    override suspend fun createSparky(addressUuid: String, serialNumber: String): Result<ChargeeDevice, ApiError> =
        chargeeDeviceRepository.createChargeeDevice(addressUuid, ChargeeDeviceType.Sparky, serialNumber)

    override suspend fun getSparky(addressUuid: String, sparkyUuid: String): Result<ChargeeDevice, ApiError> =
        chargeeDeviceRepository.getChargeeDevice(addressUuid, ChargeeDeviceType.Sparky, sparkyUuid)

    override suspend fun deleteSparky(addressUuid: String, sparkyUuid: String): Result<Unit, ApiError> =
        chargeeDeviceRepository.deleteChargeeDevice(addressUuid, ChargeeDeviceType.Sparky, sparkyUuid)

    override suspend fun getSparkyStatus(addressUuid: String, sparkyUuid: String): Result<SparkyStatus, ApiError> =
        runApi { sparkyApiClient.getSparkyStatus(addressUuid, sparkyUuid).asSparkyStatus() }
}
