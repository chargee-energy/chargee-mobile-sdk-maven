package energy.chargee.onboarding.peblar.clients

import energy.chargee.onboarding.core.InvalidCredentialsException

/**
 * Client for the local HTTP API exposed by a Peblar charger.
 *
 * Unlike solar-edge, Peblar chargers are reachable directly from the Chargee device's network,
 * so this client only issues HTTP requests to the discovered [ipAddress] and does not manage
 * a Wi-Fi association.
 *
 * Every call reports failure by throwing. The exception is the only description of what went
 * wrong, and the configuration step carries it on the failure it reports so it reaches whatever
 * the consumer is monitoring with — a client that reduced it to `false` would throw that away.
 */
interface PeblarClient {
    /**
     * Authenticates against the charger at [ipAddress] with [password].
     *
     * @throws InvalidCredentialsException if the charger rejected the password, which the step
     *   reports back to the user rather than as something that went wrong.
     */
    suspend fun login(ipAddress: String, password: String)

    /**
     * Fetches the product model name from the charger at [ipAddress], or `null` if the request
     * fails or the charger does not report one. Best-effort — the returned model is written to
     * the context as decoration and does not gate onboarding, and it is the one call here that
     * swallows its failure.
     */
    suspend fun getDeviceModel(ipAddress: String): String?

    /**
     * Enables Modbus TCP on the charger at [ipAddress] in ReadWrite mode. Returns `true` when
     * the charger's response confirms Modbus is enabled and allowed, and `false` when it answered
     * without applying the change — a refused request throws instead.
     */
    suspend fun enableModbusTcp(ipAddress: String): Boolean
}
