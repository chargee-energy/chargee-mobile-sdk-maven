package energy.chargee.onboarding.peblar.clients

import energy.chargee.onboarding.core.InvalidCredentialsException
import energy.chargee.onboarding.core.logOnboarding
import energy.chargee.onboarding.peblar.dtos.PeblarLoginDto
import energy.chargee.onboarding.peblar.dtos.PeblarSystemInfoDto
import energy.chargee.onboarding.peblar.dtos.PeblarUserConfigRequestDto
import energy.chargee.onboarding.peblar.dtos.PeblarUserConfigResponseDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.ResponseException
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.cookies.HttpCookies
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.patch
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNamingStrategy
import kotlin.coroutines.cancellation.CancellationException

class PeblarLocalApiClient : PeblarClient {
    @OptIn(ExperimentalSerializationApi::class)
    private val httpClient: HttpClient by lazy {
        HttpClient {
            expectSuccess = true
            defaultRequest {
                contentType(ContentType.Application.Json)
            }
            install(HttpCookies)
            install(ContentNegotiation) {
                json(
                    Json {
                        ignoreUnknownKeys = true
                        namingStrategy =
                            JsonNamingStrategy { _, _, serialName ->
                                serialName.replaceFirstChar { it.uppercaseChar() }
                            }
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 15_000
            }
        }
    }

    override suspend fun login(ipAddress: String, password: String) {
        try {
            httpClient.post("http://$ipAddress/api/v1/auth/login") { setBody(PeblarLoginDto(password)) }
        } catch (exception: ResponseException) {
            // The one status worth naming. Everything else travels as it is: the step reports it
            // as the cause of the failure, and a type is all `ApiError` would have added before
            // the step unwrapped it again.
            if (exception.response.status == HttpStatusCode.Unauthorized) {
                throw InvalidCredentialsException("The Peblar charger rejected the password")
            }
            throw exception
        }
    }

    override suspend fun getDeviceModel(ipAddress: String): String? =
        try {
            httpClient.get("http://$ipAddress/api/v1/system/info").body<PeblarSystemInfoDto>().productModelName
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (exception: Exception) {
            // The one failure this client is allowed to swallow: the model is decoration the
            // context carries, and onboarding does not depend on it. Debug, so a charger that
            // does not report one is a breadcrumb rather than something to look into.
            logOnboarding(throwable = exception) { "peblar: could not read the device model" }
            null
        }

    override suspend fun enableModbusTcp(ipAddress: String): Boolean {
        val request = PeblarUserConfigRequestDto(modbusServerAccessMode = "ReadWrite", modbusServerEnable = true)
        val config =
            httpClient
                .patch("http://$ipAddress/api/v1/config/user") { setBody(request) }
                .body<PeblarUserConfigResponseDto>()

        val enabled =
            config.modbusServerAccessMode == request.modbusServerAccessMode &&
                config.modbusServerEnable == request.modbusServerEnable &&
                config.modbusServerAllowed

        // The step turns `false` into a failure but cannot say what the charger came back with,
        // which is the whole difference between a charger that declined and one that never
        // answered.
        if (!enabled) {
            logOnboarding {
                "peblar: charger did not confirm Modbus — mode=${config.modbusServerAccessMode}, " +
                    "enabled=${config.modbusServerEnable}, allowed=${config.modbusServerAllowed}"
            }
        }

        return enabled
    }
}
