package energy.chargee.onboarding.peblar.steps

import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.InvalidCredentialsException
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.peblar.PeblarOnboardingContext
import energy.chargee.onboarding.peblar.clients.PeblarClient
import kotlin.coroutines.cancellation.CancellationException

internal class ConfigureDeviceStep(private val client: PeblarClient) :
    OnboardingFlow.Step<LocalDeviceStepId, PeblarOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: PeblarOnboardingContext): Result<PeblarOnboardingContext> {
        val selectedDevice =
            requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before ConfigureDeviceStep runs" }
        val password =
            context.password ?: return Result.InputRequired(context, advanceAfterInput = false)

        // Whether a failure carries a cause is what tells a monitoring logger a defect from an
        // outcome the flow is designed to produce — see the Logging section of the README.
        return try {
            client.login(selectedDevice.ipAddress, password)

            if (!client.enableModbusTcp(selectedDevice.ipAddress)) {
                // The charger answered and did not apply the change, so there is no exception to
                // report it with; make one, or the failure is indistinguishable from the expected
                // ones below.
                return Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(),
                    DeviceConfigurationException("Peblar accepted the Modbus TCP request without enabling it"),
                )
            }

            Result.Success(context.copy(model = client.getDeviceModel(selectedDevice.ipAddress)))
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: InvalidCredentialsException) {
            // The flow asks for the password again, so this is the user's to correct rather than
            // anyone's to look into — reported without a cause on purpose.
            Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true))
        } catch (exception: Exception) {
            Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(), exception)
        }
    }
}
