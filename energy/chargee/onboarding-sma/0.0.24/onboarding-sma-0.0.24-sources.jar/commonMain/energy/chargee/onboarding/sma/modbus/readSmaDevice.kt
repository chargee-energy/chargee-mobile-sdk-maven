package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.localdevice.modbus.ModbusClient
import energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException
import energy.chargee.onboarding.localdevice.modbus.uint8
import energy.chargee.onboarding.sma.SmaConfig
import energy.chargee.onboarding.sma.SmaPlatform
import kotlin.coroutines.cancellation.CancellationException

/**
 * Asks the inverter at [host]:[port] who it is, resolving the Modbus unit first where the
 * generation allows it.
 *
 * Two connections rather than one, because [ModbusClient] fixes its unit at construction and the
 * lookup lives on a different unit from the register map. They are opened one after the other and
 * each is closed before the next, which is also the advice SMA gives: an inverter serves only about
 * five connections and blocks clients that leave them open.
 *
 * A [SmaPlatform.WebConnect] inverter is asked; its unit ID is configurable and 3 is only the
 * factory default. A [SmaPlatform.EnnexOs] device has no lookup register and a unit scheme fixed by
 * the platform, so it is not asked.
 */
internal suspend fun readSmaDevice(host: String, port: Int = SmaConfig.DEFAULT_PORT, platform: SmaPlatform): SmaDeviceReading =
    try {
        val unitId =
            when (platform) {
                SmaPlatform.WebConnect -> {
                    modbusClient(
                        host,
                        port,
                        SmaConfig.LOOKUP_UNIT_ID,
                    ).connect { resolveSmaUnitId(::readHoldingRegisters) }
                }

                SmaPlatform.EnnexOs -> {
                    null
                }
            } ?: SmaConfig.DEFAULT_UNIT_ID

        val identity = modbusClient(host, port, unitId).connect { readSmaIdentity(::readHoldingRegisters) }

        SmaDeviceReading.Identified(unitId, identity)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: ModbusUnreachableException) {
        // Nothing is listening, or it stopped answering. On an SMA inverter the ordinary reason is
        // that the Modbus server has never been switched on.
        SmaDeviceReading.Unreachable
    } catch (failure: IllegalStateException) {
        // Something answered and refused: a Modbus exception, or framing this client cannot read.
        SmaDeviceReading.Refused(failure.message ?: "the device refused the register map")
    } catch (_: Exception) {
        SmaDeviceReading.Unreachable
    }

private fun modbusClient(host: String, port: Int, unitId: Int) =
    ModbusClient(
        host = host,
        port = port,
        unitId = unitId.uint8,
        responseTimeout = SmaConfig.VERIFICATION_RESPONSE_TIMEOUT,
        maxAttempts = SmaConfig.VERIFICATION_MAX_ATTEMPTS,
        connectTimeout = SmaConfig.VERIFICATION_CONNECT_TIMEOUT,
    )
