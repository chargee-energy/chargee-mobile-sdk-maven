package energy.chargee.onboarding.huawei.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.huawei.HuaweiOnboardingContext
import energy.chargee.onboarding.huawei.clients.HuaweiClient
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

internal class ConnectLocalWifiStep(private val client: HuaweiClient) :
    OnboardingFlow.Step<LocalDeviceStepId, HuaweiOnboardingContext>() {
    override val id = LocalDeviceStepId.ConnectLocalAp

    override suspend fun execute(context: HuaweiOnboardingContext): Result<HuaweiOnboardingContext> {
        val wifiConfiguration =
            context.wifiConfiguration ?: return Result.InputRequired(
                context,
                advanceAfterInput = false,
            )

        return if (client.connect(wifiConfiguration)) {
            Result.Success(context)
        } else {
            Result.Failure(context, LocalDeviceErrorCode.WifiConnectionFailure)
        }
    }

    override suspend fun onCancelled(context: HuaweiOnboardingContext) {
        client.disconnect()
    }
}
