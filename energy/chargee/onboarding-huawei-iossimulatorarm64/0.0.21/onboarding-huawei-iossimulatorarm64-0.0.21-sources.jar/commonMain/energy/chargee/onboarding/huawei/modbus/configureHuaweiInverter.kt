package energy.chargee.onboarding.huawei.modbus

import energy.chargee.onboarding.huawei.HuaweiLocalEndpoint
import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.onboarding.localdevice.modbus.ModbusClient
import energy.chargee.onboarding.localdevice.modbus.ModbusConnection
import energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException
import energy.chargee.onboarding.localdevice.modbus.decodeToIpv4
import energy.chargee.onboarding.localdevice.modbus.uint16
import energy.chargee.onboarding.localdevice.modbus.uint8
import kotlin.coroutines.cancellation.CancellationException

/** Modbus unit id Huawei inverters answer on over their own access point. */
private val LOCAL_CONFIG_UNIT_ID = 0.uint8

/** Holding register that tells the inverter to apply the network configuration it was given. */
private val APPLY_NETWORK_CONFIG_REGISTER = 43291.uint16

/** First of the two holding registers holding the IPv4 address the inverter will use on the LAN. */
private val LAN_IP_ADDRESS_REGISTER = 43198.uint16

/**
 * Runs the Huawei configuration exchange against the inverter at [endpoint]: authenticates with
 * [username] and [password], applies the network configuration, and reads back the IPv4 address
 * the inverter will use on the customer's LAN.
 *
 * Returns `null` — rather than [HuaweiResponse.Failed] — when nothing answered at [endpoint], so
 * a caller walking a list of candidate endpoints can tell "wrong address" apart from "right
 * address, exchange failed" and move on to the next candidate. An endpoint that did answer is
 * always reported as a [HuaweiResponse], including [HuaweiResponse.Unauthenticated] for rejected
 * credentials.
 */
internal suspend fun configureHuaweiInverter(endpoint: HuaweiLocalEndpoint, username: String, password: String): HuaweiResponse? =
    try {
        ModbusClient(endpoint.host, endpoint.port, unitId = LOCAL_CONFIG_UNIT_ID)
            .connect { runConfigurationExchange(username, password) }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: Exception) {
        // A connect timeout or a refused connection — nothing is listening at this endpoint.
        null
    }

private suspend fun ModbusConnection.runConfigurationExchange(username: String, password: String): HuaweiResponse? {
    try {
        authenticateHuaweiInverter(username, password)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: ModbusUnreachableException) {
        // The port accepted the connection but nothing spoke Modbus back — treat it as the wrong
        // endpoint rather than as a rejected login.
        return null
    } catch (_: IllegalStateException) {
        return HuaweiResponse.Unauthenticated
    }

    // Past the handshake the inverter has proven it is the device we are looking for, so every
    // remaining failure is a configuration failure rather than a wrong endpoint.
    return try {
        try {
            writeSingleRegister(APPLY_NETWORK_CONFIG_REGISTER, 1.uint16)
        } catch (_: IllegalStateException) {
            // Not every model has this register — the SUN2000L-4.6KTL refuses the write with
            // Modbus exception 0x02 yet already reports its LAN address — so let the read decide.
        }
        val ipAddress = readHoldingRegisters(LAN_IP_ADDRESS_REGISTER, 2.uint16).decodeToIpv4()
        ipAddress?.let { HuaweiResponse.Success(it) } ?: HuaweiResponse.Failed
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: RuntimeException) {
        HuaweiResponse.Failed
    }
}
