package energy.chargee.onboarding.huawei.modbus

import energy.chargee.onboarding.huawei.HuaweiLocalEndpoint
import energy.chargee.onboarding.localdevice.modbus.ModbusClient
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * How long to wait for the TCP handshake. Shorter than [ModbusClient]'s default because the
 * inverter is a single hop away over its own access point, and because a candidate that is not
 * there is paid for once per address and port.
 */
private val PROBE_CONNECT_TIMEOUT: Duration = 3.seconds

/**
 * Reports whether anything accepts a TCP connection at [endpoint], which is how the flow confirms
 * the phone really did end up on the inverter's access point before it moves on.
 *
 * The join itself cannot be trusted to answer that on iOS — `NEHotspotConfigurationManager`
 * reports a rejected passphrase to the user rather than to the app, and the current-SSID API keeps
 * naming the configured network afterwards — so reaching the inverter is the first reliable
 * evidence the flow gets. Without it a failed join carries on to the configuration step, which
 * fails for a reason that reads as a wrong installer password while the Wi-Fi password is what
 * actually needs correcting.
 *
 * Deliberately stops at the handshake: a Modbus read would prove more, but nothing guarantees an
 * inverter answers one before the challenge/response exchange has run, and a probe that reports a
 * joined network as unreachable would strand the flow on a step the user cannot get past.
 */
internal suspend fun probeHuaweiInverter(endpoint: HuaweiLocalEndpoint): Boolean =
    try {
        ModbusClient(endpoint.host, endpoint.port, connectTimeout = PROBE_CONNECT_TIMEOUT).connect { true }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: Exception) {
        // A connect timeout or a refused connection — nothing is listening at this endpoint.
        false
    }
