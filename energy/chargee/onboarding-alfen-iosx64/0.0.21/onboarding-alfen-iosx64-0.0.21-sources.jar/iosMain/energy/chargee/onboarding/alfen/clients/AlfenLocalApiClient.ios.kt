package energy.chargee.onboarding.alfen.clients

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.darwin.Darwin
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.convert
import platform.Foundation.NSURLCredential
import platform.Foundation.NSURLSessionAuthChallengeUseCredential
import platform.Foundation.credentialForTrust
import platform.Foundation.serverTrust

@OptIn(ExperimentalForeignApi::class)
internal actual fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit): HttpClient =
    HttpClient(Darwin) {
        block()
        engine {
            configureSession { setHTTPMaximumConnectionsPerHost(1.convert()) }
            handleChallenge { _, _, challenge, completionHandler ->
                val credential = NSURLCredential.credentialForTrust(challenge.protectionSpace.serverTrust)
                completionHandler(NSURLSessionAuthChallengeUseCredential.convert(), credential)
            }
        }
    }
