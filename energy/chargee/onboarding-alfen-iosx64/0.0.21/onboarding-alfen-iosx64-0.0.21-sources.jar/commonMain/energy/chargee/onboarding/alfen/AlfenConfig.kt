package energy.chargee.onboarding.alfen

/**
 * Alfen-specific constants shared across the flow, module, and clients.
 */
object AlfenConfig {
    /** Brand identifier used as the Alfen onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "alfen"

    /** Alfen chargers ship a single service-installer account, so only its password is ever asked for. */
    const val USERNAME = "admin"

    /**  Alfen chargers expose Modbus TCP on 502 by default. */
    const val DEFAULT_PORT = 502

    /**
     * mDNS service type Alfen chargers advertise on the local network. Used by the Alfen DI module
     * to build the [energy.chargee.discovery.core.DeviceDiscovery] registered under [BRAND].
     */
    const val SERVICE_TYPE = "_alfen._tcp"
}
