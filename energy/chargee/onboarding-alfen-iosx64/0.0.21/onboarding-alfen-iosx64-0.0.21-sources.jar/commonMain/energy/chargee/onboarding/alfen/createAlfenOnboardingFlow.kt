package energy.chargee.onboarding.alfen

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.ChargerRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.alfen.AlfenConfig.BRAND
import energy.chargee.onboarding.alfen.AlfenConfig.DEFAULT_PORT
import energy.chargee.onboarding.alfen.clients.AlfenClient
import energy.chargee.onboarding.alfen.steps.ConfigureDeviceStep
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyChargerStep

/**
 * Builds the onboarding flow for an Alfen charger behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Discover the Alfen charger via [alfenDiscovery] (mDNS on `_alfen._tcp`).
 * 3. Prompt the user for the charger's service-installer password, then log in via
 *    [alfenClient] as [AlfenConfig.USERNAME] and set the properties that enable Modbus TCP.
 * 4. Register the discovered charger through [localDeviceRepository].
 * 5. Poll [chargerRepository] until the Chargee device reports readings from the charger,
 *    confirming end-to-end connectivity.
 *
 * The Alfen charger sits on the same network as the phone, so unlike SolarEdge no
 * local-AP association step is required.
 *
 * When the context is seeded with a `deviceUuid` the flow resets that already-registered charger
 * instead: step 3 is skipped — the charger is assumed to be configured already — and step 4
 * updates the stored configuration with the rediscovered values rather than creating a second
 * registration.
 */
internal fun createAlfenOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    alfenDiscovery: DeviceDiscovery,
    alfenClient: AlfenClient,
    localDeviceRepository: LocalDeviceRepository,
    chargerRepository: ChargerRepository,
) = createOnboardingFlow<LocalDeviceStepId, AlfenOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    discoverDeviceStep { alfenDiscovery }
    whenTrue(condition = { it.deviceUuid == null }) {
        step(
            ConfigureDeviceStep(alfenClient),
            retryPolicy =
                ExponentialBackoffRetry(
                    maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                    condition = { (it as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials != true },
                ),
        )
    }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = { context, fields ->
            LocalDeviceConfig(
                type = LocalDeviceType.Charger,
                connectionType = "alfen_tcp",
                deviceType = BRAND,
                brand = BRAND,
                model = context.model,
                config = fields,
            )
        },
        createConfigFields = { context ->
            val selectedDevice =
                requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }
            listOfNotNull(
                LocalDeviceConfigField("modbus_type", "tcp"),
                LocalDeviceConfigField("ip", selectedDevice.ipAddress),
                LocalDeviceConfigField("port", DEFAULT_PORT),
                context.fuseSize?.let { LocalDeviceConfigField("fuse_size", it) },
                LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
            )
        },
    )
    verifyChargerStep(addressUuid, chargerRepository)
}
