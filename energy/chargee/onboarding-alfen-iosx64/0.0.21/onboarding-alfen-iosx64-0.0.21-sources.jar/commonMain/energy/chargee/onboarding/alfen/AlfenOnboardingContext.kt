package energy.chargee.onboarding.alfen

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext

/**
 * The mutable context that flows through the Alfen onboarding steps.
 *
 * Extends [LocalDeviceOnboardingContext] with Alfen-specific fields. [password] is the
 * service-installer password shown on the charger's screen — the username is always
 * [AlfenConfig.USERNAME] — and is required by
 * [energy.chargee.onboarding.alfen.steps.ConfigureDeviceStep], which pauses for user input until
 * it is set. [fuseSize] is the installation's fuse rating in amperes, written into the device
 * configuration during registration when the caller supplies one and left out of the
 * configuration entirely when it is `null`.
 */
data class AlfenOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    val password: String? = null,
    val fuseSize: Int? = null,
) : LocalDeviceOnboardingContext<AlfenOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
