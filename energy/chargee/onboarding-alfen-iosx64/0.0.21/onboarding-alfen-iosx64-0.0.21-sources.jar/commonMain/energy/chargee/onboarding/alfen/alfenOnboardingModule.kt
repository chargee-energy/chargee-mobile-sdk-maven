package energy.chargee.onboarding.alfen

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.onboarding.alfen.AlfenConfig.BRAND
import energy.chargee.onboarding.alfen.AlfenConfig.SERVICE_TYPE
import energy.chargee.onboarding.alfen.clients.AlfenClient
import energy.chargee.onboarding.alfen.clients.AlfenLocalApiClient
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig

val alfenOnboardingModule =
    module {
        factory<AlfenClient> { AlfenLocalApiClient() }
        factoryWithParameters<DeviceDiscovery>(name = BRAND) {
            get<DeviceDiscovery>(
                name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                parameters = parametersOf(SERVICE_TYPE),
            )
        }
        factoryWithParameters { parameters ->
            AlfenOnboardingSession(
                OnboardingEngine(
                    initialContext = AlfenOnboardingContext(),
                    flow =
                        createAlfenOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            alfenDiscovery = get<DeviceDiscovery>(name = BRAND),
                            alfenClient = get(),
                            localDeviceRepository = get(),
                            chargerRepository = get(),
                        ),
                ),
            )
        }
    }
