package energy.chargee.onboarding.alfen

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for Alfen chargers. Routes [AlfenInput] — device selection, retry, and the
 * service-installer password — and surfaces [AlfenStep]s in its typed state.
 */
@OnboardingSession
class AlfenOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, AlfenOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, AlfenOnboardingContext, AlfenStep, AlfenInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [fuseSize] and [deviceUuid] before the first step runs. Passing a
     * [deviceUuid] turns the run into a reset of that already-registered charger: the device
     * configuration step is skipped, and instead of registering a new charger the flow updates the
     * stored configuration with the rediscovered values before re-verifying.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(fuseSize: Int? = null, deviceUuid: String? = null) {
        runFlow { it.copy(fuseSize = fuseSize, deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [AlfenStep]s. A started step becomes [AlfenStep.Running].
     * On a pause for input, device configuration becomes [AlfenStep.AwaitingPassword], and device
     * discovery becomes [AlfenStep.AwaitingDevice] carrying the discovered devices. On a failure,
     * a [DeviceConfigurationFailure][LocalDeviceErrorCode.DeviceConfigurationFailure] flagged as
     * [invalidCredentials][LocalDeviceErrorCode.DeviceConfigurationFailure.invalidCredentials]
     * becomes [AlfenStep.AwaitingPassword] in a failure state, pre-filled with the rejected
     * password, and anything else becomes [AlfenStep.Failure] carrying a retry callback.
     * Flow-level events delegate to [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, AlfenStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, AlfenOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, AlfenStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = AlfenStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == LocalDeviceStepId.ConfigureDevice &&
                        (event.errorCode as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials == true -> {
                        current.copy(
                            currentStep =
                                AlfenStep.AwaitingPassword(
                                    status = OnboardingStepStatus.Failure,
                                    previousPassword = event.context.password,
                                ) {
                                    submit(AlfenInput.SetPassword(it))
                                },
                        )
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                AlfenStep.Failure(
                                    event.stepId,
                                    error = event.errorCode,
                                    deviceUuid = event.context.deviceUuid,
                                ) {
                                    submit(AlfenInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.ConfigureDevice -> {
                        current.copy(
                            currentStep =
                                AlfenStep.AwaitingPassword(status = OnboardingStepStatus.WaitingForInput) {
                                    submit(AlfenInput.SetPassword(it))
                                },
                        )
                    }

                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                AlfenStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(AlfenInput.SetDevice(it)) },
                                    rescan = { submit(AlfenInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [AlfenInput]: [Retry][AlfenInput.Retry] re-runs a failed step;
     * [SetPassword][AlfenInput.SetPassword] applies while paused on device
     * configuration; and [SetDevice][AlfenInput.SetDevice] selects the device while waiting on
     * discovery.
     */
    override fun submit(input: AlfenInput): SubmitResult =
        when (input) {
            AlfenInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is AlfenInput.SetPassword -> {
                requirePaused(LocalDeviceStepId.ConfigureDevice) {
                    engine.resume { it.copy(password = input.password) }
                }
            }

            is AlfenInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            AlfenInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }
        }
}
