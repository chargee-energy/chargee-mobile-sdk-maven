package energy.chargee.onboarding.alfen.clients

import energy.chargee.core.network.models.ApiError

interface AlfenClient {
    suspend fun <T> connect(ipAddress: String, block: suspend AlfenClientConnection.() -> T): T
}

interface AlfenClientConnection {
    suspend fun authenticate(username: String, password: String): ApiError?

    suspend fun setProperty(id: String, value: String): Boolean
}
