package energy.chargee.onboarding.alfen.steps

import energy.chargee.core.network.models.ApiError
import energy.chargee.onboarding.alfen.AlfenConfig
import energy.chargee.onboarding.alfen.AlfenOnboardingContext
import energy.chargee.onboarding.alfen.clients.AlfenClient
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

internal class ConfigureDeviceStep(private val client: AlfenClient) : OnboardingFlow.Step<LocalDeviceStepId, AlfenOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: AlfenOnboardingContext): Result<AlfenOnboardingContext> {
        val selectedDevice =
            requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before ConfigureDeviceStep runs" }
        val password =
            context.password ?: return Result.InputRequired(context, advanceAfterInput = false)

        return client.connect(selectedDevice.ipAddress) {
            val authError = authenticate(AlfenConfig.USERNAME, password)

            if (authError != null) {
                return@connect Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = authError is ApiError.Client.Forbidden),
                )
            }

            val properties =
                mapOf(
                    "2530_3" to "0",
                    "2530_2" to "1",
                    "5217_0" to "5",
                    "2530_1" to "3",
                    "2185_0" to "1",
                )

            if (properties.any { (key, value) -> !setProperty(key, value) }) {
                return@connect Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure())
            }

            Result.Success(context)
        }
    }
}
