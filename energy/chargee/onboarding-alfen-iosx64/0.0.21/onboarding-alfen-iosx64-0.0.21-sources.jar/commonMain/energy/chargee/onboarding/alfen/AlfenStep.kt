package energy.chargee.onboarding.alfen

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [AlfenOnboardingSession] surfaces through its typed state, each
 * carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_AlfenStep")
@Serializable
sealed interface AlfenStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        AlfenStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : AlfenStep

    /**
     * The flow needs the service-installer password to configure the charger. Call [setPassword]
     * with it. [status] is [OnboardingStepStatus.WaitingForInput] the first time it is requested
     * and [OnboardingStepStatus.Failure] after a rejected attempt, in which case
     * [previousPassword] holds the password that was tried.
     */
    @Serializable
    data class AwaitingPassword(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConfigureDevice,
        override val status: OnboardingStepStatus,
        val previousPassword: String? = null,
        @Transient val setPassword: (String) -> Unit = {},
    ) : AlfenStep

    /**
     * The flow is waiting for the user to pick which device to onboard from [possibleDevices]. Call
     * [setDevice] with the chosen device.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : AlfenStep
}
