package energy.chargee.onboarding.alfen

import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the Alfen charger onboarding flow. A flat, sealed hierarchy whose cases the
 * [AlfenOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_AlfenInput")
@Serializable
sealed interface AlfenInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : AlfenInput

    /**
     * Supplies the [password] required to configure the charger. Accepted while the flow is paused
     * on device configuration.
     */
    @Serializable
    data class SetPassword(val password: String) : AlfenInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : AlfenInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : AlfenInput
}
