package energy.chargee.onboarding.alfen.clients

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.utils.result.getError
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

internal expect fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit = {}): HttpClient

internal class AlfenLocalApiClient : AlfenClient {
    override suspend fun <T> connect(ipAddress: String, block: suspend AlfenClientConnection.() -> T): T {
        val client =
            createNativeHttpClient {
                expectSuccess = true
                defaultRequest {
                    url("https://$ipAddress")
                    contentType(ContentType.Application.Json)
                }
                install(ContentNegotiation) {
                    json(Json { ignoreUnknownKeys = true })
                }
                install(HttpTimeout) {
                    requestTimeoutMillis = 15_000
                    connectTimeoutMillis = 15_000
                    socketTimeoutMillis = 15_000
                }
            }

        try {
            val connection = AlfenLocalApiConnection(client)
            return connection.block()
        } finally {
            runCatching { client.post("/api/logout") }
            client.close()
        }
    }
}

private class AlfenLocalApiConnection(private val httpClient: HttpClient) : AlfenClientConnection {
    override suspend fun authenticate(username: String, password: String): ApiError? =
        runApi {
            httpClient.post("/api/login") {
                setBody(
                    mapOf(
                        "username" to username,
                        "password" to password,
                    ),
                )
            }
        }.getError()

    override suspend fun setProperty(id: String, value: String): Boolean {
        try {
            httpClient.post("/api/prop") {
                setBody(
                    mapOf(id to mapOf("id" to id, "value" to value)),
                )
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }
}
