package energy.chargee.core.annotations

/**
 * Marks a repository interface whose public API is bridged to a native Swift facade, and which
 * external code-generation tooling can discover as an entry point over the SDK's repositories.
 *
 * The annotation carries no runtime behaviour; it is consumed at build time by the `swift-facade`
 * KSP processor (`processors/swift-facade-ksp`). For every annotated interface the processor
 * generates a Swift facade `class` that wraps the bridged Kotlin repository and exposes each
 * `suspend fun … : Result<V, ApiError>` as an `async throws(ApiError)` method — unwrapping the
 * [energy.chargee.utils.result.Result] into its value or a thrown error. Values are converted to
 * Swift-friendly types (e.g. `Instant`/`LocalDate` become `Date`, a boxed `Int?` becomes `Int?`),
 * and every model in the parameter or return graph is mirrored as a Swift `struct`. Non-`suspend`
 * or `Flow`-returning functions do not fit that shape and are skipped with a warning.
 *
 * The generated facades are handed out through `ChargeeSdk.data`, so consumers obtain them from
 * there rather than constructing them directly.
 *
 * For a repository to be picked up, its module must apply the `energy.chargee.plugin.swift-facade`
 * plugin and opt into `ExperimentalObjCName`, and the interface must carry a [kotlin.native.ObjCName]
 * of `"_"` + its own name so that the clean Swift name is left free for the generated facade:
 *
 * ```
 * @Repository
 * @ObjCName("_SmartMeterRepository")
 * interface SmartMeterRepository {
 *     suspend fun getSmartMeters(addressUuid: String): Result<List<SmartMeter>, ApiError>
 * }
 * ```
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.BINARY)
annotation class Repository
