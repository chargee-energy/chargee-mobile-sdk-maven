package energy.chargee.onboarding.localdevice.steps

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.result.fold

internal class UpdateDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(
    private val addressUuid: String,
    private val chargeeDeviceType: ChargeeDeviceType,
    private val chargeeDeviceUuid: String,
    private val localDeviceRepository: LocalDeviceRepository,
    private val createConfig: (Context) -> List<LocalDeviceConfigField>,
) : OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.RegisterDevice

    override suspend fun execute(context: Context): Result<Context> {
        val deviceUuid = requireNotNull(context.deviceUuid) { "UpdateDeviceStep should have a device uuid" }
        return localDeviceRepository
            .updateLocalDevice(
                addressUuid,
                chargeeDeviceType,
                chargeeDeviceUuid,
                deviceUuid,
                createConfig(context),
            ).fold(
                success = {
                    Result.Success(context)
                },
                failure = {
                    Result.Failure(
                        context,
                        LocalDeviceErrorCode.LocalDeviceRegistrationFailure,
                    )
                },
            )
    }
}
