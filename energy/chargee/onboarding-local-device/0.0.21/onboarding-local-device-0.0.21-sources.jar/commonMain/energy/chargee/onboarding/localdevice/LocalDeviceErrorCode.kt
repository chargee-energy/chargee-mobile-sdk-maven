package energy.chargee.onboarding.localdevice

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Error codes emitted on [energy.chargee.onboarding.core.OnboardingFlow.Event.StepFailure]
 * by the shared local-device onboarding steps.
 *
 * Engine-emitted codes ([OnboardingErrorCode.Timeout], [OnboardingErrorCode.Cancelled]) may
 * also appear on the same events. Brand-specific flows layer their own [OnboardingErrorCode]
 * hierarchies on top for issues that only occur within the vendor-specific steps.
 */
@ObjCName("_LocalDeviceErrorCode")
@Serializable
sealed interface LocalDeviceErrorCode : OnboardingErrorCode {
    /** The backend lookup for the Chargee device the local device is being onboarded behind failed. */
    @Serializable
    data object FetchChargeeDeviceFailure : LocalDeviceErrorCode

    /**
     * The mDNS scan finished without seeing the expected Chargee device advertising its serial
     * number. Usually indicates the phone and the Chargee device are not on the same L2 network.
     */
    @Serializable
    data object ChargeeDeviceNotDiscovered : LocalDeviceErrorCode

    /**
     * The phone could not join the vendor-hosted access point.
     */
    @Serializable
    data object WifiConnectionFailure : LocalDeviceErrorCode

    /**
     * The device rejected the configuration payload. [invalidCredentials] is `true` when the
     * device authenticated the request but rejected it as unauthorized (wrong password / PoP);
     * `false` for all other configuration errors.
     */
    @Serializable
    data class DeviceConfigurationFailure(val invalidCredentials: Boolean = false) : LocalDeviceErrorCode

    /** The backend rejected the request to register the local device behind the Chargee device. */
    @Serializable
    data object LocalDeviceRegistrationFailure : LocalDeviceErrorCode
}
