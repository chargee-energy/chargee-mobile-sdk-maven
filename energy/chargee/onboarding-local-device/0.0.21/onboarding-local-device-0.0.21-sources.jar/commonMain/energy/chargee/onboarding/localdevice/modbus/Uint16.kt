package energy.chargee.onboarding.localdevice.modbus

import kotlin.jvm.JvmInline

/**
 * Unsigned 16-bit integer in the range `0..65535`, used for Modbus 16-bit fields such as
 * register addresses, quantities, and register values. Construction throws
 * [IllegalArgumentException] if [value] is outside this range.
 */
@JvmInline
value class Uint16(val value: Int) {
    init {
        require(value in 0..0xFFFF) { "Uint16 out of range: $value" }
    }
}

/**
 * Converts the int value to [Uint16].
 */
val Int.uint16 get() = Uint16(this)

/**
 * Reads the two bytes at [offset] and `offset + 1` as a big-endian [Uint16].
 */
fun ByteArray.uint16At(offset: Int): Uint16 {
    val hi = this[offset].toInt() and 0xFF
    val lo = this[offset + 1].toInt() and 0xFF
    return Uint16((hi shl 8) or lo)
}

/**
 * Converts the [Uint16] into a hexadecimal [String]
 */
val Uint16.hex get() = value.toString(16).padStart(4, '0')

/**
 * Converts an array of [Uint16] values to a UTF-8 [String], returns null when the [String] is empty.
 */
fun Array<Uint16>.decodeToString(): String? =
    flatMap { listOf((it.value shr 8).toByte(), (it.value and 0xFF).toByte()) }
        .toByteArray()
        .decodeToString()
        .trimEnd('\u0000')
        .takeIf { it.isNotEmpty() }

/**
 * Converts an array of [Uint16] values to a IPv4 [String], returns null when the IP is 0.0.0.0.
 */
fun Array<Uint16>.decodeToIpv4(): String? =
    takeIf { any { it.value != 0 } }
        ?.flatMap { listOf(it.value shr 8, it.value and 0xFF) }
        ?.joinToString(".")
