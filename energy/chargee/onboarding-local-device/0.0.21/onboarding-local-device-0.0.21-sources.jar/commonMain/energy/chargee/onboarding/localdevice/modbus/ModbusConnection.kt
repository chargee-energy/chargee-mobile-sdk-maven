package energy.chargee.onboarding.localdevice.modbus

import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.readByte
import io.ktor.utils.io.readByteArray
import io.ktor.utils.io.readShort
import io.ktor.utils.io.writeFully
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random
import kotlin.time.Duration

private val FC_READ_HOLDING_REGISTERS = 0x03.uint8
private val FC_READ_INPUT_REGISTERS = 0x04.uint8
private val FC_WRITE_SINGLE_REGISTER = 0x06.uint8
private val FC_WRITE_MULTIPLE_REGISTERS = 0x10.uint8
private const val EXCEPTION_BIT = 0x80

/**
 * An open Modbus TCP connection over which multiple PDUs may be exchanged. Obtain an instance
 * via [ModbusClient.connect]; the socket lifecycle is owned by that call.
 */
class ModbusConnection internal constructor(
    private val read: ByteReadChannel,
    private val write: ByteWriteChannel,
    private val unitId: Uint8,
    private val responseTimeout: Duration,
    private val maxAttempts: Int,
) {
    /**
     * Reads [quantity] consecutive 16-bit holding registers starting at [address]
     * (Modbus function code `0x03`). Returns the register values as an `Array<Uint16>` in the
     * order received.
     *
     * @throws IllegalStateException if the device returns a Modbus exception or the response
     *   framing is malformed.
     * @throws ModbusUnreachableException if no response arrives after `maxAttempts` retries.
     */
    suspend fun readHoldingRegisters(address: Uint16, quantity: Uint16): Array<Uint16> =
        readRegisters(FC_READ_HOLDING_REGISTERS, address, quantity)

    /**
     * Reads [quantity] consecutive 16-bit input registers starting at [address]
     * (Modbus function code `0x04`). Returns the register values as an `Array<Uint16>` in the
     * order received.
     *
     * @throws IllegalStateException if the device returns a Modbus exception or the response
     *   framing is malformed.
     * @throws ModbusUnreachableException if no response arrives after `maxAttempts` retries.
     */
    suspend fun readInputRegisters(address: Uint16, quantity: Uint16): Array<Uint16> =
        readRegisters(FC_READ_INPUT_REGISTERS, address, quantity)

    /**
     * Writes a single 16-bit register at [address] with [value] (Modbus function code `0x06`).
     * The device echoes the address and value back; this is verified before returning.
     *
     * @throws IllegalStateException if the device returns a Modbus exception or the echo does
     *   not match the request.
     * @throws ModbusUnreachableException if no response arrives after `maxAttempts` retries.
     */
    suspend fun writeSingleRegister(address: Uint16, value: Uint16) {
        val pdu =
            buildByteArray {
                uint8(FC_WRITE_SINGLE_REGISTER)
                uint16(address)
                uint16(value)
            }

        executeRequest(pdu) { responsePdu ->
            checkPduFunctionCode(responsePdu, FC_WRITE_SINGLE_REGISTER)
            val echoedAddress = responsePdu.uint16At(1)
            val echoedValue = responsePdu.uint16At(3)
            check(echoedAddress == address && echoedValue == value) {
                "Write echo mismatch: address $echoedAddress != ${address.value} or value $echoedValue != ${value.value}"
            }
        }
    }

    /**
     * Writes [values] as consecutive 16-bit registers starting at [address] (Modbus function
     * code `0x10`). The device echoes the start address and the count back; both are verified
     * before returning.
     *
     * @throws IllegalStateException if the device returns a Modbus exception or the echo does
     *   not match the request.
     * @throws ModbusUnreachableException if no response arrives after `maxAttempts` retries.
     */
    suspend fun writeMultipleRegisters(address: Uint16, values: Array<Uint16>) {
        val pdu =
            buildByteArray {
                uint8(FC_WRITE_MULTIPLE_REGISTERS)
                uint16(address)
                uint16(values.size)
                uint8(values.size * 2)
                for (value in values) uint16(value)
            }

        executeRequest(pdu) { responsePdu ->
            checkPduFunctionCode(responsePdu, FC_WRITE_MULTIPLE_REGISTERS)
            val echoedAddress = responsePdu.uint16At(1)
            val echoedQuantity = responsePdu.uint16At(3)
            check(echoedAddress == address && echoedQuantity == values.size.uint16) {
                "Write echo mismatch: address $echoedAddress != ${address.value} or quantity $echoedQuantity != ${values.size}"
            }
        }
    }

    /**
     * Sends an arbitrary PDU (a function code byte followed by FC-specific data) and returns
     * the raw response PDU including the function code byte. Useful for function codes not
     * directly modelled by this client or for vendor-specific extensions.
     *
     * @throws IllegalStateException if the MBAP header is malformed. PDU-level errors (exception
     *   responses, unexpected function codes) are the caller's responsibility to detect.
     * @throws ModbusUnreachableException if no response arrives after `maxAttempts` retries.
     */
    suspend fun exchangeRawPdu(pdu: ByteArray): ByteArray = executeRequest(pdu) { it }

    private suspend fun readRegisters(functionCode: Uint8, address: Uint16, quantity: Uint16): Array<Uint16> {
        val pdu =
            buildByteArray {
                uint8(functionCode)
                uint16(address)
                uint16(quantity)
            }

        return executeRequest(pdu) { responsePdu ->
            parseRegisterReadResponse(responsePdu, functionCode, quantity)
        }
    }

    private suspend fun <T> executeRequest(pdu: ByteArray, parseResponse: (ByteArray) -> T): T {
        val transactionId = Random.nextInt(0, 0xFFFF).uint16
        val frame =
            buildByteArray {
                uint16(transactionId)
                uint16(0) // Protocol ID
                uint16(pdu.size + 1) // Length (PDU + UnitId)
                uint8(unitId)
                byteArray(pdu)
            }

        // Some Modbus devices (e.g. Huawei SUN2000 on port 6607) silently drop the first
        // request and only respond once an identical retry arrives. Resend with the same
        // tx id until we get a response.
        repeat(maxAttempts) {
            write.writeFully(frame)
            write.flush()

            val responsePdu =
                withTimeoutOrNull(responseTimeout) {
                    readResponsePdu(transactionId)
                }
            if (responsePdu != null) return parseResponse(responsePdu)
        }

        throw ModbusUnreachableException("No response from Modbus peer after $maxAttempts attempts")
    }

    private suspend fun readResponsePdu(expectedTransactionId: Uint16): ByteArray {
        val transactionId = read.readShort().toInt() and 0xFFFF
        check(transactionId == expectedTransactionId.value) {
            "Transaction ID mismatch: $transactionId != ${expectedTransactionId.value}"
        }
        read.readShort() // Protocol ID
        val length = read.readShort().toInt() and 0xFFFF
        read.readByte() // Unit ID — already counted in length
        return read.readByteArray(length - 1)
    }

    private fun parseRegisterReadResponse(pdu: ByteArray, expectedFunctionCode: Uint8, quantity: Uint16): Array<Uint16> {
        checkPduFunctionCode(pdu, expectedFunctionCode)

        val byteCount = pdu[1].toInt() and 0xFF
        check(byteCount == quantity.value * 2) {
            "Byte count mismatch: expected ${quantity.value * 2}, got $byteCount"
        }

        return Array(quantity.value) { i -> pdu.uint16At(2 + i * 2) }
    }

    private fun checkPduFunctionCode(pdu: ByteArray, expectedFunctionCode: Uint8) {
        val functionCode = Uint8(pdu[0].toInt() and 0xFF)
        if (functionCode.value and EXCEPTION_BIT != 0) {
            val exceptionCode = pdu[1].toInt() and 0xFF
            error("Modbus exception 0x${exceptionCode.toString(16)}")
        }
        check(functionCode == expectedFunctionCode) {
            "Unexpected function code: 0x${functionCode.value.toString(16)}"
        }
    }
}
