package energy.chargee.onboarding.localdevice

import energy.chargee.discovery.core.DiscoveredDevice

/**
 * The mutable context that flows through the shared local-device onboarding steps.
 *
 * Concrete brand flows implement this interface (see the vendor `*OnboardingContext` data
 * classes) and add their own vendor-specific fields on top. [Self] is the concrete
 * implementation type: [copyWith] must return the concrete type so the shared steps can
 * update the base fields without forcing a downcast in the brand-specific steps.
 *
 * Fields are populated progressively as the flow advances. [model] is optional metadata the
 * caller (or an earlier discovery step) may provide. [discoveredDevices] is filled by the
 * discovery step and [selectedDevice] once a single device has been chosen — either implicitly
 * (when discovery finds exactly one candidate) or explicitly via a user-input step.
 * [deviceUuid] identifies the local device in the backend: the register step sets it and the
 * verify step consumes it. Callers can also seed it up front (see the vendor sessions' `start`)
 * to reset an already-registered device — the vendor device configuration steps are then skipped
 * and [registerOrUpdateDeviceStep] updates that device's stored configuration with the freshly
 * discovered values instead of creating a new one.
 */
interface LocalDeviceOnboardingContext<Self : LocalDeviceOnboardingContext<Self>> {
    val model: String?
    val discoveredDevices: List<DiscoveredDevice>
    val selectedDevice: DiscoveredDevice?
    val deviceUuid: String?

    /**
     * Returns a copy of this context with the given base fields overridden. Passing an argument
     * as-is (its current value) leaves the field unchanged. Brand implementations must return
     * their own concrete type so shared steps can update these fields without losing
     * vendor-specific state.
     */
    fun copyWith(
        model: String? = this.model,
        discoveredDevices: List<DiscoveredDevice> = this.discoveredDevices,
        selectedDevice: DiscoveredDevice? = this.selectedDevice,
        deviceUuid: String? = this.deviceUuid,
    ): Self
}
