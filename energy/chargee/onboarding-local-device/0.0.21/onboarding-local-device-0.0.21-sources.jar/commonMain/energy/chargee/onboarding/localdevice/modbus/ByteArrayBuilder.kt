package energy.chargee.onboarding.localdevice.modbus

@DslMarker
@Target(AnnotationTarget.CLASS)
internal annotation class ByteArrayBuilderTagMarker

/**
 * DSL builder for [ByteArray] payloads. Obtain an instance via [buildByteArray] and append
 * values using [uint8], [uint16], or [byteArray].
 */
@ByteArrayBuilderTagMarker
class ByteArrayBuilder internal constructor() {
    private val bytes = mutableListOf<Byte>()

    /** Appends [value] as a single byte. */
    fun uint8(value: Int) {
        uint8(value.uint8)
    }

    /** Appends [value] as a single byte. */
    fun uint8(value: Uint8) {
        bytes.add(value.value.toByte())
    }

    /** Appends [value] as a big-endian 16-bit unsigned integer (two bytes). */
    fun uint16(value: Int) {
        uint16(value.uint16)
    }

    /** Appends [value] as a big-endian 16-bit unsigned integer (two bytes). */
    fun uint16(value: Uint16) {
        bytes.add((value.value shr 8).toByte())
        bytes.add(value.value.toByte())
    }

    /** Appends every byte of [value] verbatim. */
    fun byteArray(value: ByteArray) {
        bytes.addAll(value.toList())
    }

    internal fun build() = bytes.toByteArray()
}

/**
 * Builds a [ByteArray] by running [block] against a [ByteArrayBuilder].
 */
fun buildByteArray(block: ByteArrayBuilder.() -> Unit): ByteArray {
    val builder = ByteArrayBuilder()
    builder.block()
    return builder.build()
}
