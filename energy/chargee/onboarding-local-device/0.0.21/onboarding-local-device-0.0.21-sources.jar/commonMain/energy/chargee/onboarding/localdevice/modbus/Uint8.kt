package energy.chargee.onboarding.localdevice.modbus

import kotlin.jvm.JvmInline

/**
 * Unsigned 8-bit integer in the range `0..255`, used for Modbus byte fields such as function
 * codes, unit identifiers, and byte counts. Construction throws [IllegalArgumentException] if
 * [value] is outside this range.
 */
@JvmInline
value class Uint8(val value: Int) {
    init {
        require(value in 0..0xFF) { "Uint8 out of range: $value" }
    }
}

/**
 * Converts the int value to [Uint8].
 */
val Int.uint8 get() = Uint8(this)

/**
 * Reads the byte at [offset] as a [Uint8].
 */
fun ByteArray.uint8At(offset: Int): Uint8 = Uint8(this[offset].toInt() and 0xFF)

/**
 * Converts the [Uint8] into a hexadecimal [String]
 */
val Uint8.hex get() = value.toString(16).padStart(2, '0')
