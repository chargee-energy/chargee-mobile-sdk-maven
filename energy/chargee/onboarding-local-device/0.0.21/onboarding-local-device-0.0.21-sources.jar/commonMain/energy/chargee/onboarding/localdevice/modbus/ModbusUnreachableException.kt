package energy.chargee.onboarding.localdevice.modbus

/**
 * Thrown when a Modbus peer could not be reached: the TCP connection could not be established
 * within the client's connect timeout, or the peer accepted the connection but never answered a
 * request within the response timeout.
 *
 * It is deliberately not an [IllegalStateException] — the rest of the Modbus code reports
 * protocol-level problems (exception responses, malformed framing, echo mismatches) with `check`
 * and `error`, so callers probing a list of candidate addresses can tell "nothing is listening
 * here" apart from "the right device answered and refused" by catching this type separately.
 */
class ModbusUnreachableException internal constructor(message: String) : RuntimeException(message)
