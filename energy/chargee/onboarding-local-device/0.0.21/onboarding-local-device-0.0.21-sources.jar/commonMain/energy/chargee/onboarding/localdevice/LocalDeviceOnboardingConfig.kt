package energy.chargee.onboarding.localdevice

import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/**
 * Tunable timing, retry, and discovery constants shared by every brand-specific local device flow.
 *
 * Centralizes the magic numbers and literals used by the reusable local-device steps and by the
 * vendor builders that layer on top, so callers (and reviewers) can find them in one place rather
 * than chasing literals through the different `create*OnboardingFlow` factories.
 */
object LocalDeviceOnboardingConfig {
    /** Poll interval inside [energy.chargee.onboarding.localdevice.steps.VerifyDeviceStep]'s while-loop. */
    val verifyDevicePollInterval: Duration = 1.seconds

    /**
     * Engine-enforced timeout for [energy.chargee.onboarding.localdevice.steps.VerifyDeviceStep];
     * the only termination condition when the predicate never becomes `true`.
     */
    val verifyDeviceTimeout: Duration = 5.minutes

    /**
     * Total number of attempts allowed for each vendor's device-configuration step before its
     * [ExponentialBackoffRetry][energy.chargee.onboarding.core.policies.ExponentialBackoffRetry]
     * gives up and the flow pauses on a failure.
     *
     * Wired as the retry policy's `maxAttempts` by every `create*OnboardingFlow` factory. Counts
     * the initial attempt, so `3` means the first try plus up to two retries. Invalid credentials
     * are not retried regardless of this value — each vendor flow's retry `condition` excludes
     * them so the user is prompted to correct the input instead.
     */
    const val CONFIGURATION_MAX_ATTEMPTS: Int = 3

    /**
     * mDNS service type advertised by the Chargee P1 dongle on the customer's network.
     *
     * Lives here rather than in a brand module because it identifies the Chargee device every
     * vendor flow starts from, not the vendor hardware: each brand DI module resolves an mDNS
     * [energy.chargee.discovery.core.DeviceDiscovery] with this service type and hands it to
     * [discoverChargeeDeviceStep], which matches the advertised `sn` extra parameter against the
     * serial number the backend holds for the device being onboarded.
     */
    const val CHARGEE_DEVICE_SERVICE_TYPE = "_chargee_p1._tcp"

    /**
     * The `pollinterval` configuration field, in milliseconds, stored for every local device.
     *
     * Lives here because every brand sends the same cadence: each flow's `createConfigFields` adds
     * this entry to the list it returns instead of declaring its own [LocalDeviceConfigField], so
     * the interval for all brands is a single edit. A brand that needs a different cadence
     * substitutes its own field under the same `pollinterval` name.
     */
    val defaultPollIntervalConfig = LocalDeviceConfigField("pollinterval", 10_000)
}
