package energy.chargee.onboarding.localdevice.steps

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.result.get
import kotlinx.coroutines.flow.any

private const val SERIAL_NUMBER_PARAMETER = "sn"

internal class DiscoverChargeeDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(
    private val addressUuid: String,
    private val deviceUuid: String,
    private val deviceType: ChargeeDeviceType,
    private val discovery: DeviceDiscovery,
    private val chargeeDeviceRepository: ChargeeDeviceRepository,
) : OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.DiscoverChargeeDevice

    override suspend fun execute(context: Context): Result<Context> {
        val chargeeDevice =
            chargeeDeviceRepository.getChargeeDevice(addressUuid, deviceType, deviceUuid).get()
                ?: return Result.Failure(context, LocalDeviceErrorCode.FetchChargeeDeviceFailure)

        val discovered =
            discovery
                .discover()
                .any { it.extraParameters[SERIAL_NUMBER_PARAMETER] == chargeeDevice.serialNumber }

        return if (discovered) {
            Result.Success(context)
        } else {
            Result.Failure(context, LocalDeviceErrorCode.ChargeeDeviceNotDiscovered)
        }
    }
}
