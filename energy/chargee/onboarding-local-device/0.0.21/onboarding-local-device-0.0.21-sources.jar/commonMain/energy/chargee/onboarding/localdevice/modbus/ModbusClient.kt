package energy.chargee.onboarding.localdevice.modbus

import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.aSocket
import io.ktor.network.sockets.openReadChannel
import io.ktor.network.sockets.openWriteChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * A Modbus TCP client for [host] and [port], identifying itself as Modbus unit [unitId].
 *
 * Each top-level read/write method on this class opens a fresh TCP connection, performs the
 * exchange, and closes it. For protocols that must share state across multiple PDUs on a single
 * connection (e.g. challenge/response authentication), use [connect].
 *
 * [responseTimeout] bounds each individual PDU exchange. [maxAttempts] caps how many times the
 * same request is resent if no response arrives — needed for devices that silently drop the
 * first request and only respond once an identical retry arrives (e.g. Huawei SUN2000 on port
 * 6607). [connectTimeout] bounds establishing the TCP connection, so probing an address nothing
 * is listening on fails in seconds instead of waiting out the platform default.
 */
class ModbusClient(
    private val host: String,
    private val port: Int = 502,
    private val unitId: Uint8 = 1.uint8,
    private val responseTimeout: Duration = 2.seconds,
    private val maxAttempts: Int = 3,
    private val connectTimeout: Duration = 5.seconds,
) {
    constructor(
        host: String,
        port: Int = 502,
        unitId: Uint8 = 1.uint8,
    ) : this(host, port, unitId, responseTimeout = 2.seconds, maxAttempts = 3, connectTimeout = 5.seconds)

    /**
     * Opens a single TCP connection and runs [block] against it. All exchanges inside the
     * block share the same socket, which is required for protocols that maintain per-session
     * state (e.g. challenge/response authentication). The socket is closed when [block] returns
     * or throws.
     *
     * @throws ModbusUnreachableException if the TCP connection cannot be established within
     *   [connectTimeout].
     */
    suspend fun <T> connect(block: suspend ModbusConnection.() -> T): T =
        withContext(Dispatchers.IO) {
            val selector = SelectorManager(Dispatchers.IO)
            val socket =
                try {
                    withTimeoutOrNull(connectTimeout) {
                        aSocket(selector).tcp().connect(host, port) {
                            noDelay = true
                        }
                    } ?: throw ModbusUnreachableException("Timed out connecting to $host:$port after $connectTimeout")
                } catch (throwable: Throwable) {
                    selector.close()
                    throw throwable
                }
            try {
                val connection =
                    ModbusConnection(
                        read = socket.openReadChannel(),
                        write = socket.openWriteChannel(autoFlush = true),
                        unitId = unitId,
                        responseTimeout = responseTimeout,
                        maxAttempts = maxAttempts,
                    )
                connection.block()
            } finally {
                socket.close()
                selector.close()
            }
        }

    /** Single-shot convenience around [ModbusConnection.readHoldingRegisters]. */
    suspend fun readHoldingRegisters(address: Uint16, quantity: Uint16): Array<Uint16> = connect { readHoldingRegisters(address, quantity) }

    /** Single-shot convenience around [ModbusConnection.readInputRegisters]. */
    suspend fun readInputRegisters(address: Uint16, quantity: Uint16): Array<Uint16> = connect { readInputRegisters(address, quantity) }

    /** Single-shot convenience around [ModbusConnection.writeSingleRegister]. */
    suspend fun writeSingleRegister(address: Uint16, value: Uint16) = connect { writeSingleRegister(address, value) }

    /** Single-shot convenience around [ModbusConnection.writeMultipleRegisters]. */
    suspend fun writeMultipleRegisters(address: Uint16, values: Array<Uint16>) = connect { writeMultipleRegisters(address, values) }

    /** Single-shot convenience around [ModbusConnection.exchangeRawPdu]. */
    suspend fun exchangeRawPdu(pdu: ByteArray): ByteArray = connect { exchangeRawPdu(pdu) }
}
