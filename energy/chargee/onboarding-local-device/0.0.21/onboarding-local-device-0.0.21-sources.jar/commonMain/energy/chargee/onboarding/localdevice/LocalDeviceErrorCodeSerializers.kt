package energy.chargee.onboarding.localdevice

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * The [SerializersModule] registering the [LocalDeviceErrorCode] cases as polymorphic subtypes of
 * the open [OnboardingErrorCode].
 *
 * Each concrete case is registered directly, rather than the [LocalDeviceErrorCode] sealed
 * interface as a whole: kotlinx.serialization rejects a sealed serializer as a `subclass` of
 * another polymorphic base ("its kind SEALED is not concrete"), and registering the leaves keeps
 * a single, flat `type` discriminator. A new case must be added here to be serializable. The
 * brand flows (Goodwe, Huawei, Peblar, SolarEdge) all surface these shared codes, so this single
 * registration covers every one of them.
 */
val localDeviceErrorCodeSerializersModule: SerializersModule =
    SerializersModule {
        polymorphic(OnboardingErrorCode::class) {
            subclass(LocalDeviceErrorCode.FetchChargeeDeviceFailure::class)
            subclass(LocalDeviceErrorCode.ChargeeDeviceNotDiscovered::class)
            subclass(LocalDeviceErrorCode.WifiConnectionFailure::class)
            subclass(LocalDeviceErrorCode.DeviceConfigurationFailure::class)
            subclass(LocalDeviceErrorCode.LocalDeviceRegistrationFailure::class)
        }
    }
