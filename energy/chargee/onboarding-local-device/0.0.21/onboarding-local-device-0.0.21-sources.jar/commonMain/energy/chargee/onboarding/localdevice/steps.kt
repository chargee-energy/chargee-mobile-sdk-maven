package energy.chargee.onboarding.localdevice

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.ChargerRepository
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.builders.OnboardingFlowBuilder
import energy.chargee.onboarding.localdevice.steps.DiscoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.steps.DiscoverDeviceStep
import energy.chargee.onboarding.localdevice.steps.RegisterDeviceStep
import energy.chargee.onboarding.localdevice.steps.UpdateDeviceStep
import energy.chargee.onboarding.localdevice.steps.VerifyDeviceStep
import energy.chargee.utils.result.get

/**
 * Adds a step that confirms the Chargee device identified by [deviceUuid] is visible on the
 * local network before starting the vendor-specific onboarding.
 *
 * The step first looks up the device via [chargeeDeviceRepository] at [addressUuid] with the
 * given [deviceType] and then runs [discovery], matching the returned serial number against
 * the `sn` extra parameter of the discovered devices.
 *
 * Fails with [LocalDeviceErrorCode.FetchChargeeDeviceFailure] if the backend lookup fails and
 * with [LocalDeviceErrorCode.ChargeeDeviceNotDiscovered] if discovery finishes without matching
 * the expected serial number.
 */
fun <Context : LocalDeviceOnboardingContext<Context>> OnboardingFlowBuilder<LocalDeviceStepId, Context>.discoverChargeeDeviceStep(
    addressUuid: String,
    deviceUuid: String,
    deviceType: ChargeeDeviceType,
    discovery: DeviceDiscovery,
    chargeeDeviceRepository: ChargeeDeviceRepository,
) {
    step(DiscoverChargeeDeviceStep(addressUuid, deviceUuid, deviceType, discovery, chargeeDeviceRepository))
}

/**
 * Adds a step that discovers vendor-specific devices reachable from the phone. The discovery
 * strategy is created lazily per execution via [discoveryFactory], so callers can build it from
 * the current context (e.g. narrowing the scan to a network the previous step just joined).
 *
 * If a single candidate is found it is assigned to `selectedDevice` (alongside `discoveredDevices`)
 * and the flow continues immediately. Otherwise — whether several candidates or none were found —
 * the step returns [energy.chargee.onboarding.core.OnboardingFlow.Step.Result.InputRequired] so the
 * caller can prompt the user to pick one or retry the scan.
 *
 * Set [continueWhenEmpty] when finding nothing is a branch rather than a dead end: the step then
 * succeeds with an empty `discoveredDevices` and no `selectedDevice`, so a following decision node
 * can route the flow somewhere else — a vendor-specific fallback, say — instead of stopping to ask
 * the user. It changes nothing when at least one device is found.
 */
fun <Context : LocalDeviceOnboardingContext<Context>> OnboardingFlowBuilder<LocalDeviceStepId, Context>.discoverDeviceStep(
    continueWhenEmpty: Boolean = false,
    discoveryFactory: (Context) -> DeviceDiscovery,
) {
    step(DiscoverDeviceStep(continueWhenEmpty, discoveryFactory))
}

/**
 * Adds a step that persists the discovered local device behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid], via [localDeviceRepository].
 *
 * Whether the device is created or updated depends on the context:
 * - No `deviceUuid` yet — the regular onboarding path. [createConfigFields] produces the
 *   protocol-specific settings (host/port and any vendor parameters), [createConfig] wraps them
 *   into the full [LocalDeviceConfig], and the device is registered. `deviceUuid` is populated
 *   from the newly created device.
 * - `deviceUuid` already set — the reset path, where the caller seeded the uuid of an existing
 *   device through the vendor session's `start`. Only the fields from [createConfigFields] are
 *   sent, replacing that device's stored configuration in place, and the context is left
 *   unchanged.
 *
 * Both branches report as [LocalDeviceStepId.RegisterDevice] and fail with
 * [LocalDeviceErrorCode.LocalDeviceRegistrationFailure] if the backend rejects the request.
 */
fun <Context : LocalDeviceOnboardingContext<Context>> OnboardingFlowBuilder<LocalDeviceStepId, Context>.registerOrUpdateDeviceStep(
    addressUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceUuid: String,
    localDeviceRepository: LocalDeviceRepository,
    createConfig: (Context, List<LocalDeviceConfigField>) -> LocalDeviceConfig,
    createConfigFields: (Context) -> List<LocalDeviceConfigField>,
) {
    decision(condition = { it.deviceUuid == null }) {
        whenTrue {
            step(
                RegisterDeviceStep(
                    addressUuid,
                    chargeeDeviceType,
                    chargeeDeviceUuid,
                    localDeviceRepository,
                ) { createConfig(it, createConfigFields(it)) },
            )
        }
        whenFalse {
            step(
                UpdateDeviceStep(
                    addressUuid,
                    chargeeDeviceType,
                    chargeeDeviceUuid,
                    localDeviceRepository,
                    createConfigFields,
                ),
            )
        }
    }
}

/**
 * Adds a step that polls [inverterRepository] at [addressUuid] until the newly registered
 * inverter returns at least one reading, confirming the Chargee device can talk to it.
 *
 * The step reads `deviceUuid` from the context (set by [registerOrUpdateDeviceStep], or seeded by
 * the caller) and requires [LocalDeviceOnboardingConfig.verifyDeviceTimeout] to enforce termination —
 * the predicate never fails on its own, it just polls until data arrives or the engine times out.
 */
fun <Context : LocalDeviceOnboardingContext<Context>> OnboardingFlowBuilder<LocalDeviceStepId, Context>.verifyInverterStep(
    addressUuid: String,
    inverterRepository: InverterRepository,
) {
    step(
        VerifyDeviceStep { inverterUuid ->
            inverterRepository.getInverterReadings(addressUuid, inverterUuid, limit = 1).get()?.isNotEmpty() ?: false
        },
        timeout = LocalDeviceOnboardingConfig.verifyDeviceTimeout,
    )
}

/**
 * Adds a step that polls [chargerRepository] at [addressUuid] until the newly registered
 * charger returns at least one reading, confirming the Chargee device can talk to it.
 *
 * The step reads `deviceUuid` from the context (set by [registerOrUpdateDeviceStep], or seeded by
 * the caller) and requires [LocalDeviceOnboardingConfig.verifyDeviceTimeout] to enforce termination —
 * the predicate never fails on its own, it just polls until data arrives or the engine times out.
 */
fun <Context : LocalDeviceOnboardingContext<Context>> OnboardingFlowBuilder<LocalDeviceStepId, Context>.verifyChargerStep(
    addressUuid: String,
    chargerRepository: ChargerRepository,
) {
    step(
        VerifyDeviceStep { chargerUuid ->
            chargerRepository.getChargerReadings(addressUuid, chargerUuid, limit = 1).get()?.isNotEmpty() ?: false
        },
        timeout = LocalDeviceOnboardingConfig.verifyDeviceTimeout,
    )
}
