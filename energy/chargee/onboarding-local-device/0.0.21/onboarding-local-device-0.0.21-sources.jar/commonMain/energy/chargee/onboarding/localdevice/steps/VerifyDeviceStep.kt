package energy.chargee.onboarding.localdevice.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.coroutines.delay

internal class VerifyDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(private val verifyDevice: suspend (String) -> Boolean) :
    OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.VerifyDevice

    override suspend fun execute(context: Context): Result<Context> {
        val deviceUuid =
            requireNotNull(context.deviceUuid) { "deviceUuid must be set by RegisterDeviceStep before VerifyDeviceStep runs" }

        while (!verifyDevice(deviceUuid)) {
            delay(LocalDeviceOnboardingConfig.verifyDevicePollInterval)
        }

        // The engine-enforced timeout (LocalDeviceOnboardingConfig.verifyDeviceTimeout, set on the
        // step node in verifyDeviceStep) is the only termination condition when the
        // predicate never becomes true.
        return Result.Success(context)
    }
}
