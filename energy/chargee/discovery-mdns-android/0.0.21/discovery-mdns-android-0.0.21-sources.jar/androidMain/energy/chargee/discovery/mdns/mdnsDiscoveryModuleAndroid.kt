package energy.chargee.discovery.mdns

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import kotlin.time.Duration.Companion.seconds

val mdnsDiscoveryModuleAndroid =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.MDNS_DISCOVERY_TYPE) { parameters ->
            MdnsDiscovery(
                platformDiscovery = MdnsDiscoveryAndroid(context = get(), serviceType = parameters.get(0)),
                timeout = parameters.getOrNull(1) ?: 5.seconds,
            )
        }
    }
