package energy.chargee.discovery.mdns

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import androidx.annotation.RequiresApi
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.concurrent.CopyOnWriteArrayList

internal class MdnsDiscoveryAndroid(private val context: Context, private val serviceType: String) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        callbackFlow {
            val nsd = context.getSystemService(NsdManager::class.java)
            val activeCallbacks = CopyOnWriteArrayList<NsdManager.ServiceInfoCallback>()

            val listener =
                object : NsdManager.DiscoveryListener {
                    override fun onServiceFound(info: NsdServiceInfo) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                            registerCallback(nsd, info, activeCallbacks)
                        } else {
                            resolveLegacy(nsd, info)
                        }
                    }

                    override fun onServiceLost(info: NsdServiceInfo) = Unit

                    override fun onDiscoveryStarted(type: String) = Unit

                    override fun onDiscoveryStopped(type: String) = Unit

                    override fun onStartDiscoveryFailed(type: String, code: Int) {
                        close()
                    }

                    override fun onStopDiscoveryFailed(type: String, code: Int) = Unit
                }

            nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
            awaitClose {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activeCallbacks.forEach { cb ->
                        runCatching { nsd.unregisterServiceInfoCallback(cb as NsdManager.ServiceInfoCallback) }
                    }
                }
                runCatching { nsd.stopServiceDiscovery(listener) }
            }
        }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private fun ProducerScope<DiscoveredDevice>.registerCallback(
        nsd: NsdManager,
        info: NsdServiceInfo,
        activeCallbacks: MutableList<NsdManager.ServiceInfoCallback>,
    ) {
        val cb =
            object : NsdManager.ServiceInfoCallback {
                override fun onServiceUpdated(resolved: NsdServiceInfo) {
                    val host = resolved.hostAddresses.firstOrNull()?.hostAddress ?: return
                    val port = resolved.port.takeIf { it > 0 }
                    val txt =
                        resolved.attributes
                            .mapValues { (_, v) -> v?.toString(Charsets.UTF_8).orEmpty() }
                    trySend(DiscoveredDevice(host, port, txt))
                }

                override fun onServiceLost() = Unit

                override fun onServiceInfoCallbackRegistrationFailed(errorCode: Int) = Unit

                override fun onServiceInfoCallbackUnregistered() = Unit
            }

        activeCallbacks.add(cb)
        nsd.registerServiceInfoCallback(info, context.mainExecutor, cb)
    }

    @Suppress("DEPRECATION")
    private fun ProducerScope<DiscoveredDevice>.resolveLegacy(nsd: NsdManager, info: NsdServiceInfo) {
        nsd.resolveService(
            info,
            object : NsdManager.ResolveListener {
                override fun onServiceResolved(resolved: NsdServiceInfo) {
                    val host = resolved.host?.hostAddress ?: return
                    val port = resolved.port.takeIf { it > 0 }
                    val txt =
                        resolved.attributes
                            .mapValues { (_, v) -> v?.toString(Charsets.UTF_8).orEmpty() }
                    trySend(DiscoveredDevice(host, port, txt))
                }

                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = Unit
            },
        )
    }
}
