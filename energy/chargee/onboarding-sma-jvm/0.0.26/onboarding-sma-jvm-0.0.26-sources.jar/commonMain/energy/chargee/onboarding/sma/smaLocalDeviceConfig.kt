package energy.chargee.onboarding.sma

import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.sma.SmaConfig.BRAND

/**
 * Builds the protocol settings stored for the configured inverter.
 *
 * Everything here was either fixed for the brand or read from the inverter itself. The address is
 * the Modbus unit the configure step resolved rather than an assumption: on a WebConnect inverter
 * it is configurable and 3 is only the factory default, so an installer who moved it would
 * otherwise leave the Chargee device talking to a unit that answers exception 11.
 *
 * The installer password is deliberately absent. It belongs to the inverter's web UI, and the
 * Chargee device speaks plain Modbus — unlike Huawei, where the credentials are part of the
 * connection and are stored with it.
 */
internal fun smaConfigFields(context: SmaOnboardingContext): List<LocalDeviceConfigField> {
    val device =
        requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }

    return listOf(
        LocalDeviceConfigField("modbus_type", "tcp"),
        LocalDeviceConfigField("ip", device.ipAddress),
        LocalDeviceConfigField("port", device.port ?: SmaConfig.DEFAULT_PORT),
        LocalDeviceConfigField("address", context.unitId ?: SmaConfig.DEFAULT_UNIT_ID),
        LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
    )
}

/**
 * Wraps [fields] into the full configuration stored for the inverter.
 *
 * The model comes from the device type code the configure step read, resolved to the name SMA
 * prints on the type label. An inverter whose code this SDK has no name for stores whatever the
 * caller seeded instead, which is usually nothing — a name is what belongs in a model field, and a
 * bare number would only be shown to someone as though it were one.
 */
internal fun smaLocalDeviceConfig(context: SmaOnboardingContext, fields: List<LocalDeviceConfigField>) =
    LocalDeviceConfig(
        type = LocalDeviceType.Inverter,
        connectionType = "sma_tcp",
        deviceType = BRAND,
        brand = BRAND,
        model = context.model,
        config = fields,
    )
