package energy.chargee.onboarding.sma.discovery

import energy.chargee.onboarding.sma.SmaConfig
import energy.chargee.onboarding.sma.clients.SmaClient
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException

/**
 * The generation probe [SmaDeviceVerifier] runs on each candidate, backed by the inverter's own web
 * API through [client].
 *
 * Bounded by [SmaConfig.VERIFICATION_HTTP_TIMEOUT] on top of the client's own timeouts, because a
 * verifier runs once per host a discovery turns up and every candidate waits its turn — a host that
 * accepts a connection and then says nothing would otherwise hold up the whole scan.
 *
 * A host that cannot be reached and a host that answers without being an SMA inverter are reported
 * apart, even though discovery drops both: only the second is a settled fact about the device.
 */
internal fun probeSmaGeneration(client: SmaClient): suspend (host: String) -> SmaVerification =
    { host ->
        withTimeoutOrNull(SmaConfig.VERIFICATION_HTTP_TIMEOUT) {
            try {
                client
                    .connect(host) { detectPlatform() }
                    ?.let { SmaVerification.Verified(it) }
                    ?: SmaVerification.Rejected("nothing at $host answers an SMA web API")
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (_: Exception) {
                // A refused connection, a TLS handshake that went nowhere, or a peer that dropped
                // mid-request. None of them says the host is not an SMA inverter.
                SmaVerification.Unreachable
            }
        } ?: SmaVerification.Unreachable
    }
