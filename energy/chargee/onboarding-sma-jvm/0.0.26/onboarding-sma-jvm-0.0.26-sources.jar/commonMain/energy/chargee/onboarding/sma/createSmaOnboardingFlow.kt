package energy.chargee.onboarding.sma

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyInverterStep
import energy.chargee.onboarding.sma.SmaConfig.BRAND
import energy.chargee.onboarding.sma.clients.SmaClient
import energy.chargee.onboarding.sma.modbus.SmaDeviceReading
import energy.chargee.onboarding.sma.modbus.readSmaDevice
import energy.chargee.onboarding.sma.steps.ConfigureDeviceStep

/**
 * Builds the onboarding flow for an SMA inverter behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Discover the SMA inverter via [smaDiscovery], which asks for it by Speedwire and falls back to
 *    scanning the subnet for its web UI, then confirms each candidate over that web API.
 * 3. Get the inverter talking: read it over Modbus, and when that fails ask for the installer login
 *    and switch its Modbus TCP server on through [smaClient] before reading it.
 * 4. Register the inverter through [localDeviceRepository].
 * 5. Poll [inverterRepository] until the Chargee device reports readings from the inverter,
 *    confirming end-to-end connectivity.
 *
 * Five nodes and no branches, which is worth a word given that SMA needs more done to it than any
 * other brand. Step 3 decides for itself whether there is anything to do, by trying Modbus before
 * it asks for a password — so an inverter that already serves Modbus passes straight through, and
 * a reset (a context seeded with a `deviceUuid`) runs exactly the same steps, with step 4 updating
 * that inverter's stored configuration rather than registering a second one.
 *
 * The retry policy on step 3 stops as soon as the inverter rejects the login: retrying a password
 * the inverter has already refused only risks locking the account, and the user has to supply
 * another one before anything can change.
 *
 * [readDevice] is how step 3 reaches the inverter over Modbus, with a seam for the same reason the
 * step itself has one: it is the only part of this flow that opens a socket of its own.
 */
internal fun createSmaOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    smaDiscovery: DeviceDiscovery,
    smaClient: SmaClient,
    localDeviceRepository: LocalDeviceRepository,
    inverterRepository: InverterRepository,
    readDevice: suspend (host: String, port: Int, platform: SmaPlatform) -> SmaDeviceReading = ::readSmaDevice,
) = createOnboardingFlow<LocalDeviceStepId, SmaOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    discoverDeviceStep { smaDiscovery }
    step(
        ConfigureDeviceStep(smaClient, readDevice),
        retryPolicy =
            ExponentialBackoffRetry(
                maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                condition = { (it as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials != true },
            ),
        timeout = SmaConfig.CONFIGURE_TIMEOUT,
    )
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = ::smaLocalDeviceConfig,
        createConfigFields = ::smaConfigFields,
    )
    verifyInverterStep(addressUuid, inverterRepository)
}
