package energy.chargee.onboarding.sma

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps an [SmaOnboardingSession] surfaces through its typed state, each
 * carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_SmaStep")
@Serializable
sealed interface SmaStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        SmaStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : SmaStep

    /**
     * The flow is waiting for the user to pick which inverter to onboard from [possibleDevices], or
     * is reporting that the scan found none — the same step covers both, with an empty
     * [possibleDevices] for the second. Call [setDevice] with the chosen inverter, or [rescan] to
     * scan again.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : SmaStep

    /**
     * The flow needs the installer login for the inverter's web UI, which is what switches its
     * Modbus TCP server on. Call [setCredentials].
     *
     * [status] is [OnboardingStepStatus.WaitingForInput] the first time they are asked for and
     * [OnboardingStepStatus.Failure] after the inverter rejected an attempt, with
     * [previousUsername] and [previousPassword] carrying what was tried so a UI can show it back.
     *
     * [requiresUsername] says whether the username is used at all: an ennexOS device has real user
     * accounts, while a WebConnect inverter logs in as a fixed role and needs only the password. A
     * UI should hide the username field when this is `false` rather than ask for something the
     * inverter will ignore.
     *
     * Note that this step is reached on a first attempt, not only after a failure. SMA ships no
     * universal installer password, so unlike the other brands there is nothing to try first.
     */
    @Serializable
    data class AwaitingCredentials(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConfigureDevice,
        override val status: OnboardingStepStatus,
        val requiresUsername: Boolean,
        val previousUsername: String? = null,
        val previousPassword: String? = null,
        @Transient val setCredentials: (username: String, password: String) -> Unit = { _, _ -> },
    ) : SmaStep
}
