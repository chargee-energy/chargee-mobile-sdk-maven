package energy.chargee.onboarding.sma.clients

import kotlinx.datetime.TimeZone
import kotlinx.datetime.number
import kotlinx.datetime.toLocalDateTime
import kotlin.time.Instant

/**
 * [instant] as the timestamp an ennexOS parameter write carries: UTC, ISO-8601, with exactly three
 * fractional digits and a `Z`, e.g. `2026-11-10T09:15:30.250Z`.
 *
 * Built by hand rather than taken from [Instant.toString], which varies its precision with the
 * value — a whole second prints no fractional digits at all, and a sub-millisecond one prints more
 * than three. The ennexOS API is documented with one fixed shape, so the shape is produced
 * explicitly instead of hoping the default matches.
 */
internal fun smaTimestamp(instant: Instant): String {
    val utc = instant.toLocalDateTime(TimeZone.UTC)
    val millis = instant.toEpochMilliseconds().mod(1000L)

    return buildString {
        append(utc.year.toString().padStart(4, '0'))
        append('-')
        append(utc.month.number.pad())
        append('-')
        append(utc.day.pad())
        append('T')
        append(utc.hour.pad())
        append(':')
        append(utc.minute.pad())
        append(':')
        append(utc.second.pad())
        append('.')
        append(millis.toString().padStart(3, '0'))
        append('Z')
    }
}

private fun Int.pad() = toString().padStart(2, '0')
