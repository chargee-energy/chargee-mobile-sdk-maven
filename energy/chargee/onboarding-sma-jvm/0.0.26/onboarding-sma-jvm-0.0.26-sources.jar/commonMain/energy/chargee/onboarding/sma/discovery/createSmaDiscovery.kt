package energy.chargee.onboarding.sma.discovery

import energy.chargee.discovery.core.CompositeDeviceDiscovery
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DeviceVerifier
import energy.chargee.discovery.core.VerifyingDeviceDiscovery

/**
 * Composes the two ways of finding an SMA inverter, preferring [speedwireDiscovery] and falling back
 * to [webUiDiscovery], with every candidate from either run past [verifier].
 *
 * Speedwire comes first because it is both faster and more precise: it is answered only by SMA
 * devices, it needs no subnet sweep, and it works while the Modbus server is still switched off.
 *
 * The fallback is not merely belt-and-braces. Sending to a multicast group on iOS needs an
 * entitlement the consuming app does not currently hold, so on iOS the Speedwire strategy answers
 * nothing at all and this composition is what keeps discovery working —
 * [CompositeDeviceDiscovery] moves on to the next strategy whenever one completes without emitting,
 * which is exactly that case and needs no platform branching anywhere. A network that drops
 * multicast behaves the same way.
 */
internal fun createSmaDiscovery(
    speedwireDiscovery: DeviceDiscovery,
    webUiDiscovery: DeviceDiscovery,
    verifier: DeviceVerifier,
): DeviceDiscovery =
    CompositeDeviceDiscovery(
        VerifyingDeviceDiscovery(speedwireDiscovery, verifier),
        VerifyingDeviceDiscovery(webUiDiscovery, verifier),
    )
