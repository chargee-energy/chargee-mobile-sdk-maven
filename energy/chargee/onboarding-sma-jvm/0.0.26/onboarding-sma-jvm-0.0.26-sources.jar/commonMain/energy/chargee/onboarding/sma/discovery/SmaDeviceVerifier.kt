package energy.chargee.onboarding.sma.discovery

import energy.chargee.discovery.core.DeviceVerifier
import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.sma.SmaConfig

/**
 * The [DeviceVerifier] that turns a candidate host into a confirmed SMA inverter, or discards it.
 *
 * It carries more weight for SMA than for the other brands. Elsewhere a verifier narrows a port scan
 * that cast too wide a net, and the device's own protocol settles the question; here Modbus is
 * switched off on a new inverter, so nothing can be read from it at all, and the only thing that can
 * be asked before the user supplies an installer password is the inverter's own web API. That probe
 * does double duty: it confirms the vendor *and* reports which generation answered, which is what
 * decides the API used to switch Modbus on.
 *
 * A verified device carries its generation under [SmaConfig.PLATFORM_PARAMETER] so the configure
 * step does not have to ask again.
 *
 * [probeGeneration] is the probe itself, separated out so the mapping can be tested without a
 * socket.
 */
internal class SmaDeviceVerifier(private val probeGeneration: suspend (host: String) -> SmaVerification) : DeviceVerifier {
    override suspend fun verify(device: DiscoveredDevice): DiscoveredDevice? =
        when (val verification = probeGeneration(device.ipAddress)) {
            is SmaVerification.Verified -> {
                device.copy(
                    // The Modbus port, deliberately, and not whatever port the device was found on.
                    // Speedwire reports no port at all and a web-UI scan reports 443, and neither is
                    // the port anything downstream talks to: the configure step dials Modbus and the
                    // registered configuration stores the Modbus endpoint for the Chargee device.
                    port = SmaConfig.DEFAULT_PORT,
                    extraParameters = device.extraParameters + mapOf(SmaConfig.PLATFORM_PARAMETER to verification.platform.key),
                )
            }

            is SmaVerification.Rejected, SmaVerification.Unreachable -> {
                null
            }
        }
}
