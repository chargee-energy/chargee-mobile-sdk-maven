package energy.chargee.onboarding.sma.clients

import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.sma.SmaPlatform

/**
 * The inverter's own local web API, which is the only thing that can be asked about an SMA inverter
 * before the flow has switched its Modbus server on.
 *
 * Two operations, one per question the flow has: which generation is this, and please switch Modbus
 * on. Both are scoped by [connect] so the underlying HTTP client — and the session it holds — is
 * closed whether the block returns or throws.
 */
internal interface SmaClient {
    suspend fun <T> connect(ipAddress: String, block: suspend SmaClientConnection.() -> T): T
}

/** An open connection to one inverter's web API. */
internal interface SmaClientConnection {
    /**
     * Which generation answers at this address, or `null` when nothing there looks like an SMA
     * inverter. Needs no credentials, which is what lets discovery run it on every candidate.
     */
    suspend fun detectPlatform(): SmaPlatform?

    /**
     * Logs in with [credentials] and switches the Modbus TCP server on, for an inverter already
     * known to be of [platform].
     *
     * Reports only what the web API said. It is deliberately not proof that Modbus is on: SMA
     * acknowledges configuration writes it then silently does not store, so the caller confirms by
     * asking the Modbus port itself.
     */
    suspend fun enableModbusTcp(platform: SmaPlatform, credentials: SmaCredentials): SmaEnableResult
}

/**
 * The installer login for an inverter's web API.
 *
 * [username] is only used by [SmaPlatform.EnnexOs], which has real user accounts.
 * [SmaPlatform.WebConnect] logs in as a fixed role and ignores it.
 */
internal data class SmaCredentials(val username: String, val password: String)

/** What the web API made of a request to switch the Modbus TCP server on. */
internal sealed interface SmaEnableResult {
    /** The inverter accepted the parameter write. */
    data object Enabled : SmaEnableResult

    /** The inverter rejected the installer login. */
    data object InvalidCredentials : SmaEnableResult

    /**
     * Anything else: the API was unreachable, answered unexpectedly, or refused the write.
     *
     * [cause] is the exception behind it when the request failed, and `null` when the inverter
     * answered and refused. The step reports one as the cause of the failure it returns, which is
     * what marks it as something to look into rather than an outcome the flow expects.
     */
    data class Failed(val reason: String, val cause: Throwable? = null) : SmaEnableResult {
        /** This failure as something a logger can raise, inventing one when the inverter just refused. */
        val throwable: Throwable get() = cause ?: DeviceConfigurationException(reason)
    }
}
