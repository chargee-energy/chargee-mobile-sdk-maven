package energy.chargee.onboarding.sma.clients

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull

/**
 * The body that switches the Modbus TCP server on for a WebConnect inverter.
 *
 * ```json
 * {"destDev":[],"values":[{"6800_088B7000":{"1":[1129]}}]}
 * ```
 *
 * Two things here are not what the open-source libraries do, and both come from `sma_setup.py`
 * running against our bench inverter. The inner key is the constant channel `"1"` and not a device
 * id, so no read is needed to address the write. And the value is an SMA enum **tag** — 1129 for
 * "Yes" or 308 for "On" — rather than a plain 1, which is why [webConnectEnableTag] has to look at
 * what the parameter currently holds before anything can be written to it.
 */
internal fun webConnectEnableBody(tag: Int): String =
    """{"destDev":[],"values":[{"${SmaApiPaths.WEBCONNECT_MODBUS_PARAMETER}":{"${SmaApiPaths.WEBCONNECT_CHANNEL}":[$tag]}}]}"""

/**
 * The tag that means "on" for a parameter currently holding [currentTag].
 *
 * SMA uses two different yes/no vocabularies and a parameter accepts only its own: a switch reading
 * On (308) or Off (303) takes 308, and anything else takes Yes (1129). Writing the wrong vocabulary
 * is how a write gets acknowledged and quietly does nothing.
 */
internal fun webConnectEnableTag(currentTag: Int?): Int =
    if (currentTag == SmaApiPaths.TAG_ON || currentTag == SmaApiPaths.TAG_OFF) SmaApiPaths.TAG_ON else SmaApiPaths.TAG_YES

/**
 * Digs the enum tag out of the value a WebConnect parameter read reports for one key.
 *
 * The shape is nested and varies by model, so each layer is peeled only if it is there:
 *
 * ```json
 * {"1": [{"val": {"tag": 1129}}]}
 * ```
 *
 * A channel key that is not `"1"` is accepted, since some models use another — only the first entry
 * is read, as `sma_setup.py` does. Returns `null` when the value holds no tag at all, which is not
 * an error: it is how [webConnectEnableTag] decides to use the Yes/No vocabulary.
 */
internal fun webConnectParameterTag(value: JsonElement?): Int? {
    val channelValue = if (value is JsonObject && "val" !in value) value.values.firstOrNull() else value
    val entry = if (channelValue is JsonArray) channelValue.firstOrNull() else channelValue
    val raw = if (entry is JsonObject) entry["val"] ?: entry else entry

    return when (raw) {
        is JsonObject -> (raw["tag"] as? JsonPrimitive)?.intOrNull
        is JsonPrimitive -> raw.intOrNull
        else -> null
    }
}

/**
 * The body that switches the Modbus TCP server on for an ennexOS device, stamped [timestamp] and
 * carrying [value].
 *
 * ```json
 * {"values":[{"channelId":"Parameter.Mb.TcpSrv.IsOn","timestamp":"<timestamp>","value":"<value>"}]}
 * ```
 *
 * Still untested — we own no ennexOS device — but the value is no longer guessed at: it is chosen
 * from what the device itself says the parameter accepts, by [ennexOsEnableValue].
 */
internal fun ennexOsEnableBody(timestamp: String, value: String): String =
    """{"values":[{"channelId":"${SmaApiPaths.ENNEXOS_MODBUS_CHANNEL}","timestamp":"$timestamp","value":"$value"}]}"""

/**
 * Picks the value meaning "on" from the [possibleValues] an ennexOS device reports for its Modbus
 * switch, or `null` when none of them does.
 *
 * Asking rather than assuming, because the vocabulary varies: the same switch may be expressed as
 * the tag 1129, the tag 308, or the words `On` or `Yes`. Refusing to write when none matches is
 * deliberate — an unrecognised vocabulary means we do not know what the device would do with any
 * value we picked.
 */
internal fun ennexOsEnableValue(possibleValues: List<String>): String? = ENNEXOS_ON_VALUES.firstOrNull { it in possibleValues }

private val ENNEXOS_ON_VALUES =
    listOf(SmaApiPaths.TAG_YES.toString(), SmaApiPaths.TAG_ON.toString(), "On", "Yes")
