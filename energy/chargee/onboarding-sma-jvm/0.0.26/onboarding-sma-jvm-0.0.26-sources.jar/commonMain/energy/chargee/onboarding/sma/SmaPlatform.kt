package energy.chargee.onboarding.sma

import energy.chargee.discovery.core.DiscoveredDevice

/**
 * Which generation of SMA inverter answered, which decides both the local web API used to switch
 * Modbus TCP on and where the Modbus registers live.
 *
 * The two generations are not variants of one protocol. They have different web APIs, different
 * unit-ID schemes and different power-limit registers, so every piece of the flow that talks to the
 * inverter branches on this and nothing assumes a shared default.
 */
internal enum class SmaPlatform(val key: String) {
    /**
     * The WebConnect generation: Sunny Boy 1.5–6.0, Sunny Tripower 3.0–10.0, CORE1, Smart Energy
     * and Sunny Boy Storage. Bench-tested on a Sunny Boy 3.6.
     *
     * Its unit ID is configurable and has to be read from the inverter
     * ([SmaConfig.UNIT_ID_LOOKUP_ADDRESS] on [SmaConfig.LOOKUP_UNIT_ID]), and it reports SMA as its
     * manufacturer at [SmaConfig.MANUFACTURER_ADDRESS].
     */
    WebConnect(key = "webconnect"),

    /**
     * The ennexOS generation: Sunny Tripower X, Sunny Boy Smart Energy, Sunny Tripower Hybrid X and
     * the Data Manager.
     *
     * Its unit IDs are fixed ([SmaConfig.DEFAULT_UNIT_ID] for the device itself), it has no unit-ID
     * lookup register, and it does not report a manufacturer. **Not tested on a device** — we own
     * none; everything here comes from SMA's documents and open-source integrations.
     */
    EnnexOs(key = "ennexos"),
}

/**
 * The generation recorded for this device during discovery, or `null` when the reply identified no
 * known generation.
 *
 * Discovery writes it under [SmaConfig.PLATFORM_PARAMETER] because the probe that determines it —
 * an unauthenticated request to the inverter's own web API — runs before the user has supplied any
 * credentials, and the answer is what decides which API the configure step then calls.
 */
internal fun DiscoveredDevice.smaPlatform(): SmaPlatform? =
    SmaPlatform.entries.firstOrNull { it.key == extraParameters[SmaConfig.PLATFORM_PARAMETER] }
