package energy.chargee.onboarding.sma

import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the SMA inverter onboarding flow. A flat, sealed hierarchy whose cases the
 * [SmaOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_SmaInput")
@Serializable
sealed interface SmaInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : SmaInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : SmaInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : SmaInput

    /**
     * Supplies the installer [username] and [password] for the inverter's own web UI, which is what
     * switches its Modbus TCP server on.
     *
     * Accepted while the flow is paused on device configuration — either because the credentials
     * have been asked for, or because the ones already given were rejected. Unlike every other
     * brand, SMA ships no universal installer password, so there is nothing to try before asking
     * and the first attempt is always the user's own.
     *
     * [username] is ignored on a WebConnect inverter, which logs in as a fixed role.
     * [SmaStep.AwaitingCredentials] says which kind answered.
     */
    @Serializable
    data class SetCredentials(val username: String, val password: String) : SmaInput
}
