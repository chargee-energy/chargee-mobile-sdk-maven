package energy.chargee.onboarding.sma

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * The [SerializersModule] registering the [SmaErrorCode] cases as polymorphic subtypes of the open
 * [OnboardingErrorCode].
 *
 * Each concrete case is registered directly rather than the sealed interface as a whole, for the
 * same reason as the shared local-device codes: kotlinx.serialization rejects a sealed serializer
 * as a `subclass` of another polymorphic base. A new case must be added here to be serializable.
 */
val smaErrorCodeSerializersModule: SerializersModule =
    SerializersModule {
        polymorphic(OnboardingErrorCode::class) {
            subclass(SmaErrorCode.UnsupportedModel::class)
            subclass(SmaErrorCode.UnsupportedFirmware::class)
            subclass(SmaErrorCode.ModbusNotEnabled::class)
        }
    }
