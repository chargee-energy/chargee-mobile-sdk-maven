package energy.chargee.onboarding.sma.clients

import energy.chargee.onboarding.sma.SmaConfig
import energy.chargee.onboarding.sma.SmaPlatform
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.cookies.HttpCookies
import io.ktor.client.request.forms.submitForm
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.put
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.Parameters
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Clock

internal expect fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit = {}): HttpClient

private val json = Json { ignoreUnknownKeys = true }

/**
 * Talks to an inverter's own local web API.
 *
 * The certificate is self-signed, so the engine is built by [createNativeHttpClient] — the same
 * trust-all-for-this-call arrangement the Alfen charger flow uses, since there is no certificate to
 * pin on hardware that generates its own.
 *
 * Every call is tried over HTTPS first and then plain HTTP, which is what `sma_setup.py` does: not
 * every generation and firmware serves TLS. `expectSuccess` is off because status codes carry
 * meaning here — a 401 on the login is a wrong password, not a transport failure.
 */
internal class SmaWebApiClient : SmaClient {
    override suspend fun <T> connect(ipAddress: String, block: suspend SmaClientConnection.() -> T): T {
        val client =
            createNativeHttpClient {
                expectSuccess = false
                // ennexOS hands out a JSESSIONID alongside the bearer token and expects it back.
                install(HttpCookies)
                install(HttpTimeout) {
                    connectTimeoutMillis = SmaConfig.VERIFICATION_CONNECT_TIMEOUT.inWholeMilliseconds
                    requestTimeoutMillis = SmaConfig.WEB_API_TIMEOUT.inWholeMilliseconds
                    socketTimeoutMillis = SmaConfig.WEB_API_TIMEOUT.inWholeMilliseconds
                }
            }

        try {
            return SmaWebApiConnection(client, ipAddress).block()
        } finally {
            client.close()
        }
    }
}

private class SmaWebApiConnection(private val client: HttpClient, private val ipAddress: String) : SmaClientConnection {
    /** The scheme that last worked, so the enable calls do not re-discover it on every request. */
    private var base: String? = null

    override suspend fun detectPlatform(): SmaPlatform? {
        for (scheme in SCHEMES) {
            val candidate = "$scheme://$ipAddress"

            val systemInfo = runCatching { client.get("$candidate${SmaApiPaths.ENNEXOS_SYSTEM_INFO}") }.getOrNull()
            if (systemInfo != null && systemInfo.status.isSuccess() && systemInfo.jsonObject()?.containsKey(ENNEXOS_FIELD) == true) {
                base = candidate
                return SmaPlatform.EnnexOs
            }

            // The web UI's own parameter metadata, which needs no login and is answered in about
            // half a second. Deliberately not a login attempt: an inverter delays a failed one by
            // roughly three seconds to frustrate guessing, and this probe runs against every host a
            // scan turns up rather than only the inverter.
            val metadata = runCatching { client.get("$candidate${SmaApiPaths.WEBCONNECT_OBJECT_METADATA}") }.getOrNull()
            if (metadata != null && metadata.status.isSuccess() && isSmaParameterMetadata(metadata.bodyAsText())) {
                base = candidate
                return SmaPlatform.WebConnect
            }
        }

        return null
    }

    override suspend fun enableModbusTcp(platform: SmaPlatform, credentials: SmaCredentials): SmaEnableResult =
        try {
            val url = base ?: "${SCHEMES.first()}://$ipAddress"
            when (platform) {
                SmaPlatform.WebConnect -> enableOverWebConnect(url, credentials)
                SmaPlatform.EnnexOs -> enableOverEnnexOs(url, credentials)
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (throwable: Exception) {
            // Carried rather than flattened into the message: it is the only thing that says the
            // request failed rather than the inverter refusing.
            SmaEnableResult.Failed(throwable.message ?: "the web API could not be reached", throwable)
        }

    /**
     * Logs in as the installer role, reads the Modbus switch to learn which yes/no vocabulary it
     * speaks, and writes it.
     *
     * The read is what makes the write correct rather than merely accepted: the same switch is
     * expressed as On/Off on some models and Yes/No on others.
     */
    private suspend fun enableOverWebConnect(url: String, credentials: SmaCredentials): SmaEnableResult {
        val login =
            client.post("$url${SmaApiPaths.WEBCONNECT_LOGIN}") {
                contentType(ContentType.Application.Json)
                setBody("""{"right":"${SmaApiPaths.WEBCONNECT_INSTALLER_ROLE}","pass":"${credentials.password.escaped()}"}""")
            }

        val body = login.jsonObject()
        val sessionId = (body?.get("result") as? JsonObject)?.get("sid")?.stringOrNull()
        if (sessionId == null) {
            // 503 means the inverter is already serving as many sessions as it will.
            val error = (body?.get("err") as? JsonPrimitive)?.intOrNull
            return if (error == SESSIONS_EXHAUSTED) {
                SmaEnableResult.Failed("the inverter is already serving as many web sessions as it allows")
            } else {
                SmaEnableResult.InvalidCredentials
            }
        }

        try {
            val parameters =
                client.post("$url${SmaApiPaths.WEBCONNECT_GET_ALL_PARAM_VALUES}") {
                    parameter("sid", sessionId)
                    contentType(ContentType.Application.Json)
                    setBody("""{"destDev":[]}""")
                }

            val device = (parameters.jsonObject()?.get("result") as? JsonObject)?.values?.firstOrNull() as? JsonObject
            val switch =
                device?.get(SmaApiPaths.WEBCONNECT_MODBUS_PARAMETER)
                    ?: return SmaEnableResult.Failed("this inverter does not expose the Modbus TCP server parameter")

            val write =
                client.post("$url${SmaApiPaths.WEBCONNECT_SET_PARAM_VALUES}") {
                    parameter("sid", sessionId)
                    contentType(ContentType.Application.Json)
                    setBody(webConnectEnableBody(webConnectEnableTag(webConnectParameterTag(switch))))
                }

            // A successful write answers with an empty object; anything carrying `err` did not take.
            val result = write.jsonObject()
            return if (write.status.isSuccess() && result != null && "err" !in result) {
                SmaEnableResult.Enabled
            } else {
                SmaEnableResult.Failed("the inverter refused the parameter write")
            }
        } finally {
            // The inverter serves only a few sessions at a time, so one is never left open.
            runCatching { client.post("$url${SmaApiPaths.WEBCONNECT_LOGOUT}") { parameter("sid", sessionId) } }
        }
    }

    private suspend fun enableOverEnnexOs(url: String, credentials: SmaCredentials): SmaEnableResult {
        val token =
            client.submitForm(
                url = "$url${SmaApiPaths.ENNEXOS_TOKEN}",
                formParameters =
                    Parameters.build {
                        append("grant_type", "password")
                        append("username", credentials.username)
                        append("password", credentials.password)
                    },
            )

        val accessToken =
            token.jsonObject()?.get("access_token")?.stringOrNull() ?: return SmaEnableResult.InvalidCredentials

        val search =
            client.post("$url${SmaApiPaths.ENNEXOS_PARAMETER_SEARCH}") {
                header("Authorization", "Bearer $accessToken")
                contentType(ContentType.Application.Json)
                setBody("""{"queryItems":[{"componentId":"${SmaApiPaths.ENNEXOS_SELF}"}]}""")
            }

        val possibleValues = search.modbusSwitchPossibleValues()
        val value =
            ennexOsEnableValue(possibleValues)
                ?: return SmaEnableResult.Failed(
                    if (possibleValues.isEmpty()) {
                        "this device does not expose the Modbus TCP server parameter"
                    } else {
                        "the Modbus TCP server parameter accepts none of the values that mean on: $possibleValues"
                    },
                )

        val write =
            client.put("$url${SmaApiPaths.ENNEXOS_PARAMETERS}") {
                header("Authorization", "Bearer $accessToken")
                contentType(ContentType.Application.Json)
                setBody(ennexOsEnableBody(smaTimestamp(Clock.System.now()), value))
            }

        return if (write.status.isSuccess()) {
            SmaEnableResult.Enabled
        } else {
            SmaEnableResult.Failed("the inverter refused the parameter write: ${write.status}")
        }
    }

    /** The values the device says its Modbus switch accepts, from a parameter search answer. */
    private suspend fun HttpResponse.modbusSwitchPossibleValues(): List<String> {
        val components = runCatching { json.parseToJsonElement(bodyAsText()) as? JsonArray }.getOrNull().orEmpty()
        val values = (components.firstOrNull() as? JsonObject)?.get("values") as? JsonArray ?: return emptyList()
        val channel =
            values.filterIsInstance<JsonObject>().firstOrNull {
                it["channelId"]?.stringOrNull() == SmaApiPaths.ENNEXOS_MODBUS_CHANNEL
            } ?: return emptyList()

        return (channel["possibleValues"] as? JsonArray).orEmpty().mapNotNull { it.stringOrNull() }
    }

    private suspend fun HttpResponse.jsonObject(): JsonObject? =
        runCatching { json.parseToJsonElement(bodyAsText()) as? JsonObject }.getOrNull()
}

/** Tried in order: not every generation and firmware serves TLS. */
private val SCHEMES = listOf("https", "http")

private const val ENNEXOS_FIELD = SmaApiPaths.ENNEXOS_PRODUCT_FIELD

/** WebConnect's error code for "no session slots left". */
private const val SESSIONS_EXHAUSTED = 503

private fun JsonElement?.stringOrNull() = (this as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotEmpty() }

private fun JsonArray?.orEmpty(): JsonArray = this ?: JsonArray(emptyList())

private fun String.escaped() = replace("\\", "\\\\").replace("\"", "\\\"")
