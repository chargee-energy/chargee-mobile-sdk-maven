package energy.chargee.onboarding.sma

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Failures specific to onboarding an SMA inverter, layered on top of the shared
 * [energy.chargee.onboarding.localdevice.LocalDeviceErrorCode] cases the flow also emits.
 *
 * All three come from the same place: SMA ships with Modbus TCP switched off, so the flow has to
 * switch it on and then establish what it is talking to — and each of these is a way that can end
 * without the inverter being usable. A rejected installer login is **not** here; it is reported as
 * the shared
 * [DeviceConfigurationFailure][energy.chargee.onboarding.localdevice.LocalDeviceErrorCode.DeviceConfigurationFailure]
 * with `invalidCredentials` set, because the host app handles it the same way it does for every
 * brand.
 */
@ObjCName("_SmaErrorCode")
@Serializable
sealed interface SmaErrorCode : OnboardingErrorCode {
    /**
     * The inverter identified itself as a model the Chargee device's driver cannot drive.
     *
     * Covers the inverters that reach Modbus only through a plug-in Speedwire data module and the
     * Sunny Tripower TL-20, whose register set matches neither generation. These answer enough
     * registers to look onboardable while lacking the unit-ID lookup and the limit registers the
     * driver needs, so they are refused deliberately rather than registered and left reporting
     * nothing.
     *
     * [deviceTypeCode] is the raw code read from the inverter, passed through so an unrecognised
     * model can be identified from a support report rather than guessed at.
     */
    @Serializable
    data class UnsupportedModel(val deviceTypeCode: Int?) : SmaErrorCode

    /**
     * The inverter runs firmware older than the minimum its generation needs, where the register set
     * is too thin to drive. Early Sunny Tripower X firmware served almost nothing but the AC power
     * register.
     *
     * [version] is what the inverter reported and [minimumVersion] what its generation requires,
     * both as SMA writes them (`4.10.10.R`), so the user can be told what to update to.
     */
    @Serializable
    data class UnsupportedFirmware(val version: String, val minimumVersion: String) : SmaErrorCode

    /**
     * The installer login succeeded and the inverter accepted the parameter write, but the Modbus
     * TCP server never came up.
     *
     * Kept apart from a configuration failure because nothing went wrong on the wire: SMA
     * acknowledges configuration writes it then silently does not store, so a normal reply is no
     * proof the setting took. The flow waits [SmaConfig.MODBUS_READY_TIMEOUT] for the port to start
     * answering and reports this when it never does — which usually means the parameter has to be
     * set from the inverter's own web UI or the SMA 360° app instead.
     */
    @Serializable
    data object ModbusNotEnabled : SmaErrorCode
}
