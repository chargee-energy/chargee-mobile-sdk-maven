package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.localdevice.modbus.uint16
import energy.chargee.onboarding.sma.SmaConfig

private val LOOKUP_ADDRESS = SmaConfig.UNIT_ID_LOOKUP_ADDRESS.uint16
private val LOOKUP_QUANTITY = SmaConfig.UNIT_ID_LOOKUP_QUANTITY.uint16

/** Offsets inside the lookup block: SUSy-ID, then the serial across two registers, then the unit ID. */
private const val UNIT_ID_OFFSET = 3

/**
 * Asks a [energy.chargee.onboarding.sma.SmaPlatform.WebConnect] inverter which Modbus unit its
 * register map answers on, read from unit [SmaConfig.LOOKUP_UNIT_ID].
 *
 * Returns `null` when the inverter gives no usable answer, which covers more cases than it looks:
 * the register is absent (a Modbus exception), it answers with the not-available pattern, or it
 * answers with something outside [SmaConfig.CONFIGURABLE_UNIT_IDS] and so is not a unit ID at all.
 * The caller falls back to [SmaConfig.DEFAULT_UNIT_ID] in each of them.
 *
 * A null therefore says nothing about *which* generation answered. An ennexOS device has no lookup
 * register and, depending on the model, refuses this read, answers it with the not-available
 * pattern, or does not answer at all — so the generation is settled over the inverter's web API
 * before anything gets this far, and is never inferred from here.
 *
 * @throws energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException if the device
 *   never answers. Unlike a refusal, silence is not a fact about the register, so it is the
 *   caller's to interpret.
 */
internal suspend fun resolveSmaUnitId(reader: SmaRegisterReader): Int? {
    val lookup =
        try {
            reader.readHoldingRegisters(LOOKUP_ADDRESS, LOOKUP_QUANTITY)
        } catch (_: IllegalStateException) {
            // A device without the register refuses the read rather than answering it blank.
            return null
        }

    return lookup.u16At(UNIT_ID_OFFSET)?.takeIf { it in SmaConfig.CONFIGURABLE_UNIT_IDS }
}
