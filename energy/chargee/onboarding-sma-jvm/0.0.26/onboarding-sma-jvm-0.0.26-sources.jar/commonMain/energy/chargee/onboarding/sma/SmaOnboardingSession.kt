package energy.chargee.onboarding.sma

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for SMA inverters. Routes [SmaInput] — device selection, rescanning, the
 * installer login, and retry — and surfaces [SmaStep]s in its typed state.
 */
@OnboardingSession
class SmaOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, SmaOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, SmaOnboardingContext, SmaStep, SmaInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered inverter: instead of registering a new inverter
     * the flow updates the stored configuration with the rediscovered values before re-verifying.
     *
     * A reset usually asks for no password at all, because an inverter onboarded once already
     * serves Modbus and the configure step finds it that way.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [SmaStep]s: a started step becomes [SmaStep.Running]; a
     * pause on discovery becomes [SmaStep.AwaitingDevice]; a pause on configuration becomes
     * [SmaStep.AwaitingCredentials]; and a failure the engine has stopped retrying becomes
     * [SmaStep.Failure] with a retry callback.
     *
     * A login the inverter rejected is the one failure that does not surface as
     * [SmaStep.Failure]. It becomes [SmaStep.AwaitingCredentials] again, marked
     * [OnboardingStepStatus.Failure] and carrying what was tried — because the only way forward is
     * another password, and offering a bare "retry" would resend the one already refused.
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, SmaStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, SmaOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, SmaStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = SmaStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == LocalDeviceStepId.ConfigureDevice &&
                        (event.errorCode as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials == true -> {
                        current.copy(currentStep = event.context.awaitingCredentials(OnboardingStepStatus.Failure))
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                SmaStep.Failure(
                                    event.stepId,
                                    error = event.errorCode,
                                    deviceUuid = event.context.deviceUuid,
                                ) {
                                    submit(SmaInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                SmaStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(SmaInput.SetDevice(it)) },
                                    rescan = { submit(SmaInput.RescanDevices) },
                                ),
                        )
                    }

                    LocalDeviceStepId.ConfigureDevice -> {
                        current.copy(currentStep = event.context.awaitingCredentials(OnboardingStepStatus.WaitingForInput))
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [SmaInput]: [Retry][SmaInput.Retry] re-runs a failed step,
     * [SetDevice][SmaInput.SetDevice] and [RescanDevices][SmaInput.RescanDevices] select an
     * inverter or scan again while the flow waits on discovery, and
     * [SetCredentials][SmaInput.SetCredentials] supplies the installer login.
     *
     * Credentials are accepted whether the flow is waiting for them or has just had some rejected,
     * which is why they use `requirePaused` rather than `requireWaitingForInput`: both states are
     * waiting for the same thing.
     */
    override fun submit(input: SmaInput): SubmitResult =
        when (input) {
            SmaInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is SmaInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            SmaInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }

            is SmaInput.SetCredentials -> {
                requirePaused(LocalDeviceStepId.ConfigureDevice) {
                    engine.resume { it.copy(username = input.username, password = input.password) }
                }
            }
        }

    /**
     * The credentials step for this context, asking the inverter's recorded generation whether a
     * username is wanted and carrying back whatever was tried last.
     */
    private fun SmaOnboardingContext.awaitingCredentials(status: OnboardingStepStatus) =
        SmaStep.AwaitingCredentials(
            status = status,
            requiresUsername = selectedDevice?.smaPlatform() == SmaPlatform.EnnexOs,
            previousUsername = username,
            previousPassword = password,
        ) { username, password ->
            submit(SmaInput.SetCredentials(username, password))
        }
}
