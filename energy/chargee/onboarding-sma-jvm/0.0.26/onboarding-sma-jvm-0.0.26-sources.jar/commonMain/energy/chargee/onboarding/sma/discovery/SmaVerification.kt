package energy.chargee.onboarding.sma.discovery

import energy.chargee.onboarding.sma.SmaPlatform

/**
 * The outcome of asking a candidate host which SMA generation it is.
 *
 * [Unreachable] and [Rejected] are kept apart deliberately, as they are for Growatt: one host
 * stopped answering mid-probe, the other answered and is not an SMA inverter. Both are dropped from
 * discovery, but only the second is a settled fact about the device — and here it is the only thing
 * that settles it, since nothing about an SMA inverter can be read over Modbus until the flow has
 * switched Modbus on.
 */
internal sealed interface SmaVerification {
    /** The host answered as an SMA inverter of [platform]. */
    data class Verified(val platform: SmaPlatform) : SmaVerification

    /** Something answered, and it is not an SMA inverter this SDK can onboard. [reason] says what failed. */
    data class Rejected(val reason: String) : SmaVerification

    /** Nothing answered at the address — wrong host, or the device went away mid-probe. */
    data object Unreachable : SmaVerification
}
