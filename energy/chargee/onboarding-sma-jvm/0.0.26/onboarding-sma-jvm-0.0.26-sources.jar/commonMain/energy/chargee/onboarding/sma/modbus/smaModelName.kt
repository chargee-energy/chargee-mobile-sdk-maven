package energy.chargee.onboarding.sma.modbus

/**
 * SMA's device type codes mapped to the product names SMA prints on the type label.
 *
 * Only the codes our research states outright are here. SMA publishes a code per model in each
 * family's parameter list, and this covers the two families those lists were read for — the bench
 * Sunny Boy's, and the Sunny Tripower X and Sunny Boy Smart Energy lists read for the ennexOS
 * research. The rest of the supported hardware is absent, which is why an unknown code resolves to
 * no name rather than to a rejection: a Sunny Tripower 3AV-40 is fully supported and simply is not
 * in this table.
 *
 * The US Sunny Boy Smart Energy codes are deliberately left out. Our research lists them
 * (19084–19134) but pairs them with no model, and the US ratings differ from the European ones, so
 * any mapping would be guesswork.
 */
private val MODEL_NAMES =
    mapOf(
        // Sunny Boy 3.0-6.0, 1AV-41 (WebConnect). 9402 is the bench inverter.
        9401 to "SB3.0-1AV-41",
        9402 to "SB3.6-1AV-41",
        9403 to "SB4.0-1AV-41",
        9404 to "SB5.0-1AV-41",
        9405 to "SB6.0-1AV-41",
        // Sunny Tripower X (ennexOS). Our research reads SMA's list as 9488 for the X 25 family
        // down to 9492 for the X 12, which is the order followed here. Note that the SMA emulator
        // in modbus-mock labels 9488 as "STP 12-50" instead - one of the two is wrong, and it is
        // only a model name either way, so this follows SMA's own parameter list.
        9488 to "STP 25-50",
        9489 to "STP 20-50",
        9491 to "STP 15-50",
        9492 to "STP 12-50",
        // Sunny Boy Smart Energy (ennexOS), European ratings.
        19128 to "SBSE3.6-50",
        19129 to "SBSE4.0-50",
        19130 to "SBSE5.0-50",
        19085 to "SBSE6.0-50",
        19103 to "SBSE8.0-50",
        19166 to "SBSE9.9-50",
    )

/**
 * The product name for [deviceTypeCode], or `null` when the code is absent or not one this SDK has
 * a name for.
 *
 * A `null` is stored as no model rather than as the raw number, the same choice the Growatt flow
 * makes: a model field holds a name, and putting a code there would make every consumer that
 * displays it show a number instead.
 */
internal fun smaModelName(deviceTypeCode: Int?): String? = deviceTypeCode?.let(MODEL_NAMES::get)
