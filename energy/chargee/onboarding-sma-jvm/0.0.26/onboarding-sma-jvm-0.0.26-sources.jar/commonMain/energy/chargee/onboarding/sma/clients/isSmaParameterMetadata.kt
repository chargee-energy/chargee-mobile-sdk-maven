package energy.chargee.onboarding.sma.clients

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/** An SMA parameter id, as the web UI's metadata is keyed: four hex digits, an underscore, eight. */
private val PARAMETER_ID = Regex("^[0-9A-Fa-f]{4}_[0-9A-Fa-f]{8}$")

private val lenientJson = Json { ignoreUnknownKeys = true }

/**
 * Whether [body] is the parameter metadata a WebConnect inverter serves, and so whether the host it
 * came from is one.
 *
 * The status code cannot answer this on its own. Plenty of local hardware answers `200` to any path
 * at all — a router and two appliances on our office network each return their own single-page app
 * for this URL — so what identifies an inverter is the shape of what comes back: a JSON object
 * whose keys are SMA parameter ids such as `6100_00416C00`.
 */
internal fun isSmaParameterMetadata(body: String): Boolean {
    val metadata = runCatching { lenientJson.parseToJsonElement(body) as? JsonObject }.getOrNull() ?: return false

    return metadata.keys.any { PARAMETER_ID.matches(it) }
}
