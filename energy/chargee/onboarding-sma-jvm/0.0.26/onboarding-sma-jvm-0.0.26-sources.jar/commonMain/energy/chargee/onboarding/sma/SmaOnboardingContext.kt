package energy.chargee.onboarding.sma

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext

/**
 * The mutable context that flows through the SMA onboarding steps.
 *
 * It adds the installer login and the Modbus unit to the shared state, which is the shape of the
 * SMA problem: the inverter ships with its Modbus server switched off, so the flow has to log in to
 * the inverter's own web API to switch it on, and only afterwards can it ask the inverter which
 * unit its register map answers on.
 *
 * What the configure step learns about the inverter beyond that — its serial and firmware — travels
 * on [selectedDevice]'s [DiscoveredDevice.extraParameters] rather than as fields here, the same
 * choice the Growatt flow makes: they are facts about the device, and the device is what carries
 * them to a UI choosing between several.
 */
data class SmaOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    /** Installer username. Only [SmaPlatform.EnnexOs] uses it; WebConnect logs in as a fixed role. */
    val username: String? = null,
    /** Installer password, held only for the length of the flow and never stored on the device. */
    val password: String? = null,
    /** The Modbus unit the inverter answers on, read from the inverter rather than assumed. */
    val unitId: Int? = null,
) : LocalDeviceOnboardingContext<SmaOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
