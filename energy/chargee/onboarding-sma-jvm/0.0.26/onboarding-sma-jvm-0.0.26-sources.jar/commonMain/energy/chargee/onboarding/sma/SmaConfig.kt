package energy.chargee.onboarding.sma

import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * SMA-specific constants shared across the flow, module, clients, and discovery wiring.
 *
 * Every value here comes from the embedded team's research on a bench Sunny Boy 3.6 (SB3.6-1AV-41,
 * firmware 4.10.10.R) or from SMA's own documents, recorded under "SMA inverters: Modbus TCP
 * reference" in Confluence. Where a value is documented but untested, its own doc comment says so.
 */
object SmaConfig {
    /** Brand identifier used as the SMA onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "sma"

    /**
     * Modbus TCP port, once the server has been switched on.
     *
     * Unlike every other brand onboarded so far, this port is **closed on a new or factory-reset
     * inverter**: SMA ships with the Modbus TCP server disabled, and a factory reset disables it
     * again. Discovery therefore cannot look for it, and the flow's job is to open it.
     */
    const val DEFAULT_PORT = 502

    /**
     * Port of the inverter's own web UI, which is what the flow logs in to in order to switch Modbus
     * on, and what discovery falls back to scanning for.
     *
     * Always served, on both generations and whatever the state of the Modbus server, which is
     * exactly why it is usable as a discovery marker when [DEFAULT_PORT] is not.
     */
    const val WEB_UI_PORT = 443

    /** Multicast group every SMA device with Speedwire answers discovery on. */
    const val SPEEDWIRE_GROUP = "239.12.255.254"

    /** UDP port the Speedwire discovery request is sent to on [SPEEDWIRE_GROUP]. */
    const val SPEEDWIRE_PORT = 9522

    /**
     * The Speedwire discovery request, answered by every SMA device on the network whether or not
     * Modbus is switched on — which is what makes it the preferred strategy over any port scan.
     */
    val SPEEDWIRE_REQUEST: ByteArray = "534d4100000402a0ffffffff0000002000000000".hexToByteArray()

    /**
     * The four bytes every Speedwire datagram starts with — `SMA\0`. The whole of what a reply is
     * checked for: it identifies the vendor, and everything else worth knowing about the device is
     * read over Modbus afterwards rather than guessed at from offsets no source documents.
     */
    val SPEEDWIRE_MAGIC: ByteArray = byteArrayOf(0x53, 0x4D, 0x41, 0x00)

    /**
     * How long discovery listens for replies before completing. Several inverters can answer one
     * request, so the window is a collection period rather than a deadline for the first reply.
     */
    val DISCOVERY_TIMEOUT: Duration = 10.seconds

    /**
     * Modbus unit the unit-ID lookup is read from on a [SmaPlatform.WebConnect] inverter. Unit 1 is
     * the communication-product slot; on a lone inverter [UNIT_ID_LOOKUP_ADDRESS] is the only thing
     * there worth reading.
     */
    const val LOOKUP_UNIT_ID = 1

    /**
     * Where a [SmaPlatform.WebConnect] inverter reports which unit its register map answers on, as
     * four registers: SUSy-ID (U16), serial number (U32), then the unit ID (U16).
     *
     * The SUSy-ID coming **first** is worth stating, because several sources describe this block as
     * "serial, SUSy-ID, unit ID". On our bench inverter it is not.
     */
    const val UNIT_ID_LOOKUP_ADDRESS = 42109

    /** How many registers [UNIT_ID_LOOKUP_ADDRESS] spans. */
    const val UNIT_ID_LOOKUP_QUANTITY = 4

    /**
     * The unit an inverter's register map is assumed to answer on when the inverter does not say.
     *
     * It is 3 for both generations, for two different reasons. On [SmaPlatform.WebConnect] the unit
     * ID is configurable and 3 is the factory default, so this is the fallback when
     * [UNIT_ID_LOOKUP_ADDRESS] gives nothing usable. On [SmaPlatform.EnnexOs] there is no lookup at
     * all and 3 is fixed by the unit scheme — 1 product info, 2 system values, 3 this device, 10+
     * subdevices, 126 SunSpec. Documented, not tested.
     */
    const val DEFAULT_UNIT_ID = 3

    /**
     * The unit IDs a [SmaPlatform.WebConnect] inverter may be configured onto. A lookup answering
     * outside this range is not a unit ID — it is a not-available pattern or a misread — so
     * [DEFAULT_UNIT_ID] is used instead.
     */
    val CONFIGURABLE_UNIT_IDS = 3..123

    /**
     * First register of the identity block, and how many registers it spans: 30051 through 30060,
     * which is the read our research cites as safe to make in one go.
     *
     * Read as one block rather than register by register. The unused addresses inside it answer as
     * not-available rather than failing, and SMA asks for values to be grouped into few requests —
     * while a read that *ended* mid-value would be refused outright, which is why the block runs to
     * 30060 and not to 30059.
     */
    const val IDENTITY_ADDRESS = 30051

    /** How many registers [IDENTITY_ADDRESS] spans, ending on the last register of the firmware value. */
    const val IDENTITY_QUANTITY = 10

    /** Device class, distinguishing a solar inverter (8001) from a battery (8007) or hybrid (8009). */
    const val DEVICE_CLASS_ADDRESS = 30051

    /** Device type, whose code identifies the model — 9402 is the bench Sunny Boy 3.6, for example. */
    const val DEVICE_TYPE_ADDRESS = 30053

    /**
     * Manufacturer, which reads 461 for SMA on a [SmaPlatform.WebConnect] inverter and is **absent
     * on ennexOS**, so it confirms a vendor but its absence does not deny one.
     */
    const val MANUFACTURER_ADDRESS = 30055

    /** The value [MANUFACTURER_ADDRESS] holds on an SMA device. */
    const val MANUFACTURER_SMA = 461

    /** Serial number. */
    const val SERIAL_ADDRESS = 30057

    /** Firmware version, packed as BCD major, BCD minor, build, release type. */
    const val FIRMWARE_ADDRESS = 30059

    /**
     * How long to wait for the TCP connection while verifying a candidate.
     *
     * Shorter than the Modbus client's own default for the same reason as Growatt's: every
     * candidate waits in turn, so a connection that now takes seconds is a dying link rather than a
     * slow one.
     */
    val VERIFICATION_CONNECT_TIMEOUT: Duration = 2.seconds

    /** How long to wait for the inverter to answer each identity read before giving up on it. */
    val VERIFICATION_RESPONSE_TIMEOUT: Duration = 2.seconds

    /**
     * How many times an unanswered identity read is resent before the candidate counts as
     * unreachable. Counts the initial attempt, so `2` means one retry.
     */
    const val VERIFICATION_MAX_ATTEMPTS = 2

    /**
     * How long one call to the inverter's web API may take.
     *
     * Longer than the Modbus verification timeouts because this is not a scan: by the time it runs,
     * one inverter has been chosen and the user is waiting on it. The connect timeout stays at
     * [VERIFICATION_CONNECT_TIMEOUT], since a host that will not accept a connection in two seconds
     * will not accept one in fifteen.
     */
    val WEB_API_TIMEOUT: Duration = 15.seconds

    /**
     * How long the unauthenticated generation probe may take per candidate.
     *
     * Short on purpose: it runs once for every host a discovery turns up, and on the fallback path
     * that is every host on the subnet with a web server. It is not as short as it could be, since
     * local hardware that answers slowly is common — we measured an appliance on our own network
     * taking nearly three seconds to answer a path it does not serve.
     */
    val VERIFICATION_HTTP_TIMEOUT: Duration = 5.seconds

    /**
     * How long to keep checking for the Modbus server after switching it on.
     *
     * The server does not come up with the write that enables it: on the bench the port opened
     * about 6 seconds later. And a write reply is not proof it was stored at all — configuration
     * writes can be acknowledged and silently ignored — so the only way to know is to keep asking
     * the inverter until it answers.
     */
    val MODBUS_READY_TIMEOUT: Duration = 30.seconds

    /** How long to wait between checks while waiting out [MODBUS_READY_TIMEOUT]. */
    val MODBUS_READY_POLL_INTERVAL: Duration = 2.seconds

    /**
     * Ceiling on one run of the configure step, enforced by the engine.
     *
     * It bounds a single execution, not the pause while the user types a password: the engine
     * applies a step timeout around `execute`, which has already returned by the time the flow
     * pauses for input, and a resumed step is executed again under a fresh timeout.
     */
    val CONFIGURE_TIMEOUT: Duration = 90.seconds

    /**
     * `extraParameters` key naming the generation that answered, as a [SmaPlatform] key. Written by
     * discovery, which determines it without credentials, and read by the configure step to decide
     * which web API to call.
     */
    const val PLATFORM_PARAMETER = "platform"

    /** `extraParameters` key carrying the inverter serial number read during verification. */
    const val SERIAL_PARAMETER = "serial"

    /** `extraParameters` key carrying the inverter firmware version read during verification. */
    const val FIRMWARE_PARAMETER = "firmware"

    /** `extraParameters` key carrying the inverter model name resolved from its device type code. */
    const val MODEL_PARAMETER = "model"
}
