package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.localdevice.modbus.uint16
import energy.chargee.onboarding.sma.SmaConfig

private val IDENTITY_ADDRESS = SmaConfig.IDENTITY_ADDRESS.uint16
private val IDENTITY_QUANTITY = SmaConfig.IDENTITY_QUANTITY.uint16

private const val DEVICE_CLASS_OFFSET = SmaConfig.DEVICE_CLASS_ADDRESS - SmaConfig.IDENTITY_ADDRESS
private const val DEVICE_TYPE_OFFSET = SmaConfig.DEVICE_TYPE_ADDRESS - SmaConfig.IDENTITY_ADDRESS
private const val MANUFACTURER_OFFSET = SmaConfig.MANUFACTURER_ADDRESS - SmaConfig.IDENTITY_ADDRESS
private const val SERIAL_OFFSET = SmaConfig.SERIAL_ADDRESS - SmaConfig.IDENTITY_ADDRESS
private const val FIRMWARE_OFFSET = SmaConfig.FIRMWARE_ADDRESS - SmaConfig.IDENTITY_ADDRESS

/**
 * Reads the identity block off whatever [reader] is talking to, as one request.
 *
 * Nothing here decides whether the device is usable — that is [unsupportedReason]'s job. This only
 * reports what the inverter said, with every register it had no value for coming back as `null`
 * rather than as a number.
 *
 * @throws IllegalStateException if the block cannot be read at all, which on an SMA inverter means
 *   a Modbus exception: the device is listening but is not serving this register map.
 * @throws energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException if the device
 *   stops answering part-way through.
 */
internal suspend fun readSmaIdentity(reader: SmaRegisterReader): SmaIdentity {
    val identity = reader.readHoldingRegisters(IDENTITY_ADDRESS, IDENTITY_QUANTITY)

    return SmaIdentity(
        deviceClass = identity.u32At(DEVICE_CLASS_OFFSET)?.toInt(),
        deviceTypeCode = identity.u32At(DEVICE_TYPE_OFFSET)?.toInt(),
        manufacturer = identity.u32At(MANUFACTURER_OFFSET)?.toInt(),
        serialNumber = identity.u32At(SERIAL_OFFSET),
        firmware = decodeSmaFirmware(identity.u32At(FIRMWARE_OFFSET)),
    )
}
