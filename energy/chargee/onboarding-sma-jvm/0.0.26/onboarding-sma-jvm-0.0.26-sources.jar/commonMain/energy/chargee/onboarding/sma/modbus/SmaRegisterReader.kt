package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.localdevice.modbus.Uint16

/**
 * The single Modbus operation the SMA identity reads need, narrowed to a function so they can be
 * driven without a socket.
 *
 * Backed in production by [energy.chargee.onboarding.localdevice.modbus.ModbusConnection], whose
 * contract it inherits: a Modbus exception response or malformed framing throws
 * [IllegalStateException], and a peer that never answers throws
 * [energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException].
 *
 * The distinction carries meaning here. An SMA inverter answers an address it does not serve with
 * an exception, which is a fact about the device — notably how a WebConnect inverter and an ennexOS
 * one differ at the unit-ID lookup — whereas silence says only that nothing arrived.
 */
internal fun interface SmaRegisterReader {
    suspend fun readHoldingRegisters(address: Uint16, quantity: Uint16): Array<Uint16>
}
