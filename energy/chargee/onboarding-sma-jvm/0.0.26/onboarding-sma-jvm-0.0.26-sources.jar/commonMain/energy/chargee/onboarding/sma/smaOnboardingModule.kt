package energy.chargee.onboarding.sma

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.discovery.core.logged
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.sma.SmaConfig.BRAND
import energy.chargee.onboarding.sma.clients.SmaClient
import energy.chargee.onboarding.sma.clients.SmaWebApiClient
import energy.chargee.onboarding.sma.discovery.SmaDeviceVerifier
import energy.chargee.onboarding.sma.discovery.SpeedwireResponseParser
import energy.chargee.onboarding.sma.discovery.createSmaDiscovery
import energy.chargee.onboarding.sma.discovery.probeSmaGeneration

val smaOnboardingModule =
    module {
        factory<SmaClient> { SmaWebApiClient() }
        // Two strategies rather than one, because neither is sufficient alone. Speedwire is
        // answered only by SMA devices and works while the Modbus server is still off, but reaching
        // its multicast group needs an entitlement the consuming app does not hold on iOS. The port
        // scan is the fallback that needs nothing special: it sweeps the web UI's port, which an
        // SMA inverter always serves, and leans on the verifier to discard everything else on the
        // subnet that happens to run a web server.
        factory<DeviceDiscovery>(name = BRAND) {
            createSmaDiscovery(
                speedwireDiscovery =
                    get<DeviceDiscovery>(
                        name = DiscoveryConfig.UDP_BROADCAST_DISCOVERY_TYPE,
                        parameters =
                            parametersOf(
                                SmaConfig.SPEEDWIRE_PORT,
                                SmaConfig.SPEEDWIRE_REQUEST,
                                SmaConfig.DISCOVERY_TIMEOUT,
                                SpeedwireResponseParser,
                                SmaConfig.SPEEDWIRE_GROUP,
                            ),
                    ),
                webUiDiscovery =
                    get<DeviceDiscovery>(
                        name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE,
                        parameters = parametersOf(SmaConfig.WEB_UI_PORT),
                    ),
                verifier = SmaDeviceVerifier(probeSmaGeneration(get())),
            ).logged(BRAND)
        }
        factoryWithParameters { parameters ->
            SmaOnboardingSession(
                OnboardingEngine(
                    initialContext = SmaOnboardingContext(),
                    flow =
                        createSmaOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            smaDiscovery = get<DeviceDiscovery>(name = BRAND),
                            smaClient = get(),
                            localDeviceRepository = get(),
                            inverterRepository = get(),
                        ),
                ),
            )
        }
    }
