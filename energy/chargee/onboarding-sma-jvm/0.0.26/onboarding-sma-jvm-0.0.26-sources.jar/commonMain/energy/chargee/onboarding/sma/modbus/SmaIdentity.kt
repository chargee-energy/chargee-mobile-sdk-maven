package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.sma.SmaErrorCode
import energy.chargee.onboarding.sma.SmaPlatform

/**
 * What an SMA inverter says about itself, read from its identity block once Modbus TCP is up.
 *
 * Every field is nullable because SMA answers a register it has no value for with a "not
 * available" pattern rather than an error, and does so for real reasons: an ennexOS device has no
 * manufacturer register at all, and a WebConnect inverter reports its device type as not-available
 * while it is booting or asleep. A null here therefore means "the inverter did not say", never
 * "the inverter is wrong".
 */
internal data class SmaIdentity(
    /** Device class: 8001 a solar inverter, 8007 a battery inverter, 8009 a hybrid. */
    val deviceClass: Int?,
    /** Device type, whose code identifies the model. Resolve it with [smaModelName]. */
    val deviceTypeCode: Int?,
    /** Manufacturer: 461 for SMA on WebConnect, absent on ennexOS. */
    val manufacturer: Int?,
    /** Serial number. A U32, so it does not fit an `Int` — the bench inverter's is 3018587439. */
    val serialNumber: Long?,
    /** Firmware version. */
    val firmware: SmaFirmware?,
) {
    /** The product name for [deviceTypeCode], or `null` when it names no model this SDK knows. */
    val model: String? get() = smaModelName(deviceTypeCode)
}

/**
 * Device classes the Chargee device's driver can drive: a solar inverter, a battery inverter, or a
 * hybrid of the two.
 */
private val SUPPORTED_DEVICE_CLASSES = setOf(8001, 8007, 8009)

/**
 * The oldest ennexOS firmware worth onboarding.
 *
 * Early Sunny Tripower X firmware served almost nothing but the AC power register, so a device
 * below this would register successfully and then report no readings. SMA's own minimums differ per
 * model — 03.14.22.R for the Sunny Tripower X, 03.12.17.R for the Sunny Boy Smart Energy — and
 * telling those two apart needs a device type code we do not have for every ennexOS model, so the
 * lower of the two is used. It is the floor that cannot wrongly reject supported hardware.
 */
private val ENNEXOS_MINIMUM_FIRMWARE = SmaFirmware(major = 3, minor = 12, build = 17, releaseType = SmaFirmware.RELEASE_TYPE_R)

/**
 * Why this inverter cannot be onboarded, or `null` when nothing stands in the way.
 *
 * Two checks, and deliberately only two:
 *
 * - **Device class**, which rejects the ennexOS products that are not inverters — a Data Manager or
 *   an eCharger runs the same platform and answers the same registers. It is checked rather than the
 *   device type code because a code this SDK has no name for is an ordinary supported inverter whose
 *   family's parameter list we have not read, not an unsupported one.
 * - **Firmware**, for [SmaPlatform.EnnexOs] only. The WebConnect families are deliberately not
 *   gated: their documented minimums span 3.14.xx.R for the Sunny Tripower CORE1 up to 4.03.07.R for
 *   the Sunny Boy, and with no way to tell which family a given inverter belongs to, a floor set
 *   high enough to mean anything would reject a perfectly good CORE1. Firmware too old to serve the
 *   register map shows up anyway, as an identity block that cannot be read.
 *
 * What is *not* checked here is the hardware this SDK does not support at all — the inverters that
 * reach Modbus only through a plug-in Speedwire data module, and the Sunny Tripower TL-20. Those
 * have no local web UI, so they never answer the probe that discovery identifies a generation with,
 * and never reach this point.
 */
internal fun SmaIdentity.unsupportedReason(platform: SmaPlatform): SmaErrorCode? =
    when {
        deviceClass != null && deviceClass !in SUPPORTED_DEVICE_CLASSES -> {
            SmaErrorCode.UnsupportedModel(deviceTypeCode)
        }

        platform == SmaPlatform.EnnexOs && firmware != null && firmware < ENNEXOS_MINIMUM_FIRMWARE -> {
            SmaErrorCode.UnsupportedFirmware(firmware.toString(), ENNEXOS_MINIMUM_FIRMWARE.toString())
        }

        else -> {
            null
        }
    }
