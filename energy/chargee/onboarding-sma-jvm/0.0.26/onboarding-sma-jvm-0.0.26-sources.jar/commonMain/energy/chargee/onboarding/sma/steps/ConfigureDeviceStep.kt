package energy.chargee.onboarding.sma.steps

import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.sma.SmaConfig
import energy.chargee.onboarding.sma.SmaErrorCode
import energy.chargee.onboarding.sma.SmaOnboardingContext
import energy.chargee.onboarding.sma.SmaPlatform
import energy.chargee.onboarding.sma.clients.SmaClient
import energy.chargee.onboarding.sma.clients.SmaCredentials
import energy.chargee.onboarding.sma.clients.SmaEnableResult
import energy.chargee.onboarding.sma.modbus.SmaDeviceReading
import energy.chargee.onboarding.sma.modbus.readSmaDevice
import energy.chargee.onboarding.sma.modbus.unsupportedReason
import energy.chargee.onboarding.sma.smaPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Gets the chosen inverter to the point where the Chargee device can read it: switches its Modbus
 * TCP server on if it is off, then asks the inverter who it is.
 *
 * It probes before it prompts. The first thing it does is try to read the inverter over Modbus, and
 * when that succeeds the step is already done — no password is asked for and nothing is written.
 * That covers more than it sounds: an inverter a previous attempt configured, a reset of a device
 * already onboarded, and an installer who switched Modbus on in the SMA 360° app before starting.
 * It is also why the flow needs no branch around this step and why the reset path needs no
 * special-casing.
 *
 * Only when Modbus does not answer does it ask for the installer login, switch the server on
 * through [client], and wait. The waiting is not optional: the port opened about six seconds after
 * the write on the bench, and SMA acknowledges configuration writes it then silently does not
 * store — so the inverter answering over Modbus is the only thing that counts as proof.
 *
 * [readDevice] is the Modbus read, injected so the whole step can be driven without a socket.
 */
internal class ConfigureDeviceStep(
    private val client: SmaClient,
    private val readDevice: suspend (host: String, port: Int, platform: SmaPlatform) -> SmaDeviceReading = ::readSmaDevice,
) : OnboardingFlow.Step<LocalDeviceStepId, SmaOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    // Whether a failure carries a cause is what tells a monitoring logger a defect from an
    // outcome the flow is designed to produce — see the Logging section of the README.
    override suspend fun execute(context: SmaOnboardingContext): Result<SmaOnboardingContext> {
        val device =
            context.selectedDevice
                ?: return Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(),
                    DeviceConfigurationException("SMA onboarding reached the configuration step with no device selected"),
                )
        val platform =
            device.smaPlatform()
                ?: return Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(),
                    DeviceConfigurationException("The discovered device does not report which SMA platform it is"),
                )
        val host = device.ipAddress
        val port = device.port ?: SmaConfig.DEFAULT_PORT

        when (val reading = readDevice(host, port, platform)) {
            is SmaDeviceReading.Identified -> {
                return identified(context, reading)
            }

            is SmaDeviceReading.Refused -> {
                return Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(), reading.throwable)
            }

            SmaDeviceReading.Unreachable -> {
                Unit
            }
        }

        // Modbus is off, so the inverter has to be logged in to. SMA ships no universal installer
        // password the way Huawei does, so there is nothing to try before asking the user.
        val password = context.password ?: return Result.InputRequired(context, advanceAfterInput = false)
        val credentials = SmaCredentials(username = context.username.orEmpty(), password = password)

        when (val enabled = client.connect(host) { enableModbusTcp(platform, credentials) }) {
            SmaEnableResult.Enabled -> {
                Unit
            }

            SmaEnableResult.InvalidCredentials -> {
                // The installer login is the user's to correct and the flow asks for it again.
                return Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true))
            }

            is SmaEnableResult.Failed -> {
                return Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(), enabled.throwable)
            }
        }

        return when (val reading = awaitModbus(host, port, platform)) {
            is SmaDeviceReading.Identified -> {
                identified(context, reading)
            }

            // The port opened and serves something else. Waiting longer cannot change that.
            is SmaDeviceReading.Refused -> {
                Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(), reading.throwable)
            }

            // The write was accepted and the port never opened, which is exactly the case SMA
            // warns about: a configuration write can be acknowledged and silently not stored.
            // Nothing threw, so one is made — the install is stuck and someone should see it.
            SmaDeviceReading.Unreachable -> {
                Result.Failure(
                    context,
                    SmaErrorCode.ModbusNotEnabled,
                    DeviceConfigurationException("The inverter acknowledged the Modbus TCP write and the port never opened"),
                )
            }
        }
    }

    /**
     * Keeps asking the inverter until it answers over Modbus, or until the server has had long
     * enough to come up and plainly has not.
     *
     * A [SmaDeviceReading.Refused] ends the wait too, and is reported as itself: the port being
     * open is a fact, and no amount of waiting makes a device start serving a register map it does
     * not have. A timeout is reported as [SmaDeviceReading.Unreachable], the state it never left.
     */
    private suspend fun awaitModbus(host: String, port: Int, platform: SmaPlatform): SmaDeviceReading =
        withTimeoutOrNull(SmaConfig.MODBUS_READY_TIMEOUT) {
            var settled: SmaDeviceReading = SmaDeviceReading.Unreachable
            while (settled is SmaDeviceReading.Unreachable) {
                settled = readDevice(host, port, platform)
                if (settled is SmaDeviceReading.Unreachable) delay(SmaConfig.MODBUS_READY_POLL_INTERVAL)
            }
            settled
        } ?: SmaDeviceReading.Unreachable

    /**
     * Records what the inverter said, or refuses it.
     *
     * The model gets its own field because the registered device stores it; the serial and firmware
     * ride on the discovered device, which is what a UI shows when it lists what was found.
     */
    private fun identified(context: SmaOnboardingContext, reading: SmaDeviceReading.Identified): Result<SmaOnboardingContext> {
        val platform =
            context.selectedDevice?.smaPlatform()
                ?: return Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(),
                    DeviceConfigurationException("The discovered device does not report which SMA platform it is"),
                )

        // Hardware this SDK does not support yet: nothing is broken, and the flow says so to the
        // installer. No cause, so it stays a log line.
        reading.identity.unsupportedReason(platform)?.let { return Result.Failure(context, it) }

        val described =
            context.selectedDevice.copy(
                extraParameters =
                    context.selectedDevice.extraParameters +
                        buildMap {
                            reading.identity.serialNumber?.let { put(SmaConfig.SERIAL_PARAMETER, it.toString()) }
                            reading.identity.firmware?.let { put(SmaConfig.FIRMWARE_PARAMETER, it.toString()) }
                            reading.identity.model?.let { put(SmaConfig.MODEL_PARAMETER, it) }
                        },
            )

        return Result.Success(
            context.copy(
                selectedDevice = described,
                model = reading.identity.model ?: context.model,
                unitId = reading.unitId,
            ),
        )
    }
}
