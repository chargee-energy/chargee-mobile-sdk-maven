package energy.chargee.onboarding.sma.clients

/**
 * The local web API paths of both generations, the parameters written on each, and the enum tags
 * those parameters take.
 *
 * Taken from the embedded team's `sma_setup.py` (attached to CHRG-3348), which does this
 * successfully against our bench Sunny Boy, rather than from the open-source libraries it was
 * originally reconstructed from — those write a different value.
 */
internal object SmaApiPaths {
    /** ennexOS: unauthenticated system information. Answering it at all identifies the generation. */
    const val ENNEXOS_SYSTEM_INFO = "/api/v1/system/info"

    /** The field an ennexOS device names its product with, and the one its presence is checked by. */
    const val ENNEXOS_PRODUCT_FIELD = "productFriendlyNameTagId"

    /** ennexOS: OAuth-style token endpoint. */
    const val ENNEXOS_TOKEN = "/api/v1/token"

    /** ennexOS: parameter search. */
    const val ENNEXOS_PARAMETER_SEARCH = "/api/v1/parameters/search"

    /** ennexOS: parameter write, for the device itself. */
    const val ENNEXOS_PARAMETERS = "/api/v1/parameters/IGULD:SELF"

    /** ennexOS: the component id a device uses for itself. */
    const val ENNEXOS_SELF = "IGULD:SELF"

    /** ennexOS: the channel switching the Modbus TCP server on. */
    const val ENNEXOS_MODBUS_CHANNEL = "Parameter.Mb.TcpSrv.IsOn"

    /** ennexOS: the channel holding the Modbus TCP port. */
    const val ENNEXOS_MODBUS_PORT_CHANNEL = "Parameter.Mb.TcpSrv.Port"

    /**
     * WebConnect: the web UI's own parameter metadata, which is what a WebConnect inverter is
     * recognised by.
     *
     * Served without a login and answered in about half a second, and its keys are SMA parameter
     * ids — so it identifies the generation cheaply and without pretending to log in. That matters
     * because this probe runs against every host a scan turns up, not just the inverter.
     */
    const val WEBCONNECT_OBJECT_METADATA = "/data/ObjectMetadata_Istl.json"

    /** WebConnect: login, as a fixed role rather than a named user. */
    const val WEBCONNECT_LOGIN = "/dyn/login.json"

    /** WebConnect: log out, releasing the session. The inverter serves only a few at a time. */
    const val WEBCONNECT_LOGOUT = "/dyn/logout.json"

    /** WebConnect: read every parameter the logged-in role may see. */
    const val WEBCONNECT_GET_ALL_PARAM_VALUES = "/dyn/getAllParamValues.json"

    /** WebConnect: write parameter values. */
    const val WEBCONNECT_SET_PARAM_VALUES = "/dyn/setParamValues.json"

    /** WebConnect: the installer role, which is what `right` is set to when logging in. */
    const val WEBCONNECT_INSTALLER_ROLE = "istl"

    /** WebConnect: the parameter switching the Modbus TCP server on. */
    const val WEBCONNECT_MODBUS_PARAMETER = "6800_088B7000"

    /**
     * WebConnect: the channel index a parameter is written on.
     *
     * Always `"1"`. A read nests the value under a key that can vary on some models, but the write
     * is addressed to this constant — which is what `sma_setup.py` does, on a device.
     */
    const val WEBCONNECT_CHANNEL = "1"

    /** SMA's enum tag for "Yes". */
    const val TAG_YES = 1129

    /** SMA's enum tag for "No". */
    const val TAG_NO = 1130

    /** SMA's enum tag for "On". */
    const val TAG_ON = 308

    /** SMA's enum tag for "Off". */
    const val TAG_OFF = 303
}
