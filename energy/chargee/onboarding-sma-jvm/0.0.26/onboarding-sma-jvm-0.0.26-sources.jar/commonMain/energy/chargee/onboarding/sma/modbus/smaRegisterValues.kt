package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.localdevice.modbus.Uint16

/**
 * The patterns SMA answers with when a register has no value. Treating any of them as a number is
 * the mistake that shows up downstream as a spike of four billion.
 *
 * `0xFFFFFFFF` is the plain U32 pattern, `0xFFFFFFFE` the one unit 1 uses, and `0x00FFFFFD` the one
 * for the status and enum registers, which only use the lower 24 bits. Both of the latter were seen
 * on the bench, not inferred.
 */
private val U32_NOT_AVAILABLE = setOf(0xFFFFFFFFL, 0xFFFFFFFEL, 0x00FFFFFDL)

/** The U16 pattern for a register with no value. */
private const val U16_NOT_AVAILABLE = 0xFFFF

/**
 * Reads the two registers at [index] as a big-endian unsigned 32-bit value, or `null` when they
 * hold one of the not-available patterns.
 *
 * Returned as a `Long` because a U32 does not fit an `Int` — the bench inverter's serial number,
 * 3018587439, is larger than `Int.MAX_VALUE`.
 */
internal fun Array<Uint16>.u32At(index: Int): Long? {
    val raw = (this[index].value.toLong() shl 16) or this[index + 1].value.toLong()
    return raw.takeIf { it !in U32_NOT_AVAILABLE }
}

/**
 * Reads the register at [index] as an unsigned 16-bit value, or `null` when it holds the
 * not-available pattern.
 */
internal fun Array<Uint16>.u16At(index: Int): Int? = this[index].value.takeIf { it != U16_NOT_AVAILABLE }
