package energy.chargee.onboarding.sma.modbus

/**
 * A firmware version as SMA packs it into one U32 register: [major] and [minor] as BCD bytes, then
 * [build] as a plain byte and [releaseType] as a code.
 *
 * Ordering deliberately ignores [releaseType] and compares [major], [minor] and [build] only. The
 * release type says how a build was published, not how new it is, and SMA documents no ordering
 * over it — so comparing on it would invent a ranking rather than read one.
 */
internal data class SmaFirmware(val major: Int, val minor: Int, val build: Int, val releaseType: Int) : Comparable<SmaFirmware> {
    override fun compareTo(other: SmaFirmware): Int =
        compareValuesBy(this, other, SmaFirmware::major, SmaFirmware::minor, SmaFirmware::build)

    /**
     * The version as SMA writes it, e.g. `4.10.10.R`.
     *
     * Only release type 4 is rendered as a letter, because `R` for release is the only code our
     * research confirmed on a device. Any other code is rendered as its own number rather than
     * guessed at from the letters SMA's documents list elsewhere.
     */
    override fun toString(): String = "$major.${minor.pad()}.${build.pad()}.${releaseTypeLabel()}"

    private fun releaseTypeLabel() = if (releaseType == RELEASE_TYPE_R) "R" else releaseType.toString()

    private fun Int.pad() = toString().padStart(2, '0')

    companion object {
        /** The release type our bench inverter reported, rendered as `R`. */
        const val RELEASE_TYPE_R = 4
    }
}

/**
 * Decodes the four bytes of an SMA firmware register into an [SmaFirmware], or `null` when [raw] is
 * one of the "not available" patterns.
 *
 * [major] and [minor] are BCD — `0x10` is the decimal 10, not 16 — while the build byte is plain.
 * That mix is what makes `0x04100A04` read as `4.10.10.R`.
 */
internal fun decodeSmaFirmware(raw: Long?): SmaFirmware? {
    if (raw == null) return null

    val major = ((raw shr 24) and 0xFF).toInt().fromBcd() ?: return null
    val minor = ((raw shr 16) and 0xFF).toInt().fromBcd() ?: return null

    return SmaFirmware(
        major = major,
        minor = minor,
        build = ((raw shr 8) and 0xFF).toInt(),
        releaseType = (raw and 0xFF).toInt(),
    )
}

/** This byte read as two BCD digits, or `null` when either nibble is not a decimal digit. */
private fun Int.fromBcd(): Int? {
    val tens = (this shr 4) and 0x0F
    val units = this and 0x0F
    return if (tens > 9 || units > 9) null else tens * 10 + units
}
