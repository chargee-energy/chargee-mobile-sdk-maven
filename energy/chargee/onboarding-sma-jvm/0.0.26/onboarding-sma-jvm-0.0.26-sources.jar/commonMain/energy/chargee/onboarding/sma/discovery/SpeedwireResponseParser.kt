package energy.chargee.onboarding.sma.discovery

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.discovery.udpbroadcast.UdpDatagramParser
import energy.chargee.onboarding.sma.SmaConfig

/**
 * Reads a device's answer to the Speedwire discovery request.
 *
 * The reply is binary, so this is a [UdpDatagramParser] rather than a text one. It checks the whole
 * 18-byte Speedwire header rather than just the `SMA\0` magic — the same check the embedded team's
 * `sma_setup.py` makes, which is what it took to tell a reply apart from anything else that happens
 * to arrive on the socket.
 *
 * In particular it rejects a datagram byte-identical to the request we sent. Our own request opens
 * with the same magic, and a multicast datagram can come back to its sender, so without this the
 * phone reports itself as an inverter.
 *
 * Nothing past the header is read. The reply does carry device fields, but no source we have
 * documents their offsets, and the serial and firmware are read over Modbus later anyway.
 */
internal object SpeedwireResponseParser : UdpDatagramParser {
    override fun parse(payload: ByteArray, sourceAddress: String): DiscoveredDevice? =
        if (payload.isSpeedwireDiscoveryReply()) DiscoveredDevice(ipAddress = sourceAddress) else null
}

/** Length of the Speedwire header this parser validates. */
private const val HEADER_LENGTH = 18

private fun ByteArray.isSpeedwireDiscoveryReply(): Boolean {
    if (size < HEADER_LENGTH) return false
    if (contentEquals(SmaConfig.SPEEDWIRE_REQUEST)) return false

    val magic = SmaConfig.SPEEDWIRE_MAGIC
    if (!magic.indices.all { this[it] == magic[it] }) return false

    return u16At(4) == 4 &&
        u16At(6) == 0x02A0 &&
        u32At(8) == 1L &&
        u16At(12) == 2 &&
        u16At(14) == 0 &&
        u16At(16) == 1
}

private fun ByteArray.u16At(offset: Int): Int = ((this[offset].toInt() and 0xFF) shl 8) or (this[offset + 1].toInt() and 0xFF)

private fun ByteArray.u32At(offset: Int): Long = (u16At(offset).toLong() shl 16) or u16At(offset + 2).toLong()
