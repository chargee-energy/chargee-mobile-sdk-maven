package energy.chargee.onboarding.sma.modbus

import energy.chargee.onboarding.core.DeviceConfigurationException

/**
 * What came back from asking an inverter, over Modbus, who it is.
 *
 * The three outcomes say different things and the flow acts differently on each, which is why they
 * are kept apart rather than collapsed into a nullable identity.
 */
internal sealed interface SmaDeviceReading {
    /** The inverter answered on [unitId] and reported [identity]. */
    data class Identified(val unitId: Int, val identity: SmaIdentity) : SmaDeviceReading

    /**
     * Nothing answered on the Modbus port.
     *
     * On an SMA inverter this is the expected state rather than a fault: the server ships switched
     * off, and switching it off again closes the port outright. It is what tells the flow it has
     * work to do.
     */
    data object Unreachable : SmaDeviceReading

    /**
     * Something answered the Modbus port and refused to serve the SMA register map. [reason] says
     * what failed.
     *
     * Distinct from [Unreachable] because the port being open is a fact: switching Modbus on cannot
     * help a device that is already listening and does not speak this map.
     */
    data class Refused(val reason: String, val cause: Throwable? = null) : SmaDeviceReading {
        /**
         * This refusal as something a logger can raise.
         *
         * [cause] is the Modbus exception the inverter refused with — a
         * [ModbusErrorResponseException][energy.chargee.onboarding.localdevice.modbus.ModbusErrorResponseException]
         * carries the function and exception code it named — so it is worth far more than the
         * flattened [reason] once a report comes back from the field.
         */
        val throwable: Throwable get() = cause ?: DeviceConfigurationException(reason)
    }
}
