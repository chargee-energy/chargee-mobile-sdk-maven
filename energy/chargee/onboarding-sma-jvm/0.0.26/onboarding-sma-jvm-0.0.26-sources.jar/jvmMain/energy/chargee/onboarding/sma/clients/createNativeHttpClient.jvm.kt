package energy.chargee.onboarding.sma.clients

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.okhttp.OkHttp
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

private val trustAll =
    object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit

        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

/**
 * The JVM client, which matches the Android one.
 *
 * The JVM target exists so the SDK can be driven from a laptop while it is being worked on, and
 * talking to a device on the local network is most of what there is to debug — so this is a real
 * client rather than the error it used to be. The certificate is self-signed and trusted for the
 * call, exactly as on Android.
 */
internal actual fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit): HttpClient {
    val sslContext =
        SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(trustAll), SecureRandom())
        }

    return HttpClient(OkHttp) {
        block()
        engine {
            config {
                sslSocketFactory(sslContext.socketFactory, trustAll)
                hostnameVerifier { _, _ -> true }
            }
        }
    }
}
