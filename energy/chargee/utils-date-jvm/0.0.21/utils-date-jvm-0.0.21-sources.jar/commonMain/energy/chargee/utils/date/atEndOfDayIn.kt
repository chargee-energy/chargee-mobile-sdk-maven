package energy.chargee.utils.date

import kotlinx.datetime.DateTimeUnit
import kotlinx.datetime.LocalDate
import kotlinx.datetime.TimeZone
import kotlinx.datetime.atStartOfDayIn
import kotlinx.datetime.plus
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Instant

/**
 * Returns the last millisecond of this date in [timeZone].
 */
fun LocalDate.atEndOfDayIn(timeZone: TimeZone): Instant = plus(1, DateTimeUnit.DAY).atStartOfDayIn(timeZone).minus(1.milliseconds)
