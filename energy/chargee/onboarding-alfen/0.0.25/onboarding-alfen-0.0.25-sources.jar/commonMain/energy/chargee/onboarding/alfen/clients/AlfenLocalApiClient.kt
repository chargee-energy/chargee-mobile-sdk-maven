package energy.chargee.onboarding.alfen.clients

import energy.chargee.onboarding.core.InvalidCredentialsException
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.ResponseException
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

internal expect fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit = {}): HttpClient

internal class AlfenLocalApiClient : AlfenClient {
    override suspend fun <T> connect(ipAddress: String, block: suspend AlfenClientConnection.() -> T): T {
        val client =
            createNativeHttpClient {
                expectSuccess = true
                defaultRequest {
                    url("https://$ipAddress")
                    contentType(ContentType.Application.Json)
                }
                install(ContentNegotiation) {
                    json(Json { ignoreUnknownKeys = true })
                }
                install(HttpTimeout) {
                    requestTimeoutMillis = 15_000
                    connectTimeoutMillis = 15_000
                    socketTimeoutMillis = 15_000
                }
            }

        try {
            val connection = AlfenLocalApiConnection(client)
            return connection.block()
        } finally {
            runCatching { client.post("/api/logout") }
            client.close()
        }
    }
}

private class AlfenLocalApiConnection(private val httpClient: HttpClient) : AlfenClientConnection {
    override suspend fun authenticate(username: String, password: String) {
        try {
            httpClient.post("/api/login") {
                setBody(
                    mapOf(
                        "username" to username,
                        "password" to password,
                    ),
                )
            }
        } catch (exception: ResponseException) {
            // The one status worth naming. Everything else travels as it is: the step reports it
            // as the cause of the failure, and a type is all `ApiError` would have added before
            // the step unwrapped it again.
            if (exception.response.status == HttpStatusCode.Forbidden) {
                throw InvalidCredentialsException("The Alfen charger rejected the installer password")
            }
            throw exception
        }
    }

    /**
     * Writes one property, letting the HTTP failure out rather than reporting it as a refusal.
     *
     * `expectSuccess` is on, so a charger that rejects the write throws, and the step turns that
     * exception into the failure it reports. Swallowing it here would cost the only description
     * of what went wrong — and leave a cancelled onboarding looking like a charger that said no.
     */
    override suspend fun setProperty(id: String, value: String) {
        httpClient.post("/api/prop") {
            setBody(
                mapOf(id to mapOf("id" to id, "value" to value)),
            )
        }
    }
}
