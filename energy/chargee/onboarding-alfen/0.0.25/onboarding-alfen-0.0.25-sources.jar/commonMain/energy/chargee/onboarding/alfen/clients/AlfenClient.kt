package energy.chargee.onboarding.alfen.clients

import energy.chargee.onboarding.core.InvalidCredentialsException

/**
 * Client for the local HTTPS API exposed by an Alfen charger.
 *
 * The charger holds a session for the duration of a [connect] block and is logged out when it
 * ends, so every call belongs to one.
 */
interface AlfenClient {
    /**
     * Opens a session against the charger at [ipAddress], runs [block] against it, and logs out
     * afterwards whether or not it succeeded.
     */
    suspend fun <T> connect(ipAddress: String, block: suspend AlfenClientConnection.() -> T): T
}

/**
 * One open session with a charger.
 *
 * Both calls report failure by throwing. The exception is the only description of what went
 * wrong, and the configuration step carries it on the failure it reports so it reaches whatever
 * the consumer is monitoring with.
 */
interface AlfenClientConnection {
    /**
     * Authenticates as [username] with [password].
     *
     * @throws InvalidCredentialsException if the charger rejected the credentials, which the step
     *   reports back to the user rather than as something that went wrong.
     */
    suspend fun authenticate(username: String, password: String)

    /**
     * Writes the charger property [id] with [value], throwing if the charger refuses it.
     */
    suspend fun setProperty(id: String, value: String)
}
