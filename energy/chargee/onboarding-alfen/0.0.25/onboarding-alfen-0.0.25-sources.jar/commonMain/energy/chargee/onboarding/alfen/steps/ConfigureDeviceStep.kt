package energy.chargee.onboarding.alfen.steps

import energy.chargee.onboarding.alfen.AlfenConfig
import energy.chargee.onboarding.alfen.AlfenOnboardingContext
import energy.chargee.onboarding.alfen.clients.AlfenClient
import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.InvalidCredentialsException
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlin.coroutines.cancellation.CancellationException

/** The charger settings onboarding writes, in the order they are applied. */
private val PROPERTIES =
    mapOf(
        "2530_3" to "0",
        "2530_2" to "1",
        "5217_0" to "5",
        "2530_1" to "3",
        "2185_0" to "1",
    )

internal class ConfigureDeviceStep(private val client: AlfenClient) : OnboardingFlow.Step<LocalDeviceStepId, AlfenOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: AlfenOnboardingContext): Result<AlfenOnboardingContext> {
        val selectedDevice =
            requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before ConfigureDeviceStep runs" }
        val password =
            context.password ?: return Result.InputRequired(context, advanceAfterInput = false)

        // Whether a failure carries a cause is what tells a monitoring logger a defect from an
        // outcome the flow is designed to produce — see the Logging section of the README.
        return try {
            client.connect(selectedDevice.ipAddress) {
                authenticate(AlfenConfig.USERNAME, password)

                for ((key, value) in PROPERTIES) {
                    try {
                        setProperty(key, value)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (exception: Exception) {
                        // The ids are opaque numbers, so which one the charger refused is the
                        // whole diagnosis — and the exception names only the request, which is
                        // the same for all five.
                        return@connect Result.Failure(
                            context,
                            LocalDeviceErrorCode.DeviceConfigurationFailure(),
                            DeviceConfigurationException("Alfen refused property $key", exception),
                        )
                    }
                }

                Result.Success(context)
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: InvalidCredentialsException) {
            // The flow asks for the password again, so this is the user's to correct rather than
            // anyone's to look into — reported without a cause on purpose.
            Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true))
        } catch (exception: Exception) {
            Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(), exception)
        }
    }
}
