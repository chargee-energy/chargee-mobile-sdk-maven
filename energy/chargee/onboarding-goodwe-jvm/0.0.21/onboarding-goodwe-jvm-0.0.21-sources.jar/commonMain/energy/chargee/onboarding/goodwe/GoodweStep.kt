package energy.chargee.onboarding.goodwe

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.goodwe.models.GoodweBluetoothDevice
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [GoodweOnboardingSession] surfaces through its typed state, each
 * carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_GoodweStep")
@Serializable
sealed interface GoodweStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        GoodweStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : GoodweStep

    /**
     * The flow is waiting for the user to pick which device to onboard from [possibleDevices]. Call
     * [setDevice] with the chosen device.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : GoodweStep

    /**
     * Several Goodwe dongles are in Bluetooth range and the flow cannot tell which one belongs to
     * this installation. Call [setBluetoothDevice] with the one the user picked from
     * [possibleDevices].
     *
     * Only reached when the dongle did not answer the discovery broadcast.
     */
    @Serializable
    data class AwaitingBluetoothDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConnectLocalAp,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<GoodweBluetoothDevice>,
        @Transient val setBluetoothDevice: (GoodweBluetoothDevice) -> Unit = {},
    ) : GoodweStep

    /**
     * The dongle wants its password before it will accept any configuration. Call
     * [setBluetoothPassword] with what the user entered. The installer hands the password to the
     * customer; it is not printed on the dongle, so there is nowhere to read it off.
     *
     * Reached both the first time the dongle asks ([status] is
     * [OnboardingStepStatus.WaitingForInput]) and after it rejected an attempt ([status] is
     * [OnboardingStepStatus.Failure], with [previousPassword] carrying what was tried). There is no
     * factory default to fall back on, and the module locks itself after repeated failures, so each
     * attempt has to come from the user.
     */
    @Serializable
    data class AwaitingBluetoothPassword(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConnectLocalAp,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val previousPassword: String? = null,
        @Transient val setBluetoothPassword: (String) -> Unit = {},
    ) : GoodweStep
}
