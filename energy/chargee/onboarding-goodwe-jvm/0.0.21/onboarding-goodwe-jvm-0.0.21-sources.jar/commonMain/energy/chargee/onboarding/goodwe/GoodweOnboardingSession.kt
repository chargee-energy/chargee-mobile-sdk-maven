package energy.chargee.onboarding.goodwe

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for Goodwe inverters. Routes [GoodweInput] — the shared retry and set-device
 * cases — and surfaces [GoodweStep]s in its typed state.
 */
@OnboardingSession
class GoodweOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, GoodweOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, GoodweOnboardingContext, GoodweStep, GoodweInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered inverter: Goodwe has no device configuration step
     * to skip, so the flow rediscovers the inverter, updates its stored configuration with the
     * rediscovered values instead of registering a new one, and re-verifies.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [GoodweStep]s: a started step becomes [GoodweStep.Running];
     * a failed step becomes [GoodweStep.Failure] carrying a retry callback; and a pause on device
     * discovery becomes [GoodweStep.AwaitingDevice]. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, GoodweStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, GoodweOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, GoodweStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = GoodweStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == LocalDeviceStepId.ConnectLocalAp &&
                        (event.errorCode as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials == true -> {
                        current.copy(
                            currentStep =
                                GoodweStep.AwaitingBluetoothPassword(
                                    status = OnboardingStepStatus.Failure,
                                    previousPassword = event.context.bluetoothPassword,
                                ) {
                                    submit(GoodweInput.SetBluetoothPassword(it))
                                },
                        )
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                GoodweStep.Failure(
                                    event.stepId,
                                    error = event.errorCode,
                                    deviceUuid = event.context.deviceUuid,
                                ) {
                                    submit(GoodweInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.ConnectLocalAp -> {
                        if (event.context.selectedBluetoothDevice == null) {
                            current.copy(
                                currentStep =
                                    GoodweStep.AwaitingBluetoothDevice(
                                        possibleDevices = event.context.bluetoothDevices,
                                        setBluetoothDevice = { submit(GoodweInput.SetBluetoothDevice(it)) },
                                    ),
                            )
                        } else {
                            current.copy(
                                currentStep =
                                    GoodweStep.AwaitingBluetoothPassword(
                                        setBluetoothPassword = { submit(GoodweInput.SetBluetoothPassword(it)) },
                                    ),
                            )
                        }
                    }

                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                GoodweStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(GoodweInput.SetDevice(it)) },
                                    rescan = { submit(GoodweInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [GoodweInput]: [Retry][GoodweInput.Retry] re-runs a failed step and
     * [SetDevice][GoodweInput.SetDevice] selects the device to onboard while the flow is waiting on
     * device discovery.
     */
    override fun submit(input: GoodweInput): SubmitResult =
        when (input) {
            GoodweInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is GoodweInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            GoodweInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }

            is GoodweInput.SetBluetoothDevice -> {
                requireWaitingForInput(LocalDeviceStepId.ConnectLocalAp) {
                    engine.resume { it.copy(selectedBluetoothDevice = input.device) }
                }
            }

            // requirePaused rather than requireWaitingForInput: the password prompt is reachable
            // both from the dongle's first ask and after it rejected an attempt.
            is GoodweInput.SetBluetoothPassword -> {
                requirePaused(LocalDeviceStepId.ConnectLocalAp) {
                    engine.resume { it.copy(bluetoothPassword = input.password) }
                }
            }
        }
}
