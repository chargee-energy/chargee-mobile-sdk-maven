package energy.chargee.onboarding.goodwe.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.goodwe.GoodweConfig
import energy.chargee.onboarding.goodwe.GoodweErrorCode
import energy.chargee.onboarding.goodwe.GoodweOnboardingContext
import energy.chargee.onboarding.goodwe.ble.GoodweBleClient
import energy.chargee.onboarding.goodwe.ble.GoodweBleResult
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Reaches a dongle over Bluetooth that did not answer the discovery broadcast, authenticating if
 * the module asks for a password.
 *
 * The step is re-entrant: it pauses for input without advancing, so the engine runs it again once
 * the user has picked a dongle or supplied a password, and the scan result cached on the context
 * means re-entry does not scan a second time.
 */
internal class ConnectBluetoothStep(private val client: GoodweBleClient) :
    OnboardingFlow.Step<LocalDeviceStepId, GoodweOnboardingContext>() {
    override val id = LocalDeviceStepId.ConnectLocalAp

    override suspend fun execute(context: GoodweOnboardingContext): Result<GoodweOnboardingContext> {
        // Reaching this step with a device already selected means the broadcast was answered in a
        // shape we could not classify. Surface the reply rather than assume it is a dongle we know
        // how to configure.
        context.selectedDevice?.let { device ->
            return Result.Failure(
                context,
                GoodweErrorCode.UnrecognisedDongleResponse(device.extraParameters[GoodweConfig.RESPONSE_PARAMETER].orEmpty()),
            )
        }

        val devices = context.bluetoothDevices.ifEmpty { client.scan() }
        val selected =
            when {
                devices.isEmpty() -> {
                    return Result.Failure(context, GoodweErrorCode.NoDongleFound)
                }

                devices.size == 1 -> {
                    devices.single()
                }

                // Several dongles in range, and nothing distinguishes them for us - only the user
                // knows which inverter they are standing in front of.
                else -> {
                    context.selectedBluetoothDevice
                        ?: return Result.InputRequired(context.copy(bluetoothDevices = devices), advanceAfterInput = false)
                }
            }

        val scanned = context.copy(bluetoothDevices = devices, selectedBluetoothDevice = selected)

        return when (val connection = client.connect(selected.id)) {
            GoodweBleResult.Success -> Result.Success(scanned)

            GoodweBleResult.Unauthorized -> authenticate(scanned)

            // No password can help any more, so do not open the prompt.
            is GoodweBleResult.Locked -> Result.Failure(scanned, GoodweErrorCode.DongleLocked(connection.remainingSeconds))

            is GoodweBleResult.Failure -> Result.Failure(scanned, GoodweErrorCode.BluetoothFailure)
        }
    }

    private suspend fun authenticate(context: GoodweOnboardingContext): Result<GoodweOnboardingContext> {
        // There is no factory default to try first: the SolarGo app has none either, it always asks.
        // Guessing would spend attempts against the module's lock-out counter for nothing.
        val password = context.bluetoothPassword ?: return Result.InputRequired(context, advanceAfterInput = false)

        return when (val result = client.login(password)) {
            GoodweBleResult.Success -> {
                Result.Success(context)
            }

            // Deliberately terminal rather than retried: the module locks itself after repeated
            // failures, so the next attempt has to come from the user.
            GoodweBleResult.Unauthorized -> {
                Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true))
            }

            // That attempt used up the module's last allowance. Reported differently so the user is
            // told the dongle is locked rather than asked for yet another password.
            is GoodweBleResult.Locked -> {
                Result.Failure(context, GoodweErrorCode.DongleLocked(result.remainingSeconds))
            }

            is GoodweBleResult.Failure -> {
                Result.Failure(context, GoodweErrorCode.BluetoothFailure)
            }
        }
    }

    // Only on cancellation: the link has to stay open for the configuration step that follows.
    override suspend fun onCancelled(context: GoodweOnboardingContext) {
        client.disconnect()
    }
}
