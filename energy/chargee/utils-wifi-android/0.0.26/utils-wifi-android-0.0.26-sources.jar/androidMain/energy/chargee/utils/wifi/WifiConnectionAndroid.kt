package energy.chargee.utils.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.annotation.RequiresApi
import energy.chargee.utils.concurrency.ResumeOnce
import kotlinx.coroutines.suspendCancellableCoroutine
import java.net.Inet4Address

class WifiConnectionAndroid(private val context: Context) : WifiConnection {
    // holds the call while connected using ConnectivityManager.requestNetwork API
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    // holds the network id returned by WifiManager.addNetwork, required to disconnect (API < 29)
    private var networkId: Int? = null

    // holds the network the process is bound to, required to resolve its routes (API >= 29).
    // Querying ConnectivityManager.activeNetwork instead would be ambiguous here: the AP we join
    // has no internet, so the system may keep another transport as the active network.
    private var boundNetwork: Network? = null

    private val connectivityManager: ConnectivityManager by lazy {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    private val wifiManager: WifiManager by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }

    /**
     * Joins [configuration], associating through `WifiManager` below API 29 and through
     * `ConnectivityManager.requestNetwork` from API 29 on.
     *
     * Throws [UnsupportedOperationException] for a WEP network from API 29 on, which no
     * implementation of this interface can join — see [WifiAuth.Wep].
     */
    override suspend fun connect(configuration: WifiConfiguration, saveNetwork: Boolean): Boolean {
        val legacy = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

        // WEP has nowhere to go from API 29 on: `WifiNetworkSpecifier` has no WEP builder, and the
        // legacy path it is routed to instead stopped working for third-party apps in that same
        // release — `addNetwork` answers -1 and `enableNetwork` answers false, so [connectLegacy]
        // can only report a refusal that reads exactly like a wrong passphrase. Nothing a caller
        // does gets past this, so it is raised rather than returned: a `false` here invites the
        // retry and the corrected password that cannot help.
        if (configuration.auth == WifiAuth.Wep && !legacy) {
            throw UnsupportedOperationException(
                "WEP networks cannot be joined on API ${Build.VERSION.SDK_INT}: WifiNetworkSpecifier has no WEP " +
                    "builder and WifiManager.addNetwork is a no-op for third-party apps from API 29",
            )
        }

        return if (legacy) {
            connectLegacy(
                configuration.password?.let { password ->
                    if (configuration.auth == WifiAuth.Wep) {
                        createWEPConfig(configuration.ssid, password)
                    } else {
                        createWifiConfig(configuration.ssid, password)
                    }
                } ?: createWifiConfig(configuration.ssid),
            )
        } else {
            connectModern(
                WifiNetworkSpecifier
                    .Builder()
                    .setSsid(configuration.ssid)
                    .apply {
                        configuration.password?.let { password ->
                            if (configuration.auth == WifiAuth.Wpa3) {
                                setWpa3Passphrase(password)
                            } else {
                                setWpa2Passphrase(password)
                            }
                        }
                    }.build(),
            )
        }
    }

    override suspend fun disconnect(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            disconnectModern()
        } else {
            disconnectLegacy()
        }

    @Suppress("DEPRECATION")
    override suspend fun getSsid(): String? {
        val ssid = wifiManager.connectionInfo.ssid
        return if (ssid != WifiManager.UNKNOWN_SSID) ssid else null
    }

    override suspend fun getGatewayAddress(): String? = defaultRouteGateway() ?: dhcpGateway()

    /**
     * Resolves the gateway from the routes of the network [connectModern] bound the process to.
     * This is the address `LinkProperties` records for the default route, which is what Android
     * points to now that `WifiManager.getDhcpInfo` is deprecated.
     */
    private fun defaultRouteGateway(): String? {
        val network = boundNetwork ?: return null

        return connectivityManager
            .getLinkProperties(network)
            ?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway
            ?.hostAddress
    }

    /**
     * Fallback for the [connectLegacy] path (API < 29), which associates through `WifiManager`
     * and so never receives a [Network] to read routes from. `DhcpInfo` is only deprecated from
     * API 31, above the range this path runs in. Its `gateway` is a little-endian IPv4 integer
     * and is `0` when the lease carried no router.
     */
    @Suppress("DEPRECATION")
    private fun dhcpGateway(): String? {
        val gateway = wifiManager.dhcpInfo?.gateway?.takeIf { it != 0 } ?: return null

        return "${gateway and 0xFF}.${(gateway shr 8) and 0xFF}.${(gateway shr 16) and 0xFF}.${(gateway shr 24) and 0xFF}"
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private suspend fun connectModern(specifier: WifiNetworkSpecifier): Boolean =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            networkCallback?.let(connectivityManager::unregisterNetworkCallback)

            val request =
                NetworkRequest
                    .Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(specifier)
                    .build()

            networkCallback =
                object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        super.onAvailable(network)
                        boundNetwork = network
                        connectivityManager.bindProcessToNetwork(network)
                        gate.resumeOnce(true)
                    }

                    override fun onUnavailable() {
                        super.onUnavailable()
                        gate.resumeOnce(false)
                    }

                    override fun onLost(network: Network) {
                        super.onLost(network)
                        if (network != boundNetwork) return

                        // The access point can go away without anyone calling disconnect() — the
                        // device drops it, or the system tears the request down. The binding
                        // outlives the network it points at, and every socket the process opens
                        // afterwards fails against a handle the system no longer knows: name
                        // resolution first, then socket() itself with ENONET. That reaches the
                        // whole app, not just the onboarding call that joined, so the binding is
                        // released here rather than waiting for a disconnect that may never come.
                        boundNetwork = null
                        connectivityManager.bindProcessToNetwork(null)
                    }
                }

            val handler = Handler(Looper.getMainLooper())
            connectivityManager.requestNetwork(request, networkCallback!!, handler)
        }

    @Suppress("DEPRECATION")
    private fun createWifiConfig(ssid: String): android.net.wifi.WifiConfiguration =
        android.net.wifi.WifiConfiguration().apply {
            SSID = "\"" + ssid + "\""
            allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.NONE)

            allowedProtocols.set(android.net.wifi.WifiConfiguration.Protocol.RSN)
            allowedProtocols.set(android.net.wifi.WifiConfiguration.Protocol.WPA)

            allowedAuthAlgorithms.clear()

            allowedPairwiseCiphers.set(android.net.wifi.WifiConfiguration.PairwiseCipher.CCMP)
            allowedPairwiseCiphers.set(android.net.wifi.WifiConfiguration.PairwiseCipher.TKIP)

            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.WEP40)
            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.WEP104)
            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.CCMP)
            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.TKIP)
        }

    @Suppress("DEPRECATION")
    private fun createWifiConfig(ssid: String, password: String): android.net.wifi.WifiConfiguration =
        createWifiConfig(ssid).apply {
            preSharedKey = "\"" + password + "\""
            status = android.net.wifi.WifiConfiguration.Status.ENABLED

            allowedKeyManagement.clear()
            allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.WPA_PSK)
        }

    @Suppress("DEPRECATION")
    private fun createWEPConfig(ssid: String, password: String): android.net.wifi.WifiConfiguration =
        createWifiConfig(ssid).apply {
            wepKeys[0] = "\"" + password + "\""
            wepTxKeyIndex = 0

            allowedGroupCiphers.clear()
            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.WEP40)
            allowedGroupCiphers.set(android.net.wifi.WifiConfiguration.GroupCipher.WEP104)

            allowedAuthAlgorithms.set(android.net.wifi.WifiConfiguration.AuthAlgorithm.OPEN)
            allowedAuthAlgorithms.set(android.net.wifi.WifiConfiguration.AuthAlgorithm.SHARED)
        }

    @Suppress("DEPRECATION")
    private suspend fun connectLegacy(wifiConfiguration: android.net.wifi.WifiConfiguration): Boolean =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            val network = wifiManager.addNetwork(wifiConfiguration)
            if (network == -1) {
                gate.resumeOnce(false)
                return@suspendCancellableCoroutine
            }
            wifiManager.saveConfiguration()

            val wifiChangeReceiver =
                object : BroadcastReceiver() {
                    var count = 0

                    override fun onReceive(context: Context, intent: Intent) {
                        count++
                        val info = intent.getParcelableExtra<NetworkInfo>(WifiManager.EXTRA_NETWORK_INFO)
                        if (info != null && info.isConnected) {
                            if (info.extraInfo == wifiConfiguration.SSID || getSSID() == wifiConfiguration.SSID) {
                                gate.resumeOnce(true)
                                context.unregisterReceiver(this)
                            } else if (count > 1) {
                                // Ignore first callback if not success. It may be for the already connected SSID
                                gate.resumeOnce(false)
                                context.unregisterReceiver(this)
                            }
                        }
                    }
                }

            val intentFilter = IntentFilter()
            intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            context.registerReceiver(wifiChangeReceiver, intentFilter)

            // enable the new network and attempt to connect to it
            wifiManager.enableNetwork(network, true)
            networkId = network
        }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun disconnectModern(): Boolean {
        val callback = networkCallback ?: return false

        connectivityManager.unregisterNetworkCallback(callback)
        connectivityManager.bindProcessToNetwork(null)
        networkCallback = null
        boundNetwork = null

        return true
    }

    @Suppress("DEPRECATION")
    private suspend fun disconnectLegacy(): Boolean =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)

            val network = networkId
            if (network == null) {
                gate.resumeOnce(false)
                return@suspendCancellableCoroutine
            }

            val wifiChangeReceiver =
                object : BroadcastReceiver() {
                    override fun onReceive(context: Context, intent: Intent) {
                        val info = intent.getParcelableExtra<NetworkInfo>(WifiManager.EXTRA_NETWORK_INFO)
                        if (info != null && !info.isConnected) {
                            gate.resumeOnce(true)
                            context.unregisterReceiver(this)
                        }
                    }
                }

            val intentFilter = IntentFilter()
            intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            context.registerReceiver(wifiChangeReceiver, intentFilter)

            // remove network to emulate a behavior as close as possible to new Android API
            wifiManager.removeNetwork(network)
            wifiManager.reconnect()
            networkId = null
        }

    @Suppress("DEPRECATION")
    fun getSSID(): String = wifiManager.connectionInfo.ssid
}
