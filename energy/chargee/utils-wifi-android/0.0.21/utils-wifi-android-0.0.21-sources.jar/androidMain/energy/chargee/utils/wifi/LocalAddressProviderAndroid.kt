package energy.chargee.utils.wifi

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address

class LocalAddressProviderAndroid(private val context: Context) : LocalAddressProvider {
    override fun getLocalAddress(): LocalAddress? {
        val connectivityManager = context.getSystemService(ConnectivityManager::class.java)
        val network = connectivityManager.activeNetwork ?: return null

        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return null
        if (!capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null

        val linkAddress =
            connectivityManager
                .getLinkProperties(network)
                ?.linkAddresses
                ?.firstOrNull { it.address is Inet4Address }
                ?: return null

        val host = linkAddress.address.hostAddress ?: return null
        return LocalAddress(host, linkAddress.prefixLength)
    }
}
