package energy.chargee.sdk

import android.content.Context
import energy.chargee.core.logging.ChargeeLogger
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the Android [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production], and sending everything it logs to
 * [logger] — omit it and the SDK logs nothing.
 *
 * Pass an application [Context]: the SDK holds on to it for the lifetime of the instance and uses
 * it for Wi-Fi access, network-service discovery, and Bluetooth provisioning.
 */
@Suppress("ktlint:standard:function-naming")
fun ChargeeSdk(
    context: Context,
    tokenProvider: TokenProvider,
    environment: Environment = Environment.production,
    logger: ChargeeLogger? = null,
): ChargeeSdk = ChargeeSdkAndroid(environment, tokenProvider, logger, context)
