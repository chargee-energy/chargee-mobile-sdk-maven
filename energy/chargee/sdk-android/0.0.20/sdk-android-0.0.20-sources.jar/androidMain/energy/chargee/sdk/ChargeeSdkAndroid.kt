package energy.chargee.sdk

import android.content.Context
import energy.chargee.core.di.module
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider
import energy.chargee.discovery.mdns.mdnsDiscoveryModuleAndroid
import energy.chargee.onboarding.chargeedevice.chargeeDeviceOnboardingModuleAndroid
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.LocalAddressProviderAndroid
import energy.chargee.utils.wifi.WifiConnection
import energy.chargee.utils.wifi.WifiConnectionAndroid

/**
 * The Android [ChargeeSdk], adding the Android implementations of Wi-Fi access, local address
 * lookup, mDNS discovery, and ESP provisioning on top of the shared modules. The [context] is
 * registered as a singleton for those implementations to resolve. Created via the `ChargeeSdk`
 * factory function.
 */
internal class ChargeeSdkAndroid(environment: Environment, tokenProvider: TokenProvider, private val context: Context) :
    ChargeeSdk(environment, tokenProvider) {
    init {
        dependencyRegistry.registerModule(
            module {
                singleton(context)
                factory<WifiConnection> { WifiConnectionAndroid(get()) }
                lazySingleton<LocalAddressProvider> { LocalAddressProviderAndroid(get()) }
            },
        )
        dependencyRegistry.registerModule(mdnsDiscoveryModuleAndroid)
        dependencyRegistry.registerModule(chargeeDeviceOnboardingModuleAndroid)
    }
}
