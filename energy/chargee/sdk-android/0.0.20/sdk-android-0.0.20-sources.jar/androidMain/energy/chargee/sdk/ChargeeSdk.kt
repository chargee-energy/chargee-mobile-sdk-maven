package energy.chargee.sdk

import android.content.Context
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the Android [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production].
 *
 * Pass an application [Context]: the SDK holds on to it for the lifetime of the instance and uses
 * it for Wi-Fi access, network-service discovery, and Bluetooth provisioning.
 */
@Suppress("ktlint:standard:function-naming")
fun ChargeeSdk(context: Context, tokenProvider: TokenProvider, environment: Environment = Environment.production): ChargeeSdk =
    ChargeeSdkAndroid(environment, tokenProvider, context)
