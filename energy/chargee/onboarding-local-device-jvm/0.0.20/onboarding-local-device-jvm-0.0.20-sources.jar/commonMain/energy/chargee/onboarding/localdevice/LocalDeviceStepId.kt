package energy.chargee.onboarding.localdevice

import kotlinx.serialization.Serializable

/**
 * Step identifiers emitted on [energy.chargee.onboarding.core.OnboardingFlow.Event] for the
 * shared local-device onboarding steps.
 *
 * Match against these entries when reacting to step events
 * (e.g. [energy.chargee.onboarding.core.OnboardingFlow.Event.StepInputRequired] or
 * [energy.chargee.onboarding.core.OnboardingFlow.Event.StepFailure]).
 *
 * [RegisterDevice] covers both halves of [registerOrUpdateDeviceStep]: it is emitted whether the
 * device is being registered for the first time or an existing registration is having its
 * configuration updated during a reset.
 */
@Serializable
enum class LocalDeviceStepId {
    DiscoverChargeeDevice,
    ConnectLocalWifi,
    ConfigureDevice,
    DiscoverDevice,
    RegisterDevice,
    VerifyDevice,
}
