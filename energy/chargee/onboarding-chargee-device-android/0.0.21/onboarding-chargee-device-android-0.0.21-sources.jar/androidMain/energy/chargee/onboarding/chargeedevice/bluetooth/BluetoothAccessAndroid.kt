package energy.chargee.onboarding.chargeedevice.bluetooth

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.provider.Settings

internal class BluetoothAccessAndroid(private val context: Context) : BluetoothAccess {
    override suspend fun checkBluetoothAvailability(): BluetoothAvailability {
        if (!context.getSystemService(BluetoothManager::class.java).adapter.isEnabled) {
            return BluetoothAvailability.NotAvailable
        }

        if (!isLocationAvailable()) {
            return BluetoothAvailability.LocationNotAvailable
        }

        return BluetoothAvailability.Available
    }

    override suspend fun checkBluetoothPermissionStatus(): BluetoothPermissionStatus {
        if (!isBluetoothPermissionGranted()) {
            return BluetoothPermissionStatus.Denied
        }

        if (!isLocationPermissionGranted()) {
            return BluetoothPermissionStatus.DeniedLocation
        }

        return BluetoothPermissionStatus.Granted
    }

    @Suppress("DEPRECATION")
    private fun isLocationAvailable(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val locationManager = context.getSystemService(LocationManager::class.java)
            return locationManager.isLocationEnabled
        }

        return try {
            Settings.Secure.getInt(
                context.contentResolver,
                Settings.Secure.LOCATION_MODE,
            ) != Settings.Secure.LOCATION_MODE_OFF
        } catch (_: Settings.SettingNotFoundException) {
            false
        }
    }

    private fun isBluetoothPermissionGranted(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        }

        return context.checkSelfPermission(Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
    }

    private fun isLocationPermissionGranted(): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
}
