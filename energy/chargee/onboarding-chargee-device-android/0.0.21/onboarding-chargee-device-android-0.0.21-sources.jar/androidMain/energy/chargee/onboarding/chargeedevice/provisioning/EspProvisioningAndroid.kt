package energy.chargee.onboarding.chargeedevice.provisioning

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanResult
import android.content.Context
import com.espressif.provisioning.DeviceConnectionEvent
import com.espressif.provisioning.ESPConstants
import com.espressif.provisioning.ESPDevice
import com.espressif.provisioning.ESPProvisionManager
import com.espressif.provisioning.WiFiAccessPoint
import com.espressif.provisioning.listeners.BleScanListener
import com.espressif.provisioning.listeners.ProvisionListener
import com.espressif.provisioning.listeners.WiFiScanListener
import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork
import energy.chargee.utils.concurrency.ResumeOnce
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * The Android [EspProvisioning], provisioning over BLE through Espressif's ESP-IDF provisioning
 * library.
 *
 * Every call into that library happens on the main thread. It constructs its `Handler`s on the
 * calling thread, so reaching it from a background thread fails with "Can't create handler inside
 * thread … that has not called Looper.prepare()" — which would otherwise make the caller's
 * dispatcher part of this SDK's contract, and a caller driving the onboarding flow from anywhere
 * other than the main dispatcher would hit it on the first step. Confining the switch here keeps
 * the flow runnable from any dispatcher.
 *
 * [Dispatchers.Main.immediate][kotlinx.coroutines.MainCoroutineDispatcher.immediate] is used so
 * that a caller already on the main thread — a `viewModelScope`, say — is not dispatched again.
 */
internal class EspProvisioningAndroid(private val context: Context) : EspProvisioning {
    private data class BleConnector(val device: BluetoothDevice, val scanResult: ScanResult) {
        val primaryServiceUuid =
            scanResult.scanRecord
                ?.serviceUuids
                ?.get(0)
                ?.toString() ?: ""
    }

    /**
     * Created on first use rather than in the constructor, so that resolving this class from the
     * dependency registry — which happens on whichever thread the flow is running on — does not
     * itself reach the library off the main thread.
     */
    private val provisioningManager by lazy { ESPProvisionManager.getInstance(context) }
    private val connectors = mutableMapOf<String, BleConnector>()

    @SuppressLint("MissingPermission")
    override suspend fun scanDevices(prefix: String?): List<String> =
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
                val gate = ResumeOnce(continuation)
                continuation.invokeOnCancellation { provisioningManager.stopBleScan() }
                connectors.clear()
                provisioningManager.searchBleEspDevices(
                    prefix ?: "",
                    object : BleScanListener {
                        override fun scanStartFailed() = gate.resumeOnce(emptyList())

                        override fun onPeripheralFound(device: BluetoothDevice?, scanResult: ScanResult?) {
                            if (device != null && scanResult != null) {
                                connectors[device.name] = BleConnector(device, scanResult)
                            }
                        }

                        override fun scanCompleted() = gate.resumeOnce(connectors.values.mapNotNull { it.device.name })

                        override fun onFailure(e: Exception?) = gate.resumeOnce(emptyList())
                    },
                )
            }
        }

    override suspend fun scanWifiNetworks(deviceName: String, proofOfPossession: String): List<WifiNetwork> =
        withContext(Dispatchers.Main.immediate) {
            val device = connect(deviceName, proofOfPossession) ?: return@withContext emptyList()
            suspendCancellableCoroutine { continuation ->
                val gate = ResumeOnce(continuation)
                continuation.invokeOnCancellation { device.disconnectDevice() }
                device.scanNetworks(
                    object : WiFiScanListener {
                        override fun onWifiListReceived(wifiList: ArrayList<WiFiAccessPoint?>?) {
                            val networks =
                                wifiList?.filterNotNull()?.map { wifi ->
                                    WifiNetwork(
                                        ssid = wifi.wifiName,
                                        rssi = wifi.rssi,
                                        secure = wifi.security != 0,
                                    )
                                } ?: emptyList()
                            gate.resumeOnce(networks)
                            device.disconnectDevice()
                        }

                        override fun onWiFiScanFailed(e: java.lang.Exception?) {
                            gate.resumeOnce(emptyList())
                            device.disconnectDevice()
                        }
                    },
                )
            }
        }

    override suspend fun provisionDevice(
        deviceName: String,
        proofOfPossession: String,
        ssid: String,
        passphrase: String?,
    ): ProvisioningResult =
        withContext(Dispatchers.Main.immediate) {
            val device =
                connect(deviceName, proofOfPossession)
                    ?: return@withContext ProvisioningResult.UnknownFailure
            suspendCancellableCoroutine { continuation ->
                val gate = ResumeOnce(continuation)
                continuation.invokeOnCancellation { device.disconnectDevice() }
                device.provision(
                    ssid,
                    passphrase,
                    object : ProvisionListener {
                        override fun createSessionFailed(e: java.lang.Exception?) = gate.resumeOnce(ProvisioningResult.UnknownFailure)

                        override fun wifiConfigSent() = Unit

                        override fun wifiConfigFailed(e: java.lang.Exception?) = gate.resumeOnce(ProvisioningResult.UnknownFailure)

                        override fun wifiConfigApplied() = Unit

                        override fun wifiConfigApplyFailed(e: java.lang.Exception?) = gate.resumeOnce(ProvisioningResult.UnknownFailure)

                        override fun provisioningFailedFromDevice(failureReason: ESPConstants.ProvisionFailureReason?) =
                            gate.resumeOnce(
                                if (failureReason == ESPConstants.ProvisionFailureReason.AUTH_FAILED) {
                                    ProvisioningResult.AuthenticationFailure
                                } else {
                                    ProvisioningResult.UnknownFailure
                                },
                            )

                        override fun deviceProvisioningSuccess() = gate.resumeOnce(ProvisioningResult.Success)

                        override fun onProvisioningFailed(e: java.lang.Exception?) = gate.resumeOnce(ProvisioningResult.UnknownFailure)
                    },
                )
            }
        }

    /**
     * Connects to [deviceName], already on the main thread — every caller reaches this from inside
     * the `withContext` above.
     */
    @SuppressLint("MissingPermission")
    private suspend fun connect(deviceName: String, proofOfPossession: String): ESPDevice? {
        val connector = connectors[deviceName] ?: return null
        return suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            val espDevice =
                provisioningManager.createESPDevice(
                    ESPConstants.TransportType.TRANSPORT_BLE,
                    ESPConstants.SecurityType.SECURITY_1,
                )

            val subscriber =
                object {
                    @Subscribe(threadMode = ThreadMode.MAIN)
                    fun onEvent(event: DeviceConnectionEvent) {
                        when (event.eventType) {
                            ESPConstants.EVENT_DEVICE_CONNECTED -> {
                                EventBus.getDefault().unregister(this)
                                espDevice.proofOfPossession = proofOfPossession
                                gate.resumeOnce(espDevice)
                            }

                            ESPConstants.EVENT_DEVICE_CONNECTION_FAILED, ESPConstants.EVENT_DEVICE_DISCONNECTED -> {
                                EventBus.getDefault().unregister(this)
                                gate.resumeOnce(null)
                            }
                        }
                    }
                }

            continuation.invokeOnCancellation {
                if (EventBus.getDefault().isRegistered(subscriber)) {
                    EventBus.getDefault().unregister(subscriber)
                }
            }

            EventBus.getDefault().register(subscriber)
            espDevice.connectBLEDevice(connector.device, connector.primaryServiceUuid)
        }
    }
}
