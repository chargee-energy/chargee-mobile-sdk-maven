package energy.chargee.onboarding.chargeedevice

import energy.chargee.core.di.module
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccessAndroid
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioningAndroid

val chargeeDeviceOnboardingModuleAndroid =
    module {
        factory<EspProvisioning> { EspProvisioningAndroid(get()) }
        factory<BluetoothAccess> { BluetoothAccessAndroid(get()) }
    }
