package energy.chargee.sdk

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.core.logging.ChargeeLogger
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the iOS [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production], and sending everything it logs to
 * [logger] — omit it and the SDK logs nothing.
 *
 * SKIE default-argument interop is enabled so Swift callers can omit [environment] and [logger] —
 * from Swift, pass `ChargeeEnvironment.development` or `.production` to select an environment
 * explicitly.
 */
@DefaultArgumentInterop.Enabled
fun createChargeeSdk(
    environment: Environment = Environment.production,
    tokenProvider: TokenProvider,
    logger: ChargeeLogger? = null,
): ChargeeSdk = ChargeeSdkIos(environment, tokenProvider, logger)
