package energy.chargee.core.di.providers

import energy.chargee.core.di.DependencyRegistry
import energy.chargee.core.di.Parameters
import kotlin.reflect.KClass

/**
 * A [DependencyProvider] that creates the instance on the first [provide] call and returns
 * the same instance on all subsequent calls.
 *
 * The [factory] lambda is invoked lazily with [DependencyRegistry] as its receiver, so
 * other registered dependencies can be resolved inside it at the time of first access.
 */
@PublishedApi
internal class LazySingletonDependencyProvider<T : Any>(override val klass: KClass<T>, private val factory: DependencyRegistry.() -> T) :
    DependencyProvider<T> {
    private var dependency: T? = null

    override fun DependencyRegistry.provide(parameters: Parameters) = dependency ?: factory().also { dependency = it }
}
