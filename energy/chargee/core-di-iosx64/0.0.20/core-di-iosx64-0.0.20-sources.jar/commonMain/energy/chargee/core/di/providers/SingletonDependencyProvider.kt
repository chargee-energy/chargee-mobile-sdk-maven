package energy.chargee.core.di.providers

import energy.chargee.core.di.DependencyRegistry
import energy.chargee.core.di.Parameters
import kotlin.reflect.KClass

/**
 * A [DependencyProvider] that always returns the same pre-constructed [dependency] instance.
 *
 * Use this when the instance already exists at module-definition time. For dependencies that
 * should be constructed lazily on first access, use [LazySingletonDependencyProvider] instead.
 */
@PublishedApi
internal class SingletonDependencyProvider<T : Any>(override val klass: KClass<T>, private val dependency: T) : DependencyProvider<T> {
    override fun DependencyRegistry.provide(parameters: Parameters) = dependency
}
