package energy.chargee.core.di.providers

import energy.chargee.core.di.DependencyRegistry
import energy.chargee.core.di.Parameters
import kotlin.reflect.KClass

/**
 * A [DependencyProvider] that calls [factory] on every [provide] invocation.
 *
 * Use this for stateless or intentionally short-lived dependencies. Prefer
 * [LazySingletonDependencyProvider] when sharing a single instance across the application.
 */
@PublishedApi
internal class FactoryDependencyProvider<T : Any>(
    override val klass: KClass<T>,
    private val factory: DependencyRegistry.(Parameters) -> T,
) : DependencyProvider<T> {
    override fun DependencyRegistry.provide(parameters: Parameters) = factory(parameters)
}
