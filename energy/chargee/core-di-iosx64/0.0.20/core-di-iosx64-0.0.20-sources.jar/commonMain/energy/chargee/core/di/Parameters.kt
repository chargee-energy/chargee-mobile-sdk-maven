package energy.chargee.core.di

/**
 * A positional, type-erased argument list forwarded to a parameterized factory.
 *
 * Callers construct instances via [parametersOf] and pass them to
 * [DependencyRegistry.get] to supply per-resolution inputs. Inside a factory registered with
 * [DependencyRegistry.factoryWithParameters], read them back through [get] (required) or
 * [getOrNull] (optional). Slots are matched by [index] and cast to the reified `T`, so
 * arguments must be passed in the order the factory expects.
 *
 * @property values the raw argument list, exposed for consumers that need untyped access.
 */
class Parameters(val values: List<Any?>) {
    /**
     * Returns the value at [index] cast to [T].
     *
     * @throws IndexOutOfBoundsException if [index] is outside [values].
     * @throws ClassCastException if the stored value is not a [T].
     */
    inline fun <reified T> get(index: Int = 0): T = values[index] as T

    /**
     * Returns the value at [index] cast to [T], or `null` if fewer than `index + 1` values
     * were supplied. Use this for optional trailing arguments.
     */
    inline fun <reified T> getOrNull(index: Int = 0): T? = if (values.size > index) values[index] as T else null

    companion object {
        /**
         * Shared empty instance used as the default when no parameters are supplied.
         */
        val EMPTY = Parameters(emptyList())
    }
}

/**
 * Builds a [Parameters] instance from [args] in the order they are passed.
 *
 * ```kotlin
 * registry.get<DeviceDiscovery>(name = "port-scan", parameters = parametersOf(host, ports))
 * ```
 */
fun parametersOf(vararg args: Any?) = Parameters(args.toList())
