package energy.chargee.core.di

/**
 * A deferred bundle of dependency registrations.
 *
 * A [Module] captures a [builder] block that runs against [DependencyRegistry] once the
 * module is handed to [DependencyRegistry.registerModule]. Construct one with the [module]
 * DSL and declare dependencies inside [builder] via [DependencyRegistry.factory],
 * [DependencyRegistry.lazySingleton], or [DependencyRegistry.singleton].
 *
 * ```kotlin
 * val appModule = module {
 *     singleton(MyService())
 *     lazySingleton { OtherService(get()) }
 *     factory { RequestHandler(get()) }
 * }
 * DependencyRegistry.registerModule(appModule)
 * ```
 */
class Module internal constructor(private val builder: DependencyRegistry.() -> Unit) {
    internal fun DependencyRegistry.build() = builder()
}

/**
 * Creates a [Module] whose [builder] block will register its dependencies against
 * [DependencyRegistry] when [DependencyRegistry.registerModule] is called.
 */
fun module(builder: DependencyRegistry.() -> Unit) = Module(builder)
