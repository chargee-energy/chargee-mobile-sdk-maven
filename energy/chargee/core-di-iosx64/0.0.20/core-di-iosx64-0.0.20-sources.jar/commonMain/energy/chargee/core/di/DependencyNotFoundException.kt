package energy.chargee.core.di

/**
 * Thrown by [DependencyRegistry.get] when no registered module provides the requested type.
 *
 * This usually means the corresponding [Module] was never passed to
 * [DependencyRegistry.registerModule], or SDK setup was not called before accessing dependencies.
 */
class DependencyNotFoundException(override val message: String?) : Exception(message)
