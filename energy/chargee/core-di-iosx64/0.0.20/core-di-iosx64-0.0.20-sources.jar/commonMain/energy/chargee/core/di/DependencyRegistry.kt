package energy.chargee.core.di

import energy.chargee.core.di.providers.DependencyProvider
import energy.chargee.core.di.providers.FactoryDependencyProvider
import energy.chargee.core.di.providers.LazySingletonDependencyProvider
import energy.chargee.core.di.providers.SingletonDependencyProvider
import kotlin.reflect.KClass

/**
 * Global registry that holds all registered dependencies and resolves them by type and name.
 *
 * Dependencies are declared once during SDK setup — either directly via [factory],
 * [lazySingleton], [singleton], or bundled inside a [Module] and installed with
 * [registerModule] — and are resolved on demand via [get] or [getOrNull].
 */
class DependencyRegistry {
    @PublishedApi
    internal data class DependencyKey<T : Any>(val klass: KClass<T>, val name: String? = null)

    @PublishedApi
    internal val dependencies = mutableMapOf<DependencyKey<*>, DependencyProvider<*>>()

    /**
     * Resolves the dependency of type [T] registered under [name].
     *
     * Whether a fresh instance is created or a cached one returned depends on how the
     * dependency was declared ([factory], [lazySingleton], or [singleton]). Pass [name] to
     * disambiguate when multiple providers of the same type are registered; a `null` [name]
     * resolves the unnamed provider. Runtime [parameters] are forwarded to providers declared
     * via [factoryWithParameters] and ignored by others.
     *
     * @throws DependencyNotFoundException if no provider is registered for [T] under [name].
     */
    @Throws(DependencyNotFoundException::class)
    inline fun <reified T : Any> get(name: String? = null, parameters: Parameters = Parameters.EMPTY): T =
        getOrNull(name, parameters)
            ?: throw DependencyNotFoundException("Dependency of type ${T::class.qualifiedName} not found.")

    /**
     * Returns the dependency of type [T] registered under [name], or `null` if no such
     * provider exists. Non-throwing counterpart of [get] with the same lookup semantics.
     */
    inline fun <reified T : Any> getOrNull(name: String? = null, parameters: Parameters = Parameters.EMPTY): T? =
        dependencies[DependencyKey(T::class, name)]?.let { with(it) { provide(parameters) as? T } }

    /**
     * Registers [provider] under [name], replacing any existing provider for the same type
     * and [name]. Prefer the higher-level [factory], [lazySingleton], and [singleton] helpers
     * over calling this directly. A `null` [name] registers the default (unnamed) provider.
     */
    inline fun <reified T : Any> register(provider: DependencyProvider<T>, name: String?) {
        dependencies[DependencyKey(T::class, name)] = provider
    }

    /**
     * Declares a factory dependency of type [T], optionally qualified by [name].
     *
     * A new instance is produced by [factory] on every call to [get]. The [factory] lambda
     * receives this registry as its receiver, so other dependencies can be resolved inside
     * it via [get]. Pass [name] to register multiple factories of the same type; a `null`
     * [name] registers the default (unnamed) factory.
     */
    inline fun <reified T : Any> factory(name: String? = null, noinline factory: DependencyRegistry.() -> T) {
        register(FactoryDependencyProvider(T::class) { factory() }, name)
    }

    /**
     * Declares a parameterized factory dependency of type [T], optionally qualified by [name].
     *
     * Like [factory], but the [factory] lambda additionally receives the [Parameters] passed
     * to [get] on each resolution, so callers can supply per-instance inputs. Pass [name] to
     * disambiguate multiple parameterized factories of the same type.
     */
    inline fun <reified T : Any> factoryWithParameters(name: String? = null, noinline factory: DependencyRegistry.(Parameters) -> T) {
        register(FactoryDependencyProvider(T::class, factory), name)
    }

    /**
     * Declares a lazy singleton dependency of type [T], optionally qualified by [name].
     *
     * The [factory] lambda is invoked on the first [get] call and its result is cached for
     * all subsequent calls. The [factory] lambda receives this registry as its receiver, so
     * other dependencies can be resolved inside it via [get]. Pass [name] to register multiple
     * lazy singletons of the same type.
     */
    inline fun <reified T : Any> lazySingleton(name: String? = null, noinline factory: DependencyRegistry.() -> T) {
        register(LazySingletonDependencyProvider(T::class, factory), name)
    }

    /**
     * Declares a singleton dependency of type [T] from an already-created [dependency]
     * instance, optionally qualified by [name].
     *
     * The same [dependency] object is returned on every [get] call. Pass [name] to register
     * multiple singletons of the same type; a `null` [name] registers the default (unnamed)
     * singleton.
     */
    inline fun <reified T : Any> singleton(dependency: T, name: String? = null) {
        register(SingletonDependencyProvider(T::class, dependency), name)
    }

    /**
     * Installs [module] by running its builder block against this registry, adding all of
     * its dependencies to the global set of registrations.
     */
    fun registerModule(module: Module) {
        with(module) { build() }
    }
}
