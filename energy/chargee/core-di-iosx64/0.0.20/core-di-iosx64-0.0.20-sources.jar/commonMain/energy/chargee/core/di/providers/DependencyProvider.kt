package energy.chargee.core.di.providers

import energy.chargee.core.di.DependencyRegistry
import energy.chargee.core.di.Parameters
import kotlin.reflect.KClass

/**
 * Produces instances of a dependency of type [T].
 *
 * Concrete implementations decide the lifecycle: [FactoryDependencyProvider] creates a new
 * instance on every call, [LazySingletonDependencyProvider] creates one on first access and
 * caches it, and [SingletonDependencyProvider] wraps an already-created instance.
 */
interface DependencyProvider<T : Any> {
    /**
     * The type this provider supplies, used as the lookup key in a `Module`.
     */
    val klass: KClass<T>

    /**
     * Returns an instance of [T] following the lifecycle defined by the implementation.
     */
    fun DependencyRegistry.provide(parameters: Parameters = Parameters.EMPTY): T
}
