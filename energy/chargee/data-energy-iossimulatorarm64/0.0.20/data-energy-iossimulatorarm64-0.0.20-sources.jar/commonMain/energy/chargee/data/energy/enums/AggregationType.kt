package energy.chargee.data.energy.enums

/**
 * The type of energy aggregation to query.
 */
enum class AggregationType {
    /** Energy drawn from the grid. */
    Delivered,

    /** Energy fed back into the grid (e.g. solar export). */
    Returned,

    /** Energy produced on-site (e.g. solar panels). */
    Produced,

    /** Total energy consumed on-site. */
    Consumed,
}
