package energy.chargee.data.energy.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * The fractional distribution of energy across meter connections.
 *
 * [p1] is the share attributed to the P1 (main grid) meter and [p4] to the P4 (sub) meter.
 * Values are in the range `[0.0, 1.0]` and sum to `1.0`.
 */
@Serializable
@ObjCName("_SourceDistribution")
data class SourceDistribution(val p1: Float, val p4: Float)
