package energy.chargee.data.energy.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * A collection of [CombinedEnergyInterval]s for a queried time range, with an optional
 * [sourceDistribution] describing how energy is split across meter connections.
 */
@Serializable
@ObjCName("_CombinedEnergyIntervals")
data class CombinedEnergyIntervals(val intervals: List<CombinedEnergyInterval>, val sourceDistribution: SourceDistribution? = null)
