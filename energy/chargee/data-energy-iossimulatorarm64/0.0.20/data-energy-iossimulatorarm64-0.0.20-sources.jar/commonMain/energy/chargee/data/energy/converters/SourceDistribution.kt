package energy.chargee.data.energy.converters

import energy.chargee.data.energy.dtos.SourceDistributionDto
import energy.chargee.data.energy.models.SourceDistribution

internal fun SourceDistributionDto.asSourceDistribution() = SourceDistribution(p1, p4)
