package energy.chargee.data.energy.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.energy.enums.AggregationType
import energy.chargee.data.energy.enums.EnergyType
import energy.chargee.data.energy.enums.Resolution
import energy.chargee.data.energy.enums.ValueType
import energy.chargee.data.energy.models.CombinedEnergyIntervals
import energy.chargee.data.energy.models.EnergyTotal
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * Provides access to aggregated energy data from the remote API.
 */
@Repository
@ObjCName("_EnergyRepository")
interface EnergyRepository {
    /**
     * Fetches energy data for [addressUuid] across multiple aggregation types and merges them into
     * a [CombinedEnergyIntervals]. Pass `withPredictions = true` to also include forecast data.
     *
     * [from] and [to] are snapped outwards to whole [resolution] buckets — the API only accepts
     * bucket boundaries — so the range returned always covers, and may slightly exceed, the one
     * asked for. Boundaries are computed in the API's own time zone, so callers need not know
     * which that is. The intervals returned are exactly the buckets the API reported, in
     * chronological order; a period with no data yields an empty list rather than a run of
     * value-less intervals.
     */
    suspend fun getCombinedEnergyIntervals(
        addressUuid: String,
        energyType: EnergyType,
        resolution: Resolution,
        from: Instant,
        to: Instant,
        withPredictions: Boolean,
    ): Result<CombinedEnergyIntervals, ApiError>

    /**
     * Fetches the total aggregated energy for [addressUuid] over the given time range,
     * returning an [EnergyTotal].
     *
     * As with [getCombinedEnergyIntervals], [from] and [to] are snapped outwards to whole
     * [resolution] buckets before the request is sent.
     */
    suspend fun getEnergyTotal(
        addressUuid: String,
        valueType: ValueType,
        energyType: EnergyType,
        aggregationType: AggregationType,
        resolution: Resolution,
        from: Instant,
        to: Instant,
    ): Result<EnergyTotal, ApiError>
}
