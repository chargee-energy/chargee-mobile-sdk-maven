package energy.chargee.data.energy.enums

/**
 * The time bucket size used when aggregating energy data.
 */
enum class Resolution {
    QuarterHourly,
    Hourly,
    Daily,
    Weekly,
    Monthly,
    Yearly,
}
