package energy.chargee.data.energy.models

import kotlinx.serialization.Serializable
import kotlin.math.max
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A single time-bucketed snapshot combining multiple energy aggregation types for one address.
 *
 * All energy values are in watt-hours (Wh) and may be `null` when data is unavailable.
 * [selfConsumption] is derived as `max(produced - returned, 0)` and is `null` when either
 * [produced] or [returned] is absent.
 */
@Serializable
@ObjCName("_CombinedEnergyInterval")
data class CombinedEnergyInterval(
    val time: Instant,
    val delivered: Int? = null,
    val returned: Int? = null,
    val produced: Int? = null,
    val predictedDelivery: Int? = null,
    val predictedReturn: Int? = null,
) {
    val selfConsumption = returned?.let { returned -> produced?.let { produced -> max(produced - returned, 0) } }
}
