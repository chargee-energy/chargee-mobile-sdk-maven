package energy.chargee.data.energy.clients

import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.energy.dtos.EnergyIntervalDto
import energy.chargee.data.energy.dtos.EnergyIntervalMetaDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

internal class EnergyApiClient(private val httpClient: HttpClient) {
    suspend fun getAggregatedEnergy(
        addressUuid: String,
        valueType: String,
        energyType: String,
        aggregationType: String,
        resolution: String,
        from: String,
        to: String,
        timezone: String,
    ): PaginatedResponseDto<EnergyIntervalMetaDto, EnergyIntervalDto> =
        httpClient
            .get("/v5/addresses/$addressUuid/energy/$energyType/$valueType") {
                url {
                    parameters.append("aggregateType", aggregationType)
                    parameters.append("resolution", resolution)
                    parameters.append("fromDate", from)
                    parameters.append("toDate", to)
                    parameters.append("timezone", timezone)
                }
            }.body()
}
