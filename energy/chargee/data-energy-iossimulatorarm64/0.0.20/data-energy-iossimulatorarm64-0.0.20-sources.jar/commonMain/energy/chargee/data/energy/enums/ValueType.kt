package energy.chargee.data.energy.enums

/**
 * Whether the energy values represent measured data or forecasts.
 */
enum class ValueType {
    /** Measured/actual energy data. */
    Aggregation,

    /** Forecasted/predicted energy data. */
    Prediction,
}
