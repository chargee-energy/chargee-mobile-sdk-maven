package energy.chargee.data.energy.time

import energy.chargee.data.energy.enums.Resolution
import kotlinx.datetime.DateTimeUnit
import kotlinx.datetime.LocalDate
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.LocalTime
import kotlinx.datetime.Month
import kotlinx.datetime.TimeZone
import kotlinx.datetime.atStartOfDayIn
import kotlinx.datetime.isoDayNumber
import kotlinx.datetime.minus
import kotlinx.datetime.plus
import kotlinx.datetime.toInstant
import kotlinx.datetime.toLocalDateTime
import kotlin.time.Instant

/*
 * Bucket-boundary arithmetic for a Resolution.
 *
 * The energy API buckets by whole resolution units in a fixed time zone and only accepts those
 * boundaries as a query range, so requests are snapped with startOfBucket and endOfBucket
 * before they are sent. Boundaries are computed in *local* time — a daily bucket starts at local
 * midnight, not at a fixed UTC offset — which keeps them correct across daylight-saving changes.
 */

/**
 * The start of the bucket containing [instant], in [timeZone].
 *
 * Returns [instant] unchanged when it already sits exactly on a boundary.
 */
internal fun Resolution.startOfBucket(instant: Instant, timeZone: TimeZone): Instant {
    val local = instant.toLocalDateTime(timeZone)
    return when (this) {
        Resolution.QuarterHourly -> {
            LocalDateTime(local.date, LocalTime(local.hour, local.minute / 15 * 15)).toInstant(timeZone)
        }

        Resolution.Hourly -> {
            LocalDateTime(local.date, LocalTime(local.hour, 0)).toInstant(timeZone)
        }

        Resolution.Daily -> {
            local.date.atStartOfDayIn(timeZone)
        }

        // ISO weeks start on Monday, so step back to the most recent one.
        Resolution.Weekly -> {
            local.date
                .minus(local.date.dayOfWeek.isoDayNumber - 1, DateTimeUnit.DAY)
                .atStartOfDayIn(timeZone)
        }

        Resolution.Monthly -> {
            LocalDate(local.year, local.month, 1).atStartOfDayIn(timeZone)
        }

        Resolution.Yearly -> {
            LocalDate(local.year, Month.JANUARY, 1).atStartOfDayIn(timeZone)
        }
    }
}

/**
 * The start of the bucket that follows the one beginning at [bucketStart].
 *
 * Stepping in calendar units rather than by a fixed duration keeps every boundary on a real local
 * boundary — a day is 23 or 25 hours long across a daylight-saving change, and months differ in
 * length.
 */
internal fun Resolution.nextBucket(bucketStart: Instant, timeZone: TimeZone): Instant =
    when (this) {
        Resolution.QuarterHourly -> bucketStart.plus(15, DateTimeUnit.MINUTE)
        Resolution.Hourly -> bucketStart.plus(1, DateTimeUnit.HOUR)
        Resolution.Daily -> bucketStart.plus(1, DateTimeUnit.DAY, timeZone)
        Resolution.Weekly -> bucketStart.plus(1, DateTimeUnit.WEEK, timeZone)
        Resolution.Monthly -> bucketStart.plus(1, DateTimeUnit.MONTH, timeZone)
        Resolution.Yearly -> bucketStart.plus(1, DateTimeUnit.YEAR, timeZone)
    }

/**
 * The first boundary at or after [instant], in [timeZone].
 *
 * Used to round the exclusive end of a range *outwards*, so the caller's requested span is always
 * fully covered rather than clipped.
 */
internal fun Resolution.endOfBucket(instant: Instant, timeZone: TimeZone): Instant {
    val start = startOfBucket(instant, timeZone)
    return if (start == instant) instant else nextBucket(start, timeZone)
}
