package energy.chargee.data.energy.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class EnergyIntervalDto(val time: String, val value: Int)
