package energy.chargee.data.energy.enums

/**
 * The energy carrier to query.
 */
enum class EnergyType {
    Electricity,
    Gas,
}
