package energy.chargee.data.energy.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class SourceDistributionDto(val p1: Float, val p4: Float)
