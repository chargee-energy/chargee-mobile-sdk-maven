package energy.chargee.data.energy

import energy.chargee.core.di.module
import energy.chargee.data.energy.clients.EnergyApiClient
import energy.chargee.data.energy.repositories.EnergyApiRepository
import energy.chargee.data.energy.repositories.EnergyRepository

val energyDataModule =
    module {
        factory { EnergyApiClient(get()) }
        factory<EnergyRepository> { EnergyApiRepository(get()) }
    }
