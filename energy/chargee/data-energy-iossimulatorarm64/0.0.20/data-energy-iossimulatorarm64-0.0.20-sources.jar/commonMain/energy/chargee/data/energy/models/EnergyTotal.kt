package energy.chargee.data.energy.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * The total aggregated energy in watt-hours (Wh) for a queried time range.
 *
 * [value] is `null` when no data is available for the requested period.
 */
@Serializable
@ObjCName("_EnergyTotal")
data class EnergyTotal(val value: Int?)
