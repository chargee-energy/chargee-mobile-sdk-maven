package energy.chargee.data.energy.converters

import energy.chargee.data.energy.dtos.EnergyIntervalDto
import energy.chargee.data.energy.models.CombinedEnergyInterval
import kotlin.time.Instant

/**
 * Merges the per-aggregation responses into one [CombinedEnergyInterval] per timestamp the backend
 * actually returned.
 *
 * The timeline is the sorted union of every series' timestamps rather than a range generated from
 * the request. That matters for correctness: a generated timeline only lines up when the request
 * was snapped to bucket boundaries, and when it isn't, every lookup misses and the caller receives
 * a full set of intervals with nothing but `null`s — data loss that looks like "no data". Reading
 * the timeline off the responses removes that failure mode entirely.
 *
 * A series that is absent for a timestamp leaves that field `null`, so gaps survive rather than
 * being invented, and a prediction series reaching past the measured data simply extends the
 * timeline.
 */
internal fun combineEnergyIntervals(
    delivered: List<EnergyIntervalDto>,
    returned: List<EnergyIntervalDto>?,
    produced: List<EnergyIntervalDto>?,
    predictedDelivery: List<EnergyIntervalDto>?,
    predictedReturn: List<EnergyIntervalDto>?,
): List<CombinedEnergyInterval> {
    val deliveredByTime = delivered.indexByTime()
    val returnedByTime = returned.indexByTime()
    val producedByTime = produced.indexByTime()
    val predictedDeliveryByTime = predictedDelivery.indexByTime()
    val predictedReturnByTime = predictedReturn.indexByTime()

    val times =
        (
            deliveredByTime.keys +
                returnedByTime.keys +
                producedByTime.keys +
                predictedDeliveryByTime.keys +
                predictedReturnByTime.keys
        ).sorted()

    return times.map { time ->
        CombinedEnergyInterval(
            time = time,
            delivered = deliveredByTime[time],
            returned = returnedByTime[time],
            produced = producedByTime[time],
            predictedDelivery = predictedDeliveryByTime[time],
            predictedReturn = predictedReturnByTime[time],
        )
    }
}

/**
 * Indexes a series by timestamp, parsing each one exactly once.
 *
 * The previous per-bucket linear scan re-parsed every row's timestamp on every lookup, so a long
 * range at a fine resolution spent most of its time in [Instant.parse].
 */
private fun List<EnergyIntervalDto>?.indexByTime(): Map<Instant, Int> = this?.associate { Instant.parse(it.time) to it.value }.orEmpty()
