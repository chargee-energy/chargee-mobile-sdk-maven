package energy.chargee.data.energy.repositories

import energy.chargee.core.network.DEFAULT_TIMEZONE
import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.energy.clients.EnergyApiClient
import energy.chargee.data.energy.converters.asSourceDistribution
import energy.chargee.data.energy.converters.combineEnergyIntervals
import energy.chargee.data.energy.dtos.SourceDistributionDto
import energy.chargee.data.energy.enums.AggregationType
import energy.chargee.data.energy.enums.EnergyType
import energy.chargee.data.energy.enums.Resolution
import energy.chargee.data.energy.enums.ValueType
import energy.chargee.data.energy.models.CombinedEnergyIntervals
import energy.chargee.data.energy.models.EnergyTotal
import energy.chargee.data.energy.time.endOfBucket
import energy.chargee.data.energy.time.startOfBucket
import energy.chargee.utils.result.Result
import energy.chargee.utils.string.kebabCase
import kotlinx.datetime.TimeZone
import kotlin.time.Instant

internal class EnergyApiRepository(private val energyApiClient: EnergyApiClient) : EnergyRepository {
    override suspend fun getCombinedEnergyIntervals(
        addressUuid: String,
        energyType: EnergyType,
        resolution: Resolution,
        from: Instant,
        to: Instant,
        withPredictions: Boolean,
    ): Result<CombinedEnergyIntervals, ApiError> =
        runApi {
            val timeZone = TimeZone.of(DEFAULT_TIMEZONE)
            val alignedFrom = resolution.startOfBucket(from, timeZone)
            val alignedTo = resolution.endOfBucket(to, timeZone)

            val canReturn = energyType == EnergyType.Electricity
            val deliveredResponse =
                energyApiClient.getAggregatedEnergy(
                    addressUuid,
                    ValueType.Aggregation.toString().kebabCase(),
                    energyType.toString().kebabCase(),
                    AggregationType.Delivered.toString().kebabCase(),
                    resolution.toString().kebabCase(),
                    alignedFrom.toString(),
                    alignedTo.toString(),
                    DEFAULT_TIMEZONE,
                )

            val returned =
                if (canReturn) {
                    energyApiClient
                        .getAggregatedEnergy(
                            addressUuid,
                            ValueType.Aggregation.toString().kebabCase(),
                            energyType.toString().kebabCase(),
                            AggregationType.Returned.toString().kebabCase(),
                            resolution.toString().kebabCase(),
                            alignedFrom.toString(),
                            alignedTo.toString(),
                            DEFAULT_TIMEZONE,
                        ).results
                } else {
                    null
                }

            val produced =
                if (canReturn) {
                    energyApiClient
                        .getAggregatedEnergy(
                            addressUuid,
                            ValueType.Aggregation.toString().kebabCase(),
                            energyType.toString().kebabCase(),
                            AggregationType.Produced.toString().kebabCase(),
                            resolution.toString().kebabCase(),
                            alignedFrom.toString(),
                            alignedTo.toString(),
                            DEFAULT_TIMEZONE,
                        ).results
                } else {
                    null
                }

            val predictedDelivery =
                if (withPredictions) {
                    energyApiClient
                        .getAggregatedEnergy(
                            addressUuid,
                            ValueType.Prediction.toString().kebabCase(),
                            energyType.toString().kebabCase(),
                            AggregationType.Delivered.toString().kebabCase(),
                            resolution.toString().kebabCase(),
                            alignedFrom.toString(),
                            alignedTo.toString(),
                            DEFAULT_TIMEZONE,
                        ).results
                } else {
                    null
                }

            val predictedReturn =
                if (withPredictions && canReturn) {
                    energyApiClient
                        .getAggregatedEnergy(
                            addressUuid,
                            ValueType.Prediction.toString().kebabCase(),
                            energyType.toString().kebabCase(),
                            AggregationType.Returned.toString().kebabCase(),
                            resolution.toString().kebabCase(),
                            alignedFrom.toString(),
                            alignedTo.toString(),
                            DEFAULT_TIMEZONE,
                        ).results
                } else {
                    null
                }

            CombinedEnergyIntervals(
                intervals =
                    combineEnergyIntervals(
                        delivered = deliveredResponse.results,
                        returned = returned,
                        produced = produced,
                        predictedDelivery = predictedDelivery,
                        predictedReturn = predictedReturn,
                    ),
                sourceDistribution = deliveredResponse.meta.sourceDistribution?.let(SourceDistributionDto::asSourceDistribution),
            )
        }

    override suspend fun getEnergyTotal(
        addressUuid: String,
        valueType: ValueType,
        energyType: EnergyType,
        aggregationType: AggregationType,
        resolution: Resolution,
        from: Instant,
        to: Instant,
    ): Result<EnergyTotal, ApiError> =
        runApi {
            val timeZone = TimeZone.of(DEFAULT_TIMEZONE)
            val alignedFrom = resolution.startOfBucket(from, timeZone)
            val alignedTo = resolution.endOfBucket(to, timeZone)

            EnergyTotal(
                energyApiClient
                    .getAggregatedEnergy(
                        addressUuid,
                        valueType.toString().kebabCase(),
                        energyType.toString().kebabCase(),
                        aggregationType.toString().kebabCase(),
                        resolution.toString().kebabCase(),
                        alignedFrom.toString(),
                        alignedTo.toString(),
                        DEFAULT_TIMEZONE,
                    ).results
                    .firstOrNull()
                    ?.value,
            )
        }
}
