package energy.chargee.data.energy.dtos

import energy.chargee.core.network.dtos.PaginatedMeta
import kotlinx.serialization.Serializable

@Serializable
internal data class EnergyIntervalMetaDto(
    val sourceDistribution: SourceDistributionDto? = null,
    override val total: Int? = null,
    override val offset: Int? = null,
) : PaginatedMeta
