package energy.chargee.onboarding.alfen.clients

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig

internal actual fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit): HttpClient {
    error("JVM is not directly supported. It is only supported through Android which has it's own implementation.")
}
