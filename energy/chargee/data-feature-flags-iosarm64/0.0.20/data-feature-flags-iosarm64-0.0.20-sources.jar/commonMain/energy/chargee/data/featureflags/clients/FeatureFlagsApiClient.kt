package energy.chargee.data.featureflags.clients

import energy.chargee.data.featureflags.dtos.FeatureFlagsResponseDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

internal class FeatureFlagsApiClient(val httpClient: HttpClient) {
    suspend fun getFeatureFlags(): FeatureFlagsResponseDto = httpClient.get("/v5/feature-flags").body()
}
