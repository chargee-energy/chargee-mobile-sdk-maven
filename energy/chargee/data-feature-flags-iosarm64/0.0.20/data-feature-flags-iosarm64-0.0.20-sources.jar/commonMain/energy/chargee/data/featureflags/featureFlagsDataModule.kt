package energy.chargee.data.featureflags

import energy.chargee.core.di.module
import energy.chargee.data.featureflags.clients.FeatureFlagsApiClient
import energy.chargee.data.featureflags.repositories.FeatureFlagsApiRepository
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository

val featureFlagsDataModule =
    module {
        factory { FeatureFlagsApiClient(get()) }
        factory<FeatureFlagsRepository> { FeatureFlagsApiRepository(get()) }
    }
