package energy.chargee.data.featureflags.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to feature flags from the remote API.
 */
@Repository
@ObjCName("_FeatureFlagsRepository")
interface FeatureFlagsRepository {
    /**
     * Fetches all feature flags, returning a map of flag key to the list of addresses it applies to.
     */
    suspend fun getFeatureFlags(): Result<Map<String, List<String>>, ApiError>
}
