package energy.chargee.data.featureflags

/**
 * Known feature flag keys returned by the feature flags API.
 */
object Features {
    /**
     * Key for the correction factor feature flag.
     */
    const val CORRECTION_FACTOR = "correction_factor"
}
