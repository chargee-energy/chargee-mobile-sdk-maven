package energy.chargee.data.featureflags.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.featureflags.clients.FeatureFlagsApiClient
import energy.chargee.utils.result.Result

internal class FeatureFlagsApiRepository(private val featureFlagsApiClient: FeatureFlagsApiClient) : FeatureFlagsRepository {
    override suspend fun getFeatureFlags(): Result<Map<String, List<String>>, ApiError> =
        runApi { featureFlagsApiClient.getFeatureFlags().addresses }
}
