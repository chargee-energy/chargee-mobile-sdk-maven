package energy.chargee.data.featureflags.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class FeatureFlagsResponseDto(val addresses: Map<String, List<String>>)
