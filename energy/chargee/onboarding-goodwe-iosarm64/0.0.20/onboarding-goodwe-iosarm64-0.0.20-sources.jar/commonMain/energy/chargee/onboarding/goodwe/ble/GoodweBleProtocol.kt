package energy.chargee.onboarding.goodwe.ble

import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

/**
 * Wire-level constants for talking to a Goodwe Wi-Fi/LAN dongle over Bluetooth.
 *
 * The two registers here are the only ones this flow writes, and they are named after the switches
 * they drive rather than after the app's internal constants, so that what the code touches can be
 * read straight off the vendor app's Privacy & Security screen. Everything else on that screen —
 * Bluetooth stays-on, the password switch, SSH — is deliberately absent.
 *
 * Two addresses are deliberately *not* constants here, so that reaching for them takes a
 * deliberate act rather than autocomplete:
 * - `0xFA 0482` (`RESET_CLOUD_PARAM`) was taken for an "apply and restart" and is not one. Writing
 *   it cleared a Kit-20's stored WLAN configuration, turned its always-on Bluetooth off, and left
 *   both switches disabled. No commit is needed: each switch takes effect on its own write, and
 *   the vendor app sends exactly one frame per toggle and nothing after it.
 * - `0xF7 82EF` (`SET_MODBUS_TCP_STATUS`) is the inverter's own Modbus-TCP switch, from a
 *   different screen. It is not the WLAN Control switch and onboarding has no reason to write it.
 *
 * Everything here was read out of the SolarGo Android app. The GATT identifiers, the device-name
 * filter, the register frames and the module-status predicates ([isLocked], [lockRemainingSeconds]
 * and [isLoginRequired], all traced to `BleDeviceFragment.getModuleStatus`) are confirmed against
 * its code. [isLoginAccepted] is not, and says so.
 */
internal object GoodweBleProtocol {
    /** The dongle's GATT service. `0000fed4-…` is the EV-charger channel and is never used here. */
    const val SERVICE_UUID = "0000e0ff-3c17-d293-8e48-14fe2e4da212"

    /** Characteristic every request is written to, as a single write. */
    const val WRITE_CHARACTERISTIC_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"

    /** Characteristic every reply is notified on, in one or more chunks. */
    const val NOTIFY_CHARACTERISTIC_UUID = "0000ffe2-0000-1000-8000-00805f9b34fb"

    /**
     * Advertised names that belong to a Goodwe dongle. The tokens may appear anywhere in the name,
     * which is why this is a search rather than a prefix match.
     */
    val DEVICE_NAME = Regex("(WNN-|CCM-|WFA|WLA|GSA|GSB|GSC|LGA)")

    /**
     * Dongle register behind the **Modbus TCP** switch on the vendor app's Privacy & Security
     * screen — `SETTING_TCP_STATUS = 0x288` there, which builds `FA 10 1010 0001 02`.
     */
    const val MODBUS_TCP_REGISTER = 0x1010

    /**
     * Dongle register behind the **WLAN Control** switch on the same screen —
     * `SETTING_LAN_STATUS = 0x291` there, which builds `FA 10 1023 0001 02`.
     *
     * Both switches are needed. A Kit-20 with only [MODBUS_TCP_REGISTER] set shows Modbus TCP on,
     * WLAN Control still off, and serves no data.
     */
    const val WLAN_CONTROL_REGISTER = 0x1023

    /** Value written to a switch register to turn it on. */
    const val ENABLED = 1

    /** AA55 control and function bytes for the security/lock state probe. */
    const val SECURITY_PROBE_CONTROL = 0x02
    const val SECURITY_PROBE_FUNCTION = 0x03

    /** AA55 control and function bytes for the login handshake. */
    const val LOGIN_CONTROL = 0x02
    const val LOGIN_FUNCTION = 0x01

    /** Passwords are sent as UTF-8 zero-padded to a fixed width. */
    const val PASSWORD_LENGTH = 16

    /** Flag byte preceding the password, selecting the end-user account rather than the installer. */
    const val END_USER_ACCOUNT = 0x00

    /** Per-request reply timeout, matching the app's default. */
    val REQUEST_TIMEOUT = 2500.milliseconds

    /** How long to collect advertisements before offering the user what was found. */
    val SCAN_TIMEOUT = 10.seconds

    /**
     * Smallest probe reply the module status can be read from: the app ignores anything shorter.
     */
    private const val MODULE_STATUS_LENGTH = 3

    /**
     * Values of the first status byte, which is an authentication state rather than a result code.
     * The same byte is reported by the probe and by the login reply.
     *
     * Confirmed on a Kit-20 dongle: the probe answers `00 00 B4` before any attempt, a login with
     * the correct password answers `02 00 B4`, and a probe afterwards still answers `02` — the
     * module holds the authenticated state for the rest of the connection.
     */
    private const val NOT_AUTHENTICATED = 0
    private const val LOCKED = 1
    private const val AUTHENTICATED = 2

    /**
     * Whether the module has locked itself after too many rejected passwords.
     *
     * Read from the first byte of the probe's data region, matching
     * `BleDeviceFragment$getModuleStatus$2`: a `1` there sends the app down its lock-notice path
     * instead of showing the login prompt.
     */
    fun isLocked(probeReply: ByteArray): Boolean {
        val data = GoodweFraming.aa55Data(probeReply)
        return data.size >= MODULE_STATUS_LENGTH && data[0].toInt() == LOCKED
    }

    /**
     * How many seconds the module stays locked, or `null` when it is not locked.
     *
     * The third byte of the probe's data region. The app renders it straight into its lock notice
     * suffixed with `" s"`, which is what fixes the unit as seconds rather than minutes.
     */
    fun lockRemainingSeconds(probeReply: ByteArray): Int? {
        if (!isLocked(probeReply)) return null
        return GoodweFraming.aa55Data(probeReply)[2].toInt() and 0xFF
    }

    /**
     * Whether the module wants a password before it will accept configuration.
     *
     * Neither already locked nor already authenticated. An unrecognised status still counts as
     * wanting one: asking for a password the module did not need is recoverable, skipping one it
     * did need is not.
     */
    fun isLoginRequired(probeReply: ByteArray): Boolean {
        val data = GoodweFraming.aa55Data(probeReply)
        if (data.size < MODULE_STATUS_LENGTH) return false
        val status = data[0].toInt()
        return status != LOCKED && status != AUTHENTICATED
    }

    /**
     * Whether the dongle accepted the password, which it reports by moving to [AUTHENTICATED].
     *
     * Note that the status byte is a state and not a result: [NOT_AUTHENTICATED] is where the
     * module sits before any attempt and where it stays after a rejected one, so a reply that
     * carries it is a refusal rather than a success. Reading it the other way round rejects every
     * correct password, and the caller sends the user back to a prompt they cannot satisfy.
     */
    fun isLoginAccepted(loginReply: ByteArray): Boolean {
        val data = GoodweFraming.aa55Data(loginReply)
        return data.size >= MODULE_STATUS_LENGTH && data[0].toInt() == AUTHENTICATED
    }
}
