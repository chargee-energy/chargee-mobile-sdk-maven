package energy.chargee.onboarding.goodwe.steps

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.goodwe.GoodweConfig
import energy.chargee.onboarding.goodwe.GoodweErrorCode
import energy.chargee.onboarding.goodwe.GoodweOnboardingContext
import energy.chargee.onboarding.goodwe.ble.GoodweBleClient
import energy.chargee.onboarding.goodwe.ble.GoodweBleResult
import energy.chargee.onboarding.goodwe.discovery.goodweGeneration
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.toList

/**
 * Switches local communication on over the Bluetooth link opened by [ConnectBluetoothStep], then
 * waits for the dongle to come back on the network.
 *
 * The dongle is rediscovered by broadcast rather than read back over Bluetooth, because that
 * re-discovery is the real acceptance test: an answer to the broadcast is exactly what onboarding
 * needed and could not get before. It lives inside this step because it is a poll rather than a
 * single scan, and because a flow node cannot loop.
 *
 * The step is also what makes the Bluetooth branch rejoin the main path — it sets `selectedDevice`
 * so registration proceeds as it would have if the first broadcast had been answered.
 */
internal class EnableLocalCommunicationStep(private val client: GoodweBleClient, private val discoveryFactory: () -> DeviceDiscovery) :
    OnboardingFlow.Step<LocalDeviceStepId, GoodweOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: GoodweOnboardingContext): Result<GoodweOnboardingContext> {
        when (val result = client.enableLocalCommunication()) {
            GoodweBleResult.Success -> {
                Unit
            }

            GoodweBleResult.Unauthorized -> {
                return Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true),
                )
            }

            is GoodweBleResult.Locked -> {
                return Result.Failure(context, GoodweErrorCode.DongleLocked(result.remainingSeconds))
            }

            is GoodweBleResult.Failure -> {
                return Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure())
            }
        }

        client.disconnect()

        val device = awaitDongleOnNetwork() ?: return Result.Failure(context, GoodweErrorCode.DongleNotReachable)

        return Result.Success(context.copyWith(discoveredDevices = listOf(device), selectedDevice = device))
    }

    /**
     * Polls the broadcast until a recognised dongle answers, or the attempts run out.
     *
     * A reply marked busy still proves local communication is on, so it is accepted once the
     * preference window has passed — on a re-onboarding the Chargee device itself may be holding
     * the dongle's session, and waiting for a quiet one would never succeed.
     */
    private suspend fun awaitDongleOnNetwork(): DiscoveredDevice? {
        var busy: DiscoveredDevice? = null

        repeat(GoodweConfig.READINESS_ATTEMPTS) { attempt ->
            delay(if (attempt == 0) GoodweConfig.SETTLE_DELAY else GoodweConfig.READINESS_POLL_INTERVAL)

            val dongles = discoveryFactory().discover().toList().filter { it.goodweGeneration() != null }

            dongles.firstOrNull { !it.extraParameters.containsKey(GoodweConfig.BUSY_PARAMETER) }?.let { return it }
            busy = busy ?: dongles.firstOrNull()
        }

        return busy
    }

    override suspend fun onFinished(context: GoodweOnboardingContext) {
        client.disconnect()
    }
}
