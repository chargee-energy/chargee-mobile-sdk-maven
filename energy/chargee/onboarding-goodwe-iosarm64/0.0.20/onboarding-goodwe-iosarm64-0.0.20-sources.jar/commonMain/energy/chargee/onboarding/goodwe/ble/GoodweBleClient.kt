package energy.chargee.onboarding.goodwe.ble

import energy.chargee.onboarding.goodwe.models.GoodweBluetoothDevice
import energy.chargee.utils.bluetooth.BleClient
import energy.chargee.utils.bluetooth.BleException

/**
 * The outcome of one exchange with a dongle.
 *
 * [Unauthorized] is kept apart from [Failure] because it is the only outcome the user can do
 * anything about, and because retrying it automatically risks locking the module.
 */
internal sealed interface GoodweBleResult {
    /** The dongle accepted the request. */
    data object Success : GoodweBleResult

    /** The dongle wants a password, or rejected the one it was given. */
    data object Unauthorized : GoodweBleResult

    /**
     * The dongle has locked itself after too many rejected passwords, for [remainingSeconds] more
     * if it said. Distinct from [Unauthorized] because another password cannot help: asking for one
     * would be a dead end.
     */
    data class Locked(val remainingSeconds: Int? = null) : GoodweBleResult

    /** Anything else — out of range, link dropped, or a reply that made no sense. */
    data class Failure(val reason: String) : GoodweBleResult
}

/**
 * Talks to a Goodwe Wi-Fi/LAN dongle over Bluetooth, for the one job onboarding needs: switching
 * local communication on so the dongle starts answering the discovery broadcast.
 *
 * A client holds at most one connection. The expected order is [scan], [connect], [login] if the
 * dongle asked for it, [enableLocalCommunication], then [disconnect]. It deliberately does not
 * provision Wi-Fi credentials — the dongle is already on the home network, and writing an SSID
 * could take it off.
 */
internal interface GoodweBleClient {
    /** Scans for dongles in range, returning what was found in the order it was seen. */
    suspend fun scan(): List<GoodweBluetoothDevice>

    /**
     * Connects to [id] and probes the module's security state: [GoodweBleResult.Success] when it is
     * already open, [GoodweBleResult.Unauthorized] when [login] is needed first, and
     * [GoodweBleResult.Locked] when it has stopped accepting passwords altogether.
     */
    suspend fun connect(id: String): GoodweBleResult

    /**
     * Logs in with [password], answering [GoodweBleResult.Locked] if that attempt was the one that
     * exhausted the module's retry budget.
     *
     * Call this at most once per password. The module keeps a retry counter and locks itself after
     * repeated failures, so a rejected password must go back to the user rather than be retried.
     */
    suspend fun login(password: String): GoodweBleResult

    /**
     * Switches local communication on, by writing both of the dongle's communication switches.
     *
     * Each switch takes effect on its own write; nothing is committed or restarted afterwards.
     */
    suspend fun enableLocalCommunication(): GoodweBleResult

    /** Closes the link if one is open. Safe to call when nothing is connected. */
    suspend fun disconnect()
}

/**
 * The [GoodweBleClient] used in production, driving a [BleClient] configured with the dongle's
 * GATT identifiers.
 */
internal class DefaultGoodweBleClient(private val ble: BleClient) : GoodweBleClient {
    override suspend fun scan(): List<GoodweBluetoothDevice> =
        runCatching { ble.scan(GoodweBleProtocol.DEVICE_NAME, GoodweBleProtocol.SCAN_TIMEOUT) }
            .getOrElse { emptyList() }
            .map { GoodweBluetoothDevice(id = it.id, name = it.name, signalStrength = it.signalStrength) }

    override suspend fun connect(id: String): GoodweBleResult =
        exchange {
            ble.connect(id)

            val probe =
                ble.request(
                    payload = GoodweFraming.aa55(GoodweBleProtocol.SECURITY_PROBE_CONTROL, GoodweBleProtocol.SECURITY_PROBE_FUNCTION),
                    timeout = GoodweBleProtocol.REQUEST_TIMEOUT,
                    isComplete = GoodweFraming::isCompleteAa55Reply,
                )

            when {
                GoodweBleProtocol.isLocked(probe) -> GoodweBleResult.Locked(GoodweBleProtocol.lockRemainingSeconds(probe))
                GoodweBleProtocol.isLoginRequired(probe) -> GoodweBleResult.Unauthorized
                else -> GoodweBleResult.Success
            }
        }

    override suspend fun login(password: String): GoodweBleResult =
        exchange {
            val credentials =
                byteArrayOf(GoodweBleProtocol.END_USER_ACCOUNT.toByte()) +
                    password.encodeToByteArray().padded(GoodweBleProtocol.PASSWORD_LENGTH)

            val reply =
                ble.request(
                    payload = GoodweFraming.aa55(GoodweBleProtocol.LOGIN_CONTROL, GoodweBleProtocol.LOGIN_FUNCTION, credentials),
                    timeout = GoodweBleProtocol.REQUEST_TIMEOUT,
                    isComplete = GoodweFraming::isCompleteAa55Reply,
                )

            when {
                GoodweBleProtocol.isLoginAccepted(reply) -> GoodweBleResult.Success

                // Re-probe rather than guess: a refusal and a refusal that used up the last attempt
                // look the same in the login reply, and only the probe carries the lock state.
                else -> lockedNow() ?: GoodweBleResult.Unauthorized
            }
        }

    override suspend fun enableLocalCommunication(): GoodweBleResult =
        exchange {
            // Two switches, not one: the vendor app's Privacy & Security screen exposes "Modbus
            // TCP" and "WLAN Control" separately and both have to be on. Observed on a Kit-20 —
            // writing only the first leaves the second off and the dongle serves no data.
            val modbusTcpEnabled = writeDongleRegister(GoodweBleProtocol.MODBUS_TCP_REGISTER)
            if (modbusTcpEnabled != GoodweBleResult.Success) return@exchange modbusTcpEnabled

            val wlanControlEnabled = writeDongleRegister(GoodweBleProtocol.WLAN_CONTROL_REGISTER)
            if (wlanControlEnabled != GoodweBleResult.Success) return@exchange wlanControlEnabled

            // Nothing follows them. Each switch takes effect on its own write, and the one address
            // that looked like a commit is a configuration wipe — see the warning on
            // [GoodweBleProtocol].
            GoodweBleResult.Success
        }

    override suspend fun disconnect() {
        runCatching { ble.disconnect() }
    }

    private suspend fun lockedNow(): GoodweBleResult.Locked? =
        runCatching {
            val probe =
                ble.request(
                    payload = GoodweFraming.aa55(GoodweBleProtocol.SECURITY_PROBE_CONTROL, GoodweBleProtocol.SECURITY_PROBE_FUNCTION),
                    timeout = GoodweBleProtocol.REQUEST_TIMEOUT,
                    isComplete = GoodweFraming::isCompleteAa55Reply,
                )

            if (GoodweBleProtocol.isLocked(probe)) GoodweBleResult.Locked(GoodweBleProtocol.lockRemainingSeconds(probe)) else null
        }.getOrNull()

    private suspend fun writeDongleRegister(register: Int): GoodweBleResult {
        val reply =
            ble.request(
                payload = GoodweFraming.writeRegisters(GoodweFraming.DONGLE_SLAVE, register, GoodweBleProtocol.ENABLED),
                timeout = GoodweBleProtocol.REQUEST_TIMEOUT,
                isComplete = GoodweFraming::isCompleteModbusReply,
            )

        return if (GoodweFraming.isAccepted(reply)) {
            GoodweBleResult.Success
        } else {
            GoodweBleResult.Failure("The dongle rejected the write to register $register")
        }
    }

    private suspend fun exchange(block: suspend () -> GoodweBleResult): GoodweBleResult =
        try {
            block()
        } catch (exception: BleException) {
            GoodweBleResult.Failure(exception.message ?: "Bluetooth communication failed")
        }
}

/** This array padded with zeros to [length], or truncated when it is already longer. */
private fun ByteArray.padded(length: Int) = copyOf(length)
