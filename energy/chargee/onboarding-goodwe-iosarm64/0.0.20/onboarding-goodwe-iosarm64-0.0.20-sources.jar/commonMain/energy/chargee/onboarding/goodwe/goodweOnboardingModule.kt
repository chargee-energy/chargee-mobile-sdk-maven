package energy.chargee.onboarding.goodwe

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.goodwe.GoodweConfig.BRAND
import energy.chargee.onboarding.goodwe.GoodweConfig.BROADCAST_MESSAGE
import energy.chargee.onboarding.goodwe.GoodweConfig.BROADCAST_PORT
import energy.chargee.onboarding.goodwe.GoodweConfig.DISCOVERY_TIMEOUT
import energy.chargee.onboarding.goodwe.ble.DefaultGoodweBleClient
import energy.chargee.onboarding.goodwe.ble.GoodweBleProtocol
import energy.chargee.onboarding.goodwe.discovery.GoodweBroadcastParser
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.utils.bluetooth.KableBleClient

val goodweOnboardingModule =
    module {
        factoryWithParameters<DeviceDiscovery>(name = BRAND) {
            get<DeviceDiscovery>(
                name = DiscoveryConfig.UDP_BROADCAST_DISCOVERY_TYPE,
                parameters = parametersOf(BROADCAST_PORT, BROADCAST_MESSAGE.encodeToByteArray(), DISCOVERY_TIMEOUT, GoodweBroadcastParser),
            )
        }
        factoryWithParameters { parameters ->
            GoodweOnboardingSession(
                OnboardingEngine(
                    initialContext = GoodweOnboardingContext(),
                    flow =
                        createGoodweOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            goodweDiscovery = get<DeviceDiscovery>(name = BRAND),
                            goodweBleClient =
                                DefaultGoodweBleClient(
                                    KableBleClient(
                                        serviceUuid = GoodweBleProtocol.SERVICE_UUID,
                                        writeCharacteristicUuid = GoodweBleProtocol.WRITE_CHARACTERISTIC_UUID,
                                        notifyCharacteristicUuid = GoodweBleProtocol.NOTIFY_CHARACTERISTIC_UUID,
                                    ),
                                ),
                            localDeviceRepository = get(),
                            inverterRepository = get(),
                        ),
                ),
            )
        }
    }
