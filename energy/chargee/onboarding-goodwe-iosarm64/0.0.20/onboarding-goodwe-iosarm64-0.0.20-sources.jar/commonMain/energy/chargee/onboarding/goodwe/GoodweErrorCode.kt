package energy.chargee.onboarding.goodwe

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Failures specific to onboarding a Goodwe inverter, layered on top of the shared
 * [energy.chargee.onboarding.localdevice.LocalDeviceErrorCode] cases the flow also emits.
 *
 * These all come from the Bluetooth fallback the flow takes when the dongle does not answer the
 * discovery broadcast. A wrong password is reported as the shared
 * [energy.chargee.onboarding.localdevice.LocalDeviceErrorCode.DeviceConfigurationFailure] with
 * `invalidCredentials` set, because the host app handles it the same way it does for every brand.
 */
@ObjCName("_GoodweErrorCode")
@Serializable
sealed interface GoodweErrorCode : OnboardingErrorCode {
    /**
     * No dongle could be reached at all: nothing answered the discovery broadcast and no dongle was
     * advertising over Bluetooth either. Usually means the phone is on a different network from the
     * dongle, or the dongle has no power.
     */
    @Serializable
    data object NoDongleFound : GoodweErrorCode

    /**
     * Bluetooth could not be used to reach the dongle — switched off, permission not granted, out
     * of range, or the link dropped mid-exchange.
     */
    @Serializable
    data object BluetoothFailure : GoodweErrorCode

    /**
     * A dongle answered the broadcast with [response], which matches neither generation's reply
     * format. Reported verbatim rather than guessed at, since acting on a misread reply would
     * store an unusable configuration.
     */
    @Serializable
    data class UnrecognisedDongleResponse(val response: String) : GoodweErrorCode

    /**
     * Local communication was switched on over Bluetooth, but the dongle still did not answer the
     * discovery broadcast afterwards. The switches may not have taken, or the dongle is on a
     * different network from the phone.
     */
    @Serializable
    data object DongleNotReachable : GoodweErrorCode

    /**
     * The dongle has locked itself after too many rejected passwords and will not accept another
     * until it is reset or the lock expires.
     *
     * Terminal for this attempt: there is nothing the user can type that will be accepted, so the
     * flow must not offer the password prompt again. Prompting would only spend attempts that no
     * longer count for anything.
     *
     * [remainingSeconds] is how long the dongle said the lock has left to run, or `null` when it did
     * not say — show it so the user knows whether to wait or come back later.
     */
    @Serializable
    data class DongleLocked(val remainingSeconds: Int? = null) : GoodweErrorCode
}
