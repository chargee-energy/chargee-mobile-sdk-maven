package energy.chargee.onboarding.goodwe.discovery

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.goodwe.GoodweConfig

/**
 * The generation of Wi-Fi/LAN dongle that answered the discovery broadcast.
 *
 * The two generations speak different Modbus transports, so the generation decides the
 * [modbusType] stored on the device. The firmware reads that value as the *highest* rung of the
 * ladder `tcp` > `dtls_udp` > `udp` and walks down until a transport answers — it never walks up.
 * Sending [Kit20] a `udp` value can therefore never work, while [WifiKit] genuinely is `udp` and
 * not merely a conservative choice.
 */
internal enum class GoodweDongleGeneration(val key: String, val modbusType: String) {
    /** The original Wi-Fi kit, which answers with its own IP address, MAC and model. */
    WifiKit(key = "wifi_kit", modbusType = "udp"),

    /** The Kit-20 "cyber security" dongle, which answers with its serial and a `dtls_port` field. */
    Kit20(key = "kit_20", modbusType = "tcp"),
}

/**
 * The generation this device was classified as, or `null` when the broadcast reply matched no
 * known shape.
 *
 * A `null` means the reply was left deliberately unclassified rather than guessed at — the raw
 * text is preserved under [GoodweConfig.RESPONSE_PARAMETER] so it can be surfaced to the user.
 */
internal fun DiscoveredDevice.goodweGeneration(): GoodweDongleGeneration? =
    GoodweDongleGeneration.entries.firstOrNull { it.key == extraParameters[GoodweConfig.GENERATION_PARAMETER] }
