package energy.chargee.onboarding.goodwe.discovery

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.discovery.udpbroadcast.UdpBroadcastResponseParser
import energy.chargee.onboarding.goodwe.GoodweConfig

private const val KIT_20_ADDRESS_PREFIX = "dongle@"
private const val KIT_20_PORT_FIELD = "dtls_port"
private const val BUSY_SUFFIX = "@busy"

/**
 * Reads a Goodwe dongle's answer to the `WIFIKIT-214028-READ` broadcast.
 *
 * Both generations answer with three comma-separated fields, but they mean different things:
 *
 * ```
 * 192.168.1.50,AABBCCDDEEFF,Solar-WiFi123       // Wi-Fi kit: ip, mac, model
 * dongle@sn,dtls_port:8899,9010KETU123456       // Kit-20:    serial, port field, inverter serial
 * ```
 *
 * A Kit-20 reply carries no IP address of its own, so its address is taken from the datagram
 * source. The `dtls_port` field is only ever used to recognise the generation and to detect the
 * `@busy` marker — it is deliberately not read as a port number.
 *
 * `@busy` means another client (SolarGo, or a Chargee device already polling it) holds the
 * dongle's session right now. That is a normal state and not a failure: it proves local
 * communication is switched on.
 *
 * A reply matching neither shape is still reported, carrying only its raw text under
 * [GoodweConfig.RESPONSE_PARAMETER], so the flow can show it rather than guess at it.
 */
internal object GoodweBroadcastParser : UdpBroadcastResponseParser {
    override fun parse(payload: String, sourceAddress: String): DiscoveredDevice {
        // Datagrams are zero-padded by some firmware revisions, so strip NULs before splitting.
        val parts =
            payload
                .trim()
                .trimEnd(Char(0))
                .trim()
                .split(",")
                .map { it.trim() }
        val portField = parts.getOrNull(1).orEmpty()

        return when {
            parts.first().startsWith(KIT_20_ADDRESS_PREFIX) || portField.startsWith(KIT_20_PORT_FIELD) -> {
                DiscoveredDevice(
                    // The Kit-20 reply has no address field of its own.
                    ipAddress = sourceAddress,
                    extraParameters =
                        buildMap {
                            put(GoodweConfig.GENERATION_PARAMETER, GoodweDongleGeneration.Kit20.key)
                            parts.getOrNull(2)?.takeIf { it.isNotEmpty() }?.let { put(GoodweConfig.SERIAL_PARAMETER, it) }
                            if (portField.endsWith(BUSY_SUFFIX)) put(GoodweConfig.BUSY_PARAMETER, true.toString())
                        },
                )
            }

            parts.size >= 3 && parts.first().isNotEmpty() -> {
                DiscoveredDevice(
                    // Unchanged from before the Kit-20 existed: the Wi-Fi kit reports its own address.
                    ipAddress = parts.first(),
                    extraParameters =
                        buildMap {
                            put(GoodweConfig.GENERATION_PARAMETER, GoodweDongleGeneration.WifiKit.key)
                            parts[2].takeIf { it.isNotEmpty() }?.let { put(GoodweConfig.MODEL_PARAMETER, it) }
                        },
                )
            }

            else -> {
                DiscoveredDevice(
                    ipAddress = sourceAddress,
                    extraParameters = mapOf(GoodweConfig.RESPONSE_PARAMETER to payload.trim()),
                )
            }
        }
    }
}
