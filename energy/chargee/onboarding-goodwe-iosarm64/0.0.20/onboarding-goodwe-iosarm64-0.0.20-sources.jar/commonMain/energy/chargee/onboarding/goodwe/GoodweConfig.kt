package energy.chargee.onboarding.goodwe

import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/**
 * Goodwe-specific constants shared across the flow, module, and discovery wiring.
 */
object GoodweConfig {
    /** Brand identifier used as the Goodwe onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "goodwe"

    /** UDP port the Goodwe Wi-Fi/LAN dongle listens on for the discovery broadcast. */
    const val BROADCAST_PORT = 48899

    /**
     * Magic payload the dongle answers with a datagram identifying itself. Sent by the
     * UDP-broadcast [energy.chargee.discovery.core.DeviceDiscovery] the Goodwe DI module registers
     * under [BRAND], and read back by [GoodweBroadcastParser] — what the reply's fields mean
     * depends on which dongle generation sent it.
     */
    const val BROADCAST_MESSAGE = "WIFIKIT-214028-READ"

    /**
     * How long the broadcast discovery listens for replies before completing. Several dongles can
     * answer one broadcast, so the window is a collection period rather than a deadline for the
     * first reply.
     */
    val DISCOVERY_TIMEOUT = 10.seconds

    /**
     * How long to leave the dongle alone after its switches are written before looking for it on
     * the network.
     *
     * The switches take effect on their own write and nothing restarts, so this is a settling
     * period rather than a wait for a boot. The value dates from when the flow did restart the
     * module and has not been re-tuned since; it costs a one-off delay before the first poll and
     * nothing else, so it errs long.
     */
    val SETTLE_DELAY = 15.seconds

    /** How long to wait between readiness checks once the first one has not found the dongle. */
    val READINESS_POLL_INTERVAL = 5.seconds

    /** How many times to look for the dongle after enabling local communication before giving up. */
    const val READINESS_ATTEMPTS = 6

    /**
     * Ceiling on the whole switch-on-and-wait step, enforced by the engine. The step paces itself
     * with [SETTLE_DELAY] and [READINESS_ATTEMPTS]; this only stops a dongle that answers
     * discovery slowly from holding the flow open indefinitely.
     */
    val LOCAL_COMMUNICATION_TIMEOUT = 3.minutes

    /**
     * `extraParameters` key naming the dongle generation that answered, as a
     * [GoodweDongleGeneration] key. Absent when the reply matched no known shape.
     */
    const val GENERATION_PARAMETER = "generation"

    /** `extraParameters` key carrying the dongle model. Only the original Wi-Fi kit reports one. */
    const val MODEL_PARAMETER = "model"

    /** `extraParameters` key carrying the inverter serial number. Only the Kit-20 reports one. */
    const val SERIAL_PARAMETER = "serial"

    /**
     * `extraParameters` key present and set to `"true"` when the dongle reported that another
     * client holds its session. It confirms local communication is on rather than signalling an error.
     */
    const val BUSY_PARAMETER = "busy"

    /**
     * `extraParameters` key carrying the raw reply of a dongle whose answer matched no known
     * shape, so the flow can surface the text instead of guessing at it.
     */
    const val RESPONSE_PARAMETER = "response"
}
