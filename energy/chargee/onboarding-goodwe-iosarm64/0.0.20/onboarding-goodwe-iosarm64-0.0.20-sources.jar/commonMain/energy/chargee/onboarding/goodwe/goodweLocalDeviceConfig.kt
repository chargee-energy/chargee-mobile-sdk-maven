package energy.chargee.onboarding.goodwe

import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.onboarding.goodwe.GoodweConfig.BRAND
import energy.chargee.onboarding.goodwe.discovery.goodweGeneration
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig

/**
 * Builds the protocol settings stored for the discovered dongle.
 *
 * `modbus_type` comes from the dongle generation rather than being assumed — see
 * [GoodweDongleGeneration] for why the value is a ceiling the firmware walks down from, and why
 * sending the wrong one leaves the inverter unreachable. The field is always sent: the firmware
 * falls back to `rs485` when it is missing, which is wrong for every Wi-Fi dongle.
 */
internal fun goodweConfigFields(context: GoodweOnboardingContext): List<LocalDeviceConfigField> {
    val device =
        requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }
    val generation =
        requireNotNull(device.goodweGeneration()) { "selectedDevice must be a recognised Goodwe dongle before RegisterDeviceStep runs" }

    return listOf(
        LocalDeviceConfigField("modbus_type", generation.modbusType),
        LocalDeviceConfigField("ip", device.ipAddress),
        LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
    )
}

/**
 * Wraps [fields] into the full configuration stored for the inverter.
 *
 * A model is only reported by the original Wi-Fi kit. The Kit-20's third reply field is the
 * inverter's serial number, which must not be stored as a model, so it is left `null` unless the
 * caller seeded one on the context.
 */
internal fun goodweLocalDeviceConfig(context: GoodweOnboardingContext, fields: List<LocalDeviceConfigField>) =
    LocalDeviceConfig(
        type = LocalDeviceType.Inverter,
        connectionType = "goodwe_udp",
        deviceType = BRAND,
        brand = BRAND,
        model = context.model ?: context.selectedDevice?.extraParameters?.get(GoodweConfig.MODEL_PARAMETER),
        config = fields,
    )
