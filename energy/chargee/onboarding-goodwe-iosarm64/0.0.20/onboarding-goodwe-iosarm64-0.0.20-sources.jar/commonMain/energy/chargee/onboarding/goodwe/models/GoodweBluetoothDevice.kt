package energy.chargee.onboarding.goodwe.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * A Goodwe dongle found over Bluetooth, offered to the user when more than one is in range.
 *
 * [id] identifies the dongle only for the current scan and is not meaningful to a person — show
 * [name], and [signalStrength] (RSSI in dBm, closer to zero being nearer) when two dongles are
 * named alike and the user has to tell them apart by which one they are standing next to.
 *
 * The `_` prefix on the Objective-C name leaves the clean `GoodweBluetoothDevice` free for the
 * generated Swift facade.
 */
@Serializable
@ObjCName("_GoodweBluetoothDevice")
data class GoodweBluetoothDevice(val id: String, val name: String, val signalStrength: Int)
