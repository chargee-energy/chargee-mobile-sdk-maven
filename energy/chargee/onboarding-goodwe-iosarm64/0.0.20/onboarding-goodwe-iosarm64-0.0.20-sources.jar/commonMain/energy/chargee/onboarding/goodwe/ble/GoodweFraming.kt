package energy.chargee.onboarding.goodwe.ble

import energy.chargee.onboarding.localdevice.modbus.buildByteArray

/**
 * The two frame families a Goodwe dongle speaks over Bluetooth, and the two different trailers
 * that make them easy to confuse.
 *
 * Modbus RTU frames carry a CRC-16/Modbus appended **low byte first**, while AA55 frames carry a
 * plain 16-bit additive sum of every preceding byte, big-endian. Getting the two the wrong way
 * round produces frames the dongle silently ignores, which is why both are covered by golden
 * vectors in `GoodweFramingTest`.
 */
internal object GoodweFraming {
    /** Modbus slave address of the communication module — the dongle itself. */
    const val DONGLE_SLAVE = 0xFA

    private const val READ_HOLDING_REGISTERS = 0x03
    private const val WRITE_SINGLE_REGISTER = 0x06
    private const val WRITE_MULTIPLE_REGISTERS = 0x10

    private const val AA55_HEADER_SIZE = 7
    private const val AA55_LENGTH_INDEX = 6

    /**
     * Preamble the dongle puts in front of a Modbus reply on the Bluetooth link.
     *
     * The same two bytes that open an AA55 frame, but here they are only a marker: what follows is
     * an ordinary Modbus RTU frame, CRC and all, and the CRC does not cover them. A reply has to be
     * read past them or neither its checksum nor its function code lands where it is expected.
     */
    private val MODBUS_REPLY_PREAMBLE = byteArrayOf(0xAA.toByte(), 0x55.toByte())

    /**
     * Function codes a dongle echoes back in byte 3 of a reply it accepted.
     *
     * Wider than the one code this flow sends: a dongle that answers a read or a single-register
     * write has still accepted it, and reading the echo rather than the request keeps that true.
     */
    private val ACCEPTED_FUNCTION_CODES = setOf(READ_HOLDING_REGISTERS, WRITE_SINGLE_REGISTER, WRITE_MULTIPLE_REGISTERS)

    /**
     * Builds a multiple-register write of [values] starting at [register] on [slave].
     *
     * This is the form the dongle's own settings use even for a single register, so the byte count
     * and register count are always written out rather than collapsed into a single-register write.
     */
    fun writeRegisters(slave: Int, register: Int, vararg values: Int): ByteArray =
        buildByteArray {
            uint8(slave)
            uint8(WRITE_MULTIPLE_REGISTERS)
            uint16(register)
            uint16(values.size)
            uint8(values.size * 2)
            values.forEach { uint16(it) }
        }.withModbusCrc()

    /**
     * Builds an AA55 frame for [control] and [function] carrying [data].
     *
     * The app is always the source (`0xC0`) and the module the destination (`0x7F`).
     */
    fun aa55(control: Int, function: Int, data: ByteArray = ByteArray(0)): ByteArray =
        buildByteArray {
            uint8(0xAA)
            uint8(0x55)
            uint8(0xC0)
            uint8(0x7F)
            uint8(control)
            uint8(function)
            uint8(data.size)
            byteArray(data)
        }.withAdditiveSum()

    /**
     * Whether [reply] is a complete Modbus RTU frame — long enough to hold a trailer, and ending
     * in a CRC that matches the rest.
     *
     * This is what terminates reassembly rather than a predicted length: the dongle's own expected
     * length heuristic is two bytes longer than standard Modbus RTU and goes unexplained, so it is
     * only safe as an upper bound.
     */
    fun isCompleteModbusReply(reply: ByteArray): Boolean {
        val frame = modbusFrame(reply)
        if (frame.size < 5) return false
        val crc = frame.copyOfRange(0, frame.size - 2).modbusCrc16()
        return frame[frame.size - 2] == (crc and 0xFF).toByte() && frame[frame.size - 1] == ((crc shr 8) and 0xFF).toByte()
    }

    /**
     * [reply] without the [MODBUS_REPLY_PREAMBLE], when it carries one.
     *
     * Stripping is unambiguous here: every frame this flow sends is addressed to [DONGLE_SLAVE],
     * so a reply can never legitimately begin `AA 55` of its own accord.
     */
    private fun modbusFrame(reply: ByteArray): ByteArray =
        if (reply.size >= MODBUS_REPLY_PREAMBLE.size &&
            reply[0] == MODBUS_REPLY_PREAMBLE[0] &&
            reply[1] == MODBUS_REPLY_PREAMBLE[1]
        ) {
            reply.copyOfRange(MODBUS_REPLY_PREAMBLE.size, reply.size)
        } else {
            reply
        }

    /**
     * Whether [reply] is a complete AA55 frame, judged by the length byte in its header plus the
     * two trailer bytes.
     */
    fun isCompleteAa55Reply(reply: ByteArray): Boolean {
        if (reply.size < AA55_HEADER_SIZE + 2) return false
        if (reply[0] != 0xAA.toByte() || reply[1] != 0x55.toByte()) return false
        return reply.size >= AA55_HEADER_SIZE + (reply[AA55_LENGTH_INDEX].toInt() and 0xFF) + 2
    }

    /**
     * The data region of an AA55 [reply], or an empty array when the frame carries none.
     */
    fun aa55Data(reply: ByteArray): ByteArray {
        if (!isCompleteAa55Reply(reply)) return ByteArray(0)
        val length = reply[AA55_LENGTH_INDEX].toInt() and 0xFF
        return reply.copyOfRange(AA55_HEADER_SIZE, AA55_HEADER_SIZE + length)
    }

    /**
     * Whether [reply] is the dongle accepting a request rather than reporting an exception.
     *
     * A Modbus exception reply sets the high bit of the function code, so an echo of the original
     * code is the acknowledgement.
     */
    fun isAccepted(reply: ByteArray): Boolean =
        modbusFrame(reply).let { frame -> frame.size > 1 && (frame[1].toInt() and 0xFF) in ACCEPTED_FUNCTION_CODES }
}

/**
 * CRC-16/Modbus over the whole array: reflected polynomial `0xA001`, seeded with `0xFFFF`.
 */
internal fun ByteArray.modbusCrc16(): Int {
    var crc = 0xFFFF
    for (byte in this) {
        crc = crc xor (byte.toInt() and 0xFF)
        repeat(8) {
            crc = if (crc and 1 != 0) (crc shr 1) xor 0xA001 else crc shr 1
        }
    }
    return crc and 0xFFFF
}

/** This frame with its CRC-16/Modbus appended low byte first, as Modbus RTU requires. */
internal fun ByteArray.withModbusCrc(): ByteArray {
    val crc = modbusCrc16()
    return this + (crc and 0xFF).toByte() + ((crc shr 8) and 0xFF).toByte()
}

/** This frame with a big-endian 16-bit additive sum of its bytes appended, as AA55 requires. */
internal fun ByteArray.withAdditiveSum(): ByteArray {
    val sum = fold(0) { total, byte -> total + (byte.toInt() and 0xFF) } and 0xFFFF
    return this + ((sum shr 8) and 0xFF).toByte() + (sum and 0xFF).toByte()
}
