package energy.chargee.onboarding.goodwe

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.goodwe.models.GoodweBluetoothDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext

/**
 * The mutable context that flows through the Goodwe onboarding steps.
 *
 * Beyond the base fields, it carries what the Bluetooth fallback needs. That branch only runs when
 * the dongle did not answer the discovery broadcast, so on the common path every Bluetooth field
 * stays at its default.
 *
 * [bluetoothDevices] is the result of the last scan, kept so that re-entering the step after the
 * user answers a prompt does not scan again. [selectedBluetoothDevice] is the dongle the user
 * picked, or the only one found. [bluetoothPassword] is `null` until the user supplies one — the
 * flow has no factory default to fall back on, and must not guess at passwords because the module
 * locks itself after repeated failures.
 */
data class GoodweOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    val bluetoothDevices: List<GoodweBluetoothDevice> = emptyList(),
    val selectedBluetoothDevice: GoodweBluetoothDevice? = null,
    val bluetoothPassword: String? = null,
) : LocalDeviceOnboardingContext<GoodweOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
