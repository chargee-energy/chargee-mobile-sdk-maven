package energy.chargee.onboarding.goodwe

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * The [SerializersModule] registering the [GoodweErrorCode] cases as polymorphic subtypes of the
 * open [OnboardingErrorCode].
 *
 * Each concrete case is registered directly rather than the sealed interface as a whole, for the
 * same reason as the shared local-device codes: kotlinx.serialization rejects a sealed serializer
 * as a `subclass` of another polymorphic base. A new case must be added here to be serializable.
 */
val goodweErrorCodeSerializersModule: SerializersModule =
    SerializersModule {
        polymorphic(OnboardingErrorCode::class) {
            subclass(GoodweErrorCode.NoDongleFound::class)
            subclass(GoodweErrorCode.BluetoothFailure::class)
            subclass(GoodweErrorCode.UnrecognisedDongleResponse::class)
            subclass(GoodweErrorCode.DongleNotReachable::class)
            subclass(GoodweErrorCode.DongleLocked::class)
        }
    }
