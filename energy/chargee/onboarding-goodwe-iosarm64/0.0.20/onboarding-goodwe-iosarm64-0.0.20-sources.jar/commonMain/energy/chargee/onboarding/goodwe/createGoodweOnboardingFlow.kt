package energy.chargee.onboarding.goodwe

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.goodwe.GoodweConfig.BRAND
import energy.chargee.onboarding.goodwe.ble.GoodweBleClient
import energy.chargee.onboarding.goodwe.discovery.goodweGeneration
import energy.chargee.onboarding.goodwe.steps.ConnectBluetoothStep
import energy.chargee.onboarding.goodwe.steps.EnableLocalCommunicationStep
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyInverterStep

/**
 * Builds the onboarding flow for a Goodwe inverter behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Discover the Goodwe dongle via [goodweDiscovery] (UDP broadcast) and classify which
 *    generation answered — the reply decides the Modbus transport stored for the device.
 * 3. If nothing answered, or answered in a shape we cannot classify, reach the dongle over
 *    Bluetooth with [goodweBleClient], switch local communication on, and look for it again.
 * 4. Register the discovered inverter through [localDeviceRepository].
 * 5. Poll [inverterRepository] until the Chargee device reports readings from the inverter,
 *    confirming end-to-end connectivity.
 *
 * The Bluetooth branch exists because a Kit-20 dongle ships with local communication switched
 * off, so it stays silent on the network until something turns it on. The original Wi-Fi kit
 * answers the broadcast out of the box and never enters that branch.
 *
 * When the context is seeded with a `deviceUuid` the flow resets that already-registered inverter
 * instead: it rediscovers the dongle and updates the stored configuration with what it finds rather
 * than creating a second registration.
 */
internal fun createGoodweOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    goodweDiscovery: DeviceDiscovery,
    goodweBleClient: GoodweBleClient,
    localDeviceRepository: LocalDeviceRepository,
    inverterRepository: InverterRepository,
) = createOnboardingFlow<LocalDeviceStepId, GoodweOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    discoverDeviceStep(continueWhenEmpty = true) { goodweDiscovery }
    whenFalse(condition = { it.selectedDevice?.goodweGeneration() != null }) {
        step(
            ConnectBluetoothStep(goodweBleClient),
            retryPolicy =
                ExponentialBackoffRetry(
                    maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                    // Only a flaky link is worth retrying. A rejected password must go back to the
                    // user, because the module locks itself after repeated failed logins.
                    condition = { it is GoodweErrorCode.BluetoothFailure },
                ),
        )
        step(
            EnableLocalCommunicationStep(goodweBleClient) { goodweDiscovery },
            timeout = GoodweConfig.LOCAL_COMMUNICATION_TIMEOUT,
        )
    }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = ::goodweLocalDeviceConfig,
        createConfigFields = ::goodweConfigFields,
    )
    verifyInverterStep(addressUuid, inverterRepository)
}
