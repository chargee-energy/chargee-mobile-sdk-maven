package energy.chargee.onboarding.goodwe

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.goodwe.models.GoodweBluetoothDevice
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the Goodwe inverter onboarding flow — the [Retry] and [SetDevice] cases every
 * local-device flow shares, plus the two the Bluetooth fallback needs. A flat, sealed hierarchy
 * whose cases the [GoodweOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_GoodweInput")
@Serializable
sealed interface GoodweInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : GoodweInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : GoodweInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : GoodweInput

    /**
     * Selects the [device] to configure over Bluetooth from those found in range. Accepted while
     * the flow is waiting for a Bluetooth device to be chosen.
     */
    @Serializable
    data class SetBluetoothDevice(val device: GoodweBluetoothDevice) : GoodweInput

    /**
     * Supplies the [password] the dongle asked for. Accepted both while the flow is waiting for a
     * password and after the dongle rejected one.
     */
    @Serializable
    data class SetBluetoothPassword(val password: String) : GoodweInput
}
