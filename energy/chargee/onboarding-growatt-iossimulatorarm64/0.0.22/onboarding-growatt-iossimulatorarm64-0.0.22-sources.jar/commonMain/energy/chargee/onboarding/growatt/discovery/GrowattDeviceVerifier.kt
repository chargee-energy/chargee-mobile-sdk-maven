package energy.chargee.onboarding.growatt.discovery

import energy.chargee.discovery.core.DeviceVerifier
import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.growatt.GrowattConfig

/**
 * The [DeviceVerifier] that turns a host with port 502 open into a confirmed Growatt inverter,
 * or discards it.
 *
 * Growatt inverters advertise nothing, so discovery can only scan the subnet for the Modbus port
 * — which on a home network is just as likely to be another vendor's inverter, a charger, or a
 * gateway. This asks each candidate who it is and keeps only the ones that answer like a Growatt,
 * carrying the serial, firmware, and device type code it learned into the device's
 * [DiscoveredDevice.extraParameters] so a user choosing between several has them labelled.
 *
 * [verifyDevice] is the probe itself, separated out so the mapping can be tested without a socket.
 */
internal class GrowattDeviceVerifier(
    private val verifyDevice: suspend (host: String, port: Int) -> GrowattVerification = ::verifyGrowattDevice,
) : DeviceVerifier {
    override suspend fun verify(device: DiscoveredDevice): DiscoveredDevice? {
        val port = device.port ?: GrowattConfig.DEFAULT_PORT

        return when (val verification = verifyDevice(device.ipAddress, port)) {
            is GrowattVerification.Verified -> {
                device.copy(
                    port = port,
                    extraParameters =
                        device.extraParameters +
                            mapOf(
                                GrowattConfig.SERIAL_PARAMETER to verification.serial,
                                GrowattConfig.FIRMWARE_PARAMETER to verification.firmware,
                                GrowattConfig.DEVICE_TYPE_CODE_PARAMETER to verification.deviceTypeCode.toString(),
                            ),
                )
            }

            is GrowattVerification.Rejected, GrowattVerification.Unreachable -> {
                null
            }
        }
    }
}
