package energy.chargee.onboarding.growatt

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for Growatt inverters. Routes [GrowattInput] — device selection, rescanning,
 * and retry — and surfaces [GrowattStep]s in its typed state.
 */
@OnboardingSession
class GrowattOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, GrowattOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, GrowattOnboardingContext, GrowattStep, GrowattInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered inverter: instead of registering a new inverter
     * the flow updates the stored configuration with the rediscovered values before re-verifying.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [GrowattStep]s: a started step becomes
     * [GrowattStep.Running]; a pause on discovery becomes [GrowattStep.AwaitingDevice] carrying
     * the inverters found; and a failure the engine has stopped retrying becomes
     * [GrowattStep.Failure] with a retry callback. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, GrowattStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, GrowattOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, GrowattStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = GrowattStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                if (event.willRetry) {
                    super.reduce(current, event)
                } else {
                    current.copy(
                        currentStep =
                            GrowattStep.Failure(
                                event.stepId,
                                error = event.errorCode,
                                deviceUuid = event.context.deviceUuid,
                            ) {
                                submit(GrowattInput.Retry)
                            },
                    )
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                GrowattStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(GrowattInput.SetDevice(it)) },
                                    rescan = { submit(GrowattInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [GrowattInput]: [Retry][GrowattInput.Retry] re-runs a failed step, and
     * [SetDevice][GrowattInput.SetDevice] and [RescanDevices][GrowattInput.RescanDevices] select
     * an inverter or scan again while the flow waits on discovery.
     */
    override fun submit(input: GrowattInput): SubmitResult =
        when (input) {
            GrowattInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is GrowattInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            GrowattInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }
        }
}
