package energy.chargee.onboarding.growatt.discovery

import energy.chargee.onboarding.localdevice.modbus.Uint16

/**
 * The single Modbus operation [verifyGrowattIdentity] needs, narrowed to a function so the
 * identity checks can be driven without a socket.
 *
 * Backed in production by [energy.chargee.onboarding.localdevice.modbus.ModbusConnection], whose
 * contract it inherits: a Modbus exception response or malformed framing throws
 * [IllegalStateException], and a peer that never answers throws
 * [energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException].
 */
internal fun interface GrowattRegisterReader {
    suspend fun readHoldingRegisters(address: Uint16, quantity: Uint16): Array<Uint16>
}
