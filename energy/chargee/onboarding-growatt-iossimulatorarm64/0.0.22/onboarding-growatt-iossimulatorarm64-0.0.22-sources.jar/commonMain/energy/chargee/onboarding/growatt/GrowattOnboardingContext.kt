package energy.chargee.onboarding.growatt

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext

/**
 * The mutable context that flows through the Growatt onboarding steps.
 *
 * It adds no fields of its own: a Growatt inverter needs no configuring before it can be
 * registered, so the flow only ever carries the shared [LocalDeviceOnboardingContext] state. What
 * the discovery learned about the chosen inverter — its serial, firmware, and device type code —
 * travels on [selectedDevice]'s [DiscoveredDevice.extraParameters] rather than as separate fields,
 * because the discovery is what put it there.
 */
data class GrowattOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
) : LocalDeviceOnboardingContext<GrowattOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
