package energy.chargee.onboarding.growatt

import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * Growatt-specific constants shared across the flow, module, and discovery wiring.
 */
object GrowattConfig {
    /** Brand identifier used as the Growatt onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "growatt"

    /**
     * Modbus TCP port Growatt inverters expose on the customer's network, and the only thing that
     * marks them out before anything speaks to them: they announce no service, so the Growatt DI
     * module scans the subnet for this port and verifies each host that accepts a connection.
     */
    const val DEFAULT_PORT = 502

    /** Modbus unit identifier the inverter answers on, stored as the registered device's `address`. */
    const val MODBUS_ADDRESS = 1

    /**
     * How long to wait for the TCP connection during verification.
     *
     * Shorter than the Modbus client's own default because the host is already known to accept
     * connections on [DEFAULT_PORT] — the scan just proved it — so a connection that now takes
     * seconds is a dying link rather than a slow one, and every candidate waits in turn.
     */
    val VERIFICATION_CONNECT_TIMEOUT: Duration = 2.seconds

    /** How long to wait for the inverter to answer each identity read before giving up on it. */
    val VERIFICATION_RESPONSE_TIMEOUT: Duration = 2.seconds

    /**
     * How many times an unanswered identity read is resent before the candidate counts as
     * unreachable. Counts the initial attempt, so `2` means one retry — enough to ride out a
     * dropped frame on Wi-Fi without stretching the scan across every host that is not an inverter.
     */
    const val VERIFICATION_MAX_ATTEMPTS = 2

    /** `extraParameters` key carrying the inverter serial number read during verification. */
    const val SERIAL_PARAMETER = "serial"

    /** `extraParameters` key carrying the inverter firmware version read during verification. */
    const val FIRMWARE_PARAMETER = "firmware"

    /**
     * `extraParameters` key carrying the inverter device type code read during verification, as a
     * decimal string. Growatt publishes no table mapping it to a product name, so it is surfaced
     * raw rather than resolved to a model.
     */
    const val DEVICE_TYPE_CODE_PARAMETER = "device_type_code"
}
