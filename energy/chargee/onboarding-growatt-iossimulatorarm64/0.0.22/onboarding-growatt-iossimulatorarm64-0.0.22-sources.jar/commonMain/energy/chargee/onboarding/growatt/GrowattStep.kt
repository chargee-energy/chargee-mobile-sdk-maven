package energy.chargee.onboarding.growatt

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [GrowattOnboardingSession] surfaces through its typed state,
 * each carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_GrowattStep")
@Serializable
sealed interface GrowattStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        GrowattStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : GrowattStep

    /**
     * The flow is waiting for the user to pick which inverter to onboard from [possibleDevices],
     * or is reporting that the scan found none — the same step covers both, with an empty
     * [possibleDevices] for the second. Call [setDevice] with the chosen inverter, or [rescan] to
     * scan again.
     *
     * Each device carries the serial, firmware, and device type code read from it during
     * discovery in its [DiscoveredDevice.extraParameters]; see
     * [GrowattConfig.SERIAL_PARAMETER] and its neighbours for the keys.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : GrowattStep
}
