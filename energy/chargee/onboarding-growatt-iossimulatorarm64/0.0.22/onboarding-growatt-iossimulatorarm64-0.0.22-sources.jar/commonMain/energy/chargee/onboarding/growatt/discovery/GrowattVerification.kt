package energy.chargee.onboarding.growatt.discovery

/**
 * The outcome of reading a candidate's identity block over Modbus.
 *
 * [Unreachable] and [Rejected] are kept apart deliberately. A scan that finds an open port has
 * only proved that something is listening there, and the two say different things about what: one
 * host stopped answering mid-probe, the other answered and is not a Growatt inverter. Both are
 * dropped from discovery, but only the second is a settled fact about the device.
 */
internal sealed interface GrowattVerification {
    /** The device answered and every identity field passed. */
    data class Verified(val serial: String, val firmware: String, val deviceTypeCode: Int) : GrowattVerification

    /** Something spoke Modbus, but it did not look like a Growatt inverter. [reason] says what failed. */
    data class Rejected(val reason: String) : GrowattVerification

    /** Nothing answered at the address — wrong host, wrong port, or the device went away mid-probe. */
    data object Unreachable : GrowattVerification
}
