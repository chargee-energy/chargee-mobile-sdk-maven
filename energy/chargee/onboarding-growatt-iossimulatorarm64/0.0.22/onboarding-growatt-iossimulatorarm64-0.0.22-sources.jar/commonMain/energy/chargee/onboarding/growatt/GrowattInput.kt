package energy.chargee.onboarding.growatt

import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the Growatt inverter onboarding flow. A flat, sealed hierarchy whose cases the
 * [GrowattOnboardingSession] routes; each documents when it is accepted.
 *
 * Shorter than the other brands' by one case: a Growatt inverter is registered as it is found, so
 * the flow never stops to ask for a password.
 */
@ObjCName("_GrowattInput")
@Serializable
sealed interface GrowattInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : GrowattInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : GrowattInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : GrowattInput
}
