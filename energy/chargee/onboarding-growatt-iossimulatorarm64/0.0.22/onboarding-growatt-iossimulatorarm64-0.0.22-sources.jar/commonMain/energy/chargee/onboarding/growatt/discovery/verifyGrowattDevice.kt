package energy.chargee.onboarding.growatt.discovery

import energy.chargee.onboarding.growatt.GrowattConfig
import energy.chargee.onboarding.localdevice.modbus.ModbusClient
import energy.chargee.onboarding.localdevice.modbus.uint8
import kotlin.coroutines.cancellation.CancellationException

/**
 * Opens a Modbus connection to [host]:[port] and runs the identity checks of
 * [verifyGrowattIdentity] over it, reporting [GrowattVerification.Unreachable] when the device
 * cannot be reached or stops answering.
 *
 * Both identity reads share the one connection, which is also what bounds the probe: the timeouts
 * and attempt count come from [GrowattConfig] rather than the Modbus client's defaults, because
 * this runs once per host a subnet scan turned up and each of them waits in turn.
 */
internal suspend fun verifyGrowattDevice(host: String, port: Int = GrowattConfig.DEFAULT_PORT): GrowattVerification =
    try {
        ModbusClient(
            host = host,
            port = port,
            unitId = GrowattConfig.MODBUS_ADDRESS.uint8,
            responseTimeout = GrowattConfig.VERIFICATION_RESPONSE_TIMEOUT,
            maxAttempts = GrowattConfig.VERIFICATION_MAX_ATTEMPTS,
            connectTimeout = GrowattConfig.VERIFICATION_CONNECT_TIMEOUT,
        ).connect {
            verifyGrowattIdentity { address, quantity -> readHoldingRegisters(address, quantity) }
        }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (_: Exception) {
        // A refused or timed-out connection, or a peer that went quiet part-way through the reads.
        GrowattVerification.Unreachable
    }
