package energy.chargee.onboarding.growatt

import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.onboarding.growatt.GrowattConfig.BRAND
import energy.chargee.onboarding.growatt.GrowattConfig.DEFAULT_PORT
import energy.chargee.onboarding.growatt.GrowattConfig.MODBUS_ADDRESS
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig

/**
 * Builds the protocol settings stored for the discovered inverter.
 *
 * Every value is either fixed for the brand or came from the discovery: the inverter is reached
 * over Modbus TCP at the address it was found on, on the port the scan found open — falling back
 * to [GrowattConfig.DEFAULT_PORT] only for a device discovered without one, which a port scan
 * never produces.
 */
internal fun growattConfigFields(context: GrowattOnboardingContext): List<LocalDeviceConfigField> {
    val device =
        requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }

    return listOf(
        LocalDeviceConfigField("modbus_type", "tcp"),
        LocalDeviceConfigField("address", MODBUS_ADDRESS),
        LocalDeviceConfigField("ip", device.ipAddress),
        LocalDeviceConfigField("port", device.port ?: DEFAULT_PORT),
        LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
    )
}

/**
 * Wraps [fields] into the full configuration stored for the inverter.
 *
 * The model is left to whatever the caller seeded on the context. Verification does read a device
 * type code off the inverter, but Growatt publishes no mapping from it to a product name, so
 * storing it as a model would be storing a number where a name belongs — it travels on the
 * discovered device's `extraParameters` instead.
 */
internal fun growattLocalDeviceConfig(context: GrowattOnboardingContext, fields: List<LocalDeviceConfigField>) =
    LocalDeviceConfig(
        type = LocalDeviceType.Inverter,
        connectionType = "growatt_tcp",
        deviceType = BRAND,
        brand = BRAND,
        model = context.model,
        config = fields,
    )
