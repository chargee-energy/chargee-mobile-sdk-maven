package energy.chargee.onboarding.growatt.discovery

import energy.chargee.onboarding.localdevice.modbus.Uint16
import energy.chargee.onboarding.localdevice.modbus.decodeToString
import energy.chargee.onboarding.localdevice.modbus.uint16

/**
 * The identity block: holding registers `0..124` cover the firmware, serial, and device type
 * code in a single read. 125 is the most registers one Modbus read may return.
 */
private val IDENTITY_ADDRESS = 0.uint16
private val IDENTITY_QUANTITY = 125.uint16

/** Device type code. Non-zero on a device that has finished booting; 0 means "not a Growatt". */
private const val DEVICE_TYPE_CODE_REGISTER = 43

/** Firmware version, as ASCII, two characters per register. */
private val FIRMWARE_REGISTERS = 9..11

/** Serial number on most models, as ASCII. Left blank on the ones that use [FALLBACK_SERIAL_ADDRESS]. */
private val SERIAL_REGISTERS = 23..27

/** Serial number on models that leave [SERIAL_REGISTERS] blank. Outside the identity block. */
private val FALLBACK_SERIAL_ADDRESS = 3001.uint16
private val FALLBACK_SERIAL_QUANTITY = 15.uint16

/**
 * Decides whether whatever [reader] is talking to is a Growatt inverter, by reading its identity
 * block and checking each field is shaped the way an inverter reports it.
 *
 * Nothing in the Modbus protocol identifies a vendor, so the check is the combination: the
 * identity block is readable at all, the device type code is set, and the firmware and serial
 * decode as text rather than as whatever happens to sit at those addresses on another device.
 * A host that answers all of that is reported [GrowattVerification.Verified] with the fields it
 * gave up; one that answers and fails any of them is [GrowattVerification.Rejected].
 *
 * A peer that stops answering is not caught here — [GrowattVerification.Unreachable] is the
 * caller's to report, since only it knows whether the connection itself got that far.
 *
 * @throws energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException if the device
 *   stops answering part-way through.
 */
internal suspend fun verifyGrowattIdentity(reader: GrowattRegisterReader): GrowattVerification {
    val identity =
        try {
            reader.readHoldingRegisters(IDENTITY_ADDRESS, IDENTITY_QUANTITY)
        } catch (_: IllegalStateException) {
            return GrowattVerification.Rejected("holding 0..124 is not readable")
        }

    val deviceTypeCode = identity[DEVICE_TYPE_CODE_REGISTER].value
    if (deviceTypeCode == 0) {
        return GrowattVerification.Rejected("device type code (holding 43) is 0")
    }

    val firmware = identity.sliceArray(FIRMWARE_REGISTERS).text()
    if (firmware == null || !firmware.isPrintableAscii()) {
        return GrowattVerification.Rejected("firmware (holding 9..11) is not printable ASCII: $firmware")
    }

    val serial = identity.sliceArray(SERIAL_REGISTERS).text() ?: reader.readFallbackSerial()
    if (serial == null || !serial.isAlphanumeric()) {
        return GrowattVerification.Rejected("serial is not alphanumeric: $serial")
    }

    return GrowattVerification.Verified(serial, firmware, deviceTypeCode)
}

/** Reads the serial from the secondary location, for models that leave [SERIAL_REGISTERS] blank. */
private suspend fun GrowattRegisterReader.readFallbackSerial(): String? =
    try {
        readHoldingRegisters(FALLBACK_SERIAL_ADDRESS, FALLBACK_SERIAL_QUANTITY).text()
    } catch (_: IllegalStateException) {
        // Models without this block answer with Modbus exception 0x02 rather than blanks.
        null
    }

/**
 * Decodes an ASCII field, treating a blank field as absent.
 *
 * [decodeToString] only strips trailing NULs, but Growatt pads these fields with spaces as well,
 * so an unset field comes back as `"     "` rather than as null.
 */
private fun Array<Uint16>.text(): String? = decodeToString()?.trim()?.takeIf { it.isNotEmpty() }

private fun String.isPrintableAscii() = all { it.code in 0x20..0x7E }

private fun String.isAlphanumeric() = all { it in '0'..'9' || it in 'a'..'z' || it in 'A'..'Z' }
