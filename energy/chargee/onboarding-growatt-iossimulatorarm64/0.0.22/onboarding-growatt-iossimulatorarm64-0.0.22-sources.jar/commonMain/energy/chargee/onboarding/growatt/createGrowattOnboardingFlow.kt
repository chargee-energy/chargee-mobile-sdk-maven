package energy.chargee.onboarding.growatt

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.growatt.GrowattConfig.BRAND
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyInverterStep

/**
 * Builds the onboarding flow for a Growatt inverter behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Discover the Growatt inverter via [growattDiscovery], which scans the subnet for hosts with
 *    Modbus TCP open and asks each of them for its identity block before reporting it.
 * 3. Register the discovered inverter through [localDeviceRepository].
 * 4. Poll [inverterRepository] until the Chargee device reports readings from the inverter,
 *    confirming end-to-end connectivity.
 *
 * The shortest of the brand flows, and deliberately so: a Growatt inverter serves Modbus TCP on
 * the customer's network out of the box, so there is nothing to switch on and no local AP to join
 * first. Everything the flow needs it learns by asking the inverter — which also means a reset
 * (a context seeded with a `deviceUuid`) runs exactly the same steps, with step 3 updating that
 * inverter's stored configuration rather than registering a second one.
 */
internal fun createGrowattOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    growattDiscovery: DeviceDiscovery,
    localDeviceRepository: LocalDeviceRepository,
    inverterRepository: InverterRepository,
) = createOnboardingFlow<LocalDeviceStepId, GrowattOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    discoverDeviceStep { growattDiscovery }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = ::growattLocalDeviceConfig,
        createConfigFields = ::growattConfigFields,
    )
    verifyInverterStep(addressUuid, inverterRepository)
}
