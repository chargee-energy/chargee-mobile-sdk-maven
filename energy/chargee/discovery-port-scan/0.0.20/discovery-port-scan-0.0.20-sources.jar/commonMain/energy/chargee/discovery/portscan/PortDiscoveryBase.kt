package energy.chargee.discovery.portscan

import energy.chargee.discovery.core.DeviceDiscovery
import io.ktor.network.selector.SelectorManager
import io.ktor.network.sockets.aSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration

internal abstract class PortDiscoveryBase(private val connectionTimeout: Duration) : DeviceDiscovery {
    protected suspend fun isPortOpen(ipAddress: String, port: Int): Boolean =
        withContext(Dispatchers.IO) {
            val selector = SelectorManager(Dispatchers.IO)
            try {
                withTimeoutOrNull(connectionTimeout) {
                    runCatching {
                        aSocket(selector).tcp().connect(ipAddress, port).close()
                    }.isSuccess
                } ?: false
            } finally {
                selector.close()
            }
        }
}
