package energy.chargee.discovery.portscan

import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.time.Duration

internal class OpenPortDiscovery(private val ipAddress: String, private val possiblePorts: List<Int>, connectionTimeout: Duration) :
    PortDiscoveryBase(connectionTimeout) {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            for (port in possiblePorts) {
                if (isPortOpen(ipAddress, port)) {
                    emit(DiscoveredDevice(ipAddress, port))
                }
            }
        }
}
