package energy.chargee.discovery.portscan

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import kotlin.time.Duration.Companion.milliseconds

val portScanDiscoveryModule =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE) { parameters ->
            PortScanDiscovery(
                localAddressProvider = get(),
                port = parameters.get(0),
                connectionTimeout = parameters.getOrNull(1) ?: 100.milliseconds,
            )
        }
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.OPEN_PORT_DISCOVERY_TYPE) { parameters ->
            OpenPortDiscovery(
                ipAddress = parameters.get(0),
                possiblePorts = parameters.get(1),
                connectionTimeout = parameters.getOrNull(2) ?: 100.milliseconds,
            )
        }
    }
