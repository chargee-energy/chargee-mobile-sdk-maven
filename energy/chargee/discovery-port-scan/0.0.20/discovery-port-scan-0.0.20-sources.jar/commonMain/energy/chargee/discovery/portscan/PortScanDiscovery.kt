package energy.chargee.discovery.portscan

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.hostAddresses
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.time.Duration

internal class PortScanDiscovery(
    private val localAddressProvider: LocalAddressProvider,
    private val port: Int,
    connectionTimeout: Duration,
) : PortDiscoveryBase(connectionTimeout) {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            val local = localAddressProvider.getLocalAddress() ?: return@flow
            for (ipAddress in local.hostAddresses()) {
                if (isPortOpen(ipAddress, port)) {
                    emit(DiscoveredDevice(ipAddress, port))
                }
            }
        }
}
