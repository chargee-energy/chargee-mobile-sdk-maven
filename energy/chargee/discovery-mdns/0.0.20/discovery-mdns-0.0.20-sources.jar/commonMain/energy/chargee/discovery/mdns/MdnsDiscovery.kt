package energy.chargee.discovery.mdns

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration

internal class MdnsDiscovery(private val platformDiscovery: DeviceDiscovery, private val timeout: Duration) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            withTimeoutOrNull(timeout) {
                platformDiscovery.discover().collect(::emit)
            }
        }
}
