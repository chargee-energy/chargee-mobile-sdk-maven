package energy.chargee.discovery.mdns

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import kotlin.time.Duration.Companion.seconds

val mdnsDiscoveryModuleIos =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.MDNS_DISCOVERY_TYPE) { parameters ->
            val timeout = parameters.getOrNull(1) ?: 5.seconds
            MdnsDiscovery(
                platformDiscovery = MdnsDiscoveryIos(serviceType = parameters.get(0), resolveTimeout = timeout),
                timeout,
            )
        }
    }
