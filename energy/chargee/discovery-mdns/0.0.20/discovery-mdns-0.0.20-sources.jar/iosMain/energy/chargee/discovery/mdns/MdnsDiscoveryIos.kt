package energy.chargee.discovery.mdns

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveredDevice
import kotlinx.cinterop.ByteVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.toKString
import kotlinx.cinterop.usePinned
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import platform.Foundation.NSData
import platform.Foundation.NSDefaultRunLoopMode
import platform.Foundation.NSNetService
import platform.Foundation.NSNetServiceBrowser
import platform.Foundation.NSNetServiceBrowserDelegateProtocol
import platform.Foundation.NSNetServiceDelegateProtocol
import platform.Foundation.NSRunLoop
import platform.darwin.NSObject
import platform.posix.NI_MAXHOST
import platform.posix.NI_NUMERICHOST
import platform.posix.getnameinfo
import platform.posix.memcpy
import platform.posix.sockaddr
import kotlin.time.Duration

@OptIn(ExperimentalForeignApi::class)
internal class MdnsDiscoveryIos(private val serviceType: String, private val resolveTimeout: Duration) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        callbackFlow {
            val pendingServices = mutableListOf<NSNetService>()

            val resolveDelegate =
                object : NSObject(), NSNetServiceDelegateProtocol {
                    override fun netServiceDidResolveAddress(sender: NSNetService) {
                        val host =
                            sender.addresses
                                ?.firstNotNullOfOrNull { (it as? NSData)?.let(::addressToString) }
                        if (host != null) {
                            val port = sender.port.toInt().takeIf { it > 0 }
                            val txt = sender.TXTRecordData()?.let(::parseTxtRecord).orEmpty()
                            trySend(DiscoveredDevice(host, port, txt))
                        }
                        pendingServices.remove(sender)
                    }

                    override fun netService(sender: NSNetService, didNotResolve: Map<Any?, *>) {
                        pendingServices.remove(sender)
                    }
                }

            val browserDelegate =
                object : NSObject(), NSNetServiceBrowserDelegateProtocol {
                    override fun netServiceBrowser(browser: NSNetServiceBrowser, didFindService: NSNetService, moreComing: Boolean) {
                        pendingServices.add(didFindService)
                        didFindService.delegate = resolveDelegate
                        didFindService.resolveWithTimeout(resolveTimeout.inWholeMilliseconds / 1000.0)
                    }
                }

            val browser = NSNetServiceBrowser()
            browser.delegate = browserDelegate
            browser.scheduleInRunLoop(NSRunLoop.mainRunLoop, NSDefaultRunLoopMode)
            browser.searchForServicesOfType(serviceType, "")

            awaitClose {
                browser.stop()
                pendingServices.forEach { it.stop() }
                pendingServices.clear()
            }
        }

    private fun parseTxtRecord(data: NSData): Map<String, String> {
        val length = data.length.toInt()
        if (length == 0) return emptyMap()
        val bytes = data.toByteArray()
        val result = mutableMapOf<String, String>()
        var i = 0
        while (i < length) {
            val entryLen = bytes[i].toInt() and 0xFF
            i++
            if (entryLen == 0 || i + entryLen > length) {
                i += entryLen
                continue
            }
            val entry = bytes.decodeToString(i, i + entryLen)
            val eq = entry.indexOf('=')
            when {
                eq > 0 -> result[entry.substring(0, eq)] = entry.substring(eq + 1)
                eq < 0 && entry.isNotEmpty() -> result[entry] = ""
            }
            i += entryLen
        }
        return result
    }

    private fun addressToString(data: NSData): String? =
        memScoped {
            val sockaddrPtr = data.bytes?.reinterpret<sockaddr>() ?: return@memScoped null
            val host = allocArray<ByteVar>(NI_MAXHOST)
            val rc =
                getnameinfo(
                    sockaddrPtr,
                    data.length.toUInt(),
                    host,
                    NI_MAXHOST.toUInt(),
                    null,
                    0u,
                    NI_NUMERICHOST,
                )
            if (rc == 0) host.toKString() else null
        }

    private fun NSData.toByteArray(): ByteArray {
        val size = length.toInt()
        if (size == 0) return ByteArray(0)
        val out = ByteArray(size)
        out.usePinned { pinned ->
            memcpy(pinned.addressOf(0), bytes, length)
        }
        return out
    }
}
