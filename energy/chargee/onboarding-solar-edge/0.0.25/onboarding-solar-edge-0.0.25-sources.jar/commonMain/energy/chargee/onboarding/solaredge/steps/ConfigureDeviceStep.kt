package energy.chargee.onboarding.solaredge.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.solaredge.SolarEdgeConfig.DEFAULT_PORT
import energy.chargee.onboarding.solaredge.SolarEdgeOnboardingContext
import energy.chargee.onboarding.solaredge.clients.SolarEdgeClient
import kotlin.coroutines.cancellation.CancellationException

internal class ConfigureDeviceStep(private val client: SolarEdgeClient) :
    OnboardingFlow.Step<LocalDeviceStepId, SolarEdgeOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: SolarEdgeOnboardingContext): Result<SolarEdgeOnboardingContext> {
        val config = client.getModbusTcpConfig()
        val port = config.port ?: DEFAULT_PORT

        if (config.enabled) {
            // Modbus TCP is already enabled, no need to enable it again.
            return Result.Success(context.copy(port = port))
        }

        // The client reports a refusal by throwing, so the cause can be carried on the failure.
        // That throwable is what tells a monitoring logger this is a defect worth raising rather
        // than one of the outcomes the flow expects — see the Logging section of the README.
        return try {
            client.enableModbusTcp(port)
            Result.Success(context.copy(port = port))
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (exception: Exception) {
            Result.Failure(context.copy(port = port), LocalDeviceErrorCode.DeviceConfigurationFailure(), exception)
        }
    }

    override suspend fun onFinished(context: SolarEdgeOnboardingContext) {
        client.disconnect()
    }
}
