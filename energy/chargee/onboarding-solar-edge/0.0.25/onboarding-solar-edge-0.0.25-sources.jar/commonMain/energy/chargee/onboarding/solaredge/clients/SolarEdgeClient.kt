package energy.chargee.onboarding.solaredge.clients

import energy.chargee.onboarding.solaredge.models.ModbusTcpConfig
import energy.chargee.utils.wifi.WifiConfiguration

/**
 * Client for talking to a SolarEdge inverter over its local access point.
 *
 * The onboarding flow joins the inverter's own Wi-Fi network and then issues HTTP calls to the
 * device to inspect and enable its Modbus TCP interface. Implementations own the Wi-Fi and
 * HTTP resources for the session; callers must invoke [disconnect] when done.
 */
interface SolarEdgeClient {
    /**
     * Joins the inverter's local Wi-Fi network using [wifiConfiguration]. Returns `true` when the
     * device is reachable over the joined network and `false` if the association or the follow-up
     * initialization failed.
     */
    suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean

    /**
     * Leaves the inverter's local Wi-Fi network and releases any HTTP resources held by the
     * client. Safe to call from step lifecycle hooks even when [connect] never succeeded.
     */
    suspend fun disconnect()

    /**
     * Enables Modbus TCP on the inverter, listening on [port], throwing if the inverter refuses
     * the request.
     *
     * Any success status counts: which 2xx the inverter answers with is not documented and has
     * not been pinned down against the hardware, so treating one of them as the only acceptable
     * reply would fail an onboarding that worked. The configuration step reports the exception as
     * the cause of the failure it returns.
     */
    suspend fun enableModbusTcp(port: Int)

    /**
     * Fetches the inverter's Modbus TCP configuration. Used by
     * [energy.chargee.onboarding.solaredge.steps.ConfigureDeviceStep] to check whether Modbus
     * TCP is already enabled and on which port. If the request fails (e.g. connection dropped,
     * or the device returned a non-decodable response), returns a [ModbusTcpConfig] with
     * `enabled = false` and `port = null` so the caller falls back to enabling the default port.
     */
    suspend fun getModbusTcpConfig(): ModbusTcpConfig
}
