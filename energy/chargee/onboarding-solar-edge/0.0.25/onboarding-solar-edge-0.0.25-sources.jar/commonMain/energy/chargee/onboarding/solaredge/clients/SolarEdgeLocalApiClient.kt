package energy.chargee.onboarding.solaredge.clients

import energy.chargee.core.logging.LogLevel
import energy.chargee.onboarding.core.logOnboarding
import energy.chargee.onboarding.solaredge.models.ModbusTcpConfig
import energy.chargee.onboarding.solaredge.wire.types.Bool
import energy.chargee.onboarding.solaredge.wire.types.Uint32
import energy.chargee.onboarding.solaredge.wire.web_communication.Communication
import energy.chargee.utils.wifi.WifiConfiguration
import energy.chargee.utils.wifi.WifiConnection
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsBytes
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.coroutines.delay
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.seconds

internal class SolarEdgeLocalApiClient(private val wifiConnection: WifiConnection) : SolarEdgeClient {
    private val httpClient: HttpClient by lazy {
        HttpClient {
            // As on the Peblar and Alfen clients: a non-2xx from the inverter throws rather than
            // being handed back as a status for the caller to interpret, so the configuration
            // step reports the failure with the response that caused it.
            expectSuccess = true
            defaultRequest {
                url("http://172.16.0.1")
                contentType(ContentType("application", "x-protobuf"))
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 15_000
            }
        }
    }

    override suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean {
        // The inverter needs some time to initialize the connection after flipping the switch
        delay(5.seconds)

        val connected = wifiConnection.connect(wifiConfiguration, saveNetwork = true)
        if (connected) {
            // Give the device some time to properly initialize the connection
            delay(15.seconds)
            return true
        }

        return false
    }

    override suspend fun disconnect() {
        val disconnected = wifiConnection.disconnect()
        if (disconnected) {
            // Give the device some time to reset the connection
            delay(5.seconds)
        }
    }

    // `expectSuccess` turns anything but a 2xx into an exception, which is the whole of the
    // check: there is nothing to report back that the absence of a throw does not already say.
    override suspend fun enableModbusTcp(port: Int) {
        httpClient.post("/web/v1/communication/modbus_tcp") {
            setBody(
                Communication
                    .ModbusTcpPort(
                        enabled = Bool(true),
                        port = Uint32(port),
                    ).encode(),
            )
        }
    }

    override suspend fun getModbusTcpConfig(): ModbusTcpConfig =
        try {
            val communication =
                Communication.ADAPTER.decode(
                    httpClient
                        .get("/web/v1/communication")
                        .bodyAsBytes(),
                )

            ModbusTcpConfig(
                enabled = communication.modbus_tcp_port?.enabled?.value_ ?: false,
                port = communication.modbus_tcp_port?.port?.value_,
            )
        } catch (cancellation: CancellationException) {
            // `runCatching`, which this replaced, caught this too and reported an abandoned
            // onboarding as an inverter with Modbus switched off.
            throw cancellation
        } catch (exception: Exception) {
            // The one failure this client swallows, and on purpose: the step falls back to
            // enabling the default port and usually succeeds. Say which of the two happened,
            // because the fallback is indistinguishable from an inverter that reported Modbus
            // off — but leave the throwable off the line, since a read the next request recovers
            // from is not a defect and attaching it would raise an issue for a flow that worked.
            logOnboarding(LogLevel.Warning) {
                "solaredge: could not read the Modbus TCP config, assuming it is off " +
                    "(${exception::class.simpleName}: ${exception.message})"
            }
            ModbusTcpConfig(enabled = false)
        }
}
