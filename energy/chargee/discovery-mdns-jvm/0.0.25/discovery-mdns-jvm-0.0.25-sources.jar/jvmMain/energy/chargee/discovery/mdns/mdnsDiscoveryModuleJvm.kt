package energy.chargee.discovery.mdns

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.discovery.core.logged
import kotlinx.coroutines.flow.emptyFlow

/**
 * The JVM mDNS registration, which finds nothing.
 *
 * Android and iOS each browse through an OS service — NSD and `NSNetServiceBrowser` — and the JVM
 * has no equivalent in the standard library. Rather than take on a responder library for a target
 * that exists to debug the SDK, this completes empty.
 *
 * The practical consequence is worth knowing: mDNS is how a Chargee device is found, so every
 * onboarding flow stops at its first step on the JVM. The strategies that do not need it — the
 * subnet scan and the UDP discoveries — work normally.
 */
val mdnsDiscoveryModuleJvm =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.MDNS_DISCOVERY_TYPE) { _ ->
            DeviceDiscovery { emptyFlow() }.logged(DiscoveryConfig.MDNS_DISCOVERY_TYPE)
        }
    }
