package energy.chargee.utils.bluetooth

import com.juul.kable.ServicesDiscoveredPeripheral

/** The JVM bindings expose no MTU control, and are not used by any shipping client. */
internal actual suspend fun ServicesDiscoveredPeripheral.negotiateMtu() = Unit
