package energy.chargee.onboarding.peblar

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.peblar.PeblarConfig.BRAND
import energy.chargee.onboarding.peblar.PeblarConfig.SERVICE_TYPE
import energy.chargee.onboarding.peblar.clients.PeblarClient
import energy.chargee.onboarding.peblar.clients.PeblarLocalApiClient

val peblarOnboardingModule =
    module {
        factory<PeblarClient> { PeblarLocalApiClient() }
        factoryWithParameters<DeviceDiscovery>(name = BRAND) {
            get<DeviceDiscovery>(
                name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                parameters = parametersOf(SERVICE_TYPE),
            )
        }
        factoryWithParameters { parameters ->
            PeblarOnboardingSession(
                OnboardingEngine(
                    initialContext = PeblarOnboardingContext(),
                    flow =
                        createPeblarOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            peblarDiscovery = get<DeviceDiscovery>(name = BRAND),
                            peblarClient = get(),
                            localDeviceRepository = get(),
                            chargerRepository = get(),
                        ),
                ),
            )
        }
    }
