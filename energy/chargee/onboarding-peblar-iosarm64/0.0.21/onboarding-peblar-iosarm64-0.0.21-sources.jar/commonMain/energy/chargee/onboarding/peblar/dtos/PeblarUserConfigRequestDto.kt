package energy.chargee.onboarding.peblar.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class PeblarUserConfigRequestDto(val modbusServerAccessMode: String, val modbusServerEnable: Boolean)
