package energy.chargee.onboarding.peblar.clients

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.onboarding.peblar.dtos.PeblarLoginDto
import energy.chargee.onboarding.peblar.dtos.PeblarSystemInfoDto
import energy.chargee.onboarding.peblar.dtos.PeblarUserConfigRequestDto
import energy.chargee.onboarding.peblar.dtos.PeblarUserConfigResponseDto
import energy.chargee.utils.result.getError
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.cookies.HttpCookies
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.patch
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNamingStrategy

class PeblarLocalApiClient : PeblarClient {
    @OptIn(ExperimentalSerializationApi::class)
    private val httpClient: HttpClient by lazy {
        HttpClient {
            expectSuccess = true
            defaultRequest {
                contentType(ContentType.Application.Json)
            }
            install(HttpCookies)
            install(ContentNegotiation) {
                json(
                    Json {
                        ignoreUnknownKeys = true
                        namingStrategy =
                            JsonNamingStrategy { _, _, serialName ->
                                serialName.replaceFirstChar { it.uppercaseChar() }
                            }
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15_000
                connectTimeoutMillis = 15_000
                socketTimeoutMillis = 15_000
            }
        }
    }

    override suspend fun login(ipAddress: String, password: String): ApiError? =
        runApi { httpClient.post("http://$ipAddress/api/v1/auth/login") { setBody(PeblarLoginDto(password)) } }.getError()

    override suspend fun getDeviceModel(ipAddress: String): String? =
        try {
            httpClient.get("http://$ipAddress/api/v1/system/info").body<PeblarSystemInfoDto>().productModelName
        } catch (_: Exception) {
            null
        }

    override suspend fun enableModbusTcp(ipAddress: String): Boolean {
        try {
            val request = PeblarUserConfigRequestDto(modbusServerAccessMode = "ReadWrite", modbusServerEnable = true)
            val config =
                httpClient
                    .patch("http://$ipAddress/api/v1/config/user") { setBody(request) }
                    .body<PeblarUserConfigResponseDto>()

            return config.modbusServerAccessMode == request.modbusServerAccessMode &&
                config.modbusServerEnable == request.modbusServerEnable &&
                config.modbusServerAllowed
        } catch (_: Exception) {
            return false
        }
    }
}
