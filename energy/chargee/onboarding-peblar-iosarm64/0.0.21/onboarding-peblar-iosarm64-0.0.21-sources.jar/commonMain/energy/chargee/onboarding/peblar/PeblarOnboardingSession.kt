package energy.chargee.onboarding.peblar

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for Peblar chargers. Routes [PeblarInput] — device selection, retry, and the
 * configuration password — and surfaces [PeblarStep]s in its typed state.
 */
@OnboardingSession
class PeblarOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, PeblarOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, PeblarOnboardingContext, PeblarStep, PeblarInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered charger: the device configuration step is
     * skipped, and instead of registering a new charger the flow updates the stored configuration
     * with the rediscovered values before re-verifying.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [PeblarStep]s: a started step becomes [PeblarStep.Running];
     * a pause on device configuration becomes [PeblarStep.AwaitingPassword] and a pause on discovery
     * becomes [PeblarStep.AwaitingDevice]; a rejected configuration password becomes
     * [PeblarStep.AwaitingPassword] in a failure state, and any other failure becomes
     * [PeblarStep.Failure] carrying a retry callback. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, PeblarStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, PeblarOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, PeblarStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = PeblarStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == LocalDeviceStepId.ConfigureDevice &&
                        (event.errorCode as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials == true -> {
                        current.copy(
                            currentStep =
                                PeblarStep.AwaitingPassword(
                                    status = OnboardingStepStatus.Failure,
                                    previousPassword = event.context.password,
                                ) {
                                    submit(PeblarInput.SetPassword(it))
                                },
                        )
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                PeblarStep.Failure(
                                    event.stepId,
                                    error = event.errorCode,
                                    deviceUuid = event.context.deviceUuid,
                                ) {
                                    submit(PeblarInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.ConfigureDevice -> {
                        current.copy(
                            currentStep =
                                PeblarStep.AwaitingPassword(status = OnboardingStepStatus.WaitingForInput) {
                                    submit(PeblarInput.SetPassword(it))
                                },
                        )
                    }

                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                PeblarStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(PeblarInput.SetDevice(it)) },
                                    rescan = { submit(PeblarInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [PeblarInput]: [Retry][PeblarInput.Retry] re-runs a failed step;
     * [SetPassword][PeblarInput.SetPassword] applies while the flow is paused on device
     * configuration; and [SetDevice][PeblarInput.SetDevice] selects the device while waiting on
     * discovery.
     */
    override fun submit(input: PeblarInput): SubmitResult =
        when (input) {
            PeblarInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is PeblarInput.SetPassword -> {
                requirePaused(LocalDeviceStepId.ConfigureDevice) {
                    engine.resume { it.copy(password = input.password) }
                }
            }

            is PeblarInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            PeblarInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }
        }
}
