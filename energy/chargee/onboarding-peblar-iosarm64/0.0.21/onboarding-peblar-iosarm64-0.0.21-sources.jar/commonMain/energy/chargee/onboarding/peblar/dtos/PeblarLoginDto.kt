package energy.chargee.onboarding.peblar.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class PeblarLoginDto(val password: String, val persistentSession: Boolean = false)
