package energy.chargee.onboarding.peblar.steps

import energy.chargee.core.network.models.ApiError
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.peblar.PeblarOnboardingContext
import energy.chargee.onboarding.peblar.clients.PeblarClient

internal class ConfigureDeviceStep(private val client: PeblarClient) :
    OnboardingFlow.Step<LocalDeviceStepId, PeblarOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: PeblarOnboardingContext): Result<PeblarOnboardingContext> {
        val selectedDevice =
            requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before ConfigureDeviceStep runs" }
        val password =
            context.password ?: return Result.InputRequired(context, advanceAfterInput = false)

        val loginError = client.login(selectedDevice.ipAddress, password)

        if (loginError != null) {
            return Result.Failure(
                context,
                LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = loginError is ApiError.Client.Unauthorized),
            )
        }

        if (!client.enableModbusTcp(selectedDevice.ipAddress)) {
            return Result.Failure(context, LocalDeviceErrorCode.DeviceConfigurationFailure())
        }

        val model = client.getDeviceModel(selectedDevice.ipAddress)
        return Result.Success(context.copy(model = model))
    }
}
