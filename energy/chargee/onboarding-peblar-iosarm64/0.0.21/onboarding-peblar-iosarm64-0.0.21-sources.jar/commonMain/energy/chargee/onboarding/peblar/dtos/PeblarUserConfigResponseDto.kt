package energy.chargee.onboarding.peblar.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class PeblarUserConfigResponseDto(
    val modbusServerAccessMode: String? = null,
    val modbusServerEnable: Boolean = false,
    val modbusServerAllowed: Boolean = false,
)
