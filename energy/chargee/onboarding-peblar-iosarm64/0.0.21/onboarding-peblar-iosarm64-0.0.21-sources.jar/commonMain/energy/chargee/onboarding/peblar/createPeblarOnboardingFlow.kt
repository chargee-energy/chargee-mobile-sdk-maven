package energy.chargee.onboarding.peblar

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.ChargerRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyChargerStep
import energy.chargee.onboarding.peblar.PeblarConfig.BRAND
import energy.chargee.onboarding.peblar.clients.PeblarClient
import energy.chargee.onboarding.peblar.steps.ConfigureDeviceStep
import io.ktor.http.DEFAULT_PORT

/**
 * Builds the onboarding flow for a Peblar charger behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Discover the Peblar charger via [peblarDiscovery] (mDNS on `_pblr._tcp`).
 * 3. Prompt the user for the charger's on-screen password, then log in via [peblarClient],
 *    enable Modbus TCP, and read the product model.
 * 4. Register the discovered charger through [localDeviceRepository].
 * 5. Poll [chargerRepository] until the Chargee device reports readings from the charger,
 *    confirming end-to-end connectivity.
 *
 * The Peblar charger sits on the same network as the phone, so unlike SolarEdge no
 * local-AP association step is required.
 *
 * When the context is seeded with a `deviceUuid` the flow resets that already-registered charger
 * instead: step 3 is skipped — the charger is assumed to be configured already — and step 4
 * updates the stored configuration with the rediscovered values rather than creating a second
 * registration.
 */
internal fun createPeblarOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    peblarDiscovery: DeviceDiscovery,
    peblarClient: PeblarClient,
    localDeviceRepository: LocalDeviceRepository,
    chargerRepository: ChargerRepository,
) = createOnboardingFlow<LocalDeviceStepId, PeblarOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    discoverDeviceStep { peblarDiscovery }
    whenTrue(condition = { it.deviceUuid == null }) {
        step(
            ConfigureDeviceStep(peblarClient),
            retryPolicy =
                ExponentialBackoffRetry(
                    maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                    condition = { (it as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials != true },
                ),
        )
    }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = { context, fields ->
            LocalDeviceConfig(
                type = LocalDeviceType.Charger,
                connectionType = "peblar_tcp",
                deviceType = BRAND,
                brand = BRAND,
                model = context.model,
                config =
                fields,
            )
        },
        createConfigFields = { context ->
            val selectedDevice =
                requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }
            listOf(
                LocalDeviceConfigField("modbus_type", "tcp"),
                LocalDeviceConfigField("address", 1),
                LocalDeviceConfigField("ip", selectedDevice.ipAddress),
                LocalDeviceConfigField("port", DEFAULT_PORT),
                LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
            )
        },
    )
    verifyChargerStep(addressUuid, chargerRepository)
}
