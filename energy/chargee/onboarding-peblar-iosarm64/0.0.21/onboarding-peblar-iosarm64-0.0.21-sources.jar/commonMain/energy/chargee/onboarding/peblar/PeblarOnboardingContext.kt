package energy.chargee.onboarding.peblar

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext

/**
 * The mutable context that flows through the Peblar onboarding steps.
 *
 * Extends [LocalDeviceOnboardingContext] with Peblar-specific fields. [password] is the login
 * password shown on the charger's screen; it is required by
 * [energy.chargee.onboarding.peblar.steps.ConfigureDeviceStep], which pauses for user input
 * until it is set.
 */
data class PeblarOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    val password: String? = null,
) : LocalDeviceOnboardingContext<PeblarOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
