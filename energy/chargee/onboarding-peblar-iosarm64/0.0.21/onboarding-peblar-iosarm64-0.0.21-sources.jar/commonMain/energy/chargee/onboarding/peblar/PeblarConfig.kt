package energy.chargee.onboarding.peblar

/**
 * Peblar-specific constants shared across the flow, module, and clients.
 */
object PeblarConfig {
    /** Brand identifier used as the Peblar onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "peblar"

    /** Peblar chargers expose Modbus TCP on 502 by default. */
    const val DEFAULT_PORT = 502

    /**
     * mDNS service type Peblar chargers advertise on the local network — abbreviated `_pblr`, not
     * `_peblar`. Used by the Peblar DI module to build the
     * [energy.chargee.discovery.core.DeviceDiscovery] registered under [BRAND].
     */
    const val SERVICE_TYPE = "_pblr._tcp"
}
