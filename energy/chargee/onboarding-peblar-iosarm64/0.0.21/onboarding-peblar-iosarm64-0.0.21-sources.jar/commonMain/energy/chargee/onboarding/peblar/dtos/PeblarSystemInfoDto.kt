package energy.chargee.onboarding.peblar.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class PeblarSystemInfoDto(val productModelName: String? = null)
