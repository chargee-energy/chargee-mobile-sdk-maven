package energy.chargee.onboarding.peblar.clients

import energy.chargee.core.network.models.ApiError

/**
 * Client for the local HTTP API exposed by a Peblar charger.
 *
 * Unlike solar-edge, Peblar chargers are reachable directly from the Chargee device's network,
 * so this client only issues HTTP requests to the discovered [ipAddress] and does not manage
 * a Wi-Fi association.
 */
interface PeblarClient {
    /**
     * Authenticates against the charger at [ipAddress] with [password]. Returns `null` on
     * success and the underlying [ApiError] on failure — specifically an [ApiError.Client.Unauthorized]
     * when the password is wrong so that the step can distinguish invalid credentials from
     * other configuration errors.
     */
    suspend fun login(ipAddress: String, password: String): ApiError?

    /**
     * Fetches the product model name from the charger at [ipAddress], or `null` if the request
     * fails or the charger does not report one. Best-effort — the returned model is written to
     * the context as decoration and does not gate onboarding.
     */
    suspend fun getDeviceModel(ipAddress: String): String?

    /**
     * Enables Modbus TCP on the charger at [ipAddress] in ReadWrite mode. Returns `true` when
     * the charger's response confirms Modbus is enabled and allowed, `false` otherwise.
     */
    suspend fun enableModbusTcp(ipAddress: String): Boolean
}
