package energy.chargee.onboarding.alfen.clients

import android.annotation.SuppressLint
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.okhttp.OkHttp
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

private val trustAll =
    @SuppressLint("CustomX509TrustManager")
    object : X509TrustManager {
        @SuppressLint("TrustAllX509TrustManager")
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        }

        @SuppressLint("TrustAllX509TrustManager")
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

internal actual fun createNativeHttpClient(block: HttpClientConfig<*>.() -> Unit): HttpClient {
    val sslContext =
        SSLContext.getInstance("TLS").apply {
            init(null, arrayOf(trustAll), SecureRandom())
        }

    return HttpClient(OkHttp) {
        block()
        engine {
            // OkHttp keeps a real connection pool, so the login POST and the
            // subsequent GET reuse the same socket — the charger binds auth to
            // the TCP connection, not a cookie.
            config {
                sslSocketFactory(sslContext.socketFactory, trustAll)
                hostnameVerifier { _, _ -> true }
            }
        }
    }
}
