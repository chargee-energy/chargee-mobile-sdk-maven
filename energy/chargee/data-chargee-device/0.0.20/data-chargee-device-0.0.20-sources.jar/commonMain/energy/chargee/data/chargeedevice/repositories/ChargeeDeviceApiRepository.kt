package energy.chargee.data.chargeedevice.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.chargeedevice.clients.ChargeeDeviceApiClient
import energy.chargee.data.chargeedevice.converters.asChargeeDevice
import energy.chargee.data.chargeedevice.dtos.CreateChargeeDeviceDto
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.utils.result.Result

internal class ChargeeDeviceApiRepository(private val chargeeDeviceApiClient: ChargeeDeviceApiClient) : ChargeeDeviceRepository {
    override suspend fun getChargeeDevices(addressUuid: String, deviceType: ChargeeDeviceType): Result<List<ChargeeDevice>, ApiError> =
        runApi {
            chargeeDeviceApiClient
                .getChargeeDevices(addressUuid, getDeviceTypeString(deviceType))
                .results
                .map { it.asChargeeDevice(deviceType) }
        }

    override suspend fun createChargeeDevice(
        addressUuid: String,
        deviceType: ChargeeDeviceType,
        serialNumber: String,
    ): Result<ChargeeDevice, ApiError> =
        runApi {
            chargeeDeviceApiClient
                .createChargeeDevice(
                    addressUuid,
                    getDeviceTypeString(deviceType),
                    CreateChargeeDeviceDto(serialNumber),
                ).asChargeeDevice(deviceType)
        }

    override suspend fun getChargeeDevice(
        addressUuid: String,
        deviceType: ChargeeDeviceType,
        deviceUuid: String,
    ): Result<ChargeeDevice, ApiError> =
        runApi {
            chargeeDeviceApiClient
                .getChargeeDevice(addressUuid, getDeviceTypeString(deviceType), deviceUuid)
                .asChargeeDevice(deviceType)
        }

    override suspend fun deleteChargeeDevice(
        addressUuid: String,
        deviceType: ChargeeDeviceType,
        deviceUuid: String,
    ): Result<Unit, ApiError> =
        runApi { chargeeDeviceApiClient.deleteChargeeDevice(addressUuid, getDeviceTypeString(deviceType), deviceUuid) }

    private fun getDeviceTypeString(deviceType: ChargeeDeviceType) =
        when (deviceType) {
            ChargeeDeviceType.Sparky -> "sparkies"
            ChargeeDeviceType.Flint -> "flints"
        }
}
