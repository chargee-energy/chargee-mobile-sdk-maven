package energy.chargee.data.chargeedevice.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.chargeedevice.dtos.ChargeeDeviceDto
import energy.chargee.data.chargeedevice.dtos.CreateChargeeDeviceDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody

internal class ChargeeDeviceApiClient(private val httpClient: HttpClient) {
    suspend fun getChargeeDevices(addressUuid: String, deviceType: String): PaginatedResponseDto<PaginatedMetaDto, ChargeeDeviceDto> =
        httpClient.get("/v5/addresses/$addressUuid/$deviceType").body()

    suspend fun createChargeeDevice(addressUuid: String, deviceType: String, request: CreateChargeeDeviceDto): ChargeeDeviceDto =
        httpClient.post("/v5/addresses/$addressUuid/$deviceType") { setBody(request) }.body()

    suspend fun getChargeeDevice(addressUuid: String, deviceType: String, deviceUuid: String): ChargeeDeviceDto =
        httpClient.get("/v5/addresses/$addressUuid/$deviceType/$deviceUuid").body()

    suspend fun deleteChargeeDevice(addressUuid: String, deviceType: String, deviceUuid: String) =
        httpClient.delete("/v5/addresses/$addressUuid/$deviceType/$deviceUuid")
}
