package energy.chargee.data.chargeedevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class CreateChargeeDeviceDto(val serialNumber: String)
