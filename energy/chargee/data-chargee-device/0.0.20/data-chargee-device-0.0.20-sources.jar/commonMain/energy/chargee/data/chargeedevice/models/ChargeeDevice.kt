package energy.chargee.data.chargeedevice.models

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceStatus
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A Chargee branded device.
 *
 * [uuid] is the unique identifier assigned by the backend, and [serialNumber] is the hardware
 * serial number of the device. [type] identifies which Chargee product the device is, and
 * [status] reflects the current connectivity state of the device,
 * or `null` if the status is unknown. [createdAt] records when the device was first registered,
 * [connectedAt] when it last connected, and [disconnectedAt] when it last disconnected,
 * or `null` if the device is still connected.
 */
@Serializable
@ObjCName("_ChargeeDevice")
data class ChargeeDevice(
    val uuid: String,
    val serialNumber: String,
    val type: ChargeeDeviceType,
    val status: ChargeeDeviceStatus? = null,
    val createdAt: Instant,
    val connectedAt: Instant,
    val disconnectedAt: Instant? = null,
)
