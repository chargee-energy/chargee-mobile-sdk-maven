package energy.chargee.data.chargeedevice.enums

/**
 * The type of Chargee branded device.
 */
enum class ChargeeDeviceType {
    /**
     * A Sparky device.
     */
    Sparky,

    /**
     * A Flint device.
     */
    Flint,
}
