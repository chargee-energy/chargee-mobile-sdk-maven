package energy.chargee.data.chargeedevice

import energy.chargee.core.di.module
import energy.chargee.data.chargeedevice.clients.ChargeeDeviceApiClient
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceApiRepository
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository

val chargeeDeviceDataModule =
    module {
        factory { ChargeeDeviceApiClient(get()) }
        factory<ChargeeDeviceRepository> { ChargeeDeviceApiRepository(get()) }
    }
