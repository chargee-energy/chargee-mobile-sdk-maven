package energy.chargee.data.chargeedevice.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import energy.chargee.utils.result.Result

/**
 * Provides access to Chargee device registration for an address.
 */
interface ChargeeDeviceRepository {
    /**
     * Fetches all Chargee devices of [deviceType] for [addressUuid].
     */
    suspend fun getChargeeDevices(addressUuid: String, deviceType: ChargeeDeviceType): Result<List<ChargeeDevice>, ApiError>

    /**
     * Registers a new Chargee device of [deviceType] with [serialNumber] to the address identified
     * by [addressUuid].
     */
    suspend fun createChargeeDevice(
        addressUuid: String,
        deviceType: ChargeeDeviceType,
        serialNumber: String,
    ): Result<ChargeeDevice, ApiError>

    /**
     * Fetches the Chargee devices of [deviceType] identified by [deviceUuid] for [addressUuid].
     */
    suspend fun getChargeeDevice(addressUuid: String, deviceType: ChargeeDeviceType, deviceUuid: String): Result<ChargeeDevice, ApiError>

    /**
     * Deletes the Chargee devices of [deviceType] identified by [deviceUuid] for [addressUuid].
     */
    suspend fun deleteChargeeDevice(addressUuid: String, deviceType: ChargeeDeviceType, deviceUuid: String): Result<Unit, ApiError>
}
