package energy.chargee.data.chargeedevice.converters

import energy.chargee.data.chargeedevice.dtos.ChargeeDeviceDto
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceStatus
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.models.ChargeeDevice
import kotlin.time.Instant

internal fun ChargeeDeviceDto.asChargeeDevice(type: ChargeeDeviceType) =
    ChargeeDevice(
        uuid,
        serialNumber,
        type,
        when (status) {
            "online" -> ChargeeDeviceStatus.Online
            "offline" -> ChargeeDeviceStatus.Offline
            else -> null
        },
        Instant.parse(createdAt),
        Instant.parse(connectedAt),
        disconnectedAt?.let(Instant::parse),
    )
