package energy.chargee.data.chargeedevice.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class ChargeeDeviceDto(
    val uuid: String,
    val serialNumber: String,
    val status: String? = null,
    val createdAt: String,
    val connectedAt: String,
    val disconnectedAt: String? = null,
)
