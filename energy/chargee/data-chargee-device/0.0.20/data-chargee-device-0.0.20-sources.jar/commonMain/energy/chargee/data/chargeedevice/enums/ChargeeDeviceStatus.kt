package energy.chargee.data.chargeedevice.enums

enum class ChargeeDeviceStatus {
    Online,
    Offline,
}
