package energy.chargee.utils.wifi

import energy.chargee.utils.concurrency.ResumeOnce
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import platform.Foundation.NSError
import platform.NetworkExtension.NEHotspotConfiguration
import platform.NetworkExtension.NEHotspotConfigurationErrorAlreadyAssociated
import platform.NetworkExtension.NEHotspotConfigurationManager
import platform.NetworkExtension.NEHotspotNetwork

/**
 * The Darwin [WifiConnection], joining networks through `NEHotspotConfigurationManager` and
 * deriving the gateway from the address [localAddressProvider] reports on the joined network.
 */
class WifiConnectionIos(private val localAddressProvider: LocalAddressProvider) : WifiConnection {
    /** Creates an instance backed by [LocalAddressProviderIos]. */
    constructor() : this(LocalAddressProviderIos())

    override suspend fun connect(configuration: WifiConfiguration, saveNetwork: Boolean): Boolean {
        if (configuration.ssid == getSsid()) return true

        val hotspotConfig =
            if (configuration.password != null) {
                NEHotspotConfiguration(
                    sSID = configuration.ssid,
                    passphrase = configuration.password,
                    isWEP = configuration.auth == WifiAuth.Wep,
                )
            } else {
                NEHotspotConfiguration(sSID = configuration.ssid)
            }.apply { joinOnce = !saveNetwork }

        return suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            val scope = CoroutineScope(continuation.context)
            NEHotspotConfigurationManager.sharedManager.applyConfiguration(hotspotConfig) { error ->
                if (error is NSError) {
                    when (error.code) {
                        NEHotspotConfigurationErrorAlreadyAssociated -> gate.resumeOnce(true)
                        else -> gate.resumeOnce(false)
                    }
                } else {
                    scope.launch { gate.resumeOnce(configuration.ssid == getSsid()) }
                }
            }
        }
    }

    override suspend fun disconnect(): Boolean {
        val ssid = getSsid() ?: return false
        NEHotspotConfigurationManager.sharedManager.removeConfigurationForSSID(ssid)
        return true
    }

    override suspend fun getSsid(): String? =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            NEHotspotNetwork.fetchCurrentWithCompletionHandler { gate.resumeOnce(it?.SSID) }
        }

    /**
     * Returns the first host address of the subnet the joined network placed this device on,
     * which is where consumer access points — including the inverter and charger APs this SDK
     * onboards — put their own interface.
     *
     * Darwin exposes no supported API for the gateway of a specific interface. Reading the
     * routing table would not answer this question either: the access points joined during
     * onboarding carry no internet, so the system default route stays on another transport and
     * would yield that transport's gateway. Deriving from the address the access point itself
     * assigned cannot name a host off that subnet, at the cost of assuming the access point
     * takes the first address on it.
     */
    override suspend fun getGatewayAddress(): String? = localAddressProvider.getLocalAddress()?.hostAddresses()?.firstOrNull()
}
