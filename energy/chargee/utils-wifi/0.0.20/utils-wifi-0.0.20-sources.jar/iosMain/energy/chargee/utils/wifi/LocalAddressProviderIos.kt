package energy.chargee.utils.wifi

import kotlinx.cinterop.ByteVar
import kotlinx.cinterop.CPointerVar
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.pointed
import kotlinx.cinterop.ptr
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.toKString
import kotlinx.cinterop.value
import platform.darwin.freeifaddrs
import platform.darwin.getifaddrs
import platform.darwin.ifaddrs
import platform.posix.AF_INET
import platform.posix.NI_MAXHOST
import platform.posix.NI_NUMERICHOST
import platform.posix.getnameinfo
import platform.posix.sockaddr_in

class LocalAddressProviderIos : LocalAddressProvider {
    @OptIn(ExperimentalForeignApi::class)
    override fun getLocalAddress(): LocalAddress? =
        memScoped {
            val ifaddr = alloc<CPointerVar<ifaddrs>>()
            if (getifaddrs(ifaddr.ptr) != 0) return@memScoped null

            try {
                var cur = ifaddr.value
                while (cur != null) {
                    val ifa = cur.pointed
                    val addr = ifa.ifa_addr
                    val netmask = ifa.ifa_netmask

                    if (addr != null &&
                        netmask != null &&
                        addr.pointed.sa_family.toInt() == AF_INET &&
                        ifa.ifa_name?.toKString() == "en0"
                    ) {
                        val host = allocArray<ByteVar>(NI_MAXHOST)
                        val rc =
                            getnameinfo(
                                addr,
                                addr.pointed.sa_len.toUInt(),
                                host,
                                NI_MAXHOST.toUInt(),
                                null,
                                0u,
                                NI_NUMERICHOST,
                            )

                        if (rc == 0) {
                            val maskBits =
                                netmask
                                    .reinterpret<sockaddr_in>()
                                    .pointed.sin_addr.s_addr
                            return@memScoped LocalAddress(host.toKString(), maskBits.countOneBits())
                        }
                    }

                    cur = ifa.ifa_next
                }

                return@memScoped null
            } finally {
                freeifaddrs(ifaddr.value)
            }
        }
}
