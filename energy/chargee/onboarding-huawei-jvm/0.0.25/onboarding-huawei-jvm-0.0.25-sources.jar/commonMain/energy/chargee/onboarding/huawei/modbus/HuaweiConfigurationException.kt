package energy.chargee.onboarding.huawei.modbus

import energy.chargee.onboarding.localdevice.modbus.ModbusErrorResponseException

/**
 * The part of the Huawei configuration exchange that a [HuaweiConfigurationException] reports on.
 *
 * The exchange reaches the flow as a single [HuaweiResponse][energy.chargee.onboarding.huawei.models.HuaweiResponse],
 * so which of its three round-trips actually failed is otherwise lost — and they fail for
 * entirely different reasons: a refused handshake is usually a wrong installer password, a
 * refused register write is usually a model that does not have the register, and a read that
 * comes back empty is an inverter that has not been given a LAN address yet.
 */
internal enum class HuaweiOperation(val description: String) {
    /** The challenge/response handshake over vendor function code `0x41`. */
    Authenticate("authenticate"),

    /** The write to the apply-network-config holding register. */
    ApplyNetworkConfig("apply network config"),

    /** The read of the two holding registers carrying the inverter's LAN-side IPv4 address. */
    ReadLanIpAddress("read LAN IP address"),
}

/**
 * Why one [operation] of the Huawei configuration exchange failed, for the logger to carry.
 *
 * Built at the point a failure is caught and flattened into a
 * [HuaweiResponse][energy.chargee.onboarding.huawei.models.HuaweiResponse], purely so the [cause]
 * and the operation survive into the log instead of being thrown away with the exception. It is
 * never thrown — every call site hands it to `logOnboarding` as the throwable and returns the
 * response it was always going to return.
 *
 * [modbusExceptionCode] is the Modbus exception code when the inverter refused the request
 * outright, and `null` when the failure was anything else — an unreachable peer, a garbled frame,
 * or an HMAC that did not match.
 */
internal class HuaweiConfigurationException(val operation: HuaweiOperation, override val cause: Throwable) :
    RuntimeException("Huawei ${operation.description} failed: ${cause.message ?: cause::class.simpleName}", cause) {
    val modbusExceptionCode: Int? = (cause as? ModbusErrorResponseException)?.exceptionCode
}
