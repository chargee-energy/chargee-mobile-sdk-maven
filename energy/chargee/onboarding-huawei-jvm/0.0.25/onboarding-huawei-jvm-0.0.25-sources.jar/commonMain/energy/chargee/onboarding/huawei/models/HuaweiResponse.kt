package energy.chargee.onboarding.huawei.models

/**
 * Outcome of the Huawei configure round-trip.
 *
 * See [energy.chargee.onboarding.huawei.clients.HuaweiClient.configure]. Any failure that
 * cannot be attributed to bad credentials becomes [Failed] so the flow can distinguish
 * "wrong password" from generic Modbus errors.
 */
sealed interface HuaweiResponse {
    /**
     * The inverter rejected the credentials during the challenge/response handshake. The
     * onboarding flow reprompts for credentials if the defaults were used, and fails with
     * [energy.chargee.onboarding.localdevice.LocalDeviceErrorCode.DeviceConfigurationFailure]
     * (with `invalidCredentials = true`) otherwise.
     */
    data object Unauthenticated : HuaweiResponse

    /**
     * The configure round-trip succeeded and the inverter reported the [ipAddress] it will use
     * on the customer's LAN.
     */
    data class Success(val ipAddress: String) : HuaweiResponse

    /**
     * The configure round-trip failed for a reason other than bad credentials — most often a
     * dropped Modbus connection or an unexpected exception response.
     *
     * [cause] is why, and is never null: the exchange builds a
     * `HuaweiConfigurationException` naming which of its three round-trips failed, and the
     * client builds one when no candidate endpoint answered at all. The configuration step
     * reports it as the cause of the failure it returns, which is what tells a monitoring logger
     * this is a defect rather than an outcome the flow expects — a rejected installer login is
     * [Unauthenticated] and carries nothing.
     */
    data class Failed(val cause: Throwable) : HuaweiResponse
}
