package energy.chargee.onboarding.huawei.modbus

import energy.chargee.core.logging.LogLevel
import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.logOnboarding
import energy.chargee.onboarding.huawei.HuaweiLocalEndpoint
import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.onboarding.localdevice.modbus.ModbusClient
import energy.chargee.onboarding.localdevice.modbus.ModbusConnection
import energy.chargee.onboarding.localdevice.modbus.ModbusFramingException
import energy.chargee.onboarding.localdevice.modbus.ModbusUnreachableException
import energy.chargee.onboarding.localdevice.modbus.decodeToIpv4
import energy.chargee.onboarding.localdevice.modbus.uint16
import energy.chargee.onboarding.localdevice.modbus.uint8
import kotlin.coroutines.cancellation.CancellationException

/** Modbus unit id Huawei inverters answer on over their own access point. */
private val LOCAL_CONFIG_UNIT_ID = 0.uint8

/** Holding register that tells the inverter to apply the network configuration it was given. */
private val APPLY_NETWORK_CONFIG_REGISTER = 43291.uint16

/** First of the two holding registers holding the IPv4 address the inverter will use on the LAN. */
private val LAN_IP_ADDRESS_REGISTER = 43198.uint16

/**
 * Runs the Huawei configuration exchange against the inverter at [endpoint]: authenticates with
 * [username] and [password], applies the network configuration, and reads back the IPv4 address
 * the inverter will use on the customer's LAN.
 *
 * Returns `null` — rather than [HuaweiResponse.Failed] — when nothing answered at [endpoint], so
 * a caller walking a list of candidate endpoints can tell "wrong address" apart from "right
 * address, exchange failed" and move on to the next candidate. An endpoint that did answer is
 * always reported as a [HuaweiResponse], including [HuaweiResponse.Unauthenticated] for rejected
 * credentials.
 */
internal suspend fun configureHuaweiInverter(endpoint: HuaweiLocalEndpoint, username: String, password: String): HuaweiResponse? =
    try {
        ModbusClient(endpoint.host, endpoint.port, unitId = LOCAL_CONFIG_UNIT_ID)
            .connect { runConfigurationExchange(username, password) }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (exception: Exception) {
        // A connect timeout or a refused connection — nothing is listening at this endpoint.
        // Expected while walking candidates, so debug: it is only interesting once every
        // candidate has come up empty and the flow reports a configuration failure.
        logOnboarding(throwable = exception) { "huawei: $endpoint did not accept a connection" }
        null
    }

private suspend fun ModbusConnection.runConfigurationExchange(username: String, password: String): HuaweiResponse? {
    try {
        authenticateHuaweiInverter(username, password)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (unreachable: ModbusUnreachableException) {
        // The port accepted the connection but nothing spoke Modbus back — treat it as the wrong
        // endpoint rather than as a rejected login.
        logFailure(HuaweiOperation.Authenticate, unreachable, "no Modbus answer, trying the next endpoint")
        return null
    } catch (framing: ModbusFramingException) {
        // Something answered but the frames did not line up, so the handshake proves nothing
        // about the credentials. Reporting it as a rejected login would send the user off to
        // correct a password that was never wrong.
        logFailure(HuaweiOperation.Authenticate, framing, "frames did not line up, trying the next endpoint")
        return null
    } catch (refused: IllegalStateException) {
        // The only failure that is really about the credentials — and the one the user is asked
        // to act on — so say which check rejected them rather than only that something did.
        logFailure(HuaweiOperation.Authenticate, refused, "credentials rejected")
        return HuaweiResponse.Unauthenticated
    }

    // Past the handshake the inverter has proven it is the device we are looking for, so every
    // remaining failure is a configuration failure rather than a wrong endpoint. The write and
    // the read are guarded separately so a failure is logged against the one it happened in —
    // they fail for unrelated reasons and a single catch would blame the read for both.
    try {
        writeSingleRegister(APPLY_NETWORK_CONFIG_REGISTER, 1.uint16)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (refused: IllegalStateException) {
        // Not every model has this register — the SUN2000L-4.6KTL refuses the write with
        // Modbus exception 0x02 yet already reports its LAN address — so let the read decide.
        // The exception code tells the two apart: 0x02 is the known-harmless case, anything
        // else is the inverter refusing for a reason worth knowing when the read fails too.
        logFailure(HuaweiOperation.ApplyNetworkConfig, refused, "refused, letting the address read decide")
    } catch (failure: RuntimeException) {
        // Not a refusal but a broken exchange, and the stream may no longer be aligned; the read
        // that follows would prove nothing. Same outcome the single catch used to produce.
        return HuaweiResponse.Failed(logFailure(HuaweiOperation.ApplyNetworkConfig, failure, "exchange failed"))
    }

    return try {
        val ipAddress = readHoldingRegisters(LAN_IP_ADDRESS_REGISTER, 2.uint16).decodeToIpv4()

        if (ipAddress == null) {
            // The registers answered but hold nothing usable, which is a different problem from
            // the read failing and leaves the flow with nothing to register. No exception marks
            // it, so one is made: the step has to report a cause or the failure is
            // indistinguishable from the outcomes the flow expects.
            HuaweiResponse.Failed(
                logFailure(
                    HuaweiOperation.ReadLanIpAddress,
                    DeviceConfigurationException("the inverter's LAN address registers hold no IPv4 address"),
                    "no address to register",
                ),
            )
        } else {
            HuaweiResponse.Success(ipAddress)
        }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (failure: RuntimeException) {
        HuaweiResponse.Failed(logFailure(HuaweiOperation.ReadLanIpAddress, failure, "exchange failed"))
    }
}

/**
 * Logs [cause] against the [operation] it failed in and returns it wrapped in a
 * [HuaweiConfigurationException], so the operation and any Modbus exception code travel with it
 * both into the log and onto the [HuaweiResponse.Failed] the caller returns.
 *
 * Always [LogLevel.Debug], and deliberately. These lines are the narrative — which endpoint,
 * which round-trip, in what order — while the failure the flow stops on is raised once by the
 * configuration step, from the exception returned here. Logging them at `Warning` with a
 * throwable would raise a second issue for the same failure, and one more for every candidate
 * endpoint the exchange walked past on the way.
 */
private fun logFailure(operation: HuaweiOperation, cause: Throwable, outcome: String): HuaweiConfigurationException {
    val exception = HuaweiConfigurationException(operation, cause)
    logOnboarding(throwable = exception) { "huawei: ${operation.description} — $outcome (${exception.message})" }
    return exception
}
