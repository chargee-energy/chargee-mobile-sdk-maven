package energy.chargee.onboarding.huawei.clients

import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.huawei.HuaweiConfig
import energy.chargee.onboarding.huawei.HuaweiLocalEndpoint
import energy.chargee.onboarding.huawei.modbus.configureHuaweiInverter
import energy.chargee.onboarding.huawei.modbus.probeHuaweiInverter
import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.utils.wifi.WifiConfiguration
import energy.chargee.utils.wifi.WifiConnection
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.seconds

/**
 * Talks to the inverter over its own access point.
 *
 * The inverter is the gateway of the access point it broadcasts, so its address is read from
 * [WifiConnection.getGatewayAddress] rather than assumed; [fallbackEndpoints] covers the case
 * where no gateway can be resolved. The port cannot be resolved this way and still varies by
 * firmware, so each candidate address is tried on every port in [ports]. [configureAt] performs
 * one attempt against one endpoint and returns `null` when that endpoint did not answer, and
 * [probeAt] reports whether an endpoint is reachable at all — which is what [connect] uses to
 * decide whether the phone really is on the access point.
 */
internal class HuaweiLocalApiClient(
    private val wifiConnection: WifiConnection,
    private val ports: List<Int> = HuaweiConfig.LOCAL_CONFIG_PORTS,
    private val fallbackEndpoints: List<HuaweiLocalEndpoint> = HuaweiConfig.LOCAL_CONFIG_ENDPOINTS,
    private val configureAt: suspend (HuaweiLocalEndpoint, String, String) -> HuaweiResponse? = ::configureHuaweiInverter,
    private val probeAt: suspend (HuaweiLocalEndpoint) -> Boolean = ::probeHuaweiInverter,
) : HuaweiClient {
    /**
     * The endpoint that last answered, so the credential reprompt and the flow's configure
     * retries go straight to it instead of paying the connect timeout on every wrong candidate
     * again. Resolved by [connect] while it verifies the access point, and cleared by
     * [disconnect], which ends the session this endpoint was valid for, and by a [configure] that
     * reaches nothing — see there for why.
     */
    private var resolvedEndpoint: HuaweiLocalEndpoint? = null

    /**
     * Joins the access point and then confirms the inverter is actually reachable on it, keeping
     * the endpoint that answered for [configure] to reuse.
     *
     * The association alone does not settle it. On iOS a rejected Wi-Fi passphrase is reported to
     * the user and not to the app, so the join reports success and the flow walks into the
     * configuration step, where "nothing answered" is indistinguishable from a wrong installer
     * password. Reaching the inverter here keeps the failure on the step that can ask for the
     * Wi-Fi password again.
     */
    override suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean {
        if (!wifiConnection.connect(wifiConfiguration, saveNetwork = true)) return false

        // Give the device some time to properly initialize the connection
        delay(INITIALIZATION_DELAY)

        resolvedEndpoint = candidateEndpoints().firstOrNull { probeAt(it) }
        if (resolvedEndpoint != null) return true

        // Leave nothing installed for this SSID: on iOS a leftover configuration makes the retry
        // that carries the corrected passphrase report `alreadyAssociated` against the stale one,
        // and the new passphrase is never applied.
        disconnect()
        return false
    }

    override suspend fun disconnect() {
        resolvedEndpoint = null
        val disconnected = wifiConnection.disconnect()
        if (disconnected) {
            // Give the device some time to reset the connection
            delay(TEARDOWN_DELAY)
        }
    }

    override suspend fun configure(username: String, password: String): HuaweiResponse {
        val candidates = resolvedEndpoint?.let(::listOf) ?: candidateEndpoints()

        for (endpoint in candidates) {
            val response = configureAt(endpoint, username, password) ?: continue
            resolvedEndpoint = endpoint
            return response
        }

        // An endpoint that answered once and has now gone silent usually means the phone left the
        // access point rather than that the inverter moved, and retrying the remembered address
        // can only keep failing. Forget it so the next attempt resolves the gateway again.
        resolvedEndpoint = null

        // Nothing threw here — each candidate reported itself as unreachable and the exchange
        // logged why — so the step is given one, or the whole walk reaches it as a bare failure.
        return HuaweiResponse.Failed(
            DeviceConfigurationException("No Huawei inverter answered on any of ${candidates.size} candidate endpoints"),
        )
    }

    /**
     * The gateway of the joined network on each known port first, then [fallbackEndpoints].
     * Deduplicated, so a gateway that matches a known address does not get probed twice.
     */
    private suspend fun candidateEndpoints(): List<HuaweiLocalEndpoint> {
        val gateway = wifiConnection.getGatewayAddress()

        return buildList {
            gateway?.let { host -> ports.forEach { port -> add(HuaweiLocalEndpoint(host, port)) } }
            addAll(fallbackEndpoints)
        }.distinct()
    }

    private companion object {
        /** How long the inverter is given to bring its Modbus service up after the phone joins. */
        val INITIALIZATION_DELAY = 15.seconds

        /** How long to wait for the access point to tear down before the next attempt joins it. */
        val TEARDOWN_DELAY = 5.seconds
    }
}
