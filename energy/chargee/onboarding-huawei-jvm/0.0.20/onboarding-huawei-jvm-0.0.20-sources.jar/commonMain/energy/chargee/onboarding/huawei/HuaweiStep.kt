package energy.chargee.onboarding.huawei

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [HuaweiOnboardingSession] surfaces through its typed state, each
 * carrying the data and callbacks a UI needs to advance it.
 */
@ObjCName("_HuaweiStep")
@Serializable
sealed interface HuaweiStep : OnboardingStep<LocalDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: LocalDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        HuaweiStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: LocalDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        val deviceUuid: String? = null,
        @Transient val retry: () -> Unit = {},
    ) : HuaweiStep

    /**
     * The flow is waiting for the user to set up the inverter's Wi-Fi. Call [setWifi] with the
     * chosen network, or [skipWifi] to continue over the local connection.
     */
    @Serializable
    data class AwaitingWifi(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConnectLocalWifi,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        @Transient val setWifi: (WifiConfiguration) -> Unit = { },
        @Transient val skipWifi: () -> Unit = {},
    ) : HuaweiStep

    /**
     * The Wi-Fi connection failed. Call [setWifiPassword] to retry with a corrected password.
     */
    @Serializable
    data class AwaitingWifiPassword(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConnectLocalWifi,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        @Transient val setWifiPassword: (String) -> Unit = { },
    ) : HuaweiStep

    /**
     * The flow needs the installer credentials to configure the inverter. Call [setCredentials]
     * with the username and password. [status] is [OnboardingStepStatus.WaitingForInput] the first
     * time they are requested and [OnboardingStepStatus.Failure] after a rejected attempt.
     */
    @Serializable
    data class AwaitingCredentials(
        override val id: LocalDeviceStepId = LocalDeviceStepId.ConfigureDevice,
        override val status: OnboardingStepStatus,
        val previousUsername: String? = null,
        val previousPassword: String? = null,
        @Transient val setCredentials: (username: String, password: String) -> Unit = { _, _ -> },
    ) : HuaweiStep

    /**
     * The flow is waiting for the user to pick which device to onboard from [possibleDevices]. Call
     * [setDevice] with the chosen device.
     */
    @Serializable
    data class AwaitingDevice(
        override val id: LocalDeviceStepId = LocalDeviceStepId.DiscoverDevice,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        val possibleDevices: List<DiscoveredDevice>,
        @Transient val setDevice: (DiscoveredDevice) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : HuaweiStep
}
