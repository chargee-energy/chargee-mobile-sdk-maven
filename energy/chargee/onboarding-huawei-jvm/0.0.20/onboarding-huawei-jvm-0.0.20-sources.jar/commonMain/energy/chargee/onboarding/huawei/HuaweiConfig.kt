package energy.chargee.onboarding.huawei

/**
 * Huawei-specific constants shared across the flow, module, and clients.
 */
object HuaweiConfig {
    /** Brand identifier used as the Huawei onboarding flow name, DI qualifier, and backend `brand` value. */
    const val BRAND = "huawei"

    /**
     * Standard Modbus TCP port used once the Chargee device can reach the inverter over the
     * customer's LAN. Contrast with [LOCAL_CONFIG_ENDPOINTS], which is only used while the
     * phone is joined to the inverter's own AP.
     */
    const val DEFAULT_PORT = 502

    /** Default installer username shipped by Huawei on new inverters. */
    const val DEFAULT_INSTALLER_USERNAME = "installer"

    /**
     * Default installer password shipped by Huawei on new inverters. If the user has changed
     * the installer password the flow reprompts for credentials instead of failing outright.
     */
    const val DEFAULT_INSTALLER_PASSWORD = "00000a"

    /**
     * Modbus TCP ports a Huawei inverter is known to serve from its own access point, most
     * likely first. The port tracks firmware rather than model: builds from around December
     * 2021 onward answer on `6607`, older ones on [DEFAULT_PORT].
     */
    internal val LOCAL_CONFIG_PORTS = listOf(6607, DEFAULT_PORT)

    /**
     * Known access point addresses, used only when the gateway of the joined network cannot be
     * resolved. The inverter is the gateway of its own access point, so
     * [energy.chargee.onboarding.huawei.clients.HuaweiLocalApiClient] asks
     * [energy.chargee.utils.wifi.WifiConnection.getGatewayAddress] first and falls back to this
     * list — which cannot be exhaustive, since the address varies by dongle and firmware.
     *
     * Note that `192.168.200.1:6607` silently drops the first request and only responds once an
     * identical retry arrives, so the shared
     * [energy.chargee.onboarding.localdevice.modbus.ModbusClient] retry loop is required (see
     * the `huawei-sun2000-modbus-quirk` note).
     */
    internal val LOCAL_CONFIG_ENDPOINTS =
        listOf("192.168.200.1", "192.168.88.1").flatMap { host ->
            LOCAL_CONFIG_PORTS.map { port -> HuaweiLocalEndpoint(host, port) }
        }

    /**
     * Every Modbus TCP port a Huawei inverter is known to listen on, used to seed the scan of
     * the customer's LAN once the inverter has left its own access point. [DEFAULT_PORT] comes
     * first, followed by any port from [LOCAL_CONFIG_PORTS] that differs from it — an inverter
     * configured over a non-standard port on its access point tends to keep serving that same
     * port on the LAN.
     */
    internal val MODBUS_PORTS: List<Int> = (listOf(DEFAULT_PORT) + LOCAL_CONFIG_PORTS).distinct()
}
