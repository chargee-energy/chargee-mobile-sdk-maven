package energy.chargee.onboarding.huawei

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the Huawei inverter onboarding flow. A flat, sealed hierarchy whose cases the
 * [HuaweiOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_HuaweiInput")
@Serializable
sealed interface HuaweiInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : HuaweiInput

    /**
     * Skips connecting the inverter to Wi-Fi and continues over the local connection. Accepted
     * while the flow is waiting for Wi-Fi setup.
     */
    @Serializable
    data object SkipWifiSetup : HuaweiInput

    /**
     * Connects the inverter to the [wifi] network. Accepted while the flow is waiting for Wi-Fi
     * setup.
     */
    @Serializable
    data class SetWifi(val wifi: WifiConfiguration) : HuaweiInput

    /**
     * Retries the Wi-Fi connection with a corrected [password]. Accepted after the Wi-Fi
     * connection has failed.
     */
    @Serializable
    data class SetWifiPassword(val password: String) : HuaweiInput

    /**
     * Supplies the installer [username] and [password] required to configure the inverter. Accepted
     * while the flow is paused on device configuration.
     */
    @Serializable
    data class SetCredentials(val username: String, val password: String) : HuaweiInput

    /**
     * Selects the [device] to onboard from those surfaced by device discovery. Accepted while the
     * flow is waiting for a device to be chosen.
     */
    @Serializable
    data class SetDevice(val device: DiscoveredDevice) : HuaweiInput

    /**
     * Re-runs device discovery. Accepted while the flow is waiting for a device to be chosen.
     */
    @Serializable
    data object RescanDevices : HuaweiInput
}
