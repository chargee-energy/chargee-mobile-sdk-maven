package energy.chargee.onboarding.huawei.clients

import energy.chargee.onboarding.huawei.HuaweiConfig
import energy.chargee.onboarding.huawei.HuaweiLocalEndpoint
import energy.chargee.onboarding.huawei.modbus.configureHuaweiInverter
import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.utils.wifi.WifiConfiguration
import energy.chargee.utils.wifi.WifiConnection
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.seconds

/**
 * Talks to the inverter over its own access point.
 *
 * The inverter is the gateway of the access point it broadcasts, so its address is read from
 * [WifiConnection.getGatewayAddress] rather than assumed; [fallbackEndpoints] covers the case
 * where no gateway can be resolved. The port cannot be resolved this way and still varies by
 * firmware, so each candidate address is tried on every port in [ports]. [configureAt] performs
 * one attempt against one endpoint and returns `null` when that endpoint did not answer.
 */
internal class HuaweiLocalApiClient(
    private val wifiConnection: WifiConnection,
    private val ports: List<Int> = HuaweiConfig.LOCAL_CONFIG_PORTS,
    private val fallbackEndpoints: List<HuaweiLocalEndpoint> = HuaweiConfig.LOCAL_CONFIG_ENDPOINTS,
    private val configureAt: suspend (HuaweiLocalEndpoint, String, String) -> HuaweiResponse? = ::configureHuaweiInverter,
) : HuaweiClient {
    /**
     * The endpoint that last answered, so the credential reprompt and the flow's configure
     * retries go straight to it instead of paying the connect timeout on every wrong candidate
     * again. Cleared by [disconnect], which ends the session this endpoint was valid for.
     */
    private var resolvedEndpoint: HuaweiLocalEndpoint? = null

    override suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean {
        val connected = wifiConnection.connect(wifiConfiguration, saveNetwork = true)

        if (connected) {
            // Give the device some time to properly initialize the connection
            delay(15.seconds)
            return true
        }

        return false
    }

    override suspend fun disconnect() {
        resolvedEndpoint = null
        val disconnected = wifiConnection.disconnect()
        if (disconnected) {
            // Give the device some time to reset the connection
            delay(5.seconds)
        }
    }

    override suspend fun configure(username: String, password: String): HuaweiResponse {
        val candidates = resolvedEndpoint?.let(::listOf) ?: candidateEndpoints()

        for (endpoint in candidates) {
            val response = configureAt(endpoint, username, password) ?: continue
            resolvedEndpoint = endpoint
            return response
        }

        return HuaweiResponse.Failed
    }

    /**
     * The gateway of the joined network on each known port first, then [fallbackEndpoints].
     * Deduplicated, so a gateway that matches a known address does not get probed twice.
     */
    private suspend fun candidateEndpoints(): List<HuaweiLocalEndpoint> {
        val gateway = wifiConnection.getGatewayAddress()

        return buildList {
            gateway?.let { host -> ports.forEach { port -> add(HuaweiLocalEndpoint(host, port)) } }
            addAll(fallbackEndpoints)
        }.distinct()
    }
}
