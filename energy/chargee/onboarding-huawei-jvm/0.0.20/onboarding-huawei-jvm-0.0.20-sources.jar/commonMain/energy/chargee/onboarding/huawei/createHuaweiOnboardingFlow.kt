package energy.chargee.onboarding.huawei

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.localdevice.enums.LocalDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.models.LocalDeviceConfigField
import energy.chargee.data.localdevice.repositories.InverterRepository
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry
import energy.chargee.onboarding.huawei.HuaweiConfig.BRAND
import energy.chargee.onboarding.huawei.HuaweiConfig.MODBUS_PORTS
import energy.chargee.onboarding.huawei.clients.HuaweiClient
import energy.chargee.onboarding.huawei.steps.ConfigureDeviceStep
import energy.chargee.onboarding.huawei.steps.ConnectLocalWifiStep
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.onboarding.localdevice.discoverChargeeDeviceStep
import energy.chargee.onboarding.localdevice.discoverDeviceStep
import energy.chargee.onboarding.localdevice.registerOrUpdateDeviceStep
import energy.chargee.onboarding.localdevice.verifyInverterStep

/**
 * Builds the onboarding flow for a Huawei inverter behind the Chargee device identified by
 * [chargeeDeviceUuid] (of [chargeeDeviceType]) at [addressUuid].
 *
 * Steps run in order:
 * 1. Discover the Chargee device on the local network via [chargeeDeviceDiscovery].
 * 2. Prompt the user for the inverter's Wi-Fi credentials, then join the inverter's local AP via
 *    [huaweiClient].
 * 3. Run the Huawei challenge/response handshake and read back the LAN-side IP the inverter
 *    will use (skipped when no Wi-Fi configuration was captured). Reprompts for credentials if
 *    the shipped installer defaults are rejected.
 * 4. Scan the customer's LAN for the inverter using [huaweiDiscoveryFactory], seeded with the
 *    IP reported by the previous step and every port Huawei is known to expose
 *    ([HuaweiConfig.MODBUS_PORTS]).
 * 5. Register the discovered inverter through [localDeviceRepository], forwarding the captured
 *    installer credentials so the Chargee device can reach it.
 * 6. Poll [inverterRepository] until the Chargee device reports readings from the inverter,
 *    confirming end-to-end connectivity.
 *
 * When the context is seeded with a `deviceUuid` the flow resets that already-registered inverter
 * instead: steps 2 and 3 are skipped — the inverter is assumed to be configured already — and
 * step 5 updates the stored configuration with the rediscovered values rather than creating a
 * second registration.
 */
internal fun createHuaweiOnboardingFlow(
    addressUuid: String,
    chargeeDeviceUuid: String,
    chargeeDeviceType: ChargeeDeviceType,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    chargeeDeviceDiscovery: DeviceDiscovery,
    huaweiDiscoveryFactory: (ipAddress: String?, possiblePorts: List<Int>) -> DeviceDiscovery,
    huaweiClient: HuaweiClient,
    localDeviceRepository: LocalDeviceRepository,
    inverterRepository: InverterRepository,
) = createOnboardingFlow<LocalDeviceStepId, HuaweiOnboardingContext>(BRAND) {
    discoverChargeeDeviceStep(
        addressUuid,
        chargeeDeviceUuid,
        chargeeDeviceType,
        chargeeDeviceDiscovery,
        chargeeDeviceRepository,
    )
    whenTrue(condition = { it.deviceUuid == null }) {
        step(ConnectLocalWifiStep(huaweiClient))
        whenTrue(condition = { it.wifiConfiguration != null }) {
            step(
                ConfigureDeviceStep(huaweiClient),
                retryPolicy =
                    ExponentialBackoffRetry(
                        maxAttempts = LocalDeviceOnboardingConfig.CONFIGURATION_MAX_ATTEMPTS,
                        condition = { (it as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials != true },
                    ),
            )
        }
    }
    discoverDeviceStep { huaweiDiscoveryFactory(it.ipAddress, MODBUS_PORTS) }
    registerOrUpdateDeviceStep(
        addressUuid,
        chargeeDeviceType,
        chargeeDeviceUuid,
        localDeviceRepository,
        createConfig = { context, fields ->
            val username =
                requireNotNull(context.username) { "username must be set by ConfigureDeviceStep before RegisterDeviceStep runs" }
            val password =
                requireNotNull(context.password) { "password must be set by ConfigureDeviceStep before RegisterDeviceStep runs" }
            LocalDeviceConfig(
                type = LocalDeviceType.Inverter,
                connectionType = "huawei_tcp",
                deviceType = BRAND,
                brand = BRAND,
                model = context.model,
                config =
                    fields +
                        listOf(
                            LocalDeviceConfigField("tcp_login_username", username),
                            LocalDeviceConfigField("tcp_login_password", password),
                        ),
            )
        },
        createConfigFields = { context ->
            val selectedDevice =
                requireNotNull(context.selectedDevice) { "selectedDevice must be set by DiscoverDeviceStep before RegisterDeviceStep runs" }
            listOf(
                LocalDeviceConfigField("modbus_type", "tcp"),
                LocalDeviceConfigField("address", 0),
                LocalDeviceConfigField("ip", selectedDevice.ipAddress),
                LocalDeviceConfigField("port", selectedDevice.port ?: context.port),
                LocalDeviceOnboardingConfig.defaultPollIntervalConfig,
            )
        },
    )
    verifyInverterStep(addressUuid, inverterRepository)
}
