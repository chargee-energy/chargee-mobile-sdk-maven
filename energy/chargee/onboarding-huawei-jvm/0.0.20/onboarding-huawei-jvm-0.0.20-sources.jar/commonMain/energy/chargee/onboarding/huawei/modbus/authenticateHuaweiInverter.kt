package energy.chargee.onboarding.huawei.modbus

import energy.chargee.onboarding.localdevice.modbus.ModbusConnection
import energy.chargee.onboarding.localdevice.modbus.buildByteArray
import energy.chargee.onboarding.localdevice.modbus.hex
import energy.chargee.onboarding.localdevice.modbus.uint8
import energy.chargee.onboarding.localdevice.modbus.uint8At
import org.kotlincrypto.hash.sha2.SHA256
import org.kotlincrypto.macs.hmac.sha2.HmacSHA256
import kotlin.random.Random

/**
 * Vendor-specific Modbus function code Huawei uses for the auth handshake. Standard function
 * codes (`0x03` read holding, `0x06` write single, `0x10` write multiple, etc.) all fail with
 * a Modbus exception until the connection has authenticated through this one.
 */
val HUAWEI_FC_VENDOR = 0x41.uint8

/** Sub-command (first PDU byte after the function code) requesting the server nonce. */
val HUAWEI_SUB_CHALLENGE = 0x24.uint8

/** Sub-command (first PDU byte after the function code) submitting credentials and the server-nonce HMAC. */
val HUAWEI_SUB_LOGIN = 0x25.uint8

/** Size of the nonce exchanged in each direction during the handshake. */
const val HUAWEI_NONCE_SIZE = 16

/** Size of the HMAC-SHA256 output exchanged in each direction. */
const val HUAWEI_HMAC_SIZE = 32

/** Marker byte that prefixes the server nonce in a challenge response. */
val CHALLENGE_RESP_MARKER = 0x11.uint8

/** Status byte indicating the inverter accepted the credentials. */
val LOGIN_RESP_STATUS_OK = 0x00.uint8

/**
 * Performs the Huawei challenge/response handshake on this [ModbusConnection] using [username]
 * and [password]. Holding-register writes on Huawei inverters are refused until the connection
 * has authenticated through this handshake; reads work without it.
 *
 * The protocol is two round-trips over vendor function code `0x41`:
 *
 * ```
 * 1. CHALLENGE
 *    Client -> [FC=0x41, sub=0x24, 0x01, 0x00]
 *    Server -> [FC=0x41, sub=0x24, 0x11, <16-byte serverNonce>]
 *
 * 2. LOGIN
 *    Client -> [FC=0x41, sub=0x25, payloadLength,
 *               <16-byte clientNonce>,
 *               usernameLength, <username>,
 *               hashLength=32, <HMAC-SHA256(SHA256(password), serverNonce)>]
 *    Server -> [FC=0x41, sub=0x25, marker, status=0x00,
 *               hashLength=32, <HMAC-SHA256(SHA256(password), clientNonce)>]
 * ```
 *
 * The two HMACs in opposite directions give MUTUAL authentication: the inverter proves it
 * knows the password (without sending it) by HMAC'ing the client's nonce, and the client
 * proves the same to it by HMAC'ing the server's nonce. Either side rejects on mismatch. The
 * fresh nonces on each handshake prevent replay.
 *
 * The HMAC key is `SHA-256(password)` rather than the raw password — standard key stretching
 * so a passive observer who somehow recovers the key on the wire can't trivially recover the
 * password from it.
 *
 * @throws IllegalStateException if the response framing is unexpected, the inverter rejects
 *   the credentials with a non-zero status, or the server-side HMAC fails to match (the last
 *   case indicates a wrong password, a replayed exchange, or a MITM).
 */
suspend fun ModbusConnection.authenticateHuaweiInverter(username: String, password: String) {
    // =========================================================================
    // STEP 1: ask the inverter for its nonce (the "server challenge")
    // =========================================================================
    //
    // The 0x01, 0x00 trailing bytes after the sub-command are constants Huawei
    // documents but doesn't explain — likely a protocol-version / capability
    // selector. Sending anything else gets us an immediate Modbus exception.
    val challengeResponse =
        exchangeRawPdu(
            buildByteArray {
                uint8(HUAWEI_FC_VENDOR)
                uint8(HUAWEI_SUB_CHALLENGE)
                uint8(0x01)
                uint8(0x00)
            },
        )

    // Refuse to continue if the response shape doesn't match what Huawei
    // documents — a wrong sub-command echo or missing 0x11 marker means we're
    // either talking to a non-Huawei device or there's a frame-alignment bug.
    val subChallenge = challengeResponse.uint8At(1)
    val marker = challengeResponse.uint8At(2)
    check(subChallenge == HUAWEI_SUB_CHALLENGE && marker == CHALLENGE_RESP_MARKER) {
        "Unexpected challenge header: sub=$subChallenge, marker=$marker"
    }

    val serverNonce = challengeResponse.copyOfRange(3, 3 + HUAWEI_NONCE_SIZE)

    // Generate OUR side of the nonce pair. Random.nextInt uses the hardware
    // RNG when available — important here, because the security of the mutual
    // auth depends on this being unpredictable to anyone watching the wire.
    val clientNonce = ByteArray(HUAWEI_NONCE_SIZE) { Random.nextInt(0, 0xFF).toByte() }

    // =========================================================================
    // STEP 2 (prep): derive the HMAC key and the proof we'll send
    // =========================================================================
    //
    // The HMAC key is SHA-256(password), not the password itself. See file header.
    val hmacKey = sha256(password.encodeToByteArray())

    // Our proof to the inverter: HMAC of THE INVERTER's nonce. The inverter
    // can recompute this with the same hashed password key and check it matches.
    val clientProof = hmacSha256(hmacKey, serverNonce)
    val userNameBytes = username.encodeToByteArray()
    val payloadLength = HUAWEI_NONCE_SIZE + 1 + userNameBytes.size + 1 + HUAWEI_HMAC_SIZE

    // =========================================================================
    // STEP 2 (send): assemble and submit the login PDU
    // =========================================================================
    //
    // Layout after the FC byte:
    //
    //     [sub=0x25] [payloadLength] [clientNonce x16] [usernameLength] [username]
    //                                                           [hashLength=32] [clientProof x32]
    //
    // payloadLength covers everything from clientNonce to the end of clientProof
    // — i.e. the full TLV-style payload but NOT the sub-cmd or payloadLength bytes
    // themselves. The format is essentially three length-prefixed blobs glued
    // together, with a redundant total length up front for the inverter's
    // bounds check.
    val authResponse =
        exchangeRawPdu(
            buildByteArray {
                uint8(HUAWEI_FC_VENDOR)
                uint8(HUAWEI_SUB_LOGIN)
                uint8(payloadLength)
                byteArray(clientNonce)
                uint8(userNameBytes.size)
                byteArray(userNameBytes)
                uint8(HUAWEI_HMAC_SIZE)
                byteArray(clientProof)
            },
        )

    // =========================================================================
    // STEP 3 (verify): make sure the inverter is also who it claims to be
    // =========================================================================
    //
    // Sanity-check the response framing before trusting any of the bytes.
    val sub = authResponse.uint8At(1)
    check(sub == HUAWEI_SUB_LOGIN) {
        "Unexpected login sub-command echo: sub=${sub.hex}"
    }

    // Status byte != 0 means the inverter rejected our credentials. The most
    // common cause is a wrong username/password, but it can also be a locked-out
    // user (too many failed attempts) or a service-account-only register.
    val status = authResponse.uint8At(3)
    check(status == LOGIN_RESP_STATUS_OK) {
        "Inverter rejected login: status=${status.hex}"
    }

    val hmacSize = authResponse.uint8At(4).value
    check(hmacSize == HUAWEI_HMAC_SIZE) {
        "Unexpected HMAC length in response: $hmacSize"
    }

    // The inverter's proof to US: HMAC of OUR nonce with the same hashed-password
    // key. We recompute it locally and compare; if it doesn't match, either the
    // inverter doesn't actually know the password, or we're talking to a MITM.
    val expectedServerProof = hmacSha256(hmacKey, clientNonce)
    val serverProof = authResponse.copyOfRange(5, 5 + HUAWEI_HMAC_SIZE)

    check(expectedServerProof.contentEquals(serverProof)) {
        "Login HMAC mismatch — wrong credentials, replay, or MITM"
    }
}

private fun sha256(data: ByteArray): ByteArray = SHA256().digest(data)

private fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray = HmacSHA256(key).doFinal(data)
