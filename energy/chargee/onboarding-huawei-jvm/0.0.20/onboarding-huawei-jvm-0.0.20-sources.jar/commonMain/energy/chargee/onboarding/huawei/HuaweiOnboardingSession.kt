package energy.chargee.onboarding.huawei

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for Huawei inverters. Routes [HuaweiInput] — device selection, Wi-Fi setup,
 * Wi-Fi password retry, and installer credentials — and surfaces [HuaweiStep]s in its typed state.
 */
@OnboardingSession
class HuaweiOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, HuaweiOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, HuaweiOnboardingContext, HuaweiStep, HuaweiInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered inverter: the local-AP association and device
     * configuration steps are skipped, and instead of registering a new inverter the flow updates
     * the stored configuration with the rediscovered values before re-verifying.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [HuaweiStep]s. A started step becomes [HuaweiStep.Running].
     * On a pause for input, Wi-Fi setup becomes [HuaweiStep.AwaitingWifi], device configuration
     * becomes [HuaweiStep.AwaitingCredentials], and device discovery becomes
     * [HuaweiStep.AwaitingDevice]. On a failure, a failed Wi-Fi connection becomes
     * [HuaweiStep.AwaitingWifiPassword], invalid installer credentials become
     * [HuaweiStep.AwaitingCredentials] in a failure state, and anything else becomes
     * [HuaweiStep.Failure] carrying a retry callback. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, HuaweiStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, HuaweiOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, HuaweiStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = HuaweiStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == LocalDeviceStepId.ConnectLocalWifi -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.AwaitingWifiPassword {
                                    submit(HuaweiInput.SetWifiPassword(it))
                                },
                        )
                    }

                    event.stepId == LocalDeviceStepId.ConfigureDevice &&
                        (event.errorCode as? LocalDeviceErrorCode.DeviceConfigurationFailure)?.invalidCredentials == true -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.AwaitingCredentials(
                                    status = OnboardingStepStatus.Failure,
                                    previousUsername = event.context.password,
                                    previousPassword = event.context.password,
                                ) { username, password ->
                                    submit(HuaweiInput.SetCredentials(username, password))
                                },
                        )
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.Failure(
                                    event.stepId,
                                    error = event.errorCode,
                                    deviceUuid = event.context.deviceUuid,
                                ) {
                                    submit(HuaweiInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.ConnectLocalWifi -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.AwaitingWifi(
                                    setWifi = { submit(HuaweiInput.SetWifi(it)) },
                                    skipWifi = { submit(HuaweiInput.SkipWifiSetup) },
                                ),
                        )
                    }

                    LocalDeviceStepId.ConfigureDevice -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.AwaitingCredentials(status = OnboardingStepStatus.WaitingForInput) { username, password ->
                                    submit(HuaweiInput.SetCredentials(username, password))
                                },
                        )
                    }

                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                HuaweiStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(HuaweiInput.SetDevice(it)) },
                                    rescan = { submit(HuaweiInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [HuaweiInput]: [Retry][HuaweiInput.Retry] re-runs a failed step;
     * [SkipWifiSetup][HuaweiInput.SkipWifiSetup] and [SetWifi][HuaweiInput.SetWifi] act while
     * waiting for Wi-Fi setup; [SetWifiPassword][HuaweiInput.SetWifiPassword] retries after a failed
     * Wi-Fi connection; [SetCredentials][HuaweiInput.SetCredentials] applies while paused on device
     * configuration; and [SetDevice][HuaweiInput.SetDevice] selects the device while waiting on
     * discovery.
     */
    override fun submit(input: HuaweiInput): SubmitResult =
        when (input) {
            HuaweiInput.Retry -> {
                requireFailure { engine.resume() }
            }

            HuaweiInput.SkipWifiSetup -> {
                requireWaitingForInput(LocalDeviceStepId.ConnectLocalWifi) {
                    engine.advance()
                }
            }

            is HuaweiInput.SetWifi -> {
                requireWaitingForInput(LocalDeviceStepId.ConnectLocalWifi) {
                    engine.resume { it.copy(wifiConfiguration = input.wifi) }
                }
            }

            is HuaweiInput.SetWifiPassword -> {
                requireFailure(LocalDeviceStepId.ConnectLocalWifi) {
                    engine.resume {
                        it.copy(wifiConfiguration = it.wifiConfiguration?.copy(password = input.password))
                    }
                }
            }

            is HuaweiInput.SetCredentials -> {
                requirePaused(LocalDeviceStepId.ConfigureDevice) {
                    engine.resume { it.copy(username = input.username, password = input.password) }
                }
            }

            is HuaweiInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            HuaweiInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }
        }
}
