package energy.chargee.onboarding.huawei

import energy.chargee.discovery.core.DiscoveredDevice
import energy.chargee.onboarding.huawei.HuaweiConfig.DEFAULT_INSTALLER_PASSWORD
import energy.chargee.onboarding.huawei.HuaweiConfig.DEFAULT_INSTALLER_USERNAME
import energy.chargee.onboarding.huawei.HuaweiConfig.DEFAULT_PORT
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.utils.wifi.WifiConfiguration

/**
 * The mutable context that flows through the Huawei onboarding steps.
 *
 * Extends [LocalDeviceOnboardingContext] with Huawei-specific fields. [wifiConfiguration] holds
 * the credentials for the inverter's local AP and is required by
 * [energy.chargee.onboarding.huawei.steps.ConnectLocalWifiStep]. [username] and [password]
 * default to Huawei's installer credentials; if those are rejected the flow re-prompts and
 * the user-provided values are written back here. [ipAddress] is filled by
 * [energy.chargee.onboarding.huawei.steps.ConfigureDeviceStep] once the inverter reports the
 * IP it will use on the customer's LAN, and is used to narrow the follow-up port scan.
 * [port] is the fallback Modbus TCP port used at registration time when the discovery result
 * doesn't include one, and defaults to [HuaweiConfig.DEFAULT_PORT].
 */
data class HuaweiOnboardingContext(
    override val model: String? = null,
    override val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    override val selectedDevice: DiscoveredDevice? = null,
    override val deviceUuid: String? = null,
    val port: Int = DEFAULT_PORT,
    val wifiConfiguration: WifiConfiguration? = null,
    val username: String = DEFAULT_INSTALLER_USERNAME,
    val password: String = DEFAULT_INSTALLER_PASSWORD,
    val ipAddress: String? = null,
) : LocalDeviceOnboardingContext<HuaweiOnboardingContext> {
    override fun copyWith(
        model: String?,
        discoveredDevices: List<DiscoveredDevice>,
        selectedDevice: DiscoveredDevice?,
        deviceUuid: String?,
    ) = copy(
        model = model,
        discoveredDevices = discoveredDevices,
        selectedDevice = selectedDevice,
        deviceUuid = deviceUuid,
    )
}
