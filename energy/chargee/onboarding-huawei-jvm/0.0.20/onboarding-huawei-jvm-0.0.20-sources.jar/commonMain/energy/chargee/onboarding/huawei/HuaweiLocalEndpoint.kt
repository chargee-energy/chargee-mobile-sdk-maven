package energy.chargee.onboarding.huawei

/**
 * A [host]/[port] pair a Huawei inverter may serve Modbus TCP on while the phone is joined to
 * the inverter's own access point.
 *
 * Which pair applies is not something the flow can ask the inverter beforehand — it depends on
 * the dongle and its firmware — so [HuaweiConfig.LOCAL_CONFIG_ENDPOINTS] lists the known ones
 * and they are tried in order.
 */
internal data class HuaweiLocalEndpoint(val host: String, val port: Int)
