package energy.chargee.onboarding.huawei.steps

import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.huawei.HuaweiConfig.DEFAULT_INSTALLER_PASSWORD
import energy.chargee.onboarding.huawei.HuaweiConfig.DEFAULT_INSTALLER_USERNAME
import energy.chargee.onboarding.huawei.HuaweiOnboardingContext
import energy.chargee.onboarding.huawei.clients.HuaweiClient
import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

internal class ConfigureDeviceStep(private val client: HuaweiClient) :
    OnboardingFlow.Step<LocalDeviceStepId, HuaweiOnboardingContext>() {
    override val id = LocalDeviceStepId.ConfigureDevice

    override suspend fun execute(context: HuaweiOnboardingContext): Result<HuaweiOnboardingContext> =
        when (val result = client.configure(context.username, context.password)) {
            HuaweiResponse.Unauthenticated -> {
                if (context.username == DEFAULT_INSTALLER_USERNAME && context.password == DEFAULT_INSTALLER_PASSWORD) {
                    Result.InputRequired(
                        context,
                        advanceAfterInput = false,
                    )
                } else {
                    Result.Failure(
                        context,
                        LocalDeviceErrorCode.DeviceConfigurationFailure(invalidCredentials = true),
                    )
                }
            }

            HuaweiResponse.Failed -> {
                Result.Failure(
                    context,
                    LocalDeviceErrorCode.DeviceConfigurationFailure(),
                )
            }

            is HuaweiResponse.Success -> {
                Result.Success(context.copy(ipAddress = result.ipAddress))
            }
        }

    override suspend fun onFinished(context: HuaweiOnboardingContext) {
        client.disconnect()
    }
}
