package energy.chargee.onboarding.huawei.clients

import energy.chargee.onboarding.huawei.models.HuaweiResponse
import energy.chargee.utils.wifi.WifiConfiguration

/**
 * Client for talking to a Huawei inverter over its local access point.
 *
 * The onboarding flow joins the inverter's own Wi-Fi network and then runs the Huawei-specific
 * Modbus handshake to authenticate and read back the IP the inverter will use on the customer's
 * LAN. Implementations own the Wi-Fi and Modbus resources for the session; callers must invoke
 * [disconnect] when done.
 */
interface HuaweiClient {
    /**
     * Joins the inverter's local Wi-Fi network using [wifiConfiguration]. Returns `true` when the
     * device is reachable over the joined network and `false` if the association or the follow-up
     * initialization failed.
     */
    suspend fun connect(wifiConfiguration: WifiConfiguration): Boolean

    /**
     * Leaves the inverter's local Wi-Fi network and releases any Modbus/HTTP resources held by
     * the client. Safe to call from step lifecycle hooks even when [connect] never succeeded.
     */
    suspend fun disconnect()

    /**
     * Runs the Huawei challenge/response Modbus handshake using [username] and [password] and,
     * on success, returns the inverter's LAN-side IP address inside [HuaweiResponse.Success].
     *
     * Returns [HuaweiResponse.Unauthenticated] when credentials are rejected and
     * [HuaweiResponse.Failed] for any other Modbus-level failure.
     */
    suspend fun configure(username: String, password: String): HuaweiResponse
}
