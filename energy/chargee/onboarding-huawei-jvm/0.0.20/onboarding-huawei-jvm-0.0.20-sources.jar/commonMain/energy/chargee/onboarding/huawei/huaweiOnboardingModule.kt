package energy.chargee.onboarding.huawei

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.CompositeDeviceDiscovery
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.huawei.HuaweiConfig.BRAND
import energy.chargee.onboarding.huawei.clients.HuaweiClient
import energy.chargee.onboarding.huawei.clients.HuaweiLocalApiClient
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig
import kotlin.time.Duration.Companion.seconds

val huaweiOnboardingModule =
    module {
        factory<HuaweiClient> { HuaweiLocalApiClient(get()) }
        factoryWithParameters<DeviceDiscovery>(name = BRAND) { parameters ->
            val ipAddress: String? = parameters.get(0)
            val ports: List<Int> = parameters.get(1)

            if (ipAddress != null) {
                get<DeviceDiscovery>(
                    name = DiscoveryConfig.OPEN_PORT_DISCOVERY_TYPE,
                    parameters = parametersOf(ipAddress, ports, 1.seconds),
                )
            } else {
                CompositeDeviceDiscovery(
                    *ports
                        .map { port ->
                            get<DeviceDiscovery>(
                                name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE,
                                parameters = parametersOf(port),
                            )
                        }.toTypedArray(),
                )
            }
        }
        factoryWithParameters { parameters ->
            HuaweiOnboardingSession(
                OnboardingEngine(
                    initialContext = HuaweiOnboardingContext(),
                    flow =
                        createHuaweiOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            huaweiDiscoveryFactory = { ipAddress, possiblePorts ->
                                get<DeviceDiscovery>(
                                    name = BRAND,
                                    parameters = parametersOf(ipAddress, possiblePorts),
                                )
                            },
                            huaweiClient = get(),
                            localDeviceRepository = get(),
                            inverterRepository = get(),
                        ),
                ),
            )
        }
    }
