package energy.chargee.data.correctionfactor.converters

import energy.chargee.data.correctionfactor.dtos.CorrectionFactorDto
import energy.chargee.data.correctionfactor.models.CorrectionFactor

internal fun CorrectionFactorDto.asCorrectionFactor() =
    CorrectionFactor(
        uuid = uuid,
        info = info.asCorrectionFactorInfo(),
    )
