package energy.chargee.data.correctionfactor.models

import kotlin.native.ObjCName

/**
 * Threshold values used to correct electricity measurement readings for an address.
 *
 * All fields are optional — only the thresholds relevant to the address need to be set.
 */
@ObjCName("_CorrectionFactorInfo")
data class CorrectionFactorInfo(
    val currentThresholdPrimary: Float? = null,
    val currentThresholdSecondary: Float? = null,
    val voltageThresholdPrimary: Float? = null,
    val voltageThresholdSecondary: Float? = null,
)
