package energy.chargee.data.correctionfactor.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.correctionfactor.dtos.CorrectionFactorDto
import energy.chargee.data.correctionfactor.dtos.CorrectionFactorInfoDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody

internal class CorrectionFactorApiClient(private val httpClient: HttpClient) {
    suspend fun getCorrectionFactors(addressUuid: String): PaginatedResponseDto<PaginatedMetaDto, CorrectionFactorDto> =
        httpClient.get("/v5/addresses/$addressUuid/correction-factors").body()

    suspend fun createCorrectionFactor(addressUuid: String, info: CorrectionFactorInfoDto): CorrectionFactorDto =
        httpClient.post("/v5/addresses/$addressUuid/correction-factors") { setBody(info) }.body()

    suspend fun getCorrectionFactor(addressUuid: String, correctionFactorUuid: String): CorrectionFactorDto =
        httpClient.get("/v5/addresses/$addressUuid/correction-factors/$correctionFactorUuid").body()

    suspend fun deleteCorrectionFactor(addressUuid: String, correctionFactorUuid: String) {
        httpClient.delete("/v5/addresses/$addressUuid/correction-factors/$correctionFactorUuid")
    }
}
