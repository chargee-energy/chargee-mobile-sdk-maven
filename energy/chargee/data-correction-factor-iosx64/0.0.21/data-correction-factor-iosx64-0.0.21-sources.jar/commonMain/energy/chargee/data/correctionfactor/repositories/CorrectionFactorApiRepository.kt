package energy.chargee.data.correctionfactor.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.correctionfactor.clients.CorrectionFactorApiClient
import energy.chargee.data.correctionfactor.converters.asCorrectionFactor
import energy.chargee.data.correctionfactor.converters.asDto
import energy.chargee.data.correctionfactor.dtos.CorrectionFactorDto
import energy.chargee.data.correctionfactor.models.CorrectionFactor
import energy.chargee.data.correctionfactor.models.CorrectionFactorInfo
import energy.chargee.utils.result.Result

internal class CorrectionFactorApiRepository(private val correctionFactorApiClient: CorrectionFactorApiClient) :
    CorrectionFactorRepository {
    override suspend fun getCorrectionFactors(addressUuid: String): Result<List<CorrectionFactor>, ApiError> =
        runApi { correctionFactorApiClient.getCorrectionFactors(addressUuid).results.map(CorrectionFactorDto::asCorrectionFactor) }

    override suspend fun createCorrectionFactor(addressUuid: String, info: CorrectionFactorInfo): Result<CorrectionFactor, ApiError> =
        runApi { correctionFactorApiClient.createCorrectionFactor(addressUuid, info.asDto()).asCorrectionFactor() }

    override suspend fun getCorrectionFactor(addressUuid: String, correctionFactorUuid: String): Result<CorrectionFactor, ApiError> =
        runApi { correctionFactorApiClient.getCorrectionFactor(addressUuid, correctionFactorUuid).asCorrectionFactor() }

    override suspend fun deleteCorrectionFactor(addressUuid: String, correctionFactorUuid: String): Result<Unit, ApiError> =
        runApi { correctionFactorApiClient.deleteCorrectionFactor(addressUuid, correctionFactorUuid) }
}
