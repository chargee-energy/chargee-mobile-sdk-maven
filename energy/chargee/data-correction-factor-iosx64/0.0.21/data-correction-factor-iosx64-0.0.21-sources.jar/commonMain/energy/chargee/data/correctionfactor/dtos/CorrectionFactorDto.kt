package energy.chargee.data.correctionfactor.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class CorrectionFactorDto(val uuid: String, val info: CorrectionFactorInfoDto)
