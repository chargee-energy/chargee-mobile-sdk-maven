package energy.chargee.data.correctionfactor.models

import kotlin.native.ObjCName

/**
 * A correction factor applied to electricity measurements for a specific address.
 */
@ObjCName("_CorrectionFactor")
data class CorrectionFactor(val uuid: String, val info: CorrectionFactorInfo)
