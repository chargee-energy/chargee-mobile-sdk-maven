package energy.chargee.data.correctionfactor.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class CorrectionFactorInfoDto(
    val currentThresholdPrimary: Float? = null,
    val currentThresholdSecondary: Float? = null,
    val voltageThresholdPrimary: Float? = null,
    val voltageThresholdSecondary: Float? = null,
)
