package energy.chargee.data.correctionfactor.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.correctionfactor.models.CorrectionFactor
import energy.chargee.data.correctionfactor.models.CorrectionFactorInfo
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to correction factors for an address.
 */
@Repository
@ObjCName("_CorrectionFactorRepository")
interface CorrectionFactorRepository {
    /**
     * Fetches all correction factors for [addressUuid].
     */
    suspend fun getCorrectionFactors(addressUuid: String): Result<List<CorrectionFactor>, ApiError>

    /**
     * Creates a new correction factor for [addressUuid] with the given [info],
     * returning the created [CorrectionFactor].
     */
    suspend fun createCorrectionFactor(addressUuid: String, info: CorrectionFactorInfo): Result<CorrectionFactor, ApiError>

    /**
     * Fetches the correction factor identified by [correctionFactorUuid] for [addressUuid].
     */
    suspend fun getCorrectionFactor(addressUuid: String, correctionFactorUuid: String): Result<CorrectionFactor, ApiError>

    /**
     * Deletes the correction factor identified by [correctionFactorUuid] for [addressUuid].
     */
    suspend fun deleteCorrectionFactor(addressUuid: String, correctionFactorUuid: String): Result<Unit, ApiError>
}
