package energy.chargee.data.correctionfactor.converters

import energy.chargee.data.correctionfactor.dtos.CorrectionFactorInfoDto
import energy.chargee.data.correctionfactor.models.CorrectionFactorInfo

internal fun CorrectionFactorInfoDto.asCorrectionFactorInfo() =
    CorrectionFactorInfo(
        currentThresholdPrimary = currentThresholdPrimary,
        currentThresholdSecondary = currentThresholdSecondary,
        voltageThresholdPrimary = voltageThresholdPrimary,
        voltageThresholdSecondary = voltageThresholdSecondary,
    )

internal fun CorrectionFactorInfo.asDto() =
    CorrectionFactorInfoDto(
        currentThresholdPrimary = currentThresholdPrimary,
        currentThresholdSecondary = currentThresholdSecondary,
        voltageThresholdPrimary = voltageThresholdPrimary,
        voltageThresholdSecondary = voltageThresholdSecondary,
    )
