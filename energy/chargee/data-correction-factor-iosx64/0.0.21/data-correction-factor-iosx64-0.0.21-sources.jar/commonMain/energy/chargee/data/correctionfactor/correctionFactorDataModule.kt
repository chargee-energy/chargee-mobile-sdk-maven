package energy.chargee.data.correctionfactor

import energy.chargee.core.di.module
import energy.chargee.data.correctionfactor.clients.CorrectionFactorApiClient
import energy.chargee.data.correctionfactor.repositories.CorrectionFactorApiRepository
import energy.chargee.data.correctionfactor.repositories.CorrectionFactorRepository

val correctionFactorDataModule =
    module {
        factory { CorrectionFactorApiClient(get()) }
        factory<CorrectionFactorRepository> { CorrectionFactorApiRepository(get()) }
    }
