package energy.chargee.sdk

import energy.chargee.core.logging.ChargeeLogger
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the JVM [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production], and sending everything it logs to
 * [logger] — omit it and the SDK logs nothing.
 *
 * For development only — see [ChargeeSdkJvm] for what a desktop cannot do. A throwaway `main` is
 * the usual shape:
 *
 * ```kotlin
 * suspend fun main() {
 *     val sdk = ChargeeSdk(tokenProvider = { "<a bearer token>" }, environment = Environment.staging) { level, tag, message, _ ->
 *         println("[$level] $tag: $message")
 *     }
 *     println(sdk.data.smartMeter.getSmartMeters(addressUuid))
 * }
 * ```
 */
@Suppress("ktlint:standard:function-naming")
fun ChargeeSdk(
    tokenProvider: TokenProvider,
    environment: Environment = Environment.production,
    logger: ChargeeLogger? = null,
): ChargeeSdk = ChargeeSdkJvm(environment, tokenProvider, logger)
