package energy.chargee.sdk

import energy.chargee.core.di.module
import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider
import energy.chargee.discovery.mdns.mdnsDiscoveryModuleJvm
import energy.chargee.onboarding.chargeedevice.chargeeDeviceOnboardingModuleJvm
import energy.chargee.utils.wifi.LocalAddressProvider
import energy.chargee.utils.wifi.LocalAddressProviderJvm
import energy.chargee.utils.wifi.WifiConnection
import energy.chargee.utils.wifi.WifiConnectionJvm

/**
 * The JVM [ChargeeSdk], which exists so the SDK can be driven from a desktop while it is being
 * worked on — a `main`, a scratch file, or a debugger — instead of only from a phone.
 *
 * It is **not a shipping target**. Three of the four platform seams have no desktop equivalent and
 * are filled with implementations that report the capability as absent rather than emulate it:
 *
 * - [WifiConnectionJvm] cannot join a network, so a flow that configures an inverter over its own
 *   access point cannot run here.
 * - [mdnsDiscoveryModuleJvm] finds nothing, so every onboarding flow stops at the step that locates
 *   the Chargee device.
 * - [chargeeDeviceOnboardingModuleJvm] reports Bluetooth as unavailable, so a Sparky or Flint cannot
 *   be provisioned here.
 *
 * What does work is the part most worth debugging off-device: every `sdk.data` repository against a
 * real backend, the subnet scan and UDP discoveries, Modbus, and the local web APIs of the Alfen
 * charger and the SMA inverter. [LocalAddressProviderJvm] is a real implementation for that reason —
 * the discoveries derive their range from it.
 */
internal class ChargeeSdkJvm(environment: Environment, tokenProvider: TokenProvider) : ChargeeSdk(environment, tokenProvider) {
    init {
        dependencyRegistry.registerModule(
            module {
                factory<WifiConnection> { WifiConnectionJvm() }
                lazySingleton<LocalAddressProvider> { LocalAddressProviderJvm() }
            },
        )
        dependencyRegistry.registerModule(mdnsDiscoveryModuleJvm)
        dependencyRegistry.registerModule(chargeeDeviceOnboardingModuleJvm)
    }
}
