package energy.chargee.sdk

import energy.chargee.core.network.Environment
import energy.chargee.core.network.providers.TokenProvider

/**
 * Creates the JVM [ChargeeSdk], authenticating its requests with [tokenProvider] against
 * [environment], which defaults to [Environment.production].
 *
 * For development only — see [ChargeeSdkJvm] for what a desktop cannot do. A throwaway `main` is
 * the usual shape:
 *
 * ```kotlin
 * suspend fun main() {
 *     val sdk = ChargeeSdk(tokenProvider = { "<a bearer token>" }, environment = Environment.staging)
 *     println(sdk.data.price.getElectricityPrices(addressUuid, from, to))
 * }
 * ```
 */
@Suppress("ktlint:standard:function-naming")
fun ChargeeSdk(tokenProvider: TokenProvider, environment: Environment = Environment.production): ChargeeSdk =
    ChargeeSdkJvm(environment, tokenProvider)
