package energy.chargee.utils.concurrency

import kotlinx.coroutines.CancellableContinuation
import kotlin.concurrent.atomics.AtomicBoolean
import kotlin.concurrent.atomics.ExperimentalAtomicApi
import kotlin.coroutines.resume

/**
 * One-shot resume gate for a [CancellableContinuation] driven by a callback API that may
 * invoke its completion handler more than once.
 *
 * Wraps the raw [continuation] so every terminal-resume site can route through [resumeOnce]
 * without worrying about double-resume crashes ([IllegalStateException]) when the callback
 * source fires a "failed" callback after a "success" callback, or when a callback fires
 * after the coroutine has already been cancelled.
 *
 * The two-stage guard (atomic `compareAndSet`, then [CancellableContinuation.isActive])
 * eliminates both double-resume and resume-after-cancellation. The [CancellableContinuation.isActive]
 * check is required because `compareAndSet` does not observe cancellation.
 */
@OptIn(ExperimentalAtomicApi::class)
class ResumeOnce<T>(private val continuation: CancellableContinuation<T>) {
    private val resumed = AtomicBoolean(false)

    /**
     * Resumes the wrapped [CancellableContinuation] with [value] if and only if no prior
     * call to [resumeOnce] has won the race and the continuation is still active.
     * Subsequent calls are silently dropped.
     */
    fun resumeOnce(value: T) {
        if (resumed.compareAndSet(expectedValue = false, newValue = true) && continuation.isActive) {
            continuation.resume(value)
        }
    }
}
