package energy.chargee.data.electricity.live.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Active power readings broken down by phase.
 *
 * [total] is the combined power across all phases. [phaseOne], [phaseTwo], and [phaseThree]
 * are per-phase readings; they are `null` when the meter does not report phase-level data.
 */
@Serializable
@ObjCName("_ActivePower")
data class ActivePower(val total: Power, val phaseOne: Power? = null, val phaseTwo: Power? = null, val phaseThree: Power? = null)
