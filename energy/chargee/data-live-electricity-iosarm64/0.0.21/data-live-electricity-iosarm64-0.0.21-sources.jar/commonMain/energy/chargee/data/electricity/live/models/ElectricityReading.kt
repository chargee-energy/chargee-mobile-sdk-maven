package energy.chargee.data.electricity.live.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A single electricity meter reading.
 *
 * [time] is the moment the reading was taken. [activePower] contains the power measurements.
 * [current] and [currentCalculated] are per-phase current readings (`null` if the meter does
 * not support them). [voltage] contains per-phase voltage readings (`null` if unsupported).
 */
@Serializable
@ObjCName("_ElectricityReading")
data class ElectricityReading(
    val time: Instant,
    val activePower: ActivePower,
    val current: Current? = null,
    val currentCalculated: Current? = null,
    val voltage: Voltage? = null,
)
