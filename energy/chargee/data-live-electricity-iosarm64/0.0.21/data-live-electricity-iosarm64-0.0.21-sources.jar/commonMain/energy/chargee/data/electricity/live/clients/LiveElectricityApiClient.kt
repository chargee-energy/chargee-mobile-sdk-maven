package energy.chargee.data.electricity.live.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.electricity.live.dtos.ElectricityReadingDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter

internal class LiveElectricityApiClient(private val httpClient: HttpClient) {
    suspend fun getElectricityReadings(
        addressUuid: String,
        fromDate: String,
        toDate: String,
        limit: Int,
        sortOrder: String,
    ): PaginatedResponseDto<PaginatedMetaDto, ElectricityReadingDto> =
        httpClient
            .get("/v5/addresses/$addressUuid/energy/electricity") {
                parameter("fromDate", fromDate)
                parameter("toDate", toDate)
                parameter("limit", limit)
                parameter("sortBy", sortOrder)
            }.body()
}
