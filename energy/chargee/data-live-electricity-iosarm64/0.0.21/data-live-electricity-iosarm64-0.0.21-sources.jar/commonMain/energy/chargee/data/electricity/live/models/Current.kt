package energy.chargee.data.electricity.live.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Electrical current per phase, in Ampere.
 *
 * Each phase value is `null` when the meter does not report current for that phase.
 */
@Serializable
@ObjCName("_Current")
data class Current(val phaseOne: Float? = null, val phaseTwo: Float? = null, val phaseThree: Float? = null)
