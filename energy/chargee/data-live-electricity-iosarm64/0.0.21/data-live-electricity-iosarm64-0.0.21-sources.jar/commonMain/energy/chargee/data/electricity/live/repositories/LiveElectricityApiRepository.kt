package energy.chargee.data.electricity.live.repositories

import energy.chargee.core.network.enums.SortOrder
import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.electricity.live.clients.LiveElectricityApiClient
import energy.chargee.data.electricity.live.converters.asElectricityReading
import energy.chargee.data.electricity.live.dtos.ElectricityReadingDto
import energy.chargee.data.electricity.live.models.ElectricityReading
import energy.chargee.utils.result.Result
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.time.Clock
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant

private val POLL_INTERVAL = 1.seconds

internal class LiveElectricityApiRepository(private val liveElectricityApiClient: LiveElectricityApiClient) : LiveElectricityRepository {
    override suspend fun getElectricityReadings(
        addressUuid: String,
        fromDate: Instant,
        toDate: Instant,
        limit: Int,
        sortOrder: SortOrder,
    ): Result<List<ElectricityReading>, ApiError> =
        runApi {
            liveElectricityApiClient
                .getElectricityReadings(
                    addressUuid,
                    fromDate.toString(),
                    toDate.toString(),
                    limit,
                    when (sortOrder) {
                        SortOrder.Ascending -> "ASC"
                        SortOrder.Descending -> "DESC"
                    },
                ).results
                .map(ElectricityReadingDto::asElectricityReading)
        }

    override fun streamElectricityReadings(addressUuid: String, fromDate: Instant): Flow<Result<List<ElectricityReading>, ApiError>> =
        flow {
            var lastSeenTime: Instant? = null
            while (true) {
                val pollFromDate = lastSeenTime ?: fromDate
                val toDate = Clock.System.now()
                when (val result = getElectricityReadings(addressUuid, pollFromDate, toDate)) {
                    is Result.Success -> {
                        val newReadings =
                            lastSeenTime?.let { last -> result.value.filter { it.time > last } }
                                ?: result.value
                        if (newReadings.isNotEmpty()) {
                            lastSeenTime = newReadings.maxOf { it.time }
                            emit(Result.Success(newReadings))
                        }
                    }

                    is Result.Failure -> {
                        emit(result)
                    }
                }
                delay(POLL_INTERVAL)
            }
        }
}
