package energy.chargee.data.electricity.live.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Electrical voltage per phase, in Volts.
 *
 * Each phase value is `null` when the meter does not report voltage for that phase.
 */
@Serializable
@ObjCName("_Voltage")
data class Voltage(val phaseOne: Float? = null, val phaseTwo: Float? = null, val phaseThree: Float? = null)
