package energy.chargee.data.electricity.live

import energy.chargee.core.di.module
import energy.chargee.data.electricity.live.clients.LiveElectricityApiClient
import energy.chargee.data.electricity.live.repositories.LiveElectricityApiRepository
import energy.chargee.data.electricity.live.repositories.LiveElectricityRepository

val liveElectricityDataModule =
    module {
        factory { LiveElectricityApiClient(get()) }
        factory<LiveElectricityRepository> { LiveElectricityApiRepository(get()) }
    }
