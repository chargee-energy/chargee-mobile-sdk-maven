package energy.chargee.data.electricity.live.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.enums.SortOrder
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.electricity.live.models.ElectricityReading
import energy.chargee.utils.result.Result
import kotlinx.coroutines.flow.Flow
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * Provides access to live electricity readings for an address.
 */
@Repository
@ObjCName("_LiveElectricityRepository")
interface LiveElectricityRepository {
    /**
     * Fetches electricity readings for [addressUuid] between [fromDate] and [toDate].
     *
     * [limit] controls how many readings are returned (default 7200). [sortOrder] determines
     * whether readings are ordered oldest-first ([SortOrder.Ascending]) or newest-first
     * ([SortOrder.Descending]).
     */
    suspend fun getElectricityReadings(
        addressUuid: String,
        fromDate: Instant,
        toDate: Instant,
        limit: Int = 7200,
        sortOrder: SortOrder = SortOrder.Ascending,
    ): Result<List<ElectricityReading>, ApiError>

    /**
     * Streams electricity readings for [addressUuid] starting at [fromDate].
     *
     * The first emission contains readings between [fromDate] and the moment the stream
     * is collected. Subsequent emissions contain only readings newer than the most
     * recently observed one; emissions with no new readings are skipped. Failures are
     * emitted as [Result.Failure] and the stream continues — each emission carries no
     * accumulated error state.
     *
     * The stream runs until the collector is cancelled.
     */
    fun streamElectricityReadings(addressUuid: String, fromDate: Instant): Flow<Result<List<ElectricityReading>, ApiError>>
}
