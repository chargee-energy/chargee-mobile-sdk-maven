package energy.chargee.data.electricity.live.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class ActivePowerDto(
    val total: PowerDto,
    val phaseOne: PowerDto? = null,
    val phaseTwo: PowerDto? = null,
    val phaseThree: PowerDto? = null,
)
