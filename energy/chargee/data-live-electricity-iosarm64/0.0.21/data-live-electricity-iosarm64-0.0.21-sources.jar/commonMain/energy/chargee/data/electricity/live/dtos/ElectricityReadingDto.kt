package energy.chargee.data.electricity.live.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class ElectricityReadingDto(
    val time: String,
    val activePower: ActivePowerDto,
    val current: CurrentDto? = null,
    val currentCalculated: CurrentDto? = null,
    val voltage: VoltageDto? = null,
)
