package energy.chargee.data.electricity.live.converters

import energy.chargee.data.electricity.live.dtos.ActivePowerDto
import energy.chargee.data.electricity.live.dtos.CurrentDto
import energy.chargee.data.electricity.live.dtos.ElectricityReadingDto
import energy.chargee.data.electricity.live.dtos.PowerDto
import energy.chargee.data.electricity.live.dtos.VoltageDto
import energy.chargee.data.electricity.live.models.ActivePower
import energy.chargee.data.electricity.live.models.Current
import energy.chargee.data.electricity.live.models.ElectricityReading
import energy.chargee.data.electricity.live.models.Power
import energy.chargee.data.electricity.live.models.Voltage
import kotlin.time.Instant

internal fun PowerDto.asPower() = Power(net, delivering, returning)

internal fun ActivePowerDto.asActivePower() =
    ActivePower(
        total.asPower(),
        phaseOne?.asPower(),
        phaseTwo?.asPower(),
        phaseThree?.asPower(),
    )

internal fun CurrentDto.asCurrent() = Current(phaseOne, phaseTwo, phaseThree)

internal fun VoltageDto.asVoltage() = Voltage(phaseOne, phaseTwo, phaseThree)

internal fun ElectricityReadingDto.asElectricityReading() =
    ElectricityReading(
        Instant.parse(time),
        activePower.asActivePower(),
        current?.asCurrent(),
        currentCalculated?.asCurrent(),
        voltage?.asVoltage(),
    )
