package energy.chargee.data.electricity.live.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class VoltageDto(val phaseOne: Float? = null, val phaseTwo: Float? = null, val phaseThree: Float? = null)
