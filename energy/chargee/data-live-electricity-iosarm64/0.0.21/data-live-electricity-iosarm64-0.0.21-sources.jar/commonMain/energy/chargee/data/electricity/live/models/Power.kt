package energy.chargee.data.electricity.live.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Power measurements at a single point in time, all in Watts.
 *
 * [net] is the net power (positive = consuming, negative = returning). [delivering] is the
 * power consumed from the grid and [returning] is the power fed back to the grid.
 */
@Serializable
@ObjCName("_Power")
data class Power(val net: Int, val delivering: Int, val returning: Int)
