package energy.chargee.data.electricity.live.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class PowerDto(val net: Int, val delivering: Int, val returning: Int)
