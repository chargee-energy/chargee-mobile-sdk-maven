package energy.chargee.data.price.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.price.clients.PriceApiClient
import energy.chargee.data.price.converters.asDynamicPrice
import energy.chargee.data.price.dtos.DynamicPriceDto
import energy.chargee.data.price.models.DynamicPrice
import energy.chargee.utils.date.atEndOfDayIn
import energy.chargee.utils.result.Result
import kotlinx.datetime.LocalDate
import kotlinx.datetime.TimeZone
import kotlinx.datetime.atStartOfDayIn

internal class PriceApiRepository(private val priceApiClient: PriceApiClient) : PriceRepository {
    override suspend fun getElectricityPrices(
        addressUuid: String,
        fromDate: LocalDate,
        toDate: LocalDate,
    ): Result<List<DynamicPrice>, ApiError> =
        runApi {
            val timeZone = TimeZone.currentSystemDefault()
            val from = fromDate.atStartOfDayIn(timeZone)
            val to = toDate.atEndOfDayIn(timeZone)
            priceApiClient
                .getElectricityPrices(
                    addressUuid,
                    from.toString(),
                    to.toString(),
                ).results
                .map(DynamicPriceDto::asDynamicPrice)
        }

    override suspend fun getGasPrices(addressUuid: String, fromDate: LocalDate, toDate: LocalDate): Result<List<DynamicPrice>, ApiError> =
        runApi {
            val timeZone = TimeZone.currentSystemDefault()
            val from = fromDate.atStartOfDayIn(timeZone)
            val to = toDate.atEndOfDayIn(timeZone)
            priceApiClient
                .getGasPrices(
                    addressUuid,
                    from.toString(),
                    to.toString(),
                ).results
                .map(DynamicPriceDto::asDynamicPrice)
        }
}
