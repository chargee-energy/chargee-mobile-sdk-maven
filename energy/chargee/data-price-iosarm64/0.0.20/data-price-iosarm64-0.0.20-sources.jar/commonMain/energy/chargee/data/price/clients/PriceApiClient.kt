package energy.chargee.data.price.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.price.dtos.DynamicPriceDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

internal class PriceApiClient(private val httpClient: HttpClient) {
    suspend fun getElectricityPrices(
        addressUuid: String,
        from: String,
        to: String,
    ): PaginatedResponseDto<PaginatedMetaDto, DynamicPriceDto> =
        httpClient
            .get("/v5/addresses/$addressUuid/prices/electricity") {
                url {
                    parameters.append("fromDate", from)
                    parameters.append("toDate", to)
                }
            }.body()

    suspend fun getGasPrices(addressUuid: String, from: String, to: String): PaginatedResponseDto<PaginatedMetaDto, DynamicPriceDto> =
        httpClient
            .get("/v5/addresses/$addressUuid/prices/gas") {
                url {
                    parameters.append("fromDate", from)
                    parameters.append("toDate", to)
                }
            }.body()
}
