package energy.chargee.data.price.converters

import energy.chargee.data.price.dtos.DynamicPriceDto
import energy.chargee.data.price.models.DynamicPrice
import kotlin.time.Instant

internal fun DynamicPriceDto.asDynamicPrice() = DynamicPrice(Instant.parse(time), priceWithoutTax, priceWithTax)
