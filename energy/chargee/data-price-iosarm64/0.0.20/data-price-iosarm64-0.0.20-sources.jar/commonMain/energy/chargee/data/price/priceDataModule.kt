package energy.chargee.data.price

import energy.chargee.core.di.module
import energy.chargee.data.price.clients.PriceApiClient
import energy.chargee.data.price.repositories.PriceApiRepository
import energy.chargee.data.price.repositories.PriceRepository

val priceDataModule =
    module {
        factory { PriceApiClient(get()) }
        factory<PriceRepository> { PriceApiRepository(get()) }
    }
