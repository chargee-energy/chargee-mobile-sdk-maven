package energy.chargee.data.price.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class DynamicPriceDto(val time: String, val priceWithoutTax: Float, val priceWithTax: Float)
