package energy.chargee.data.price.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.price.models.DynamicPrice
import energy.chargee.utils.result.Result
import kotlinx.datetime.LocalDate
import kotlin.native.ObjCName

/**
 * Provides access to dynamic electricity and gas prices from the remote API.
 */
@Repository
@ObjCName("_PriceRepository")
interface PriceRepository {
    /**
     * Fetches dynamic electricity prices for [addressUuid] between [fromDate] and [toDate] inclusive.
     */
    suspend fun getElectricityPrices(addressUuid: String, fromDate: LocalDate, toDate: LocalDate): Result<List<DynamicPrice>, ApiError>

    /**
     * Fetches dynamic gas prices for [addressUuid] between [fromDate] and [toDate] inclusive.
     */
    suspend fun getGasPrices(addressUuid: String, fromDate: LocalDate, toDate: LocalDate): Result<List<DynamicPrice>, ApiError>
}
