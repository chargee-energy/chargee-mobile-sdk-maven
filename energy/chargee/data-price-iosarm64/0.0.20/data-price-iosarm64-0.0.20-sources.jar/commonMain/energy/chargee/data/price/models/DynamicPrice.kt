package energy.chargee.data.price.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A single electricity or gas price entry at a specific point in time.
 *
 * [priceWithoutTax] and [priceWithTax] are the per-unit price excluding and including taxes respectively.
 */
@Serializable
@ObjCName("_DynamicPrice")
data class DynamicPrice(val time: Instant, val priceWithoutTax: Float, val priceWithTax: Float)
