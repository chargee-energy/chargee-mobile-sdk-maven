package energy.chargee.utils.wifi

/**
 * The JVM [WifiConnection], which does nothing.
 *
 * Joining a named network is something a phone does under the user's control through an OS API that
 * has no desktop equivalent, so this reports failure rather than pretending. The flows that need it
 * — joining an inverter's own access point to configure it — cannot run off-device at all, and
 * saying so immediately is better than having them hang.
 */
class WifiConnectionJvm : WifiConnection {
    override suspend fun connect(configuration: WifiConfiguration, saveNetwork: Boolean) = false

    override suspend fun disconnect() = false

    override suspend fun getSsid(): String? = null
}
