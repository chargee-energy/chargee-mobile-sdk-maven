package energy.chargee.utils.wifi

import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface

/**
 * The address a datagram would be sent from is discovered by asking the OS to route one, using an
 * address from the documentation range (RFC 5737) that nothing answers.
 *
 * Connecting a UDP socket sends no packets; it only fixes the socket's local endpoint, which is the
 * kernel's own answer to "which interface would you use". It is the same trick the embedded team's
 * `sma_setup.py` uses for the same reason.
 */
private const val UNROUTED_PROBE_HOST = "192.0.2.1"
private const val UNROUTED_PROBE_PORT = 9

/**
 * The JVM [LocalAddressProvider], which reports the address the machine would actually talk to the
 * local network from.
 *
 * Real rather than stubbed, because the subnet scan and the UDP discoveries derive their range and
 * their outgoing interface from it — and getting it wrong is worse than having nothing. A developer
 * machine typically has several interfaces that are up and not loopback, including ones holding a
 * self-assigned `169.254.x.x` link-local address on an unplugged port. Picking one of those sends
 * discovery out an interface the hardware is not on, and asks a subnet sweep to walk a `/16` of
 * 65,534 addresses where nothing exists — around seventeen minutes of finding nothing.
 *
 * So the routable address is asked for directly, and the interface scan is only a fallback for a
 * machine with no default route. Link-local addresses are excluded from that fallback for the same
 * reason they are the wrong answer in the first place.
 */
class LocalAddressProviderJvm : LocalAddressProvider {
    override fun getLocalAddress(): LocalAddress? = routedAddress()?.let(::localAddressFor) ?: firstRoutableAddress()

    /** The local address the OS would send from, or `null` when the machine has no route out. */
    private fun routedAddress(): Inet4Address? =
        runCatching {
            DatagramSocket().use { socket ->
                socket.connect(InetSocketAddress(InetAddress.getByName(UNROUTED_PROBE_HOST), UNROUTED_PROBE_PORT))
                socket.localAddress as? Inet4Address
            }
        }.getOrNull()?.takeUnless { it.isAnyLocalAddress || it.isLoopbackAddress || it.isLinkLocalAddress }

    /** [address] paired with the prefix length of the interface that holds it. */
    private fun localAddressFor(address: Inet4Address): LocalAddress? =
        usableInterfaceAddresses()
            .firstOrNull { it.address == address }
            ?.let { LocalAddress(address.hostAddress, it.networkPrefixLength.toInt()) }

    /** The first address that could carry local traffic, for a machine with no default route. */
    private fun firstRoutableAddress(): LocalAddress? =
        usableInterfaceAddresses()
            .firstNotNullOfOrNull { interfaceAddress ->
                interfaceAddress.address.hostAddress?.let { LocalAddress(it, interfaceAddress.networkPrefixLength.toInt()) }
            }

    private fun usableInterfaceAddresses() =
        NetworkInterface
            .getNetworkInterfaces()
            ?.asSequence()
            .orEmpty()
            .filter { runCatching { it.isUp && !it.isLoopback && !it.isPointToPoint }.getOrDefault(false) }
            .flatMap { it.interfaceAddresses.asSequence() }
            .filter { it.address is Inet4Address && !it.address.isLinkLocalAddress }
}
