package energy.chargee.utils.wifi

/**
 * Wi-Fi authentication scheme for a [WifiConfiguration].
 *
 * Only schemes that require special-case handling on Android or iOS are enumerated here;
 * the default WPA2-PSK path is selected when `auth` is `null` on a password-protected
 * network.
 */
enum class WifiAuth {
    /**
     * Wired Equivalent Privacy. Legacy scheme retained for older access points; on Android
     * this forces the legacy `WifiManager.addNetwork` path since [WifiNetworkSpecifier][android.net.wifi.WifiNetworkSpecifier]
     * has no WEP builder.
     */
    Wep,

    /**
     * Wi-Fi Protected Access 3. On Android API 29+ this routes through
     * [setWpa3Passphrase][android.net.wifi.WifiNetworkSpecifier.Builder.setWpa3Passphrase]
     * instead of the WPA2 passphrase builder.
     */
    Wpa3,
}
