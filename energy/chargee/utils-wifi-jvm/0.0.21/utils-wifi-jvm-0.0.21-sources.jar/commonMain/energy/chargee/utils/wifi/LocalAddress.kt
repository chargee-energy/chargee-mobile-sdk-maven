package energy.chargee.utils.wifi

/**
 * An IPv4 address on a local network, together with the [prefixLength] (in bits) of the subnet
 * mask that identifies which portion of [address] is the network prefix.
 *
 * For example, an [address] of `192.168.1.42` with a [prefixLength] of `24` describes the host
 * `192.168.1.42` on the `192.168.1.0/24` subnet.
 */
data class LocalAddress(val address: String, val prefixLength: Int)

/**
 * Returns the subnet-directed IPv4 broadcast address for the network defined by [this] address
 * and its [LocalAddress.prefixLength]. For example, a [LocalAddress] of `192.168.1.42/24` yields
 * `192.168.1.255`.
 */
fun LocalAddress.broadcastAddress(): String = intToIp(broadcastInt())

/**
 * Returns a lazy [Sequence] of every host IPv4 address on the subnet defined by [this] address
 * and its [LocalAddress.prefixLength], excluding the network and broadcast addresses. For example,
 * a [LocalAddress] of `192.168.1.42/24` yields `192.168.1.1` through `192.168.1.254`.
 */
fun LocalAddress.hostAddresses(): Sequence<String> {
    val broadcast = broadcastInt()
    val network = broadcast and (-1 shl (32 - prefixLength))
    return (network + 1 until broadcast).asSequence().map(::intToIp)
}

private fun LocalAddress.broadcastInt(): Int {
    val addressInt = address.split('.').fold(0) { acc, octet -> (acc shl 8) or octet.toInt() }
    val mask = -1 shl (32 - prefixLength)
    return (addressInt and mask) or mask.inv()
}

private fun intToIp(v: Int): String = "${(v ushr 24) and 0xFF}.${(v ushr 16) and 0xFF}.${(v ushr 8) and 0xFF}.${v and 0xFF}"
