package energy.chargee.utils.wifi

/**
 * Platform-agnostic Wi-Fi association API used during device onboarding to join the
 * network described by a [WifiConfiguration] (typically a device's local AP).
 *
 * Implementations bridge the underlying callback-based OS APIs — `ConnectivityManager`
 * / `WifiManager` on Android and `NEHotspotConfigurationManager` on iOS — into `suspend`
 * functions.
 */
interface WifiConnection {
    /**
     * Suspends until the device has associated with the network described by [configuration],
     * returning `true` on success and `false` if the OS reports the network as unavailable
     * or the association is rejected.
     *
     * On iOS, passing `saveNetwork = true` persists the configuration across app launches;
     * `false` (the default) marks it as join-once so it is discarded when the app exits.
     * On Android this flag has no effect — modern-API associations are always process-scoped
     * and legacy-API associations are always persisted by `WifiManager.saveConfiguration`.
     */
    suspend fun connect(configuration: WifiConfiguration, saveNetwork: Boolean = false): Boolean

    /**
     * Reverses the most recent successful [connect] call, returning `true` when the
     * association was torn down and `false` when there is nothing to disconnect from
     * (no prior connect, or the OS has already dropped the network).
     */
    suspend fun disconnect(): Boolean

    /**
     * Returns the SSID of the network the device is currently associated with, or `null`
     * when there is no active association or the SSID is unavailable (e.g. Android's
     * `WifiManager.UNKNOWN_SSID` sentinel when location permission is missing).
     */
    suspend fun getSsid(): String?

    /**
     * Returns the IPv4 address of the gateway on the network joined by [connect], or `null`
     * when there is no active association or the address could not be determined.
     *
     * When the joined network is a device's own access point the gateway is that device, so
     * this is how a caller reaches it without knowing its address beforehand. The result is
     * best effort and platforms resolve it differently, so callers must handle `null` and must
     * not assume the address is reachable — verify by connecting. The default implementation
     * returns `null`.
     */
    suspend fun getGatewayAddress(): String? = null
}
