package energy.chargee.utils.wifi

/**
 * Resolves the device's own IPv4 [LocalAddress] on the currently active Wi-Fi network.
 *
 * Used by network discovery (e.g. subnet port scanning) to derive the range of hosts to probe.
 */
fun interface LocalAddressProvider {
    /**
     * Returns the device's IPv4 [LocalAddress] on the active Wi-Fi network, or `null` if the
     * device is not connected to Wi-Fi or no IPv4 address could be determined.
     */
    fun getLocalAddress(): LocalAddress?
}
