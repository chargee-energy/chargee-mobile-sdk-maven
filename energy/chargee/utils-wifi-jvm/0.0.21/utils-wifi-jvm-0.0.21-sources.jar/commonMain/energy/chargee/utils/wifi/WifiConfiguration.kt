package energy.chargee.utils.wifi

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Credentials for joining a Wi-Fi network via [WifiConnection.connect].
 *
 * A `null` [password] describes an open network. A `null` [auth] defaults the platform
 * implementation to WPA2-PSK when [password] is set; specify [auth] explicitly only for
 * schemes that need distinct API paths (see [WifiAuth]).
 */
@Serializable
@ObjCName("_WifiConfiguration")
data class WifiConfiguration(val ssid: String, val password: String? = null, val auth: WifiAuth? = null)
