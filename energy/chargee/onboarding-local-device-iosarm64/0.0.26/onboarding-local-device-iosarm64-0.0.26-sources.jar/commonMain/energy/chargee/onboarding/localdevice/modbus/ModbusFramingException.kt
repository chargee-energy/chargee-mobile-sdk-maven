package energy.chargee.onboarding.localdevice.modbus

/**
 * Thrown when bytes arrived from a Modbus peer but did not line up with the frame that was
 * expected: a transaction id that belongs to another exchange, a truncated response, or a header
 * that cannot be parsed.
 *
 * It is deliberately not an [IllegalStateException]. Vendor handshakes report a rejected login
 * with `check`, and a caller that cannot tell the two apart reports a garbled stream as bad
 * credentials and prompts the user for a password that was never wrong. Catch this type to treat
 * the peer as the wrong device — or the connection as unusable — rather than as a refusal.
 *
 * The constructor is public because vendor protocol code lives outside this module and needs to
 * raise it for its own framing checks.
 */
class ModbusFramingException(message: String) : RuntimeException(message)
