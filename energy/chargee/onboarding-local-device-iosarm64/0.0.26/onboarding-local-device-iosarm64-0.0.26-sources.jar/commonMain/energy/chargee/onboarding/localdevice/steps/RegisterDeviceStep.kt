package energy.chargee.onboarding.localdevice.steps

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.localdevice.models.LocalDeviceConfig
import energy.chargee.data.localdevice.repositories.LocalDeviceRepository
import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.result.fold

internal class RegisterDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(
    private val addressUuid: String,
    private val chargeeDeviceType: ChargeeDeviceType,
    private val chargeeDeviceUuid: String,
    private val localDeviceRepository: LocalDeviceRepository,
    private val createConfig: (Context) -> LocalDeviceConfig,
) : OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.RegisterDevice

    override suspend fun execute(context: Context): Result<Context> =
        localDeviceRepository
            .createLocalDevice(
                addressUuid,
                chargeeDeviceType,
                chargeeDeviceUuid,
                createConfig(context),
            ).fold(
                success = {
                    Result.Success(context.copyWith(deviceUuid = it.uuid))
                },
                failure = { error ->
                    // The device was found and configured and the backend would not record it —
                    // nothing the installer can do, and nobody would know without the cause. See
                    // the Logging section of the README.
                    Result.Failure(
                        context,
                        LocalDeviceErrorCode.LocalDeviceRegistrationFailure,
                        error.cause ?: DeviceConfigurationException("The backend refused to register the local device: $error"),
                    )
                },
            )
}
