package energy.chargee.onboarding.localdevice.steps

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.localdevice.LocalDeviceErrorCode
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId
import energy.chargee.utils.result.fold
import kotlinx.coroutines.flow.any

private const val SERIAL_NUMBER_PARAMETER = "sn"

internal class DiscoverChargeeDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(
    private val addressUuid: String,
    private val deviceUuid: String,
    private val deviceType: ChargeeDeviceType,
    private val discovery: DeviceDiscovery,
    private val chargeeDeviceRepository: ChargeeDeviceRepository,
) : OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.DiscoverChargeeDevice

    override suspend fun execute(context: Context): Result<Context> {
        // The backend failing to hand back a device the flow already knows the uuid of is not
        // something the installer can act on, so the cause travels with it; a Chargee device that
        // is simply not on the network is the outcome this step exists to report, and carries
        // none. See the Logging section of the README.
        val chargeeDevice =
            chargeeDeviceRepository.getChargeeDevice(addressUuid, deviceType, deviceUuid).fold(
                success = { it },
                failure = { error ->
                    return Result.Failure(
                        context,
                        LocalDeviceErrorCode.FetchChargeeDeviceFailure,
                        error.cause ?: DeviceConfigurationException("The backend would not return the Chargee device: $error"),
                    )
                },
            )

        val discovered =
            discovery
                .discover()
                .any { it.extraParameters[SERIAL_NUMBER_PARAMETER] == chargeeDevice.serialNumber }

        return if (discovered) {
            Result.Success(context)
        } else {
            Result.Failure(context, LocalDeviceErrorCode.ChargeeDeviceNotDiscovered)
        }
    }
}
