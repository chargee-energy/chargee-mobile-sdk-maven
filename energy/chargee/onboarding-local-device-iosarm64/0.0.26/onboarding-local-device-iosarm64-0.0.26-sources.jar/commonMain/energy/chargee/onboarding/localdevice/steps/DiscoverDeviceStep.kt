package energy.chargee.onboarding.localdevice.steps

import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.logOnboarding
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingContext
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

internal class DiscoverDeviceStep<Context : LocalDeviceOnboardingContext<Context>>(
    private val continueWhenEmpty: Boolean = false,
    private val discoveryFactory: (Context) -> DeviceDiscovery,
) : OnboardingFlow.Step<LocalDeviceStepId, Context>() {
    override val id = LocalDeviceStepId.DiscoverDevice

    override suspend fun execute(context: Context): Result<Context> {
        val devices =
            buildList {
                discoveryFactory(context)
                    .discover()
                    .collect(::add)
            }

        // What the engine's step lifecycle cannot say: it sees Success or InputRequired, which
        // conflates finding nothing with finding five. The addresses themselves are already logged
        // per strategy under the discovery tag, so only the count belongs here.
        return when {
            // Clearing the selection as well as the list matters: a flow that reaches this step a
            // second time must not carry a device the previous run picked.
            devices.isEmpty() && continueWhenEmpty -> {
                logOnboarding { "discover: nothing found, continuing" }
                Result.Success(context.copyWith(discoveredDevices = emptyList(), selectedDevice = null))
            }

            devices.isEmpty() -> {
                logOnboarding { "discover: nothing found, asking the user" }
                Result.InputRequired(context)
            }

            devices.size == 1 -> {
                logOnboarding { "discover: one candidate, selected" }
                Result.Success(
                    context.copyWith(
                        discoveredDevices = devices,
                        selectedDevice = devices.single(),
                    ),
                )
            }

            else -> {
                logOnboarding { "discover: ${devices.size} candidates, asking the user" }
                Result.InputRequired(context.copyWith(discoveredDevices = devices))
            }
        }
    }
}
