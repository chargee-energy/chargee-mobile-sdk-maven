package energy.chargee.onboarding.localdevice.modbus

/**
 * Thrown when a Modbus peer answered with an exception response: it understood the request and
 * refused it, naming [exceptionCode] as the reason for [functionCode] — the function code of the
 * request, with the exception bit the wire sets already stripped off.
 *
 * This is the one failure that says something about the request rather than about the connection,
 * which is why both halves are on the type instead of only in a message. `0x02` means the register
 * does not exist on this model — the SUN2000L-4.6KTL refuses the apply-network-config write that
 * way while still reporting its LAN address — and a refusal from a Huawei inverter before its
 * challenge/response handshake has run means only that the connection is not authenticated yet.
 *
 * It extends [IllegalStateException] deliberately. The rest of the Modbus code reports
 * protocol-level problems with `check` and `error`, and vendor handshakes catch
 * [IllegalStateException] to mean "the device refused"; narrowing the type here would silently
 * change what those catches see. Catch this type when the code matters,
 * [IllegalStateException] when a refusal is a refusal.
 *
 * Only [ModbusConnection] raises it in production, but the constructor is public for the same
 * reason [ModbusFramingException]'s is: every Modbus caller lives in a vendor module outside this
 * one, and a fake standing in for "the inverter refused with `0x02`" has to be able to build one.
 */
class ModbusErrorResponseException(val functionCode: Uint8, val exceptionCode: Int) :
    IllegalStateException(describeModbusError(functionCode, exceptionCode)) {
    /** What [exceptionCode] means, as the Modbus spec names it, or `"unknown"` for a vendor code. */
    val exceptionName: String get() = modbusExceptionName(exceptionCode)
}

private fun describeModbusError(functionCode: Uint8, exceptionCode: Int): String =
    "Modbus exception 0x${exceptionCode.toString(16).padStart(2, '0')} (${modbusExceptionName(exceptionCode)}) " +
        "for function 0x${functionCode.hex}"

/**
 * The spec's name for [exceptionCode]. The gaps (`0x07`, `0x09`) are codes the spec does not
 * define, and anything outside the table is a vendor extension.
 */
private fun modbusExceptionName(exceptionCode: Int): String =
    when (exceptionCode) {
        0x01 -> "illegal function"
        0x02 -> "illegal data address"
        0x03 -> "illegal data value"
        0x04 -> "server device failure"
        0x05 -> "acknowledge"
        0x06 -> "server device busy"
        0x08 -> "memory parity error"
        0x0A -> "gateway path unavailable"
        0x0B -> "gateway target device failed to respond"
        else -> "unknown"
    }
