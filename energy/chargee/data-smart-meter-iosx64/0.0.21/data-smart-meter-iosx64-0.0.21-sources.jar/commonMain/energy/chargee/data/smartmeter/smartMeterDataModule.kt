package energy.chargee.data.smartmeter

import energy.chargee.core.di.module
import energy.chargee.data.smartmeter.clients.SmartMeterApiClient
import energy.chargee.data.smartmeter.repositories.SmartMeterApiRepository
import energy.chargee.data.smartmeter.repositories.SmartMeterRepository

val smartMeterDataModule =
    module {
        factory { SmartMeterApiClient(get()) }
        factory<SmartMeterRepository> { SmartMeterApiRepository(get()) }
    }
