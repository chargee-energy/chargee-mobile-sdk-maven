package energy.chargee.data.smartmeter.models

import energy.chargee.data.smartmeter.enums.SmartMeterConnectionType
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A smart meter registered to an address.
 *
 * [uuid] is the unique identifier for the meter. [smartMeterType] and [meterNumber] are the
 * meter's model and serial identifiers; [gasMeterNumber] is the companion gas meter serial,
 * if any. [connectionType] indicates the hardware used to connect the meter to the platform,
 * or `null` when not yet determined. [createdAt] and [updatedAt] are the server-side
 * timestamps for the record.
 */
@Serializable
@ObjCName("_SmartMeter")
data class SmartMeter(
    val uuid: String,
    val smartMeterType: String? = null,
    val meterNumber: String? = null,
    val gasMeterNumber: String? = null,
    val connectionType: SmartMeterConnectionType? = null,
    val createdAt: Instant,
    val updatedAt: Instant,
)
