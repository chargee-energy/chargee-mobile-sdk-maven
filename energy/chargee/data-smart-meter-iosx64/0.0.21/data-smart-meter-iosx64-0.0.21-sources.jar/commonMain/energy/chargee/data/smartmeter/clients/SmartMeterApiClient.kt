package energy.chargee.data.smartmeter.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.smartmeter.dtos.SmartMeterDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

internal class SmartMeterApiClient(private val httpClient: HttpClient) {
    suspend fun getSmartMeters(addressUuid: String): PaginatedResponseDto<PaginatedMetaDto, SmartMeterDto> =
        httpClient.get("/v5/addresses/$addressUuid/smart-meters").body()

    suspend fun getSmartMeter(addressUuid: String, smartMeterUuid: String): SmartMeterDto =
        httpClient.get("/v5/addresses/$addressUuid/smart-meters/$smartMeterUuid").body()
}
