package energy.chargee.data.smartmeter.enums

/**
 * The type of hardware used to connect the smart meter to the Chargee platform.
 */
enum class SmartMeterConnectionType {
    Sparky,
    Flint,
}
