package energy.chargee.data.smartmeter.converters

import energy.chargee.data.smartmeter.dtos.SmartMeterDto
import energy.chargee.data.smartmeter.enums.SmartMeterConnectionType
import energy.chargee.data.smartmeter.models.SmartMeter
import kotlin.time.Instant

internal fun SmartMeterDto.asSmartMeter() =
    SmartMeter(
        uuid,
        info?.smartMeterType,
        info?.meterNumber,
        info?.gasMeterNumber,
        when (connectionType) {
            "sparky" -> SmartMeterConnectionType.Sparky
            "flint" -> SmartMeterConnectionType.Flint
            else -> null
        },
        Instant.parse(createdAt),
        Instant.parse(updatedAt),
    )
