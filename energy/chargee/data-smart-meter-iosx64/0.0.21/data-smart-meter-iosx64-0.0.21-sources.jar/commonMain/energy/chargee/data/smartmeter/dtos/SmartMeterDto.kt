package energy.chargee.data.smartmeter.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class SmartMeterDto(
    val uuid: String,
    val info: SmartMeterInfoDto?,
    val connectionType: String?,
    val createdAt: String,
    val updatedAt: String,
)
