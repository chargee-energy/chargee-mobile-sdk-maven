package energy.chargee.data.smartmeter.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.smartmeter.models.SmartMeter
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to smart meters registered to an address.
 */
@Repository
@ObjCName("_SmartMeterRepository")
interface SmartMeterRepository {
    /**
     * Returns all smart meters registered to the address identified by [addressUuid].
     */
    suspend fun getSmartMeters(addressUuid: String): Result<List<SmartMeter>, ApiError>

    /**
     * Returns the smart meter identified by [smartMeterUuid] under the address [addressUuid].
     */
    suspend fun getSmartMeter(addressUuid: String, smartMeterUuid: String): Result<SmartMeter, ApiError>
}
