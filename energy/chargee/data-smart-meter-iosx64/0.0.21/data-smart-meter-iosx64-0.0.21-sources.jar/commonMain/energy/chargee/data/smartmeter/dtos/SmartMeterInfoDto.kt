package energy.chargee.data.smartmeter.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class SmartMeterInfoDto(val smartMeterType: String?, val meterNumber: String?, val gasMeterNumber: String?)
