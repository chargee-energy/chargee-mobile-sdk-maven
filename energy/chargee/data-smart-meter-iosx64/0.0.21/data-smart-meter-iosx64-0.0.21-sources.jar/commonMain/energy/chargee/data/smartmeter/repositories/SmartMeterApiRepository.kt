package energy.chargee.data.smartmeter.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.smartmeter.clients.SmartMeterApiClient
import energy.chargee.data.smartmeter.converters.asSmartMeter
import energy.chargee.data.smartmeter.dtos.SmartMeterDto
import energy.chargee.data.smartmeter.models.SmartMeter
import energy.chargee.utils.result.Result

internal class SmartMeterApiRepository(private val smartMeterApiClient: SmartMeterApiClient) : SmartMeterRepository {
    override suspend fun getSmartMeters(addressUuid: String): Result<List<SmartMeter>, ApiError> =
        runApi { smartMeterApiClient.getSmartMeters(addressUuid).results.map(SmartMeterDto::asSmartMeter) }

    override suspend fun getSmartMeter(addressUuid: String, smartMeterUuid: String): Result<SmartMeter, ApiError> =
        runApi { smartMeterApiClient.getSmartMeter(addressUuid, smartMeterUuid).asSmartMeter() }
}
