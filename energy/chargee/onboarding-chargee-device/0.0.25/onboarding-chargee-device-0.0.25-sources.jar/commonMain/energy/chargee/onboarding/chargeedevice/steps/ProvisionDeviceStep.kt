package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.provisioning.ProvisioningResult
import energy.chargee.onboarding.core.DeviceConfigurationException
import energy.chargee.onboarding.core.OnboardingFlow

internal class ProvisionDeviceStep(private val espProvisioning: EspProvisioning) :
    OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.ProvisionDevice

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val deviceName =
            requireNotNull(context.deviceName) { "deviceName must be set by FindDeviceStep before ProvisionDeviceStep runs" }
        val wifiConfiguration =
            context.selectedWifiConfiguration ?: return Result.InputRequired(context, advanceAfterInput = false)

        val result =
            espProvisioning.provisionDevice(
                deviceName = deviceName,
                proofOfPossession = context.proofOfPossession,
                ssid = wifiConfiguration.ssid,
                passphrase = wifiConfiguration.password,
            )

        // Whether a failure carries a cause is what tells a monitoring logger a defect from an
        // outcome the flow is designed to produce — see the Logging section of the README.
        return when (result) {
            ProvisioningResult.Success -> {
                Result.Success(context)
            }

            // The device rejected the proof of possession or the Wi-Fi password: something the
            // user supplied and can supply again.
            ProvisioningResult.AuthenticationFailure -> {
                Result.Failure(
                    context,
                    ChargeeDeviceErrorCode.AuthenticationFailure,
                )
            }

            // ESP provisioning reports no reason of its own, so there is nothing to carry and one
            // is made: the device was found, authenticated and then failed to be set up.
            ProvisioningResult.UnknownFailure -> {
                Result.Failure(
                    context,
                    ChargeeDeviceErrorCode.ProvisioningFailure,
                    DeviceConfigurationException("ESP provisioning failed after the device accepted the credentials"),
                )
            }
        }
    }
}
