package energy.chargee.onboarding.chargeedevice.bluetooth

/**
 * The availability of Bluetooth hardware and services on the device.
 *
 * Reported by [BluetoothAccess.checkBluetoothAvailability]. This describes the state of the
 * underlying radio and OS service; whether the app itself is allowed to use Bluetooth is a
 * separate concern reported by [BluetoothPermissionStatus].
 */
enum class BluetoothAvailability {
    /**
     * Bluetooth is powered on and ready for use.
     */
    Available,

    /**
     * Bluetooth cannot be used right now. This collapses several distinct conditions into
     * a single value: the adapter is powered off, the device has no Bluetooth hardware, or
     * (on iOS) the OS-level Bluetooth authorization for this app is denied or restricted.
     * On Android, OS-level denial surfaces through [BluetoothPermissionStatus.Denied]
     * instead.
     */
    NotAvailable,

    /**
     * Bluetooth itself is fine, but scanning requires the system Location service to be
     * enabled and it is currently off. Android 11 and below only — newer Android versions
     * and iOS do not return this value.
     */
    LocationNotAvailable,
}
