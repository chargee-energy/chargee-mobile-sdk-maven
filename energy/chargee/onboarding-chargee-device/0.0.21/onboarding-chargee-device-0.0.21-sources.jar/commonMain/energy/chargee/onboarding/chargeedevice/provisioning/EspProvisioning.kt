package energy.chargee.onboarding.chargeedevice.provisioning

import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork

/**
 * Platform-specific ESP32 provisioning operations used by the onboarding flow.
 *
 * Implementations interact with the ESP-IDF provisioning SDK over BLE. See
 * platform source sets for the Android and iOS implementations.
 */
interface EspProvisioning {
    /**
     * Scans for nearby ESP devices over BLE and returns their names.
     *
     * Pass a [prefix] to filter results to devices whose name starts with that string.
     */
    suspend fun scanDevices(prefix: String? = null): List<String>

    /**
     * Connects to [deviceName] using [proofOfPossession] and returns the Wi-Fi networks it can see.
     */
    suspend fun scanWifiNetworks(deviceName: String, proofOfPossession: String): List<WifiNetwork>

    /**
     * Sends Wi-Fi credentials to [deviceName] and returns a [ProvisioningResult] indicating the outcome.
     *
     * [passphrase] may be `null` for open networks.
     */
    suspend fun provisionDevice(deviceName: String, proofOfPossession: String, ssid: String, passphrase: String? = null): ProvisioningResult
}
