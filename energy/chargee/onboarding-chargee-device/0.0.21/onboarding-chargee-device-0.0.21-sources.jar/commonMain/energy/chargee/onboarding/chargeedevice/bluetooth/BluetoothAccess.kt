package energy.chargee.onboarding.chargeedevice.bluetooth

/**
 * Platform-specific Bluetooth access checks used by the Chargee device onboarding flow.
 *
 * See platform source sets for the Android and iOS implementations.
 */
interface BluetoothAccess {
    /**
     * Returns the current [BluetoothAvailability] of the Bluetooth hardware and services.
     */
    suspend fun checkBluetoothAvailability(): BluetoothAvailability

    /**
     * Returns the current [BluetoothPermissionStatus] for Bluetooth (and location where required).
     */
    suspend fun checkBluetoothPermissionStatus(): BluetoothPermissionStatus
}
