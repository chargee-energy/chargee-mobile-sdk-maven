package energy.chargee.onboarding.chargeedevice

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * The [SerializersModule] registering the [ChargeeDeviceErrorCode] cases as polymorphic subtypes
 * of the open [OnboardingErrorCode].
 *
 * Each concrete case is registered directly, rather than the [ChargeeDeviceErrorCode] sealed
 * interface as a whole: kotlinx.serialization rejects a sealed serializer as a `subclass` of
 * another polymorphic base ("its kind SEALED is not concrete"), and registering the leaves keeps
 * a single, flat `type` discriminator. A new case must be added here to be serializable. The
 * aggregating SDK combines this with the other modules' contributions — see
 * [engineErrorCodeSerializersModule][energy.chargee.onboarding.core.engineErrorCodeSerializersModule].
 */
val chargeeDeviceErrorCodeSerializersModule: SerializersModule =
    SerializersModule {
        polymorphic(OnboardingErrorCode::class) {
            subclass(ChargeeDeviceErrorCode.BluetoothNotAvailable::class)
            subclass(ChargeeDeviceErrorCode.LocationNotAvailable::class)
            subclass(ChargeeDeviceErrorCode.BluetoothPermissionDenied::class)
            subclass(ChargeeDeviceErrorCode.LocationPermissionDenied::class)
            subclass(ChargeeDeviceErrorCode.NoDeviceFound::class)
            subclass(ChargeeDeviceErrorCode.AlreadyRegistered::class)
            subclass(ChargeeDeviceErrorCode.RegistrationFailure::class)
            subclass(ChargeeDeviceErrorCode.NoWifiNetworksFound::class)
            subclass(ChargeeDeviceErrorCode.AuthenticationFailure::class)
            subclass(ChargeeDeviceErrorCode.ProvisioningFailure::class)
        }
    }
