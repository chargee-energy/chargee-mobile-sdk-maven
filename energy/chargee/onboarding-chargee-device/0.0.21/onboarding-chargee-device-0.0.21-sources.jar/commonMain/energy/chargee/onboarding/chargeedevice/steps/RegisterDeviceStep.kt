package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.core.network.models.ApiError
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.utils.result.fold

internal class RegisterDeviceStep(
    private val addressUuid: String,
    private val deviceType: ChargeeDeviceType,
    private val chargeeDeviceRepository: ChargeeDeviceRepository,
) : OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.RegisterDevice

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val deviceName =
            requireNotNull(context.deviceName) { "deviceName must be set by FindDeviceStep before RegisterDeviceStep runs" }
        val serialNumber = deviceName.removePrefix(context.devicePrefix)

        return chargeeDeviceRepository.createChargeeDevice(addressUuid, deviceType, serialNumber).fold(
            success = { Result.Success(context.copy(deviceUuid = it.uuid)) },
            failure = {
                Result.Failure(
                    context,
                    errorCode =
                        if (it is ApiError.Client.Conflict) {
                            ChargeeDeviceErrorCode.AlreadyRegistered
                        } else {
                            ChargeeDeviceErrorCode.RegistrationFailure
                        },
                    throwable = it.cause,
                )
            },
        )
    }
}
