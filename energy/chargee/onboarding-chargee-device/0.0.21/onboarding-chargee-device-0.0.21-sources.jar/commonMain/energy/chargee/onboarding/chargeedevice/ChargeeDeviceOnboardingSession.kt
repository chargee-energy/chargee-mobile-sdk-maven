package energy.chargee.onboarding.chargeedevice

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.utils.wifi.WifiConfiguration

/**
 * Onboarding session for Chargee devices (ESP Wi-Fi provisioning). Routes [ChargeeDeviceInput] and
 * surfaces [ChargeeDeviceStep]s in its typed state.
 */
@OnboardingSession
class ChargeeDeviceOnboardingSession(engine: OnboardingEngine<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>) :
    OnboardingSessionBase<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext, ChargeeDeviceStep, ChargeeDeviceInput>(
        engine,
    ) {
    /**
     * Starts the flow, optionally seeding a pre-selected [selectedWifiConfiguration] and target
     * [deviceUuid] before the first step runs. Suspends until the flow finishes — see
     * [OnboardingEngine.start] for the single-use contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(selectedWifiConfiguration: WifiConfiguration? = null, deviceUuid: String? = null) {
        runFlow { it.copy(selectedWifiConfiguration = selectedWifiConfiguration, deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [ChargeeDeviceStep]s: a started step becomes
     * [ChargeeDeviceStep.Running]; a failed step becomes [ChargeeDeviceStep.Failure] carrying a
     * retry callback; and a step pausing for input becomes
     * [ChargeeDeviceStep.AwaitingWifiSelection] (with the scanned networks) or
     * [ChargeeDeviceStep.AwaitingCorrectionFactor]. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<ChargeeDeviceStepId, ChargeeDeviceStep>,
        event: OnboardingFlow.Event<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>,
    ): OnboardingState<ChargeeDeviceStepId, ChargeeDeviceStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = ChargeeDeviceStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                when {
                    event.stepId == ChargeeDeviceStepId.ProvisionDevice &&
                        event.errorCode is ChargeeDeviceErrorCode.AuthenticationFailure -> {
                        current.copy(
                            currentStep =
                                ChargeeDeviceStep.AwaitingWifiSelection(
                                    status = OnboardingStepStatus.Failure,
                                    availableWifiNetworks = event.context.availableWifiNetworks,
                                    previousSsid = event.context.selectedWifiConfiguration?.ssid,
                                    previousPassword = event.context.selectedWifiConfiguration?.password,
                                    selectWifi = { submit(ChargeeDeviceInput.SelectWifi(it)) },
                                    rescan = { submit(ChargeeDeviceInput.RescanWifi) },
                                ),
                        )
                    }

                    event.willRetry -> {
                        super.reduce(current, event)
                    }

                    else -> {
                        current.copy(
                            currentStep =
                                ChargeeDeviceStep.Failure(event.stepId, error = event.errorCode) {
                                    submit(ChargeeDeviceInput.Retry)
                                },
                        )
                    }
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    ChargeeDeviceStepId.ProvisionDevice -> {
                        current.copy(
                            currentStep =
                                ChargeeDeviceStep.AwaitingWifiSelection(
                                    status = OnboardingStepStatus.WaitingForInput,
                                    availableWifiNetworks = event.context.availableWifiNetworks,
                                    selectWifi = { submit(ChargeeDeviceInput.SelectWifi(it)) },
                                    rescan = { submit(ChargeeDeviceInput.RescanWifi) },
                                ),
                        )
                    }

                    ChargeeDeviceStepId.CorrectionFactor -> {
                        current.copy(
                            currentStep =
                                ChargeeDeviceStep.AwaitingCorrectionFactor {
                                    submit(ChargeeDeviceInput.ConfirmCorrectionFactor)
                                },
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [ChargeeDeviceInput]: [Retry][ChargeeDeviceInput.Retry] re-runs a failed step;
     * [SelectWifi][ChargeeDeviceInput.SelectWifi] provisions with the chosen network and
     * [RescanWifi][ChargeeDeviceInput.RescanWifi] re-scans — both while waiting on network
     * selection — and [ConfirmCorrectionFactor][ChargeeDeviceInput.ConfirmCorrectionFactor]
     * continues past correction-factor confirmation.
     */
    override fun submit(input: ChargeeDeviceInput): SubmitResult =
        when (input) {
            ChargeeDeviceInput.Retry -> {
                requireFailure { engine.resume() }
            }

            is ChargeeDeviceInput.SelectWifi -> {
                requirePaused(ChargeeDeviceStepId.ProvisionDevice) {
                    engine.resume { it.copy(selectedWifiConfiguration = input.wifi) }
                }
            }

            ChargeeDeviceInput.RescanWifi -> {
                requirePaused(ChargeeDeviceStepId.ProvisionDevice) {
                    engine.revert()
                }
            }

            ChargeeDeviceInput.ConfirmCorrectionFactor -> {
                requireWaitingForInput(ChargeeDeviceStepId.CorrectionFactor) {
                    engine.resume()
                }
            }
        }
}
