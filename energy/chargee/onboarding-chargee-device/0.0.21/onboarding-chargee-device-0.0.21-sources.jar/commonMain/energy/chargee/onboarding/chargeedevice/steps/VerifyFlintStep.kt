package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceStatus
import energy.chargee.data.flint.repositories.FlintRepository
import energy.chargee.utils.result.get
import kotlin.time.Instant

internal class VerifyFlintStep(private val addressUuid: String, private val flintRepository: FlintRepository) : VerifyDeviceStep() {
    override suspend fun validateData(startTime: Instant, deviceUuid: String): Boolean {
        val flint = flintRepository.getFlint(addressUuid, deviceUuid).get() ?: return false
        return flint.status == ChargeeDeviceStatus.Online
    }
}
