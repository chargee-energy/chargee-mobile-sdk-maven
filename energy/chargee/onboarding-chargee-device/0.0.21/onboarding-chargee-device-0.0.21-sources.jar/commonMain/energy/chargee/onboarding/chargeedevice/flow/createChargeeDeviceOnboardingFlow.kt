package energy.chargee.onboarding.chargeedevice.flow

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingConfig
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.steps.CorrectionFactorStep
import energy.chargee.onboarding.chargeedevice.steps.FindDeviceStep
import energy.chargee.onboarding.chargeedevice.steps.FindWifiNetworksStep
import energy.chargee.onboarding.chargeedevice.steps.ProvisionDeviceStep
import energy.chargee.onboarding.chargeedevice.steps.RegisterDeviceStep
import energy.chargee.onboarding.core.createOnboardingFlow
import energy.chargee.onboarding.core.policies.ExponentialBackoffRetry

/**
 * Builds the base ESP Wi-Fi provisioning flow shared by every Chargee device type.
 *
 * Steps run in order:
 * 1. Discover the device over BLE via [espProvisioning], gated by [bluetoothAccess]'s
 *    permission and availability checks. Bounded by
 *    [ChargeeDeviceOnboardingConfig.stepTimeout].
 * 2. Register the device against [chargeeDeviceRepository] under [addressUuid] as
 *    [deviceType]. Skipped when the context already carries a `deviceUuid` — usually because
 *    the caller pre-registered the device or the flow is being re-driven after a partial
 *    completion.
 * 3. Apply the [deviceType]-specific correction factor from [featureFlagsRepository].
 * 4. Scan for Wi-Fi networks visible to the device and pause for the user to pick one. Both
 *    the scan and the follow-up input step are skipped when the context already carries a
 *    `selectedWifiConfiguration` (e.g. injected by the caller for a headless flow).
 * 5. Provision the device with the chosen credentials. Bounded by
 *    [ChargeeDeviceOnboardingConfig.stepTimeout] and retried up to
 *    [ChargeeDeviceOnboardingConfig.provisioningMaxAttempts] times with exponential backoff,
 *    except on [energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode.AuthenticationFailure]
 *    which aborts immediately so the user can correct their Wi-Fi password.
 *
 * This factory intentionally stops after provisioning. Sparky/Flint-specific verification —
 * confirming the newly provisioned device actually shows up in the backend and produces data —
 * is layered on top by [createSparkyOnboardingFlow] and [createFlintOnboardingFlow] via the
 * `extend` DSL.
 */
internal fun createChargeeDeviceOnboardingFlow(
    addressUuid: String,
    deviceType: ChargeeDeviceType,
    bluetoothAccess: BluetoothAccess,
    espProvisioning: EspProvisioning,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    featureFlagsRepository: FeatureFlagsRepository,
) = createOnboardingFlow("chargee-device") {
    step(FindDeviceStep(bluetoothAccess, espProvisioning), timeout = ChargeeDeviceOnboardingConfig.stepTimeout)
    whenTrue(condition = { it.deviceUuid == null }) {
        step(RegisterDeviceStep(addressUuid, deviceType, chargeeDeviceRepository))
    }
    step(CorrectionFactorStep(addressUuid, featureFlagsRepository))
    whenTrue(condition = { it.selectedWifiConfiguration == null }) {
        step(FindWifiNetworksStep(espProvisioning), timeout = ChargeeDeviceOnboardingConfig.stepTimeout)
    }
    step(
        ProvisionDeviceStep(espProvisioning),
        timeout = ChargeeDeviceOnboardingConfig.stepTimeout,
        retryPolicy =
            ExponentialBackoffRetry(
                maxAttempts = ChargeeDeviceOnboardingConfig.provisioningMaxAttempts,
                condition = { it !is ChargeeDeviceErrorCode.AuthenticationFailure },
            ),
    )
}
