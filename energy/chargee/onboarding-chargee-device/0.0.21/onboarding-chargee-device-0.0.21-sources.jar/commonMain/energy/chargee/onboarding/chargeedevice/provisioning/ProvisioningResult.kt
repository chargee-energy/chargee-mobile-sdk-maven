package energy.chargee.onboarding.chargeedevice.provisioning

/**
 * The outcome of an ESP device provisioning attempt.
 */
enum class ProvisioningResult {
    /** Wi-Fi credentials were accepted and the device connected successfully. */
    Success,

    /** The proof of possession or Wi-Fi credentials were rejected by the device. */
    AuthenticationFailure,

    /** Provisioning failed for an unspecified reason. */
    UnknownFailure,
}
