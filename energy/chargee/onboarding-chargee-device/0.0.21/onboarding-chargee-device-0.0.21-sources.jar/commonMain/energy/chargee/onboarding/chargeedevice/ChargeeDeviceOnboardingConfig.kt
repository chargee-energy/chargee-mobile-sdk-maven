package energy.chargee.onboarding.chargeedevice

import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/**
 * Tunable timing and retry constants for the Chargee device onboarding flow.
 *
 * Centralizes every magic duration / count that governs flow execution so callers
 * (and reviewers) can find them in one place rather than chasing literals scattered
 * across the step implementations and flow factories.
 */
internal object ChargeeDeviceOnboardingConfig {
    /** Per-step timeout applied to find/scan/provision steps. */
    val stepTimeout: Duration = 1.minutes

    /** Max attempts (excluding the first) for [energy.chargee.onboarding.chargeedevice.steps.ProvisionDeviceStep]'s exponential backoff. */
    val provisioningMaxAttempts: Int = 3

    /** Poll interval inside [energy.chargee.onboarding.chargeedevice.steps.VerifyDeviceStep]'s while-loop. */
    val validateDataPollInterval: Duration = 1.seconds

    /**
     * Engine-enforced timeout for [energy.chargee.onboarding.chargeedevice.steps.VerifyDeviceStep]; the only termination condition
     * when the predicate never becomes `true`.
     */
    val validateDataTimeout: Duration = 5.minutes
}
