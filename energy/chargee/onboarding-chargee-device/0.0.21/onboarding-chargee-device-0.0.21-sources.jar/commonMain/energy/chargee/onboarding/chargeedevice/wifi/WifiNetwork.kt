package energy.chargee.onboarding.chargeedevice.wifi

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * A Wi-Fi network discovered by a Chargee device during provisioning.
 *
 * Returned in the list produced by `EspProvisioning.scanWifiNetworks` and surfaced to the
 * host app so the user can pick the network the device should join. The list reflects what
 * the device itself can see, not what the phone running the app can see.
 *
 * [ssid] is the network name. [rssi] is the signal strength in dBm; higher (less negative)
 * values indicate a stronger signal. [secure] indicates whether the network needs a password
 * to join, e.g. WPA2-PSK.
 */
@Serializable
@ObjCName("_WifiNetwork")
data class WifiNetwork(val ssid: String, val rssi: Int, val secure: Boolean)
