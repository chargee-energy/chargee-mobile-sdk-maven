package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAvailability
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothPermissionStatus
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.core.OnboardingFlow
import kotlin.time.Clock

internal class FindDeviceStep(private val bluetoothAccess: BluetoothAccess, private val espProvisioning: EspProvisioning) :
    OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.FindDevice

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        bluetoothAccess.checkBluetoothAvailability().let { availability ->
            if (availability == BluetoothAvailability.NotAvailable) {
                return Result.Failure(context, ChargeeDeviceErrorCode.BluetoothNotAvailable)
            }

            if (availability == BluetoothAvailability.LocationNotAvailable) {
                return Result.Failure(context, ChargeeDeviceErrorCode.LocationNotAvailable)
            }
        }

        bluetoothAccess.checkBluetoothPermissionStatus().let { permissionStatus ->
            if (permissionStatus == BluetoothPermissionStatus.Denied) {
                return Result.Failure(context, ChargeeDeviceErrorCode.BluetoothPermissionDenied)
            }

            if (permissionStatus == BluetoothPermissionStatus.DeniedLocation) {
                return Result.Failure(context, ChargeeDeviceErrorCode.LocationPermissionDenied)
            }
        }

        val deviceName =
            espProvisioning.scanDevices(context.devicePrefix).firstOrNull()
                ?: return Result.Failure(
                    context,
                    ChargeeDeviceErrorCode.NoDeviceFound,
                )

        return Result.Success(context.copy(startTime = Clock.System.now(), deviceName = deviceName))
    }
}
