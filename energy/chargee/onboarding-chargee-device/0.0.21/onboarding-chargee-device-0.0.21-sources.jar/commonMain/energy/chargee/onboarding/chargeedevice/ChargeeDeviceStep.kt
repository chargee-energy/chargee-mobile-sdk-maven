package energy.chargee.onboarding.chargeedevice

import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork
import energy.chargee.onboarding.core.OnboardingErrorCode
import energy.chargee.onboarding.core.state.OnboardingStep
import energy.chargee.onboarding.core.state.OnboardingStepStatus
import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlin.native.ObjCName

/**
 * The presentation-facing steps a [ChargeeDeviceOnboardingSession] surfaces through its typed
 * state, each carrying the callbacks a UI needs to advance it.
 */
@ObjCName("_ChargeeDeviceStep")
@Serializable
sealed interface ChargeeDeviceStep : OnboardingStep<ChargeeDeviceStepId> {
    /**
     * The step [id] is currently executing.
     */
    @Serializable
    data class Running(override val id: ChargeeDeviceStepId, override val status: OnboardingStepStatus = OnboardingStepStatus.Running) :
        ChargeeDeviceStep

    /**
     * The step [id] failed with [error] and the engine has stopped retrying. Call [retry] to run it
     * again.
     */
    @Serializable
    data class Failure(
        override val id: ChargeeDeviceStepId,
        override val status: OnboardingStepStatus = OnboardingStepStatus.Failure,
        val error: OnboardingErrorCode,
        @Transient val retry: () -> Unit = {},
    ) : ChargeeDeviceStep

    /**
     * The flow is waiting for the user to pick a network from [availableWifiNetworks]. Call
     * [selectWifi] with the chosen network, or [rescan] to scan again.
     */
    @Serializable
    data class AwaitingWifiSelection(
        override val id: ChargeeDeviceStepId = ChargeeDeviceStepId.ProvisionDevice,
        override val status: OnboardingStepStatus,
        val availableWifiNetworks: List<WifiNetwork>,
        val previousSsid: String? = null,
        val previousPassword: String? = null,
        @Transient val selectWifi: (WifiConfiguration) -> Unit = {},
        @Transient val rescan: () -> Unit = {},
    ) : ChargeeDeviceStep

    /**
     * The flow is waiting for the user to confirm the measured correction factor via
     * [confirmCorrectionFactor].
     */
    @Serializable
    data class AwaitingCorrectionFactor(
        override val id: ChargeeDeviceStepId = ChargeeDeviceStepId.CorrectionFactor,
        override val status: OnboardingStepStatus = OnboardingStepStatus.WaitingForInput,
        @Transient val confirmCorrectionFactor: () -> Unit = {},
    ) : ChargeeDeviceStep
}
