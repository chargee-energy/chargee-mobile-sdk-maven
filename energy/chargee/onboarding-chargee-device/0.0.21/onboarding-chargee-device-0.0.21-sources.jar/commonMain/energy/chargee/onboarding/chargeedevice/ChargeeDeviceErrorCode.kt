package energy.chargee.onboarding.chargeedevice

import energy.chargee.onboarding.core.OnboardingErrorCode
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Error codes emitted on [energy.chargee.onboarding.core.OnboardingFlow.Event.StepFailure]
 * by the Chargee device onboarding steps.
 *
 * Engine-emitted codes ([OnboardingErrorCode.Timeout], [OnboardingErrorCode.Cancelled]) may
 * also appear on the same events.
 */
@ObjCName("_ChargeeDeviceErrorCode")
@Serializable
sealed interface ChargeeDeviceErrorCode : OnboardingErrorCode {
    /** Bluetooth hardware is powered off, unsupported, or otherwise inaccessible. */
    @Serializable
    data object BluetoothNotAvailable : ChargeeDeviceErrorCode

    /** Location services are required for BLE scanning (Android 11 and below) and are unavailable. */
    @Serializable
    data object LocationNotAvailable : ChargeeDeviceErrorCode

    /** Bluetooth permission has been denied or not yet requested. */
    @Serializable
    data object BluetoothPermissionDenied : ChargeeDeviceErrorCode

    /** Location permission is denied; required for Bluetooth scanning on Android 11 and below. */
    @Serializable
    data object LocationPermissionDenied : ChargeeDeviceErrorCode

    /** No Chargee device matching the configured prefix was found within the BLE scan window. */
    @Serializable
    data object NoDeviceFound : ChargeeDeviceErrorCode

    /** The backend rejected the device registration because the device is already registered. */
    @Serializable
    data object AlreadyRegistered : ChargeeDeviceErrorCode

    /** The backend rejected the device registration for an unspecified reason. */
    @Serializable
    data object RegistrationFailure : ChargeeDeviceErrorCode

    /** The Wi-Fi scan returned no networks visible to the device. */
    @Serializable
    data object NoWifiNetworksFound : ChargeeDeviceErrorCode

    /** The proof-of-possession or Wi-Fi credentials were rejected by the device. */
    @Serializable
    data object AuthenticationFailure : ChargeeDeviceErrorCode

    /** Provisioning failed for an unspecified reason. */
    @Serializable
    data object ProvisioningFailure : ChargeeDeviceErrorCode
}
