package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingConfig
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.core.OnboardingFlow
import kotlinx.coroutines.delay
import kotlin.time.Instant

internal abstract class VerifyDeviceStep : OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.VerifyDevice

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val startTime =
            requireNotNull(context.startTime) { "startTime must be set by FindDeviceStep before ValidateDataStep runs" }
        val deviceUuid =
            requireNotNull(context.deviceUuid) {
                "deviceUuid must be supplied via EspOnboardingSession.start or set by RegisterDeviceStep before ValidateDataStep runs"
            }

        while (!validateData(startTime, deviceUuid)) {
            delay(ChargeeDeviceOnboardingConfig.validateDataPollInterval)
        }

        // The engine-enforced timeout (EspOnboardingConfig.validateDataTimeout, set on the
        // step node in createEspOnboardingFlow) is the only termination condition when the
        // predicate never becomes true.
        return Result.Success(context)
    }

    protected abstract suspend fun validateData(startTime: Instant, deviceUuid: String): Boolean
}
