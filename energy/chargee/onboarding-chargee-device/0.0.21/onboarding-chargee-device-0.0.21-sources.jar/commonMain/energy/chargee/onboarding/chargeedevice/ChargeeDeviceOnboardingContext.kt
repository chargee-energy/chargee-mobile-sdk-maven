package energy.chargee.onboarding.chargeedevice

import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork
import energy.chargee.utils.wifi.WifiConfiguration
import kotlin.time.Instant

/**
 * The mutable context that flows through the Chargee device onboarding steps.
 *
 * Each step reads from and returns an updated copy of this context. Fields are populated
 * progressively as the flow advances. [devicePrefix] and [proofOfPossession] are required upfront by the
 * ESP provisioning protocol. [startTime] and [deviceName] are populated after the BLE scan
 * step — at that point the device is confirmed to be in provisioning mode, so [startTime]
 * marks when provisioning effectively began. [availableWifiNetworks] is populated after the
 * Wi-Fi scan step, and [selectedWifiConfiguration] once the user has made a choice.
 */
data class ChargeeDeviceOnboardingContext(
    val devicePrefix: String,
    val proofOfPossession: String,
    val startTime: Instant? = null,
    val deviceName: String? = null,
    val deviceUuid: String? = null,
    val availableWifiNetworks: List<WifiNetwork> = emptyList(),
    val selectedWifiConfiguration: WifiConfiguration? = null,
)
