package energy.chargee.onboarding.chargeedevice.flow

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository
import energy.chargee.data.smartmeter.repositories.SmartMeterRepository
import energy.chargee.data.sparky.repositories.SparkyRepository
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingConfig
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.steps.VerifySparkyStep
import energy.chargee.onboarding.core.createOnboardingFlow

/**
 * Builds the Sparky onboarding flow: the shared Chargee device provisioning flow followed by a
 * Sparky-specific verification step.
 *
 * Composed as:
 * 1. `extend` — inlines every step from [createChargeeDeviceOnboardingFlow] (with
 *    [ChargeeDeviceType.Sparky]) so the flow's event stream reports the same step ids callers
 *    already know how to react to.
 * 2. [energy.chargee.onboarding.chargeedevice.steps.VerifySparkyStep] — polls [sparkyRepository]
 *    and [smartMeterRepository] until the newly provisioned Sparky reports data through the
 *    backend for its mounted smart meter, which is the only signal that the device is fully
 *    online. Bounded by [ChargeeDeviceOnboardingConfig.validateDataTimeout]; the step never
 *    fails on its own (it polls until the engine times out).
 */
internal fun createSparkyOnboardingFlow(
    addressUuid: String,
    bluetoothAccess: BluetoothAccess,
    espProvisioning: EspProvisioning,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    featureFlagsRepository: FeatureFlagsRepository,
    sparkyRepository: SparkyRepository,
    smartMeterRepository: SmartMeterRepository,
) = createOnboardingFlow("sparky") {
    extend(
        createChargeeDeviceOnboardingFlow(
            addressUuid,
            ChargeeDeviceType.Sparky,
            bluetoothAccess,
            espProvisioning,
            chargeeDeviceRepository,
            featureFlagsRepository,
        ),
    )
    step(
        VerifySparkyStep(addressUuid, sparkyRepository, smartMeterRepository),
        timeout = ChargeeDeviceOnboardingConfig.validateDataTimeout,
    )
}
