package energy.chargee.onboarding.chargeedevice

import energy.chargee.core.di.module
import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.onboarding.chargeedevice.flow.createFlintOnboardingFlow
import energy.chargee.onboarding.chargeedevice.flow.createSparkyOnboardingFlow
import energy.chargee.onboarding.core.OnboardingEngine

val chargeeDeviceOnboardingModule =
    module {
        factoryWithParameters { parameters ->
            val addressUuid = parameters.get<String>(0)
            val deviceType = parameters.get<ChargeeDeviceType>(1)
            ChargeeDeviceOnboardingSession(
                OnboardingEngine(
                    initialContext =
                        ChargeeDeviceOnboardingContext(
                            devicePrefix =
                                when (deviceType) {
                                    ChargeeDeviceType.Sparky -> "CHA_"
                                    ChargeeDeviceType.Flint -> "FLI_"
                                },
                            proofOfPossession =
                                when (deviceType) {
                                    ChargeeDeviceType.Sparky -> "sparky!!"
                                    ChargeeDeviceType.Flint -> "chargee!!"
                                },
                        ),
                    flow =
                        when (deviceType) {
                            ChargeeDeviceType.Sparky -> {
                                createSparkyOnboardingFlow(
                                    addressUuid = addressUuid,
                                    bluetoothAccess = get(),
                                    espProvisioning = get(),
                                    chargeeDeviceRepository = get(),
                                    featureFlagsRepository = get(),
                                    sparkyRepository = get(),
                                    smartMeterRepository = get(),
                                )
                            }

                            ChargeeDeviceType.Flint -> {
                                createFlintOnboardingFlow(
                                    addressUuid,
                                    bluetoothAccess = get(),
                                    espProvisioning = get(),
                                    chargeeDeviceRepository = get(),
                                    featureFlagsRepository = get(),
                                    flintRepository = get(),
                                )
                            }
                        },
                ),
            )
        }
    }
