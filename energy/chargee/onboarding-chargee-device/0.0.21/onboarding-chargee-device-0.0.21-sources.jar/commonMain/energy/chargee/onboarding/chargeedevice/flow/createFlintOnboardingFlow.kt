package energy.chargee.onboarding.chargeedevice.flow

import energy.chargee.data.chargeedevice.enums.ChargeeDeviceType
import energy.chargee.data.chargeedevice.repositories.ChargeeDeviceRepository
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository
import energy.chargee.data.flint.repositories.FlintRepository
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingConfig
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.steps.VerifyFlintStep
import energy.chargee.onboarding.core.createOnboardingFlow

/**
 * Builds the Flint onboarding flow: the shared Chargee device provisioning flow followed by a
 * Flint-specific verification step.
 *
 * Composed as:
 * 1. `extend` — inlines every step from [createChargeeDeviceOnboardingFlow] (with
 *    [ChargeeDeviceType.Flint]) so the flow's event stream reports the same step ids callers
 *    already know how to react to.
 * 2. [energy.chargee.onboarding.chargeedevice.steps.VerifyFlintStep] — polls
 *    [flintRepository] until the newly provisioned Flint reports data through the backend,
 *    which is the only signal that the device is fully online. Bounded by
 *    [ChargeeDeviceOnboardingConfig.validateDataTimeout]; the step never fails on its own
 *    (it polls until the engine times out).
 */
internal fun createFlintOnboardingFlow(
    addressUuid: String,
    bluetoothAccess: BluetoothAccess,
    espProvisioning: EspProvisioning,
    chargeeDeviceRepository: ChargeeDeviceRepository,
    featureFlagsRepository: FeatureFlagsRepository,
    flintRepository: FlintRepository,
) = createOnboardingFlow("flint") {
    extend(
        createChargeeDeviceOnboardingFlow(
            addressUuid,
            ChargeeDeviceType.Flint,
            bluetoothAccess,
            espProvisioning,
            chargeeDeviceRepository,
            featureFlagsRepository,
        ),
    )
    step(
        VerifyFlintStep(addressUuid, flintRepository),
        timeout = ChargeeDeviceOnboardingConfig.validateDataTimeout,
    )
}
