package energy.chargee.onboarding.chargeedevice

import kotlinx.serialization.Serializable

/**
 * Step identifiers emitted on [energy.chargee.onboarding.core.OnboardingFlow.Event] for
 * Chargee device onboarding.
 *
 * Match against these entries when reacting to step events
 * (e.g. [energy.chargee.onboarding.core.OnboardingFlow.Event.StepInputRequired] or
 * [energy.chargee.onboarding.core.OnboardingFlow.Event.StepFailure]).
 */
@Serializable
enum class ChargeeDeviceStepId {
    FindDevice,
    RegisterDevice,
    CorrectionFactor,
    FindWifiNetworks,
    ProvisionDevice,
    VerifyDevice,
}
