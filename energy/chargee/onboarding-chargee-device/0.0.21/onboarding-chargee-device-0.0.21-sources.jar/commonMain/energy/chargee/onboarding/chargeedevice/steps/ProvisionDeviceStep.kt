package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.provisioning.ProvisioningResult
import energy.chargee.onboarding.core.OnboardingFlow

internal class ProvisionDeviceStep(private val espProvisioning: EspProvisioning) :
    OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.ProvisionDevice

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val deviceName =
            requireNotNull(context.deviceName) { "deviceName must be set by FindDeviceStep before ProvisionDeviceStep runs" }
        val wifiConfiguration =
            context.selectedWifiConfiguration ?: return Result.InputRequired(context, advanceAfterInput = false)

        val result =
            espProvisioning.provisionDevice(
                deviceName = deviceName,
                proofOfPossession = context.proofOfPossession,
                ssid = wifiConfiguration.ssid,
                passphrase = wifiConfiguration.password,
            )

        return when (result) {
            ProvisioningResult.Success -> {
                Result.Success(context)
            }

            ProvisioningResult.AuthenticationFailure -> {
                Result.Failure(
                    context,
                    ChargeeDeviceErrorCode.AuthenticationFailure,
                )
            }

            ProvisioningResult.UnknownFailure -> {
                Result.Failure(
                    context,
                    ChargeeDeviceErrorCode.ProvisioningFailure,
                )
            }
        }
    }
}
