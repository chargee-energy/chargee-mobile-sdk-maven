package energy.chargee.onboarding.chargeedevice

import energy.chargee.utils.wifi.WifiConfiguration
import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * Inputs for the Chargee device onboarding flow (ESP Wi-Fi provisioning). A flat, sealed hierarchy
 * whose cases the [ChargeeDeviceOnboardingSession] routes; each documents when it is accepted.
 */
@ObjCName("_ChargeeDeviceInput")
@Serializable
sealed interface ChargeeDeviceInput {
    /**
     * Re-runs the step the flow is currently paused on. Accepted only while that step is in a
     * failure state; rejected otherwise.
     */
    @Serializable
    data object Retry : ChargeeDeviceInput

    /**
     * Provisions the device with the chosen [wifi] network. Accepted while the flow is waiting for
     * a Wi-Fi network to be selected.
     */
    @Serializable
    data class SelectWifi(val wifi: WifiConfiguration) : ChargeeDeviceInput

    /**
     * Re-scans for available Wi-Fi networks, reverting to the scan step. Accepted while the flow is
     * waiting for a Wi-Fi network to be selected.
     */
    @Serializable
    data object RescanWifi : ChargeeDeviceInput

    /**
     * Confirms the measured correction factor and continues. Accepted while the flow is waiting for
     * correction-factor confirmation.
     */
    @Serializable
    data object ConfirmCorrectionFactor : ChargeeDeviceInput
}
