package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.data.featureflags.Features
import energy.chargee.data.featureflags.repositories.FeatureFlagsRepository
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.utils.result.get

internal class CorrectionFactorStep(private val addressUuid: String, private val featureFlagsRepository: FeatureFlagsRepository) :
    OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.CorrectionFactor

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val featureFlags = featureFlagsRepository.getFeatureFlags().get()
        return if (featureFlags?.get(addressUuid)?.contains(Features.CORRECTION_FACTOR) ?: false) {
            Result.InputRequired(context)
        } else {
            Result.Success(context)
        }
    }
}
