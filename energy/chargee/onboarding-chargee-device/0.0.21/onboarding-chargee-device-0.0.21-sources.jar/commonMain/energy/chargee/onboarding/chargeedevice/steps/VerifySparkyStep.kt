package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.data.smartmeter.repositories.SmartMeterRepository
import energy.chargee.data.sparky.repositories.SparkyRepository
import energy.chargee.utils.result.get
import kotlin.time.Instant

internal class VerifySparkyStep(
    private val addressUuid: String,
    private val sparkyRepository: SparkyRepository,
    private val smartMeterRepository: SmartMeterRepository,
) : VerifyDeviceStep() {
    override suspend fun validateData(startTime: Instant, deviceUuid: String): Boolean {
        val smartMeters = smartMeterRepository.getSmartMeters(addressUuid).get() ?: return false
        val sparkyStatus = sparkyRepository.getSparkyStatus(addressUuid, deviceUuid).get() ?: return false
        val latestMessageTime = sparkyStatus.latestMessage ?: return false
        return smartMeters.any { it.connectionType != null } && latestMessageTime > startTime
    }
}
