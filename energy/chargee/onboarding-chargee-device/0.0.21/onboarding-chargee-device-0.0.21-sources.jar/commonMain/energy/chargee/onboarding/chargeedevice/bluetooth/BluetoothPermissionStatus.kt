package energy.chargee.onboarding.chargeedevice.bluetooth

/**
 * The status of the app-level permissions required to use Bluetooth.
 *
 * Reported by [BluetoothAccess.checkBluetoothPermissionStatus]. Distinct from
 * [BluetoothAvailability], which describes the state of the radio itself rather than what
 * this app is allowed to do with it.
 */
enum class BluetoothPermissionStatus {
    /**
     * Every permission required by the current OS version is granted; scanning may proceed.
     */
    Granted,

    /**
     * The Bluetooth permission has been denied or has not yet been requested. On Android
     * 12+ this covers `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT`; on Android 11 and below it
     * covers the legacy `BLUETOOTH` permission. On iOS this is the user-facing Bluetooth
     * authorization prompt.
     */
    Denied,

    /**
     * Bluetooth permissions are granted but `ACCESS_FINE_LOCATION` /
     * `ACCESS_COARSE_LOCATION` are not, and the platform requires them for scanning.
     * Android 11 and below only — newer Android versions and iOS do not return this value.
     */
    DeniedLocation,
}
