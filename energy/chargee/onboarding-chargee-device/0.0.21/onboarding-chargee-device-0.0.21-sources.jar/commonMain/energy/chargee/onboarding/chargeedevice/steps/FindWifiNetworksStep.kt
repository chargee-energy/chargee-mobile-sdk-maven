package energy.chargee.onboarding.chargeedevice.steps

import energy.chargee.onboarding.chargeedevice.ChargeeDeviceErrorCode
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceOnboardingContext
import energy.chargee.onboarding.chargeedevice.ChargeeDeviceStepId
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.core.OnboardingFlow

internal class FindWifiNetworksStep(private val espProvisioning: EspProvisioning) :
    OnboardingFlow.Step<ChargeeDeviceStepId, ChargeeDeviceOnboardingContext>() {
    override val id = ChargeeDeviceStepId.FindWifiNetworks

    override suspend fun execute(context: ChargeeDeviceOnboardingContext): Result<ChargeeDeviceOnboardingContext> {
        val deviceName =
            requireNotNull(context.deviceName) { "deviceName must be set by FindDeviceStep before FindWifiNetworksStep runs" }
        val networks =
            espProvisioning
                .scanWifiNetworks(deviceName, context.proofOfPossession)
                .sortedByDescending { it.rssi }

        if (networks.isEmpty()) {
            return Result.Failure(context, ChargeeDeviceErrorCode.NoWifiNetworksFound)
        }

        return Result.Success(context.copy(availableWifiNetworks = networks))
    }
}
