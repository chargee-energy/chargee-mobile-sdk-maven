package energy.chargee.onboarding.chargeedevice.provisioning

import cocoapods.ESPProvisionWrapper.ESPProvisionWrapper
import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork
import energy.chargee.utils.concurrency.ResumeOnce
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine

@OptIn(ExperimentalForeignApi::class)
internal class EspProvisioningIos(private val espProvisionWrapper: ESPProvisionWrapper) : EspProvisioning {
    override suspend fun scanDevices(prefix: String?) =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            continuation.invokeOnCancellation { espProvisionWrapper.stopESPDevicesSearch() }
            espProvisionWrapper.searchESPDevicesWithDevicePrefix(prefix ?: "") { deviceNames ->
                gate.resumeOnce(deviceNames?.filterIsInstance<String>() ?: emptyList())
            }
        }

    override suspend fun scanWifiNetworks(deviceName: String, proofOfPossession: String) =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            continuation.invokeOnCancellation { espProvisionWrapper.disconnectDevice() }
            espProvisionWrapper.scanWifiNetworksWithDeviceName(deviceName, proofOfPossession) { networks ->
                val convertedNetworks =
                    networks
                        ?.filterIsInstance<cocoapods.ESPProvisionWrapper.WifiNetwork>()
                        ?.map {
                            WifiNetwork(
                                ssid = it.ssid(),
                                rssi = it.rssi().toInt(),
                                secure = it.authMode() != 0L,
                            )
                        } ?: emptyList()
                gate.resumeOnce(convertedNetworks)
            }
        }

    override suspend fun provisionDevice(deviceName: String, proofOfPossession: String, ssid: String, passphrase: String?) =
        suspendCancellableCoroutine { continuation ->
            val gate = ResumeOnce(continuation)
            continuation.invokeOnCancellation { espProvisionWrapper.disconnectDevice() }
            espProvisionWrapper.provisionDeviceWithDeviceName(
                deviceName,
                proofOfPossession,
                ssid,
                passphrase ?: "",
            ) { gate.resumeOnce(it.asProvisioningResult()) }
        }

    private fun cocoapods.ESPProvisionWrapper.ProvisioningResult.asProvisioningResult(): ProvisioningResult =
        when (this) {
            cocoapods.ESPProvisionWrapper.ProvisioningResultSuccess -> ProvisioningResult.Success
            cocoapods.ESPProvisionWrapper.ProvisioningResultAuthenticationFailure -> ProvisioningResult.AuthenticationFailure
            else -> ProvisioningResult.UnknownFailure
        }
}
