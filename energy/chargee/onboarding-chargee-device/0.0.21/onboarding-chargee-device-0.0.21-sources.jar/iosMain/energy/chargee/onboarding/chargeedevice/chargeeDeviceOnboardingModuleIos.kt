package energy.chargee.onboarding.chargeedevice

import cocoapods.ESPProvisionWrapper.ESPProvisionWrapper
import energy.chargee.core.di.module
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccessIos
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioningIos
import kotlinx.cinterop.ExperimentalForeignApi

@OptIn(ExperimentalForeignApi::class)
val chargeeDeviceOnboardingModuleIos =
    module {
        factory<EspProvisioning> { EspProvisioningIos(ESPProvisionWrapper()) }
        factory<BluetoothAccess> { BluetoothAccessIos() }
    }
