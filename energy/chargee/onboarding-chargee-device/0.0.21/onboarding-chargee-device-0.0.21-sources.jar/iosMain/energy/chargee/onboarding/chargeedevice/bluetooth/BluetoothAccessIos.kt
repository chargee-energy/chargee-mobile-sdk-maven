package energy.chargee.onboarding.chargeedevice.bluetooth

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import platform.CoreBluetooth.CBCentralManager
import platform.CoreBluetooth.CBCentralManagerDelegateProtocol
import platform.CoreBluetooth.CBCentralManagerOptionShowPowerAlertKey
import platform.CoreBluetooth.CBManagerAuthorizationAllowedAlways
import platform.CoreBluetooth.CBManagerStatePoweredOn
import platform.Foundation.NSNumber
import platform.Foundation.numberWithBool
import platform.darwin.NSObject

@OptIn(ExperimentalForeignApi::class)
internal class BluetoothAccessIos : BluetoothAccess {
    private val state = MutableStateFlow<BluetoothAvailability?>(null)
    private var centralManager: CBCentralManager? = null

    private val delegate =
        object : NSObject(), CBCentralManagerDelegateProtocol {
            override fun centralManagerDidUpdateState(central: CBCentralManager) {
                state.value =
                    when (central.state) {
                        CBManagerStatePoweredOn -> BluetoothAvailability.Available
                        else -> BluetoothAvailability.NotAvailable
                    }
            }
        }

    override suspend fun checkBluetoothAvailability(): BluetoothAvailability {
        if (centralManager == null) {
            centralManager =
                CBCentralManager(
                    delegate = delegate,
                    queue = null,
                    options = mapOf(CBCentralManagerOptionShowPowerAlertKey to NSNumber.numberWithBool(false)),
                )
        }
        return state.first { it != null }!!
    }

    override suspend fun checkBluetoothPermissionStatus() =
        when (CBCentralManager.authorization()) {
            CBManagerAuthorizationAllowedAlways -> BluetoothPermissionStatus.Granted
            else -> BluetoothPermissionStatus.Denied
        }
}
