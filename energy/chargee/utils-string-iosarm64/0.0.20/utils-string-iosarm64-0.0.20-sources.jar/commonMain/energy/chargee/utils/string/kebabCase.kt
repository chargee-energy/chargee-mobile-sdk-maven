package energy.chargee.utils.string

/**
 * Converts this string to kebab-case for use as an API path segment.
 */
fun String.kebabCase(): String {
    if (this.isEmpty()) return this

    // 1. Replace underscores with spaces (snake_case)
    var str = this.replace("_", " ")

    // 2. Add space before uppercase letters that follow lowercase or digits
    str = str.replace(Regex("([a-z0-9])([A-Z])"), "$1 $2")

    // 3. Add space between consecutive uppercase letters followed by lowercase (acronyms)
    str = str.replace(Regex("([A-Z])([A-Z][a-z])"), "$1 $2")

    // 4. Split by spaces or non-word characters
    val words = str.trim().split(Regex("\\s+|[^A-Za-z0-9]"))

    // 5. Join with hyphens and lowercase
    return words
        .filter { it.isNotEmpty() }
        .joinToString("-") { it.lowercase() }
}
