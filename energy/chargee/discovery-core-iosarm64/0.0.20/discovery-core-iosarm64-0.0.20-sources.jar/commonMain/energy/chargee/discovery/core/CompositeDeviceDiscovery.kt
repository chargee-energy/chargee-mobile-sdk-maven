package energy.chargee.discovery.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * A [DeviceDiscovery] that tries [discoveries] in order and yields the results of the first
 * strategy that finds anything.
 *
 * Each strategy is collected in turn and its devices are emitted as they arrive. Once a strategy
 * finishes, discovery stops there if that strategy produced at least one device; a strategy that
 * completes without emitting counts as a miss and the next one is tried. When every strategy comes
 * up empty — or when there are no [discoveries] at all — the composite completes empty too.
 *
 * Use this to express a preference order between transports, for example an mDNS lookup first and
 * a port scan only as a fallback for devices that don't announce themselves. Every collection
 * restarts the sequence from the first strategy, so the composite honours the
 * collect-again-for-a-fresh-run contract of [DeviceDiscovery] as long as its [discoveries] do.
 */
class CompositeDeviceDiscovery(private vararg val discoveries: DeviceDiscovery) : DeviceDiscovery {
    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            for (discovery in discoveries) {
                var emitted = false
                discovery.discover().collect {
                    emitted = true
                    emit(it)
                }
                if (emitted) return@flow
            }
        }
}
