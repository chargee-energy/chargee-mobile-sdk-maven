package energy.chargee.discovery.core

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName

/**
 * A device located on the network by a [DeviceDiscovery] strategy.
 *
 * Only [ipAddress] is guaranteed; [port] is present when the strategy can determine it
 * (mDNS SRV records, TCP scan), and absent for strategies that only confirm host reachability
 * (e.g. UDP broadcast responses that don't echo a service port).
 *
 * [extraParameters] is an optional map of any extra parameters retrieved by the discovery.
 */
@Serializable
@ObjCName("_DiscoveredDevice")
data class DiscoveredDevice(val ipAddress: String, val port: Int? = null, val extraParameters: Map<String, String> = emptyMap())
