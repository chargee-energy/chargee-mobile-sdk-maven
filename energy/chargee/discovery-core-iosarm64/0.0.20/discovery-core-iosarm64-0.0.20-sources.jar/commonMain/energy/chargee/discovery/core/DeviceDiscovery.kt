package energy.chargee.discovery.core

import kotlinx.coroutines.flow.Flow

/**
 * A strategy for locating devices on the local network.
 *
 * Implementations emit [DiscoveredDevice] values as devices are found. The discovery
 * lifecycle is bound to flow collection: starting collection begins discovery,
 * cancelling the collector stops it, and releases platform resources (sockets,
 * service browsers, etc.).
 *
 * Implementations should:
 * - Be safe to collect multiple times (each collection starts a fresh discovery).
 * - Deduplicate within a single collection where the underlying transport
 *   naturally re-emits (e.g. mDNS announcements).
 * - Never throw from the flow on transient I/O errors — log and continue.
 * - Always complete the flow, even if no devices are found. When the underlying transport
 *   doesn't naturally complete (e.g. mDNS), it should implement a timeout.
 */
fun interface DeviceDiscovery {
    fun discover(): Flow<DiscoveredDevice>
}
