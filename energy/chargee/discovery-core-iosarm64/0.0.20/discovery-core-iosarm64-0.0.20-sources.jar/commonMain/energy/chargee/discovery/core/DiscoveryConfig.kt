package energy.chargee.discovery.core

/**
 * DI qualifiers under which the discovery modules register their [DeviceDiscovery] strategies.
 *
 * Each constant names one strategy, not one device: a caller picks the mechanism it wants and
 * passes the target (service type, port, broadcast payload) as DI parameters. The qualifier is
 * declared here rather than in the implementing module so that consumers — the brand onboarding
 * modules in particular — can resolve a strategy without depending on the module that provides it.
 *
 * ```kotlin
 * get<DeviceDiscovery>(
 *     name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
 *     parameters = parametersOf("_example._tcp"),
 * )
 * ```
 *
 * A qualifier only resolves once the module registering it has been registered on the
 * `DependencyRegistry`; `ChargeeSdk` registers all four.
 */
object DiscoveryConfig {
    /**
     * mDNS browsing for a service type on the current network, registered by `discovery-mdns`.
     *
     * Takes the service type (e.g. `"_chargee_p1._tcp"`) as the first parameter and an optional
     * `Duration` timeout as the second, defaulting to 5 seconds.
     */
    const val MDNS_DISCOVERY_TYPE = "mdns"

    /**
     * A sweep of the phone's local subnet for hosts accepting TCP connections on a single port,
     * registered by `discovery-port-scan`. Use it for devices that advertise nothing at all.
     *
     * Takes the port as the first parameter and an optional `Duration` per-host connection timeout
     * as the second, defaulting to 100 milliseconds.
     */
    const val PORT_SCAN_DISCOVERY_TYPE = "port-scan"

    /**
     * The inverse of [PORT_SCAN_DISCOVERY_TYPE]: one known host probed across several candidate
     * ports, registered by `discovery-port-scan`. Use it when the address is already known and the
     * port is what identifies the device.
     *
     * Takes the IP address as the first parameter, the `List<Int>` of candidate ports as the second,
     * and an optional `Duration` connection timeout as the third, defaulting to 100 milliseconds.
     */
    const val OPEN_PORT_DISCOVERY_TYPE = "open-port"

    /**
     * A UDP broadcast that devices answer with an identifying datagram, registered by
     * `discovery-udp-broadcast`.
     *
     * Takes the broadcast port as the first parameter and the `ByteArray` payload as the second,
     * with an optional `Duration` response timeout as the third, defaulting to 10 seconds, and an
     * optional `UdpBroadcastResponseParser` as the fourth. Without a parser a device is reported at
     * the address its reply came from and nothing is read out of the payload, since the reply
     * format is specific to the device. A device answering more than once is emitted once.
     */
    const val UDP_BROADCAST_DISCOVERY_TYPE = "udp-broadcast"
}
