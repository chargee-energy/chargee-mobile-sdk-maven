package energy.chargee.discovery.core

import energy.chargee.core.logging.ChargeeLog

/**
 * The tag every discovery line carries, so a consumer's logger can isolate discovery from
 * everything else it is given — `adb logcat -s ChargeeDiscovery` on Android once the lines reach
 * `Log`, a subsystem filter in Console on iOS.
 */
const val DISCOVERY_LOG_TAG = "ChargeeDiscovery"

/**
 * Writes one line about what a discovery is doing, at debug level under [DISCOVERY_LOG_TAG].
 *
 * Discovery is the part of onboarding that is hardest to reason about after the fact: several
 * strategies run, most of them find nothing most of the time, and which one produced a given
 * device decides what the rest of the flow does with it. One line per device, bracketed by the
 * strategy that found it, is enough to answer that from a log someone sends you.
 *
 * [message] is built only when the consumer installed a logger, so a line costs nothing when
 * nobody is listening. Device addresses and ports belong in it; nothing a device reports about
 * itself does. A serial number is a hardware identifier, and wherever these lines end up is the
 * host app's decision, not this module's.
 */
fun logDiscovery(message: () -> String) {
    ChargeeLog.debug(DISCOVERY_LOG_TAG, message = message)
}

/** This device as `10.33.2.53:502`, or just the address when the strategy reported no port. */
fun DiscoveredDevice.describe(): String = port?.let { "$ipAddress:$it" } ?: ipAddress
