package energy.chargee.discovery.core

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.time.Duration
import kotlin.time.TimeSource

/**
 * A [DeviceDiscovery] that re-runs [discovery] every [interval] until it finds something or
 * [timeout] has elapsed.
 *
 * Use it where a device is expected to appear rather than known to be there — most of all after a
 * flow has reconfigured the device's network and it has to drop its own access point, join the
 * customer's LAN and take a lease before anything can reach it. A discovery run against that
 * device the moment the reconfiguration is acknowledged reports no device at all, which reads as
 * missing hardware instead of hardware that is still on its way. The same goes for the phone: a
 * scan started before it is back on the LAN itself has nothing to scan from.
 *
 * [timeout] bounds when a further attempt may *start*, not how long the discovery runs. An attempt
 * already under way is left to finish, so the total can overrun by one attempt — the alternative,
 * cancelling mid-scan, would throw away a device that was about to be found.
 *
 * Only the attempt that finds something emits: an empty attempt is a miss and nothing reaches the
 * collector until one succeeds, which keeps the retry invisible to a caller that just wants the
 * devices. Each attempt collects [discovery] afresh, so the wrapped discovery must honour the
 * collect-again-for-a-fresh-run contract of [DeviceDiscovery].
 */
class RetryingDeviceDiscovery internal constructor(
    private val discovery: DeviceDiscovery,
    private val timeout: Duration,
    private val interval: Duration,
    private val timeSource: TimeSource,
) : DeviceDiscovery {
    /**
     * Retries [discovery] every [interval] until it finds a device or [timeout] has elapsed.
     */
    constructor(discovery: DeviceDiscovery, timeout: Duration, interval: Duration) :
        this(discovery, timeout, interval, TimeSource.Monotonic)

    override fun discover(): Flow<DiscoveredDevice> =
        flow {
            val start = timeSource.markNow()

            while (true) {
                var found = false
                discovery.discover().collect { device ->
                    found = true
                    emit(device)
                }

                if (found || start.elapsedNow() >= timeout) return@flow
                delay(interval)
            }
        }
}
