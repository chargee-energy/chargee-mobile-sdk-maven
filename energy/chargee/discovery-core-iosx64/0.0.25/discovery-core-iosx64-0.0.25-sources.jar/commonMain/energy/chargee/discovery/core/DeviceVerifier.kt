package energy.chargee.discovery.core

/**
 * Decides whether a device a [DeviceDiscovery] located is actually the device being looked for.
 *
 * A transport only proves that something answered: an mDNS record was published, a TCP port
 * accepted a connection, a datagram came back. Where that is not enough to identify the hardware,
 * a verifier talks to the candidate in its own protocol and either confirms or discards it.
 *
 * Returning `null` rejects [device] and drops it from the discovery. Returning a device keeps it,
 * which is also the place to fold anything learned while verifying — a serial number, a firmware
 * version — into its [DiscoveredDevice.extraParameters], so a caller choosing between several
 * candidates has something to tell them apart by. The returned device need not be the one passed
 * in, but it should describe the same host: the address a caller dials afterwards comes from it.
 *
 * Verification runs once per candidate while the discovery flow is being collected, so an
 * implementation must bound its own I/O — a probe that waits out a platform default stalls the
 * whole scan.
 */
fun interface DeviceVerifier {
    suspend fun verify(device: DiscoveredDevice): DiscoveredDevice?
}
