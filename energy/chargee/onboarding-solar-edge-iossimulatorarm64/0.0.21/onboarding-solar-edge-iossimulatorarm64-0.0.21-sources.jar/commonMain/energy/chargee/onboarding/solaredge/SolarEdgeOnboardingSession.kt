package energy.chargee.onboarding.solaredge

import co.touchlab.skie.configuration.annotations.DefaultArgumentInterop
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.core.OnboardingFlow
import energy.chargee.onboarding.core.session.OnboardingSession
import energy.chargee.onboarding.core.session.OnboardingSessionBase
import energy.chargee.onboarding.core.session.SubmitResult
import energy.chargee.onboarding.core.state.OnboardingState
import energy.chargee.onboarding.localdevice.LocalDeviceStepId

/**
 * Onboarding session for SolarEdge inverters. Routes [SolarEdgeInput] — device selection, retry,
 * and Wi-Fi setup — and surfaces [SolarEdgeStep]s in its typed state.
 */
@OnboardingSession
class SolarEdgeOnboardingSession(engine: OnboardingEngine<LocalDeviceStepId, SolarEdgeOnboardingContext>) :
    OnboardingSessionBase<LocalDeviceStepId, SolarEdgeOnboardingContext, SolarEdgeStep, SolarEdgeInput>(engine) {
    /**
     * Starts the flow, driving the engine via [OnboardingSessionBase.runFlow], seeding the context
     * with an optional [deviceUuid] before the first step runs. Passing a [deviceUuid] turns the
     * run into a reset of that already-registered inverter: the local-AP association and device
     * configuration steps are skipped, and instead of registering a new inverter the flow updates
     * the stored configuration with the rediscovered values before re-verifying.
     *
     * It is declared on each concrete session rather than the base because SKIE cannot bridge a
     * generic `suspend` function to Swift: a shared one would surface as `skie(session).start()`
     * instead of the flat `session.start()` API we want to expose.
     *
     * A session is single-use — see [OnboardingEngine.start] for the full contract.
     *
     * @throws IllegalStateException if the session has already been started.
     */
    @Throws(IllegalStateException::class)
    @DefaultArgumentInterop.Enabled
    suspend fun start(deviceUuid: String? = null) {
        runFlow { it.copy(deviceUuid = deviceUuid) }
    }

    /**
     * Maps the engine's step events onto [SolarEdgeStep]s: a started step becomes
     * [SolarEdgeStep.Running]; a failed step becomes [SolarEdgeStep.Failure] carrying a retry
     * callback; and a pause on Wi-Fi setup becomes [SolarEdgeStep.AwaitingWifi] while a pause on
     * device discovery becomes [SolarEdgeStep.AwaitingDevice]. Flow-level events delegate to
     * [OnboardingSessionBase.reduce].
     */
    override fun reduce(
        current: OnboardingState<LocalDeviceStepId, SolarEdgeStep>,
        event: OnboardingFlow.Event<LocalDeviceStepId, SolarEdgeOnboardingContext>,
    ): OnboardingState<LocalDeviceStepId, SolarEdgeStep> =
        when (event) {
            is OnboardingFlow.Event.StepStarted -> {
                current.copy(currentStep = SolarEdgeStep.Running(event.stepId))
            }

            is OnboardingFlow.Event.StepFailure -> {
                if (!event.willRetry) {
                    current.copy(
                        currentStep =
                            SolarEdgeStep.Failure(
                                event.stepId,
                                error = event.errorCode,
                                deviceUuid = event.context.deviceUuid,
                            ) {
                                submit(SolarEdgeInput.Retry)
                            },
                    )
                } else {
                    super.reduce(current, event)
                }
            }

            is OnboardingFlow.Event.StepInputRequired -> {
                when (event.stepId) {
                    LocalDeviceStepId.ConnectLocalAp -> {
                        current.copy(
                            currentStep =
                                SolarEdgeStep.AwaitingWifi(
                                    setWifi = { wifi, model -> submit(SolarEdgeInput.SetWifi(wifi, model)) },
                                    skipWifi = { submit(SolarEdgeInput.SkipWifiSetup) },
                                ),
                        )
                    }

                    LocalDeviceStepId.DiscoverDevice -> {
                        current.copy(
                            currentStep =
                                SolarEdgeStep.AwaitingDevice(
                                    possibleDevices = event.context.discoveredDevices,
                                    setDevice = { submit(SolarEdgeInput.SetDevice(it)) },
                                    rescan = { submit(SolarEdgeInput.RescanDevices) },
                                ),
                        )
                    }

                    else -> {
                        super.reduce(current, event)
                    }
                }
            }

            else -> {
                super.reduce(current, event)
            }
        }

    /**
     * Applies [SolarEdgeInput]: [Retry][SolarEdgeInput.Retry] re-runs a failed step; while waiting
     * for Wi-Fi setup [SkipWifiSetup][SolarEdgeInput.SkipWifiSetup] advances past it and
     * [SetWifi][SolarEdgeInput.SetWifi] resumes with the chosen network; and
     * [SetDevice][SolarEdgeInput.SetDevice] selects the device while waiting on discovery.
     */
    override fun submit(input: SolarEdgeInput): SubmitResult =
        when (input) {
            SolarEdgeInput.Retry -> {
                requireFailure { engine.resume() }
            }

            SolarEdgeInput.SkipWifiSetup -> {
                requireWaitingForInput(LocalDeviceStepId.ConnectLocalAp) {
                    engine.advance()
                }
            }

            is SolarEdgeInput.SetWifi -> {
                requireWaitingForInput(LocalDeviceStepId.ConnectLocalAp) {
                    engine.resume { it.copy(wifiConfiguration = input.wifi, model = input.model) }
                }
            }

            is SolarEdgeInput.SetDevice -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.resume { it.copy(selectedDevice = input.device) }
                }
            }

            SolarEdgeInput.RescanDevices -> {
                requireWaitingForInput(LocalDeviceStepId.DiscoverDevice) {
                    engine.revert()
                }
            }
        }
}
