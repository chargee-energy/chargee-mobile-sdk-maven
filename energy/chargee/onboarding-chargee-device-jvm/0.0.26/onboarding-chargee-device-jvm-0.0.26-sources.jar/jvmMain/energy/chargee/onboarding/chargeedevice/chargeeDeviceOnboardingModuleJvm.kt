package energy.chargee.onboarding.chargeedevice

import energy.chargee.core.di.module
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAccess
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothAvailability
import energy.chargee.onboarding.chargeedevice.bluetooth.BluetoothPermissionStatus
import energy.chargee.onboarding.chargeedevice.provisioning.EspProvisioning
import energy.chargee.onboarding.chargeedevice.provisioning.ProvisioningResult
import energy.chargee.onboarding.chargeedevice.wifi.WifiNetwork

/**
 * The JVM registrations for Chargee device provisioning, which report that the hardware is not
 * there.
 *
 * Provisioning a Sparky or Flint means driving ESP-IDF's BLE protocol through a vendor SDK that
 * exists for Android and iOS only. Nothing here pretends otherwise: Bluetooth reports as
 * unavailable, so a flow that reaches for it stops with the same error a phone with Bluetooth
 * switched off would produce, rather than failing somewhere less recognisable.
 */
val chargeeDeviceOnboardingModuleJvm =
    module {
        factory<BluetoothAccess> { BluetoothAccessJvm() }
        factory<EspProvisioning> { EspProvisioningJvm() }
    }

private class BluetoothAccessJvm : BluetoothAccess {
    override suspend fun checkBluetoothAvailability() = BluetoothAvailability.NotAvailable

    override suspend fun checkBluetoothPermissionStatus() = BluetoothPermissionStatus.Denied
}

private class EspProvisioningJvm : EspProvisioning {
    override suspend fun scanDevices(prefix: String?): List<String> = emptyList()

    override suspend fun scanWifiNetworks(deviceName: String, proofOfPossession: String): List<WifiNetwork> = emptyList()

    override suspend fun provisionDevice(deviceName: String, proofOfPossession: String, ssid: String, passphrase: String?) =
        ProvisioningResult.UnknownFailure
}
