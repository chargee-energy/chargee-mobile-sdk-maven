package energy.chargee.utils.result

/**
 * Chains a [Result]-returning [transform] onto a [Result.Success], leaving [Result.Failure] unchanged.
 *
 * Unlike [map], [transform] returns a [Result], so failures from the chained operation are
 * propagated naturally without nesting.
 */
inline infix fun <V, E, U> Result<V, E>.andThen(transform: (V) -> Result<U, E>): Result<U, E> =
    when (this) {
        is Result.Success -> transform(value)
        is Result.Failure -> Result.Failure(error)
    }
