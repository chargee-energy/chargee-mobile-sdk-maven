package energy.chargee.utils.result

/**
 * Transforms the error of a [Result.Failure] using [transform], leaving [Result.Success] unchanged.
 */
inline infix fun <V, E, F> Result<V, E>.mapError(transform: (E) -> F): Result<V, F> =
    when (this) {
        is Result.Failure -> Result.Failure(transform(error))
        is Result.Success -> Result.Success(value)
    }
