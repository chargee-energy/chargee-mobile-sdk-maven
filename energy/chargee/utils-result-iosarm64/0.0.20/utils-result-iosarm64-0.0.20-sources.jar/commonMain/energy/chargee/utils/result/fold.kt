package energy.chargee.utils.result

/**
 * Reduces this [Result] to a single value by applying [success] to a [Result.Success] value
 * or [failure] to a [Result.Failure] error.
 */
inline fun <V, E, U> Result<V, E>.fold(success: (V) -> U, failure: (E) -> U): U =
    when (this) {
        is Result.Success -> success(value)
        is Result.Failure -> failure(error)
    }
