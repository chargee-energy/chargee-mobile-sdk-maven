package energy.chargee.utils.result

/**
 * Represents the outcome of an operation as either a [Success] or a [Failure].
 *
 * Use [runCatching] to produce a [Result] from a block that may throw, and [map],
 * [mapError], or [fold] to transform or consume the result.
 */
sealed interface Result<out V, out E> {
    /**
     * A successful outcome carrying [value].
     */
    data class Success<out V>(val value: V) : Result<V, Nothing>

    /**
     * A failed outcome carrying [error].
     */
    data class Failure<out E>(val error: E) : Result<Nothing, E>
}
