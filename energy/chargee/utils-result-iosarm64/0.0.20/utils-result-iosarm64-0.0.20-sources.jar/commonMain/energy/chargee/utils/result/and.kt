package energy.chargee.utils.result

/**
 * Returns [result] if this is a [Result.Success], otherwise propagates this [Result.Failure].
 *
 * Use this to sequence two results when the value of the first is not needed.
 */
infix fun <V, E, U> Result<V, E>.and(result: Result<U, E>): Result<U, E> =
    when (this) {
        is Result.Success -> result
        is Result.Failure -> Result.Failure(error)
    }
