package energy.chargee.utils.result

/**
 * Transforms the value of a [Result.Success] using [transform], leaving [Result.Failure] unchanged.
 */
inline infix fun <V, E, U> Result<V, E>.map(transform: (V) -> U): Result<U, E> =
    when (this) {
        is Result.Success -> Result.Success(transform(value))
        is Result.Failure -> Result.Failure(error)
    }
