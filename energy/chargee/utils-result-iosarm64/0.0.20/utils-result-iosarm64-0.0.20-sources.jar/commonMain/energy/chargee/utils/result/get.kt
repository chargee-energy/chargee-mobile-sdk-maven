package energy.chargee.utils.result

/**
 * Returns the success value, or `null` if this [Result] is a [Result.Failure].
 */
fun <V, E> Result<V, E>.get(): V? =
    when (this) {
        is Result.Success -> value
        is Result.Failure -> null
    }
