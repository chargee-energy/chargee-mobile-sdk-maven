package energy.chargee.utils.result

/**
 * Returns the error value, or `null` if this [Result] is a [Result.Success].
 */
fun <V, E> Result<V, E>.getError(): E? =
    when (this) {
        is Result.Success -> null
        is Result.Failure -> error
    }
