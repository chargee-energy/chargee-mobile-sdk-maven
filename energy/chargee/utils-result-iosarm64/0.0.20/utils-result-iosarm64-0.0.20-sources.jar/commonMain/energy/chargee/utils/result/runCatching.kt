package energy.chargee.utils.result

/**
 * Executes [block] and wraps the outcome in a [Result].
 *
 * Returns [Result.Success] with the block's return value on normal completion,
 * or [Result.Failure] with the caught [Throwable] if [block] throws.
 */
inline infix fun <T, V> T.runCatching(block: T.() -> V): Result<V, Throwable> =
    try {
        Result.Success(block())
    } catch (e: Throwable) {
        Result.Failure(e)
    }
