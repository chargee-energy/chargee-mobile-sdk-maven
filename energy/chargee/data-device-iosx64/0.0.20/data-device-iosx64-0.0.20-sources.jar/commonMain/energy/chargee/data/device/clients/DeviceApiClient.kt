package energy.chargee.data.device.clients

import energy.chargee.core.network.dtos.PaginatedMetaDto
import energy.chargee.core.network.dtos.PaginatedResponseDto
import energy.chargee.data.device.dtos.DeviceDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.delete
import io.ktor.client.request.get

internal class DeviceApiClient(private val httpClient: HttpClient) {
    suspend fun getDevices(addressUuid: String): PaginatedResponseDto<PaginatedMetaDto, DeviceDto> =
        httpClient.get("/v5/addresses/$addressUuid/devices").body()

    suspend fun deleteDevice(addressUuid: String, deviceUuid: String): Unit =
        httpClient.delete("/v5/addresses/$addressUuid/devices/$deviceUuid").body()
}
