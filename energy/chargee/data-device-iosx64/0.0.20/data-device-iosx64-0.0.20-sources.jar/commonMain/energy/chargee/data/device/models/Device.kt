package energy.chargee.data.device.models

import kotlinx.serialization.Serializable
import kotlin.native.ObjCName
import kotlin.time.Instant

/**
 * A device registered to an address.
 *
 * [uuid] is the unique identifier for the meter. [name] is the name of the device that
 * consists of the brand and model. [createdAt] and [updatedAt] are the server-side
 * timestamps for the record.
 */
@Serializable
@ObjCName("_Device")
data class Device(val uuid: String, val name: String, val createdAt: Instant, val updatedAt: Instant)
