package energy.chargee.data.device.repositories

import energy.chargee.core.network.models.ApiError
import energy.chargee.core.network.utils.runApi
import energy.chargee.data.device.clients.DeviceApiClient
import energy.chargee.data.device.converters.asDevice
import energy.chargee.data.device.dtos.DeviceDto
import energy.chargee.data.device.models.Device
import energy.chargee.utils.result.Result

internal class DeviceApiRepository(private val deviceApiClient: DeviceApiClient) : DeviceRepository {
    override suspend fun getDevices(addressUuid: String): Result<List<Device>, ApiError> =
        runApi { deviceApiClient.getDevices(addressUuid).results.map(DeviceDto::asDevice) }

    override suspend fun deleteDevice(addressUuid: String, deviceUuid: String): Result<Unit, ApiError> =
        runApi { deviceApiClient.deleteDevice(addressUuid, deviceUuid) }
}
