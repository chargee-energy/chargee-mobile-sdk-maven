package energy.chargee.data.device

import energy.chargee.core.di.module
import energy.chargee.data.device.clients.DeviceApiClient
import energy.chargee.data.device.repositories.DeviceApiRepository
import energy.chargee.data.device.repositories.DeviceRepository

val deviceDataModule =
    module {
        factory { DeviceApiClient(get()) }
        factory<DeviceRepository> { DeviceApiRepository(get()) }
    }
