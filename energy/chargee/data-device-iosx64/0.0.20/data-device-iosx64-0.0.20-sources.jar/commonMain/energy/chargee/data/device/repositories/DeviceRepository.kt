package energy.chargee.data.device.repositories

import energy.chargee.core.annotations.Repository
import energy.chargee.core.network.models.ApiError
import energy.chargee.data.device.models.Device
import energy.chargee.utils.result.Result
import kotlin.native.ObjCName

/**
 * Provides access to smart meters registered to an address.
 */
@Repository
@ObjCName("_DeviceRepository")
interface DeviceRepository {
    /**
     * Returns all devices registered to the address identified by [addressUuid].
     */
    suspend fun getDevices(addressUuid: String): Result<List<Device>, ApiError>

    /**
     * Deletes the device identified by [deviceUuid] from the address identified by [addressUuid].
     */
    suspend fun deleteDevice(addressUuid: String, deviceUuid: String): Result<Unit, ApiError>
}
