package energy.chargee.data.device.dtos

import kotlinx.serialization.Serializable

@Serializable
internal data class DeviceDto(val uuid: String, val name: String, val createdAt: String, val updatedAt: String)
