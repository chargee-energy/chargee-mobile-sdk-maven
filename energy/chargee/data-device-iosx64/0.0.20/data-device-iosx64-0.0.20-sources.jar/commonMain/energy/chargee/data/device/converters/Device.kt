package energy.chargee.data.device.converters

import energy.chargee.data.device.dtos.DeviceDto
import energy.chargee.data.device.models.Device
import kotlin.time.Instant

internal fun DeviceDto.asDevice() =
    Device(
        uuid,
        name,
        Instant.parse(createdAt),
        Instant.parse(updatedAt),
    )
