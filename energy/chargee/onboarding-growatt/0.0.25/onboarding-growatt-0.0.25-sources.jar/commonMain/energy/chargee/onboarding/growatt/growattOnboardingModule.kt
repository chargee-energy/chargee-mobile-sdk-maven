package energy.chargee.onboarding.growatt

import energy.chargee.core.di.module
import energy.chargee.core.di.parametersOf
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import energy.chargee.discovery.core.VerifyingDeviceDiscovery
import energy.chargee.discovery.core.logged
import energy.chargee.onboarding.core.OnboardingEngine
import energy.chargee.onboarding.growatt.GrowattConfig.BRAND
import energy.chargee.onboarding.growatt.GrowattConfig.DEFAULT_PORT
import energy.chargee.onboarding.growatt.discovery.GrowattDeviceVerifier
import energy.chargee.onboarding.localdevice.LocalDeviceOnboardingConfig

val growattOnboardingModule =
    module {
        // A port scan is the only way to find a Growatt inverter — it advertises no service — and
        // on its own it reports every host that happens to serve Modbus TCP, so the scan is only
        // half the strategy and the verifier is the other half. The scan's own connection timeout
        // is left at the registry default, which is set generously enough for a Growatt precisely
        // because this flow is what measured it.
        factory<DeviceDiscovery>(name = BRAND) {
            VerifyingDeviceDiscovery(
                get<DeviceDiscovery>(
                    name = DiscoveryConfig.PORT_SCAN_DISCOVERY_TYPE,
                    parameters = parametersOf(DEFAULT_PORT),
                ),
                GrowattDeviceVerifier(),
            ).logged(BRAND)
        }
        factoryWithParameters { parameters ->
            GrowattOnboardingSession(
                OnboardingEngine(
                    initialContext = GrowattOnboardingContext(),
                    flow =
                        createGrowattOnboardingFlow(
                            addressUuid = parameters.get(0),
                            chargeeDeviceUuid = parameters.get(1),
                            chargeeDeviceType = parameters.get(2),
                            chargeeDeviceRepository = get(),
                            chargeeDeviceDiscovery =
                                get<DeviceDiscovery>(
                                    name = DiscoveryConfig.MDNS_DISCOVERY_TYPE,
                                    parameters = parametersOf(LocalDeviceOnboardingConfig.CHARGEE_DEVICE_SERVICE_TYPE),
                                ),
                            growattDiscovery = get<DeviceDiscovery>(name = BRAND),
                            localDeviceRepository = get(),
                            inverterRepository = get(),
                        ),
                ),
            )
        }
    }
