package energy.chargee.core.network

/**
 * Provides the base URL for API requests.
 *
 * Implement this interface to point the SDK at a custom backend. The [development] and
 * [production] singletons cover the standard Chargee environments.
 */
fun interface Environment {
    companion object {
        /**
         * The Chargee development environment.
         */
        val development: Environment = Environment { "https://companion-dev.chargee.io" }

        /**
         * The Chargee production environment.
         */
        val production: Environment = Environment { "https://companion-prod.chargee.io" }
    }

    /**
     * Returns the base URL (scheme + host, no trailing slash) for all API requests.
     */
    fun getBaseUrl(): String
}
