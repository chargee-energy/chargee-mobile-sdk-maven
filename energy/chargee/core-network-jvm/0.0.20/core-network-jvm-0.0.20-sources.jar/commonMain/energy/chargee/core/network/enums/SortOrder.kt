package energy.chargee.core.network.enums

/**
 * Sort order for paginated API queries.
 */
enum class SortOrder {
    Ascending,
    Descending,
}
