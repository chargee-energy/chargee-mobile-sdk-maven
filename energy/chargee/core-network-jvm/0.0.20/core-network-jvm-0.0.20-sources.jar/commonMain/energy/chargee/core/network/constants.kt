package energy.chargee.core.network

const val DEFAULT_TIMEZONE = "Europe/Amsterdam"
