package energy.chargee.core.network

import energy.chargee.core.network.providers.TokenProvider
import io.ktor.client.HttpClient
import io.ktor.client.plugins.auth.Auth
import io.ktor.client.plugins.auth.providers.BearerTokens
import io.ktor.client.plugins.auth.providers.bearer
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * Creates an [HttpClient] that attaches a Bearer token from [tokenProvider] to every request and
 * re-fetches it when a request is rejected.
 *
 * All requests target [baseUrl] and use JSON content negotiation. The Ktor `Auth` plugin calls
 * [TokenProvider.getToken] to load the token for the `Authorization` header, caches it between
 * requests, and calls it again to obtain a fresh token whenever a response comes back `401`. There
 * is no refresh token, so the [BearerTokens] refresh slot is always `null`.
 */
internal fun createHttpClient(baseUrl: String, tokenProvider: TokenProvider) =
    HttpClient {
        expectSuccess = true
        defaultRequest {
            url(baseUrl)
            contentType(ContentType.Application.Json)
        }
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
        install(Auth) {
            bearer {
                loadTokens {
                    tokenProvider.getToken()?.let {
                        BearerTokens(it, null)
                    }
                }
                refreshTokens {
                    tokenProvider.getToken()?.let {
                        BearerTokens(it, null)
                    }
                }
            }
        }
    }
