package energy.chargee.core.network.providers

import co.touchlab.skie.configuration.annotations.SuspendInterop

/**
 * Supplies the Bearer token the network layer attaches to authenticated requests.
 *
 * Implemented by the SDK consumer. The network layer calls [getToken] to load the token for the
 * `Authorization` header and again whenever a request is rejected with `401`, so an implementation
 * that fetches the token from a remote backend can suspend until a fresh one is available.
 */
fun interface TokenProvider {
    /**
     * Returns a valid JWT for the `Authorization` header, or `null` when no token is available and
     * the request should proceed unauthenticated.
     *
     * Called on the first authenticated request and again after a `401` response; return a freshly
     * obtained token in the latter case, as the previous one was rejected.
     *
     * SKIE suspend interop is disabled for this function: it is implemented by the consumer (Kotlin
     * calls into it), a direction SKIE cannot bridge to Swift `async`. Disabling it exposes the
     * function to Swift as its native `getToken(completionHandler:)` form, which conforming Swift
     * types can implement directly, instead of a `__`-prefixed requirement behind a caller-only
     * `async` wrapper. The Kotlin `suspend` contract is unchanged for JVM/Android consumers.
     */
    @SuspendInterop.Disabled
    suspend fun getToken(): String?
}
