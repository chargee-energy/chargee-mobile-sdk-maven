package energy.chargee.core.network.models

import kotlin.native.ObjCName

/**
 * Represents an error returned by an API call.
 *
 * The hierarchy mirrors the HTTP status code ranges: [Client] covers 4xx responses,
 * [Server] covers 5xx responses, and [Unknown] covers non-HTTP failures such as network
 * errors or unexpected exceptions.
 *
 * You can check at any level of specificity in a `when` expression — put more specific
 * subtypes first so they are matched before the broader category:
 * ```kotlin
 * when (error) {
 *     is ApiError.Client.NotFound -> // 404 specifically
 *     is ApiError.Client -> // any other 4xx
 *     is ApiError.Server -> // any 5xx
 *     is ApiError.Unknown -> // non-HTTP failure
 * }
 * ```
 */
@ObjCName("_ApiError")
sealed interface ApiError {
    /** HTTP status code, or `null` for [Unknown] errors. */
    val statusCode: Int?

    /** Human-readable error message, if available. */
    val message: String?

    /** The underlying cause, if available. */
    val cause: Throwable?

    /**
     * A client error (HTTP 4xx).
     *
     * [statusCode] is always non-null for client errors. Use the specific subtypes
     * ([BadRequest], [Unauthorized], etc.) when the exact code matters, or match on
     * [Client] to handle all 4xx errors uniformly. [Other] covers any 4xx code without
     * a dedicated subtype.
     */
    sealed interface Client : ApiError {
        override val statusCode: Int

        /** HTTP 400 Bad Request. */
        data class BadRequest(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 400
        }

        /** HTTP 401 Unauthorized. */
        data class Unauthorized(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 401
        }

        /** HTTP 403 Forbidden. */
        data class Forbidden(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 403
        }

        /** HTTP 404 Not Found. */
        data class NotFound(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 404
        }

        /** HTTP 409 Conflict. */
        data class Conflict(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 409
        }

        /** HTTP 422 Unprocessable Entity. */
        data class UnprocessableEntity(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 422
        }

        /** HTTP 429 Too Many Requests. */
        data class TooManyRequests(override val message: String? = null, override val cause: Throwable? = null) : Client {
            override val statusCode = 429
        }

        /** Fallback for 4xx codes without a dedicated subtype. */
        data class Other(override val statusCode: Int, override val message: String? = null, override val cause: Throwable? = null) : Client
    }

    /**
     * A server error (HTTP 5xx).
     *
     * [statusCode] is always non-null for server errors. Use the specific subtypes
     * ([InternalServerError], [ServiceUnavailable], etc.) when the exact code matters,
     * or match on [Server] to handle all 5xx errors uniformly. [Other] covers any 5xx
     * code without a dedicated subtype.
     */
    sealed interface Server : ApiError {
        override val statusCode: Int

        /** HTTP 500 Internal Server Error. */
        data class InternalServerError(override val message: String? = null, override val cause: Throwable? = null) : Server {
            override val statusCode = 500
        }

        /** HTTP 502 Bad Gateway. */
        data class BadGateway(override val message: String? = null, override val cause: Throwable? = null) : Server {
            override val statusCode = 502
        }

        /** HTTP 503 Service Unavailable. */
        data class ServiceUnavailable(override val message: String? = null, override val cause: Throwable? = null) : Server {
            override val statusCode = 503
        }

        /** HTTP 504 Gateway Timeout. */
        data class GatewayTimeout(override val message: String? = null, override val cause: Throwable? = null) : Server {
            override val statusCode = 504
        }

        /** Fallback for 5xx codes without a dedicated subtype. */
        data class Other(override val statusCode: Int, override val message: String? = null, override val cause: Throwable? = null) : Server
    }

    /**
     * A non-HTTP error such as a network failure, timeout, or unexpected exception.
     *
     * [statusCode] is always `null` for unknown errors.
     */
    data class Unknown(override val message: String? = null, override val cause: Throwable? = null) : ApiError {
        override val statusCode: Int? = null
    }
}
