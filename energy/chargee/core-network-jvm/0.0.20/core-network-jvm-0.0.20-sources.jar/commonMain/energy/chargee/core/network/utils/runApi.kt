package energy.chargee.core.network.utils

import energy.chargee.core.network.models.ApiError
import energy.chargee.utils.result.Result
import energy.chargee.utils.result.mapError
import energy.chargee.utils.result.runCatching
import io.ktor.client.plugins.ResponseException

/**
 * Executes an API [block] and wraps the outcome in a [Result] with a typed [ApiError].
 *
 * HTTP 4xx responses are mapped to [ApiError.Client] subtypes, 5xx responses to
 * [ApiError.Server] subtypes, and any other exception to [ApiError.Unknown].
 */
inline infix fun <T, V> T.runApi(block: T.() -> V): Result<V, ApiError> =
    runCatching(block).mapError {
        when (it) {
            is ResponseException -> it.toApiError()
            else -> ApiError.Unknown(message = it.message, cause = it)
        }
    }

@PublishedApi
internal fun ResponseException.toApiError(): ApiError =
    when (val status = response.status.value) {
        400 -> ApiError.Client.BadRequest(message = message, cause = this)
        401 -> ApiError.Client.Unauthorized(message = message, cause = this)
        403 -> ApiError.Client.Forbidden(message = message, cause = this)
        404 -> ApiError.Client.NotFound(message = message, cause = this)
        409 -> ApiError.Client.Conflict(message = message, cause = this)
        422 -> ApiError.Client.UnprocessableEntity(message = message, cause = this)
        429 -> ApiError.Client.TooManyRequests(message = message, cause = this)
        in 400..499 -> ApiError.Client.Other(statusCode = status, message = message, cause = this)
        500 -> ApiError.Server.InternalServerError(message = message, cause = this)
        502 -> ApiError.Server.BadGateway(message = message, cause = this)
        503 -> ApiError.Server.ServiceUnavailable(message = message, cause = this)
        504 -> ApiError.Server.GatewayTimeout(message = message, cause = this)
        in 500..599 -> ApiError.Server.Other(statusCode = status, message = message, cause = this)
        else -> ApiError.Unknown(message = message, cause = this)
    }
