package energy.chargee.core.network.dtos

import kotlinx.serialization.Serializable

/**
 * Pagination metadata returned by list endpoints.
 *
 * [total] is the total number of items across all pages; [offset] is the index of the first
 * item in the current page.
 */
interface PaginatedMeta {
    val total: Int?
    val offset: Int?
}

/**
 * Serializable DTO implementation of [PaginatedMeta].
 */
@Serializable
data class PaginatedMetaDto(override val offset: Int? = null, override val total: Int? = null) : PaginatedMeta
