package energy.chargee.core.network

import energy.chargee.core.di.module

val networkModule =
    module {
        lazySingleton { createHttpClient(get<Environment>().getBaseUrl(), get()) }
    }
