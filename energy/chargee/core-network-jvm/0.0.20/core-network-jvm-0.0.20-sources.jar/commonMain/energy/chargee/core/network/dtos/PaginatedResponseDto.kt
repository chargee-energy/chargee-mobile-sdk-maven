package energy.chargee.core.network.dtos

import kotlinx.serialization.Serializable

/**
 * Generic DTO for paginated API responses.
 *
 * [meta] carries pagination information (total count, offset); [results] contains the items
 * for the current page.
 */
@Serializable
data class PaginatedResponseDto<Meta : PaginatedMeta, T>(val meta: Meta, val results: List<T>)
