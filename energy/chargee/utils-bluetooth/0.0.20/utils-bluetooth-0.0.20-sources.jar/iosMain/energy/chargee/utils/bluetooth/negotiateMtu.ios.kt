package energy.chargee.utils.bluetooth

import com.juul.kable.ServicesDiscoveredPeripheral

/** CoreBluetooth negotiates the MTU as part of connecting, so there is nothing to ask for. */
internal actual suspend fun ServicesDiscoveredPeripheral.negotiateMtu() = Unit
