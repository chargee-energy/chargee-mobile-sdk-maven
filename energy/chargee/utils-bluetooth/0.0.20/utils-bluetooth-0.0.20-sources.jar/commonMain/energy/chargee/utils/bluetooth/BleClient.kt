package energy.chargee.utils.bluetooth

import kotlin.time.Duration

/**
 * A Bluetooth Low Energy central that talks to one peripheral at a time over a single pair of
 * write and notify characteristics.
 *
 * The shape deliberately matches request/response hardware rather than general GATT: a device is
 * found by [scan], the link is opened with [connect], and every exchange goes through [request]
 * until [disconnect] closes it. A client owns **at most one connection** — calling [connect] again
 * replaces the previous one.
 *
 * Implementations are not thread-safe; drive one from a single coroutine.
 */
interface BleClient {
    /**
     * Scans for peripherals whose advertised name matches [nameMatching], collecting for [timeout]
     * and returning what was seen, most recently reported first seen only once each.
     *
     * The returned [BlePeripheral.id]s stay valid for [connect] until the next scan.
     *
     * @throws BleException if scanning cannot start, which on both platforms most often means
     * Bluetooth is switched off or the app has not been granted permission to use it.
     */
    suspend fun scan(nameMatching: Regex, timeout: Duration): List<BlePeripheral>

    /**
     * Opens a link to the peripheral [id], previously reported by [scan].
     *
     * @throws BleException if [id] is not from the last scan, or the peripheral refuses or drops
     * the connection.
     */
    suspend fun connect(id: String)

    /**
     * Writes [payload] to the write characteristic and reassembles the notifications that come
     * back, returning as soon as [isComplete] accepts the bytes accumulated so far.
     *
     * Reassembly is required because a reply longer than the negotiated MTU arrives as several
     * notifications. [isComplete] decides where the reply ends, since only the caller knows the
     * protocol — a length prefix, a checksum, or a terminator.
     *
     * @throws BleException if no connection is open, or [timeout] elapses before [isComplete]
     * accepts the reply.
     */
    suspend fun request(payload: ByteArray, timeout: Duration, isComplete: (ByteArray) -> Boolean): ByteArray

    /**
     * Closes the link if one is open, and does nothing otherwise. Safe to call from a cleanup path.
     */
    suspend fun disconnect()
}
