package energy.chargee.utils.bluetooth

/**
 * A Bluetooth Low Energy peripheral seen while scanning.
 *
 * [id] is opaque and only meaningful to the [BleClient] that reported it — it is a MAC address on
 * Android and a system-assigned UUID on iOS, so it identifies the peripheral for the lifetime of a
 * scan but must not be stored or shown to a user. [name] is the advertised name and [signalStrength]
 * the RSSI in dBm, useful for telling two identical devices apart by proximity.
 */
data class BlePeripheral(val id: String, val name: String, val signalStrength: Int)
