package energy.chargee.utils.bluetooth

import com.juul.kable.Peripheral
import com.juul.kable.PlatformAdvertisement
import com.juul.kable.Scanner
import com.juul.kable.WriteType
import com.juul.kable.characteristicOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.runningFold
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

/**
 * A [BleClient] backed by Kable, talking to the GATT service [serviceUuid] through its
 * [writeCharacteristicUuid] and [notifyCharacteristicUuid] characteristics.
 *
 * The MTU is negotiated on connect by [negotiateMtu], because Android does not do it on its own:
 * it stays at the default of 23 until something asks, and a write without response that exceeds
 * the resulting 20 bytes is dropped silently — no error, no reply, just a request that times out.
 * CoreBluetooth negotiates by itself, which is why this only ever bit Android.
 *
 * A reply still needs reassembling, since it arrives in notifications no larger than whatever the
 * peripheral agreed to.
 */
@OptIn(ExperimentalUuidApi::class)
class KableBleClient(serviceUuid: String, writeCharacteristicUuid: String, notifyCharacteristicUuid: String) : BleClient {
    private val writeCharacteristic = characteristicOf(Uuid.parse(serviceUuid), Uuid.parse(writeCharacteristicUuid))
    private val notifyCharacteristic = characteristicOf(Uuid.parse(serviceUuid), Uuid.parse(notifyCharacteristicUuid))

    private var scanned = emptyMap<String, PlatformAdvertisement>()
    private var connected: Peripheral? = null

    override suspend fun scan(nameMatching: Regex, timeout: Duration): List<BlePeripheral> {
        val seen = linkedMapOf<String, PlatformAdvertisement>()

        try {
            withTimeoutOrNull(timeout) {
                Scanner().advertisements.collect { advertisement ->
                    val name = advertisement.name ?: return@collect
                    if (nameMatching.containsMatchIn(name) && !seen.containsKey(advertisement.identifier.toString())) {
                        seen[advertisement.identifier.toString()] = advertisement
                    }
                }
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (throwable: Throwable) {
            // Kable reports a disabled adapter and a missing permission the same way, as a failure
            // to start scanning at all.
            throw BleException("Could not scan for Bluetooth devices", throwable)
        }

        scanned = seen
        return seen.map { (id, advertisement) -> BlePeripheral(id, advertisement.name.orEmpty(), advertisement.rssi) }
    }

    override suspend fun connect(id: String) {
        val advertisement = scanned[id] ?: throw BleException("Device $id was not reported by the last scan")

        disconnect()

        val peripheral =
            Peripheral(advertisement) {
                onServicesDiscovered { negotiateMtu() }
            }
        try {
            peripheral.connect()
        } catch (cancellation: CancellationException) {
            peripheral.close()
            throw cancellation
        } catch (throwable: Throwable) {
            peripheral.close()
            throw BleException("Could not connect to Bluetooth device $id", throwable)
        }
        connected = peripheral
    }

    override suspend fun request(payload: ByteArray, timeout: Duration, isComplete: (ByteArray) -> Boolean): ByteArray {
        val peripheral = connected ?: throw BleException("Cannot send a request before connecting")

        // The write is issued from onSubscription so the notification that answers it cannot be
        // missed: the observation is already live by the time the peripheral replies.
        val notifications =
            peripheral.observe(notifyCharacteristic) {
                peripheral.write(writeCharacteristic, payload, WriteType.WithoutResponse)
            }

        return withTimeoutOrNull(timeout) {
            notifications
                .runningFold(ByteArray(0)) { accumulated, notification -> accumulated + notification }
                .first { it.isNotEmpty() && isComplete(it) }
        } ?: throw BleException("Timed out after $timeout waiting for a reply")
    }

    override suspend fun disconnect() {
        val peripheral = connected ?: return
        connected = null

        try {
            peripheral.disconnect()
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: Throwable) {
            // Already gone. A peripheral that dropped the link first is the expected case on the
            // way out, not a failure.
        } finally {
            peripheral.close()
        }
    }
}
