package energy.chargee.utils.bluetooth

/**
 * Raised when a Bluetooth operation cannot be completed.
 *
 * Callers are expected to map this onto their own error codes rather than show it: the underlying
 * cause is usually a platform exception whose message is not meaningful to a user.
 */
class BleException(message: String, cause: Throwable? = null) : Exception(message, cause)
