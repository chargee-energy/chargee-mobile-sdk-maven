package energy.chargee.utils.bluetooth

import com.juul.kable.ServicesDiscoveredPeripheral

/**
 * The ATT MTU asked for on connect, which is the largest Android allows.
 *
 * Peripherals negotiate downwards, so this is a ceiling rather than a demand: what the link ends up
 * with is whatever the peripheral was willing to grant.
 */
internal const val PREFERRED_MTU = 517

/**
 * Asks the peripheral for a larger ATT MTU, on the platforms that do not do it themselves.
 *
 * Android connects at the default MTU of 23 and leaves it there unless something asks, which caps a
 * write without response at 20 bytes — short enough that a request frame of any substance is
 * dropped with no error and no reply. CoreBluetooth negotiates on its own, so iOS has nothing to do
 * here.
 */
internal expect suspend fun ServicesDiscoveredPeripheral.negotiateMtu()
