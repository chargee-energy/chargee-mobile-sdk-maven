package energy.chargee.discovery.udpbroadcast

import energy.chargee.core.di.module
import energy.chargee.discovery.core.DeviceDiscovery
import energy.chargee.discovery.core.DiscoveryConfig
import kotlin.time.Duration.Companion.seconds

val udpBroadcastDiscoveryModule =
    module {
        factoryWithParameters<DeviceDiscovery>(name = DiscoveryConfig.UDP_BROADCAST_DISCOVERY_TYPE) { parameters ->
            UdpBroadcastDiscovery(
                localAddressProvider = get(),
                broadcastPort = parameters.get(0),
                message = parameters.get(1),
                timeout = parameters.getOrNull(2) ?: 10.seconds,
                responseParser = parameters.getOrNull(3) ?: DefaultUdpBroadcastResponseParser,
            )
        }
    }
