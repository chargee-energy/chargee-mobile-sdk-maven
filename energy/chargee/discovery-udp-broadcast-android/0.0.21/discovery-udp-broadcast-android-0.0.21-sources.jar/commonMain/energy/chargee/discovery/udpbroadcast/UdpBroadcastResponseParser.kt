package energy.chargee.discovery.udpbroadcast

import energy.chargee.discovery.core.DiscoveredDevice

/**
 * Turns one datagram answered by a device into a [DiscoveredDevice].
 *
 * The broadcast transport is generic but the reply format never is, so callers that know their
 * device's reply grammar pass a parser alongside the broadcast payload. [payload] is the datagram
 * decoded as text and [sourceAddress] is the IP the datagram actually came from — prefer it over
 * any address the device reports about itself, since not every reply carries one.
 *
 * Returning `null` ignores the datagram, which is how a parser filters out replies from devices it
 * does not recognise.
 */
fun interface UdpBroadcastResponseParser {
    fun parse(payload: String, sourceAddress: String): DiscoveredDevice?
}

/**
 * The parser used when a caller supplies none: reports the device at the address its datagram came
 * from and reads nothing out of the payload.
 *
 * Answering at all is the only thing a reply means without knowing the device's reply grammar, so
 * a caller that wants anything more out of the payload passes its own [UdpBroadcastResponseParser].
 */
internal object DefaultUdpBroadcastResponseParser : UdpBroadcastResponseParser {
    override fun parse(payload: String, sourceAddress: String) = DiscoveredDevice(ipAddress = sourceAddress)
}
